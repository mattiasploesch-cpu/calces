package p580l.p581f0;

/* JADX INFO: renamed from: l.f0.b */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractRunnableC7961b implements Runnable {

    /* JADX INFO: renamed from: u2 */
    protected final String f50620u2;

    public AbstractRunnableC7961b(String str, Object... objArr) {
        this.f50620u2 = C7962c.m43593o(str, objArr);
    }

    /* JADX INFO: renamed from: k */
    protected abstract void mo43574k();

    @Override // java.lang.Runnable
    public final void run() {
        String name = Thread.currentThread().getName();
        Thread.currentThread().setName(this.f50620u2);
        try {
            mo43574k();
        } finally {
            Thread.currentThread().setName(name);
        }
    }
}
