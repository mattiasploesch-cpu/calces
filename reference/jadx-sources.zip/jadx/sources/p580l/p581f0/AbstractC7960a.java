package p580l.p581f0;

import java.net.Socket;
import javax.net.ssl.SSLSocket;
import p580l.C7949a;
import p580l.C7952b0;
import p580l.C7956d0;
import p580l.C8018j;
import p580l.C8019k;
import p580l.C8026r;
import p580l.p581f0.p583f.C7972c;
import p580l.p581f0.p583f.C7973d;
import p580l.p581f0.p583f.C7976g;

/* JADX INFO: renamed from: l.f0.a */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC7960a {

    /* JADX INFO: renamed from: a */
    public static AbstractC7960a f50619a;

    /* JADX INFO: renamed from: a */
    public abstract void mo43564a(C8026r.a aVar, String str);

    /* JADX INFO: renamed from: b */
    public abstract void mo43565b(C8026r.a aVar, String str, String str2);

    /* JADX INFO: renamed from: c */
    public abstract void mo43566c(C8019k c8019k, SSLSocket sSLSocket, boolean z);

    /* JADX INFO: renamed from: d */
    public abstract int mo43567d(C7952b0.a aVar);

    /* JADX INFO: renamed from: e */
    public abstract boolean mo43568e(C8018j c8018j, C7972c c7972c);

    /* JADX INFO: renamed from: f */
    public abstract Socket mo43569f(C8018j c8018j, C7949a c7949a, C7976g c7976g);

    /* JADX INFO: renamed from: g */
    public abstract boolean mo43570g(C7949a c7949a, C7949a c7949a2);

    /* JADX INFO: renamed from: h */
    public abstract C7972c mo43571h(C8018j c8018j, C7949a c7949a, C7976g c7976g, C7956d0 c7956d0);

    /* JADX INFO: renamed from: i */
    public abstract void mo43572i(C8018j c8018j, C7972c c7972c);

    /* JADX INFO: renamed from: j */
    public abstract C7973d mo43573j(C8018j c8018j);
}
