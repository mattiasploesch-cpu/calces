package p580l.p581f0.p586i;

import java.io.Closeable;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import p356f.p372c.p470v.InterfaceC7310s;
import p580l.p581f0.C7962c;
import p590m.C8037c;
import p590m.C8040f;
import p590m.C8054t;
import p590m.InterfaceC8039e;
import p590m.InterfaceC8053s;

/* JADX INFO: renamed from: l.f0.i.h */
/* JADX INFO: loaded from: classes2.dex */
final class C7996h implements Closeable {

    /* JADX INFO: renamed from: u2 */
    static final Logger f50931u2 = Logger.getLogger(C7993e.class.getName());

    /* JADX INFO: renamed from: v2 */
    private final InterfaceC8039e f50932v2;

    /* JADX INFO: renamed from: w2 */
    private final a f50933w2;

    /* JADX INFO: renamed from: x2 */
    private final boolean f50934x2;

    /* JADX INFO: renamed from: y2 */
    final C7992d.a f50935y2;

    /* JADX INFO: renamed from: l.f0.i.h$a */
    static final class a implements InterfaceC8053s {

        /* JADX INFO: renamed from: u2 */
        private final InterfaceC8039e f50936u2;

        /* JADX INFO: renamed from: v2 */
        int f50937v2;

        /* JADX INFO: renamed from: w2 */
        byte f50938w2;

        /* JADX INFO: renamed from: x2 */
        int f50939x2;

        /* JADX INFO: renamed from: y2 */
        int f50940y2;

        /* JADX INFO: renamed from: z2 */
        short f50941z2;

        a(InterfaceC8039e interfaceC8039e) {
            this.f50936u2 = interfaceC8039e;
        }

        /* JADX INFO: renamed from: c */
        private void m43864c() throws IOException {
            int i2 = this.f50939x2;
            int iM43854j = C7996h.m43854j(this.f50936u2);
            this.f50940y2 = iM43854j;
            this.f50937v2 = iM43854j;
            byte b2 = (byte) (this.f50936u2.readByte() & 255);
            this.f50938w2 = (byte) (this.f50936u2.readByte() & 255);
            Logger logger = C7996h.f50931u2;
            if (logger.isLoggable(Level.FINE)) {
                logger.fine(C7993e.m43802b(true, this.f50939x2, this.f50937v2, b2, this.f50938w2));
            }
            int i3 = this.f50936u2.readInt() & Integer.MAX_VALUE;
            this.f50939x2 = i3;
            if (b2 != 9) {
                throw C7993e.m43804d("%s != TYPE_CONTINUATION", Byte.valueOf(b2));
            }
            if (i3 != i2) {
                throw C7993e.m43804d("TYPE_CONTINUATION streamId changed", new Object[0]);
            }
        }

        @Override // p590m.InterfaceC8053s
        /* JADX INFO: renamed from: Rb */
        public long mo43613Rb(C8037c c8037c, long j2) throws IOException {
            while (true) {
                int i2 = this.f50940y2;
                if (i2 != 0) {
                    long jMo43613Rb = this.f50936u2.mo43613Rb(c8037c, Math.min(j2, i2));
                    if (jMo43613Rb == -1) {
                        return -1L;
                    }
                    this.f50940y2 = (int) (((long) this.f50940y2) - jMo43613Rb);
                    return jMo43613Rb;
                }
                this.f50936u2.mo44230M8(this.f50941z2);
                this.f50941z2 = (short) 0;
                if ((this.f50938w2 & 4) != 0) {
                    return -1L;
                }
                m43864c();
            }
        }

        @Override // p590m.InterfaceC8053s
        /* JADX INFO: renamed from: S */
        public C8054t mo43614S() {
            return this.f50936u2.mo43614S();
        }

        @Override // p590m.InterfaceC8053s, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
        }
    }

    /* JADX INFO: renamed from: l.f0.i.h$b */
    interface b {
        /* JADX INFO: renamed from: a */
        void mo43839a();

        /* JADX INFO: renamed from: b */
        void mo43840b(boolean z, C8001m c8001m);

        /* JADX INFO: renamed from: c */
        void mo43841c(boolean z, int i2, int i3, List<C7991c> list);

        /* JADX INFO: renamed from: d */
        void mo43842d(int i2, long j2);

        /* JADX INFO: renamed from: e */
        void mo43843e(boolean z, int i2, InterfaceC8039e interfaceC8039e, int i3);

        /* JADX INFO: renamed from: f */
        void mo43844f(boolean z, int i2, int i3);

        /* JADX INFO: renamed from: g */
        void mo43845g(int i2, int i3, int i4, boolean z);

        /* JADX INFO: renamed from: h */
        void mo43846h(int i2, EnumC7990b enumC7990b);

        /* JADX INFO: renamed from: i */
        void mo43847i(int i2, int i3, List<C7991c> list);

        /* JADX INFO: renamed from: j */
        void mo43848j(int i2, EnumC7990b enumC7990b, C8040f c8040f);
    }

    C7996h(InterfaceC8039e interfaceC8039e, boolean z) {
        this.f50932v2 = interfaceC8039e;
        this.f50934x2 = z;
        a aVar = new a(interfaceC8039e);
        this.f50933w2 = aVar;
        this.f50935y2 = new C7992d.a(InterfaceC7310s.f47471g, aVar);
    }

    /* JADX INFO: renamed from: c */
    static int m43849c(int i2, byte b2, short s) throws IOException {
        if ((b2 & 8) != 0) {
            i2--;
        }
        if (s <= i2) {
            return (short) (i2 - s);
        }
        throw C7993e.m43804d("PROTOCOL_ERROR padding %s > remaining length %s", Short.valueOf(s), Integer.valueOf(i2));
    }

    /* JADX INFO: renamed from: f */
    private void m43850f(b bVar, int i2, byte b2, int i3) throws IOException {
        if (i3 == 0) {
            throw C7993e.m43804d("PROTOCOL_ERROR: TYPE_DATA streamId == 0", new Object[0]);
        }
        boolean z = (b2 & 1) != 0;
        if ((b2 & 32) != 0) {
            throw C7993e.m43804d("PROTOCOL_ERROR: FLAG_COMPRESSED without SETTINGS_COMPRESS_DATA", new Object[0]);
        }
        short s = (b2 & 8) != 0 ? (short) (this.f50932v2.readByte() & 255) : (short) 0;
        bVar.mo43843e(z, i3, this.f50932v2, m43849c(i2, b2, s));
        this.f50932v2.mo44230M8(s);
    }

    /* JADX INFO: renamed from: g */
    private void m43851g(b bVar, int i2, byte b2, int i3) throws IOException {
        if (i2 < 8) {
            throw C7993e.m43804d("TYPE_GOAWAY length < 8: %s", Integer.valueOf(i2));
        }
        if (i3 != 0) {
            throw C7993e.m43804d("TYPE_GOAWAY streamId != 0", new Object[0]);
        }
        int i4 = this.f50932v2.readInt();
        int i5 = this.f50932v2.readInt();
        int i6 = i2 - 8;
        EnumC7990b enumC7990bM43773c = EnumC7990b.m43773c(i5);
        if (enumC7990bM43773c == null) {
            throw C7993e.m43804d("TYPE_GOAWAY unexpected error code: %d", Integer.valueOf(i5));
        }
        C8040f c8040fMo44233T1 = C8040f.f51335v2;
        if (i6 > 0) {
            c8040fMo44233T1 = this.f50932v2.mo44233T1(i6);
        }
        bVar.mo43848j(i4, enumC7990bM43773c, c8040fMo44233T1);
    }

    /* JADX INFO: renamed from: h */
    private List<C7991c> m43852h(int i2, short s, byte b2, int i3) throws IOException {
        a aVar = this.f50933w2;
        aVar.f50940y2 = i2;
        aVar.f50937v2 = i2;
        aVar.f50941z2 = s;
        aVar.f50938w2 = b2;
        aVar.f50939x2 = i3;
        this.f50935y2.m43791k();
        return this.f50935y2.m43789e();
    }

    /* JADX INFO: renamed from: i */
    private void m43853i(b bVar, int i2, byte b2, int i3) throws IOException {
        if (i3 == 0) {
            throw C7993e.m43804d("PROTOCOL_ERROR: TYPE_HEADERS streamId == 0", new Object[0]);
        }
        boolean z = (b2 & 1) != 0;
        short s = (b2 & 8) != 0 ? (short) (this.f50932v2.readByte() & 255) : (short) 0;
        if ((b2 & 32) != 0) {
            m43856l(bVar, i3);
            i2 -= 5;
        }
        bVar.mo43841c(z, i3, -1, m43852h(m43849c(i2, b2, s), s, b2, i3));
    }

    /* JADX INFO: renamed from: j */
    static int m43854j(InterfaceC8039e interfaceC8039e) {
        return (interfaceC8039e.readByte() & 255) | ((interfaceC8039e.readByte() & 255) << 16) | ((interfaceC8039e.readByte() & 255) << 8);
    }

    /* JADX INFO: renamed from: k */
    private void m43855k(b bVar, int i2, byte b2, int i3) throws IOException {
        if (i2 != 8) {
            throw C7993e.m43804d("TYPE_PING length != 8: %s", Integer.valueOf(i2));
        }
        if (i3 != 0) {
            throw C7993e.m43804d("TYPE_PING streamId != 0", new Object[0]);
        }
        bVar.mo43844f((b2 & 1) != 0, this.f50932v2.readInt(), this.f50932v2.readInt());
    }

    /* JADX INFO: renamed from: l */
    private void m43856l(b bVar, int i2) {
        int i3 = this.f50932v2.readInt();
        bVar.mo43845g(i2, i3 & Integer.MAX_VALUE, (this.f50932v2.readByte() & 255) + 1, (Integer.MIN_VALUE & i3) != 0);
    }

    /* JADX INFO: renamed from: o */
    private void m43857o(b bVar, int i2, byte b2, int i3) throws IOException {
        if (i2 != 5) {
            throw C7993e.m43804d("TYPE_PRIORITY length: %d != 5", Integer.valueOf(i2));
        }
        if (i3 == 0) {
            throw C7993e.m43804d("TYPE_PRIORITY streamId == 0", new Object[0]);
        }
        m43856l(bVar, i3);
    }

    /* JADX INFO: renamed from: p */
    private void m43858p(b bVar, int i2, byte b2, int i3) throws IOException {
        if (i3 == 0) {
            throw C7993e.m43804d("PROTOCOL_ERROR: TYPE_PUSH_PROMISE streamId == 0", new Object[0]);
        }
        short s = (b2 & 8) != 0 ? (short) (this.f50932v2.readByte() & 255) : (short) 0;
        bVar.mo43847i(i3, this.f50932v2.readInt() & Integer.MAX_VALUE, m43852h(m43849c(i2 - 4, b2, s), s, b2, i3));
    }

    /* JADX INFO: renamed from: q */
    private void m43859q(b bVar, int i2, byte b2, int i3) throws IOException {
        if (i2 != 4) {
            throw C7993e.m43804d("TYPE_RST_STREAM length: %d != 4", Integer.valueOf(i2));
        }
        if (i3 == 0) {
            throw C7993e.m43804d("TYPE_RST_STREAM streamId == 0", new Object[0]);
        }
        int i4 = this.f50932v2.readInt();
        EnumC7990b enumC7990bM43773c = EnumC7990b.m43773c(i4);
        if (enumC7990bM43773c == null) {
            throw C7993e.m43804d("TYPE_RST_STREAM unexpected error code: %d", Integer.valueOf(i4));
        }
        bVar.mo43846h(i3, enumC7990bM43773c);
    }

    /* JADX INFO: renamed from: s */
    private void m43860s(b bVar, int i2, byte b2, int i3) throws IOException {
        if (i3 != 0) {
            throw C7993e.m43804d("TYPE_SETTINGS streamId != 0", new Object[0]);
        }
        if ((b2 & 1) != 0) {
            if (i2 != 0) {
                throw C7993e.m43804d("FRAME_SIZE_ERROR ack frame should be empty!", new Object[0]);
            }
            bVar.mo43839a();
            return;
        }
        if (i2 % 6 != 0) {
            throw C7993e.m43804d("TYPE_SETTINGS length %% 6 != 0: %s", Integer.valueOf(i2));
        }
        C8001m c8001m = new C8001m();
        for (int i4 = 0; i4 < i2; i4 += 6) {
            int i5 = this.f50932v2.readShort() & 65535;
            int i6 = this.f50932v2.readInt();
            if (i5 == 2) {
                if (i6 != 0 && i6 != 1) {
                    throw C7993e.m43804d("PROTOCOL_ERROR SETTINGS_ENABLE_PUSH != 0 or 1", new Object[0]);
                }
            } else if (i5 == 3) {
                i5 = 4;
            } else if (i5 == 4) {
                i5 = 7;
                if (i6 < 0) {
                    throw C7993e.m43804d("PROTOCOL_ERROR SETTINGS_INITIAL_WINDOW_SIZE > 2^31 - 1", new Object[0]);
                }
            } else if (i5 == 5 && (i6 < 16384 || i6 > 16777215)) {
                throw C7993e.m43804d("PROTOCOL_ERROR SETTINGS_MAX_FRAME_SIZE: %s", Integer.valueOf(i6));
            }
            c8001m.m43925i(i5, i6);
        }
        bVar.mo43840b(false, c8001m);
    }

    /* JADX INFO: renamed from: t */
    private void m43861t(b bVar, int i2, byte b2, int i3) throws IOException {
        if (i2 != 4) {
            throw C7993e.m43804d("TYPE_WINDOW_UPDATE length !=4: %s", Integer.valueOf(i2));
        }
        long j2 = ((long) this.f50932v2.readInt()) & 2147483647L;
        if (j2 == 0) {
            throw C7993e.m43804d("windowSizeIncrement was 0", Long.valueOf(j2));
        }
        bVar.mo43842d(i3, j2);
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        this.f50932v2.close();
    }

    /* JADX INFO: renamed from: d */
    public boolean m43862d(boolean z, b bVar) throws IOException {
        try {
            this.f50932v2.mo44218Bd(9L);
            int iM43854j = m43854j(this.f50932v2);
            if (iM43854j < 0 || iM43854j > 16384) {
                throw C7993e.m43804d("FRAME_SIZE_ERROR: %s", Integer.valueOf(iM43854j));
            }
            byte b2 = (byte) (this.f50932v2.readByte() & 255);
            if (z && b2 != 4) {
                throw C7993e.m43804d("Expected a SETTINGS frame but was %s", Byte.valueOf(b2));
            }
            byte b3 = (byte) (this.f50932v2.readByte() & 255);
            int i2 = this.f50932v2.readInt() & Integer.MAX_VALUE;
            Logger logger = f50931u2;
            if (logger.isLoggable(Level.FINE)) {
                logger.fine(C7993e.m43802b(true, i2, iM43854j, b2, b3));
            }
            switch (b2) {
                case 0:
                    m43850f(bVar, iM43854j, b3, i2);
                    return true;
                case 1:
                    m43853i(bVar, iM43854j, b3, i2);
                    return true;
                case 2:
                    m43857o(bVar, iM43854j, b3, i2);
                    return true;
                case 3:
                    m43859q(bVar, iM43854j, b3, i2);
                    return true;
                case 4:
                    m43860s(bVar, iM43854j, b3, i2);
                    return true;
                case 5:
                    m43858p(bVar, iM43854j, b3, i2);
                    return true;
                case 6:
                    m43855k(bVar, iM43854j, b3, i2);
                    return true;
                case 7:
                    m43851g(bVar, iM43854j, b3, i2);
                    return true;
                case 8:
                    m43861t(bVar, iM43854j, b3, i2);
                    return true;
                default:
                    this.f50932v2.mo44230M8(iM43854j);
                    return true;
            }
        } catch (IOException unused) {
            return false;
        }
    }

    /* JADX INFO: renamed from: e */
    public void m43863e(b bVar) throws IOException {
        if (this.f50934x2) {
            if (!m43862d(true, bVar)) {
                throw C7993e.m43804d("Required SETTINGS preface not received", new Object[0]);
            }
            return;
        }
        InterfaceC8039e interfaceC8039e = this.f50932v2;
        C8040f c8040f = C7993e.f50847a;
        C8040f c8040fMo44233T1 = interfaceC8039e.mo44233T1(c8040f.size());
        Logger logger = f50931u2;
        if (logger.isLoggable(Level.FINE)) {
            logger.fine(C7962c.m43593o("<< CONNECTION %s", c8040fMo44233T1.mo44282E()));
        }
        if (!c8040f.equals(c8040fMo44233T1)) {
            throw C7993e.m43804d("Expected a connection header but was %s", c8040fMo44233T1.mo44281A1());
        }
    }
}
