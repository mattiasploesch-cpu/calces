package p580l.p581f0.p586i;

import java.io.Closeable;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.Socket;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import p148e.p257h.p274c.p275d.p278k.C6105h0;
import p356f.p372c.p470v.InterfaceC7310s;
import p580l.p581f0.AbstractRunnableC7961b;
import p580l.p581f0.C7962c;
import p580l.p581f0.p588k.C8009f;
import p590m.C8037c;
import p590m.C8040f;
import p590m.InterfaceC8038d;
import p590m.InterfaceC8039e;

/* JADX INFO: renamed from: l.f0.i.g */
/* JADX INFO: loaded from: classes2.dex */
public final class C7995g implements Closeable {

    /* JADX INFO: renamed from: u2 */
    private static final ExecutorService f50869u2 = new ThreadPoolExecutor(0, Integer.MAX_VALUE, 60, TimeUnit.SECONDS, new SynchronousQueue(), C7962c.m43576B("OkHttp Http2Connection", true));

    /* JADX INFO: renamed from: A2 */
    int f50870A2;

    /* JADX INFO: renamed from: B2 */
    boolean f50871B2;

    /* JADX INFO: renamed from: C2 */
    private final ScheduledExecutorService f50872C2;

    /* JADX INFO: renamed from: D2 */
    private final ExecutorService f50873D2;

    /* JADX INFO: renamed from: E2 */
    final InterfaceC8000l f50874E2;

    /* JADX INFO: renamed from: F2 */
    private boolean f50875F2;

    /* JADX INFO: renamed from: H2 */
    long f50877H2;

    /* JADX INFO: renamed from: J2 */
    final C8001m f50879J2;

    /* JADX INFO: renamed from: K2 */
    boolean f50880K2;

    /* JADX INFO: renamed from: L2 */
    final Socket f50881L2;

    /* JADX INFO: renamed from: M2 */
    final C7998j f50882M2;

    /* JADX INFO: renamed from: N2 */
    final j f50883N2;

    /* JADX INFO: renamed from: O2 */
    final Set<Integer> f50884O2;

    /* JADX INFO: renamed from: v2 */
    final boolean f50885v2;

    /* JADX INFO: renamed from: w2 */
    final h f50886w2;

    /* JADX INFO: renamed from: y2 */
    final String f50888y2;

    /* JADX INFO: renamed from: z2 */
    int f50889z2;

    /* JADX INFO: renamed from: x2 */
    final Map<Integer, C7997i> f50887x2 = new LinkedHashMap();

    /* JADX INFO: renamed from: G2 */
    long f50876G2 = 0;

    /* JADX INFO: renamed from: I2 */
    C8001m f50878I2 = new C8001m();

    /* JADX INFO: renamed from: l.f0.i.g$a */
    class a extends AbstractRunnableC7961b {

        /* JADX INFO: renamed from: v2 */
        final /* synthetic */ int f50890v2;

        /* JADX INFO: renamed from: w2 */
        final /* synthetic */ EnumC7990b f50891w2;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        a(String str, Object[] objArr, int i2, EnumC7990b enumC7990b) {
            super(str, objArr);
            this.f50890v2 = i2;
            this.f50891w2 = enumC7990b;
        }

        @Override // p580l.p581f0.AbstractRunnableC7961b
        /* JADX INFO: renamed from: k */
        public void mo43574k() {
            try {
                C7995g.this.m43816C(this.f50890v2, this.f50891w2);
            } catch (IOException unused) {
                C7995g.this.m43812i();
            }
        }
    }

    /* JADX INFO: renamed from: l.f0.i.g$b */
    class b extends AbstractRunnableC7961b {

        /* JADX INFO: renamed from: v2 */
        final /* synthetic */ int f50893v2;

        /* JADX INFO: renamed from: w2 */
        final /* synthetic */ long f50894w2;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        b(String str, Object[] objArr, int i2, long j2) {
            super(str, objArr);
            this.f50893v2 = i2;
            this.f50894w2 = j2;
        }

        @Override // p580l.p581f0.AbstractRunnableC7961b
        /* JADX INFO: renamed from: k */
        public void mo43574k() {
            try {
                C7995g.this.f50882M2.m43906s(this.f50893v2, this.f50894w2);
            } catch (IOException unused) {
                C7995g.this.m43812i();
            }
        }
    }

    /* JADX INFO: renamed from: l.f0.i.g$c */
    class c extends AbstractRunnableC7961b {

        /* JADX INFO: renamed from: v2 */
        final /* synthetic */ int f50896v2;

        /* JADX INFO: renamed from: w2 */
        final /* synthetic */ List f50897w2;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        c(String str, Object[] objArr, int i2, List list) {
            super(str, objArr);
            this.f50896v2 = i2;
            this.f50897w2 = list;
        }

        @Override // p580l.p581f0.AbstractRunnableC7961b
        /* JADX INFO: renamed from: k */
        public void mo43574k() {
            if (C7995g.this.f50874E2.mo43913a(this.f50896v2, this.f50897w2)) {
                try {
                    C7995g.this.f50882M2.m43903o(this.f50896v2, EnumC7990b.CANCEL);
                    synchronized (C7995g.this) {
                        try {
                            C7995g.this.f50884O2.remove(Integer.valueOf(this.f50896v2));
                        } catch (Throwable th) {
                            throw th;
                        }
                    }
                } catch (IOException unused) {
                }
            }
        }
    }

    /* JADX INFO: renamed from: l.f0.i.g$d */
    class d extends AbstractRunnableC7961b {

        /* JADX INFO: renamed from: v2 */
        final /* synthetic */ int f50899v2;

        /* JADX INFO: renamed from: w2 */
        final /* synthetic */ List f50900w2;

        /* JADX INFO: renamed from: x2 */
        final /* synthetic */ boolean f50901x2;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        d(String str, Object[] objArr, int i2, List list, boolean z) {
            super(str, objArr);
            this.f50899v2 = i2;
            this.f50900w2 = list;
            this.f50901x2 = z;
        }

        @Override // p580l.p581f0.AbstractRunnableC7961b
        /* JADX INFO: renamed from: k */
        public void mo43574k() {
            boolean zMo43914b = C7995g.this.f50874E2.mo43914b(this.f50899v2, this.f50900w2, this.f50901x2);
            if (zMo43914b) {
                try {
                    C7995g.this.f50882M2.m43903o(this.f50899v2, EnumC7990b.CANCEL);
                } catch (IOException unused) {
                    return;
                }
            }
            if (zMo43914b || this.f50901x2) {
                synchronized (C7995g.this) {
                    try {
                        C7995g.this.f50884O2.remove(Integer.valueOf(this.f50899v2));
                    } catch (Throwable th) {
                        throw th;
                    }
                }
            }
        }
    }

    /* JADX INFO: renamed from: l.f0.i.g$e */
    class e extends AbstractRunnableC7961b {

        /* JADX INFO: renamed from: v2 */
        final /* synthetic */ int f50903v2;

        /* JADX INFO: renamed from: w2 */
        final /* synthetic */ C8037c f50904w2;

        /* JADX INFO: renamed from: x2 */
        final /* synthetic */ int f50905x2;

        /* JADX INFO: renamed from: y2 */
        final /* synthetic */ boolean f50906y2;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        e(String str, Object[] objArr, int i2, C8037c c8037c, int i3, boolean z) {
            super(str, objArr);
            this.f50903v2 = i2;
            this.f50904w2 = c8037c;
            this.f50905x2 = i3;
            this.f50906y2 = z;
        }

        @Override // p580l.p581f0.AbstractRunnableC7961b
        /* JADX INFO: renamed from: k */
        public void mo43574k() {
            try {
                boolean zMo43916d = C7995g.this.f50874E2.mo43916d(this.f50903v2, this.f50904w2, this.f50905x2, this.f50906y2);
                if (zMo43916d) {
                    C7995g.this.f50882M2.m43903o(this.f50903v2, EnumC7990b.CANCEL);
                }
                if (zMo43916d || this.f50906y2) {
                    synchronized (C7995g.this) {
                        C7995g.this.f50884O2.remove(Integer.valueOf(this.f50903v2));
                    }
                }
            } catch (IOException unused) {
            }
        }
    }

    /* JADX INFO: renamed from: l.f0.i.g$f */
    class f extends AbstractRunnableC7961b {

        /* JADX INFO: renamed from: v2 */
        final /* synthetic */ int f50908v2;

        /* JADX INFO: renamed from: w2 */
        final /* synthetic */ EnumC7990b f50909w2;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        f(String str, Object[] objArr, int i2, EnumC7990b enumC7990b) {
            super(str, objArr);
            this.f50908v2 = i2;
            this.f50909w2 = enumC7990b;
        }

        @Override // p580l.p581f0.AbstractRunnableC7961b
        /* JADX INFO: renamed from: k */
        public void mo43574k() {
            C7995g.this.f50874E2.mo43915c(this.f50908v2, this.f50909w2);
            synchronized (C7995g.this) {
                C7995g.this.f50884O2.remove(Integer.valueOf(this.f50908v2));
            }
        }
    }

    /* JADX INFO: renamed from: l.f0.i.g$g */
    public static class g {

        /* JADX INFO: renamed from: a */
        Socket f50911a;

        /* JADX INFO: renamed from: b */
        String f50912b;

        /* JADX INFO: renamed from: c */
        InterfaceC8039e f50913c;

        /* JADX INFO: renamed from: d */
        InterfaceC8038d f50914d;

        /* JADX INFO: renamed from: e */
        h f50915e = h.f50919a;

        /* JADX INFO: renamed from: f */
        InterfaceC8000l f50916f = InterfaceC8000l.f50979a;

        /* JADX INFO: renamed from: g */
        boolean f50917g;

        /* JADX INFO: renamed from: h */
        int f50918h;

        public g(boolean z) {
            this.f50917g = z;
        }

        /* JADX INFO: renamed from: a */
        public C7995g m43834a() {
            return new C7995g(this);
        }

        /* JADX INFO: renamed from: b */
        public g m43835b(h hVar) {
            this.f50915e = hVar;
            return this;
        }

        /* JADX INFO: renamed from: c */
        public g m43836c(int i2) {
            this.f50918h = i2;
            return this;
        }

        /* JADX INFO: renamed from: d */
        public g m43837d(Socket socket, String str, InterfaceC8039e interfaceC8039e, InterfaceC8038d interfaceC8038d) {
            this.f50911a = socket;
            this.f50912b = str;
            this.f50913c = interfaceC8039e;
            this.f50914d = interfaceC8038d;
            return this;
        }
    }

    /* JADX INFO: renamed from: l.f0.i.g$h */
    /* JADX INFO: loaded from: classes.dex */
    public static abstract class h {

        /* JADX INFO: renamed from: a */
        public static final h f50919a = new a();

        /* JADX INFO: renamed from: l.f0.i.g$h$a */
        /* JADX INFO: loaded from: classes2.dex */
        final class a extends h {
            a() {
            }

            @Override // p580l.p581f0.p586i.C7995g.h
            /* JADX INFO: renamed from: b */
            public void mo43664b(C7997i c7997i) {
                c7997i.m43869d(EnumC7990b.REFUSED_STREAM);
            }
        }

        /* JADX INFO: renamed from: a */
        public void mo43663a(C7995g c7995g) {
        }

        /* JADX INFO: renamed from: b */
        public abstract void mo43664b(C7997i c7997i);
    }

    /* JADX INFO: renamed from: l.f0.i.g$i */
    final class i extends AbstractRunnableC7961b {

        /* JADX INFO: renamed from: v2 */
        final boolean f50920v2;

        /* JADX INFO: renamed from: w2 */
        final int f50921w2;

        /* JADX INFO: renamed from: x2 */
        final int f50922x2;

        i(boolean z, int i2, int i3) {
            super("OkHttp %s ping %08x%08x", C7995g.this.f50888y2, Integer.valueOf(i2), Integer.valueOf(i3));
            this.f50920v2 = z;
            this.f50921w2 = i2;
            this.f50922x2 = i3;
        }

        @Override // p580l.p581f0.AbstractRunnableC7961b
        /* JADX INFO: renamed from: k */
        public void mo43574k() {
            C7995g.this.m43815B(this.f50920v2, this.f50921w2, this.f50922x2);
        }
    }

    /* JADX INFO: renamed from: l.f0.i.g$j */
    class j extends AbstractRunnableC7961b implements C7996h.b {

        /* JADX INFO: renamed from: v2 */
        final C7996h f50924v2;

        /* JADX INFO: renamed from: l.f0.i.g$j$a */
        class a extends AbstractRunnableC7961b {

            /* JADX INFO: renamed from: v2 */
            final /* synthetic */ C7997i f50926v2;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            a(String str, Object[] objArr, C7997i c7997i) {
                super(str, objArr);
                this.f50926v2 = c7997i;
            }

            @Override // p580l.p581f0.AbstractRunnableC7961b
            /* JADX INFO: renamed from: k */
            public void mo43574k() {
                try {
                    C7995g.this.f50886w2.mo43664b(this.f50926v2);
                } catch (IOException e2) {
                    C8009f.m43969i().mo43946p(4, "Http2Connection.Listener failure for " + C7995g.this.f50888y2, e2);
                    try {
                        this.f50926v2.m43869d(EnumC7990b.PROTOCOL_ERROR);
                    } catch (IOException unused) {
                    }
                }
            }
        }

        /* JADX INFO: renamed from: l.f0.i.g$j$b */
        class b extends AbstractRunnableC7961b {
            b(String str, Object... objArr) {
                super(str, objArr);
            }

            @Override // p580l.p581f0.AbstractRunnableC7961b
            /* JADX INFO: renamed from: k */
            public void mo43574k() {
                C7995g c7995g = C7995g.this;
                c7995g.f50886w2.mo43663a(c7995g);
            }
        }

        /* JADX INFO: renamed from: l.f0.i.g$j$c */
        class c extends AbstractRunnableC7961b {

            /* JADX INFO: renamed from: v2 */
            final /* synthetic */ C8001m f50929v2;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            c(String str, Object[] objArr, C8001m c8001m) {
                super(str, objArr);
                this.f50929v2 = c8001m;
            }

            @Override // p580l.p581f0.AbstractRunnableC7961b
            /* JADX INFO: renamed from: k */
            public void mo43574k() {
                try {
                    C7995g.this.f50882M2.m43893c(this.f50929v2);
                } catch (IOException unused) {
                    C7995g.this.m43812i();
                }
            }
        }

        j(C7996h c7996h) {
            super("OkHttp %s", C7995g.this.f50888y2);
            this.f50924v2 = c7996h;
        }

        /* JADX INFO: renamed from: l */
        private void m43838l(C8001m c8001m) {
            try {
                C7995g.this.f50872C2.execute(new c("OkHttp %s ACK Settings", new Object[]{C7995g.this.f50888y2}, c8001m));
            } catch (RejectedExecutionException unused) {
            }
        }

        @Override // p580l.p581f0.p586i.C7996h.b
        /* JADX INFO: renamed from: a */
        public void mo43839a() {
        }

        @Override // p580l.p581f0.p586i.C7996h.b
        /* JADX INFO: renamed from: b */
        public void mo43840b(boolean z, C8001m c8001m) {
            C7997i[] c7997iArr;
            long j2;
            int i2;
            synchronized (C7995g.this) {
                int iM43920d = C7995g.this.f50879J2.m43920d();
                if (z) {
                    C7995g.this.f50879J2.m43917a();
                }
                C7995g.this.f50879J2.m43924h(c8001m);
                m43838l(c8001m);
                int iM43920d2 = C7995g.this.f50879J2.m43920d();
                c7997iArr = null;
                if (iM43920d2 == -1 || iM43920d2 == iM43920d) {
                    j2 = 0;
                } else {
                    j2 = iM43920d2 - iM43920d;
                    C7995g c7995g = C7995g.this;
                    if (!c7995g.f50880K2) {
                        c7995g.m43819g(j2);
                        C7995g.this.f50880K2 = true;
                    }
                    if (!C7995g.this.f50887x2.isEmpty()) {
                        c7997iArr = (C7997i[]) C7995g.this.f50887x2.values().toArray(new C7997i[C7995g.this.f50887x2.size()]);
                    }
                }
                C7995g.f50869u2.execute(new b("OkHttp %s settings", C7995g.this.f50888y2));
            }
            if (c7997iArr == null || j2 == 0) {
                return;
            }
            for (C7997i c7997i : c7997iArr) {
                synchronized (c7997i) {
                    c7997i.m43866a(j2);
                }
            }
        }

        @Override // p580l.p581f0.p586i.C7996h.b
        /* JADX INFO: renamed from: c */
        public void mo43841c(boolean z, int i2, int i3, List<C7991c> list) {
            if (C7995g.this.m43829v(i2)) {
                C7995g.this.m43826s(i2, list, z);
                return;
            }
            synchronized (C7995g.this) {
                C7997i c7997iM43821j = C7995g.this.m43821j(i2);
                if (c7997iM43821j != null) {
                    c7997iM43821j.m43879o(list);
                    if (z) {
                        c7997iM43821j.m43878n();
                        return;
                    }
                    return;
                }
                C7995g c7995g = C7995g.this;
                if (c7995g.f50871B2) {
                    return;
                }
                if (i2 <= c7995g.f50889z2) {
                    return;
                }
                if (i2 % 2 == c7995g.f50870A2 % 2) {
                    return;
                }
                C7997i c7997i = new C7997i(i2, C7995g.this, false, z, list);
                C7995g c7995g2 = C7995g.this;
                c7995g2.f50889z2 = i2;
                c7995g2.f50887x2.put(Integer.valueOf(i2), c7997i);
                C7995g.f50869u2.execute(new a("OkHttp %s stream %d", new Object[]{C7995g.this.f50888y2, Integer.valueOf(i2)}, c7997i));
            }
        }

        @Override // p580l.p581f0.p586i.C7996h.b
        /* JADX INFO: renamed from: d */
        public void mo43842d(int i2, long j2) {
            C7995g c7995g = C7995g.this;
            if (i2 == 0) {
                synchronized (c7995g) {
                    C7995g c7995g2 = C7995g.this;
                    c7995g2.f50877H2 += j2;
                    c7995g2.notifyAll();
                }
                return;
            }
            C7997i c7997iM43821j = c7995g.m43821j(i2);
            if (c7997iM43821j != null) {
                synchronized (c7997iM43821j) {
                    c7997iM43821j.m43866a(j2);
                }
            }
        }

        @Override // p580l.p581f0.p586i.C7996h.b
        /* JADX INFO: renamed from: e */
        public void mo43843e(boolean z, int i2, InterfaceC8039e interfaceC8039e, int i3) throws IOException {
            if (C7995g.this.m43829v(i2)) {
                C7995g.this.m43825q(i2, interfaceC8039e, i3, z);
                return;
            }
            C7997i c7997iM43821j = C7995g.this.m43821j(i2);
            if (c7997iM43821j == null) {
                C7995g.this.m43817D(i2, EnumC7990b.PROTOCOL_ERROR);
                interfaceC8039e.mo44230M8(i3);
            } else {
                c7997iM43821j.m43877m(interfaceC8039e, i3);
                if (z) {
                    c7997iM43821j.m43878n();
                }
            }
        }

        @Override // p580l.p581f0.p586i.C7996h.b
        /* JADX INFO: renamed from: f */
        public void mo43844f(boolean z, int i2, int i3) {
            if (!z) {
                try {
                    C7995g.this.f50872C2.execute(C7995g.this.new i(true, i2, i3));
                } catch (RejectedExecutionException unused) {
                }
            } else {
                synchronized (C7995g.this) {
                    C7995g.this.f50875F2 = false;
                    C7995g.this.notifyAll();
                }
            }
        }

        @Override // p580l.p581f0.p586i.C7996h.b
        /* JADX INFO: renamed from: g */
        public void mo43845g(int i2, int i3, int i4, boolean z) {
        }

        @Override // p580l.p581f0.p586i.C7996h.b
        /* JADX INFO: renamed from: h */
        public void mo43846h(int i2, EnumC7990b enumC7990b) {
            if (C7995g.this.m43829v(i2)) {
                C7995g.this.m43828u(i2, enumC7990b);
                return;
            }
            C7997i c7997iM43830w = C7995g.this.m43830w(i2);
            if (c7997iM43830w != null) {
                c7997iM43830w.m43880p(enumC7990b);
            }
        }

        @Override // p580l.p581f0.p586i.C7996h.b
        /* JADX INFO: renamed from: i */
        public void mo43847i(int i2, int i3, List<C7991c> list) {
            C7995g.this.m43827t(i3, list);
        }

        @Override // p580l.p581f0.p586i.C7996h.b
        /* JADX INFO: renamed from: j */
        public void mo43848j(int i2, EnumC7990b enumC7990b, C8040f c8040f) {
            C7997i[] c7997iArr;
            c8040f.size();
            synchronized (C7995g.this) {
                c7997iArr = (C7997i[]) C7995g.this.f50887x2.values().toArray(new C7997i[C7995g.this.f50887x2.size()]);
                C7995g.this.f50871B2 = true;
            }
            for (C7997i c7997i : c7997iArr) {
                if (c7997i.m43871g() > i2 && c7997i.m43874j()) {
                    c7997i.m43880p(EnumC7990b.REFUSED_STREAM);
                    C7995g.this.m43830w(c7997i.m43871g());
                }
            }
        }

        @Override // p580l.p581f0.AbstractRunnableC7961b
        /* JADX INFO: renamed from: k */
        protected void mo43574k() throws Throwable {
            EnumC7990b enumC7990b;
            EnumC7990b enumC7990b2 = EnumC7990b.INTERNAL_ERROR;
            try {
                try {
                    this.f50924v2.m43863e(this);
                    while (this.f50924v2.m43862d(false, this)) {
                    }
                    enumC7990b = EnumC7990b.NO_ERROR;
                    try {
                        try {
                            C7995g.this.m43820h(enumC7990b, EnumC7990b.CANCEL);
                        } catch (IOException unused) {
                            EnumC7990b enumC7990b3 = EnumC7990b.PROTOCOL_ERROR;
                            C7995g.this.m43820h(enumC7990b3, enumC7990b3);
                        }
                    } catch (Throwable th) {
                        th = th;
                        try {
                            C7995g.this.m43820h(enumC7990b, enumC7990b2);
                        } catch (IOException unused2) {
                        }
                        C7962c.m43582d(this.f50924v2);
                        throw th;
                    }
                } catch (IOException unused3) {
                }
            } catch (IOException unused4) {
                enumC7990b = enumC7990b2;
            } catch (Throwable th2) {
                th = th2;
                enumC7990b = enumC7990b2;
                C7995g.this.m43820h(enumC7990b, enumC7990b2);
                C7962c.m43582d(this.f50924v2);
                throw th;
            }
            C7962c.m43582d(this.f50924v2);
        }
    }

    C7995g(g gVar) {
        C8001m c8001m = new C8001m();
        this.f50879J2 = c8001m;
        this.f50880K2 = false;
        this.f50884O2 = new LinkedHashSet();
        this.f50874E2 = gVar.f50916f;
        boolean z = gVar.f50917g;
        this.f50885v2 = z;
        this.f50886w2 = gVar.f50915e;
        int i2 = z ? 1 : 2;
        this.f50870A2 = i2;
        if (z) {
            this.f50870A2 = i2 + 2;
        }
        if (z) {
            this.f50878I2.m43925i(7, C6105h0.f39062g);
        }
        String str = gVar.f50912b;
        this.f50888y2 = str;
        ScheduledThreadPoolExecutor scheduledThreadPoolExecutor = new ScheduledThreadPoolExecutor(1, C7962c.m43576B(C7962c.m43593o("OkHttp %s Writer", str), false));
        this.f50872C2 = scheduledThreadPoolExecutor;
        if (gVar.f50918h != 0) {
            i iVar = new i(false, 0, 0);
            int i3 = gVar.f50918h;
            scheduledThreadPoolExecutor.scheduleAtFixedRate(iVar, i3, i3, TimeUnit.MILLISECONDS);
        }
        this.f50873D2 = new ThreadPoolExecutor(0, 1, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue(), C7962c.m43576B(C7962c.m43593o("OkHttp %s Push Observer", str), true));
        c8001m.m43925i(7, 65535);
        c8001m.m43925i(5, InterfaceC7310s.f47472h);
        this.f50877H2 = c8001m.m43920d();
        this.f50881L2 = gVar.f50911a;
        this.f50882M2 = new C7998j(gVar.f50914d, z);
        this.f50883N2 = new j(new C7996h(gVar.f50913c, z));
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: i */
    public void m43812i() {
        try {
            EnumC7990b enumC7990b = EnumC7990b.PROTOCOL_ERROR;
            m43820h(enumC7990b, enumC7990b);
        } catch (IOException unused) {
        }
    }

    /* JADX INFO: renamed from: o */
    private C7997i m43813o(int i2, List<C7991c> list, boolean z) {
        int i3;
        C7997i c7997i;
        boolean z2;
        boolean z3 = !z;
        synchronized (this.f50882M2) {
            synchronized (this) {
                if (this.f50870A2 > 1073741823) {
                    m43831x(EnumC7990b.REFUSED_STREAM);
                }
                if (this.f50871B2) {
                    throw new C7989a();
                }
                i3 = this.f50870A2;
                this.f50870A2 = i3 + 2;
                c7997i = new C7997i(i3, this, z3, false, list);
                z2 = !z || this.f50877H2 == 0 || c7997i.f50943b == 0;
                if (c7997i.m43875k()) {
                    this.f50887x2.put(Integer.valueOf(i3), c7997i);
                }
            }
            if (i2 == 0) {
                this.f50882M2.m43905q(z3, i3, i2, list);
            } else {
                if (this.f50885v2) {
                    throw new IllegalArgumentException("client streams shouldn't have associated stream IDs");
                }
                this.f50882M2.m43902l(i2, i3, list);
            }
        }
        if (z2) {
            this.f50882M2.flush();
        }
        return c7997i;
    }

    /* JADX INFO: renamed from: A */
    public void m43814A(int i2, boolean z, C8037c c8037c, long j2) {
        long j3;
        int iMin;
        long j4;
        if (j2 == 0) {
            this.f50882M2.m43895e(z, i2, c8037c, 0);
            return;
        }
        while (j2 > 0) {
            synchronized (this) {
                while (true) {
                    try {
                        j3 = this.f50877H2;
                        if (j3 <= 0) {
                            if (!this.f50887x2.containsKey(Integer.valueOf(i2))) {
                                throw new IOException("stream closed");
                            }
                            wait();
                        }
                    } catch (InterruptedException unused) {
                        throw new InterruptedIOException();
                    }
                }
                iMin = Math.min((int) Math.min(j2, j3), this.f50882M2.m43900j());
                j4 = iMin;
                this.f50877H2 -= j4;
            }
            j2 -= j4;
            this.f50882M2.m43895e(z && j2 == 0, i2, c8037c, iMin);
        }
    }

    /* JADX INFO: renamed from: B */
    void m43815B(boolean z, int i2, int i3) {
        boolean z2;
        if (!z) {
            synchronized (this) {
                z2 = this.f50875F2;
                this.f50875F2 = true;
            }
            if (z2) {
                m43812i();
                return;
            }
        }
        try {
            this.f50882M2.m43901k(z, i2, i3);
        } catch (IOException unused) {
            m43812i();
        }
    }

    /* JADX INFO: renamed from: C */
    void m43816C(int i2, EnumC7990b enumC7990b) {
        this.f50882M2.m43903o(i2, enumC7990b);
    }

    /* JADX INFO: renamed from: D */
    void m43817D(int i2, EnumC7990b enumC7990b) {
        try {
            this.f50872C2.execute(new a("OkHttp %s stream %d", new Object[]{this.f50888y2, Integer.valueOf(i2)}, i2, enumC7990b));
        } catch (RejectedExecutionException unused) {
        }
    }

    /* JADX INFO: renamed from: E */
    void m43818E(int i2, long j2) {
        try {
            this.f50872C2.execute(new b("OkHttp Window Update %s stream %d", new Object[]{this.f50888y2, Integer.valueOf(i2)}, i2, j2));
        } catch (RejectedExecutionException unused) {
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() throws IOException {
        m43820h(EnumC7990b.NO_ERROR, EnumC7990b.CANCEL);
    }

    public void flush() {
        this.f50882M2.flush();
    }

    /* JADX INFO: renamed from: g */
    void m43819g(long j2) {
        this.f50877H2 += j2;
        if (j2 > 0) {
            notifyAll();
        }
    }

    /* JADX INFO: renamed from: h */
    void m43820h(EnumC7990b enumC7990b, EnumC7990b enumC7990b2) throws IOException {
        C7997i[] c7997iArr = null;
        try {
            m43831x(enumC7990b);
            e = null;
        } catch (IOException e2) {
            e = e2;
        }
        synchronized (this) {
            if (!this.f50887x2.isEmpty()) {
                c7997iArr = (C7997i[]) this.f50887x2.values().toArray(new C7997i[this.f50887x2.size()]);
                this.f50887x2.clear();
            }
        }
        if (c7997iArr != null) {
            for (C7997i c7997i : c7997iArr) {
                try {
                    c7997i.m43869d(enumC7990b2);
                } catch (IOException e3) {
                    if (e != null) {
                        e = e3;
                    }
                }
            }
        }
        try {
            this.f50882M2.close();
        } catch (IOException e4) {
            if (e == null) {
                e = e4;
            }
        }
        try {
            this.f50881L2.close();
        } catch (IOException e5) {
            e = e5;
        }
        this.f50872C2.shutdown();
        this.f50873D2.shutdown();
        if (e != null) {
            throw e;
        }
    }

    /* JADX INFO: renamed from: j */
    synchronized C7997i m43821j(int i2) {
        return this.f50887x2.get(Integer.valueOf(i2));
    }

    /* JADX INFO: renamed from: k */
    public synchronized boolean m43822k() {
        return this.f50871B2;
    }

    /* JADX INFO: renamed from: l */
    public synchronized int m43823l() {
        return this.f50879J2.m43921e(Integer.MAX_VALUE);
    }

    /* JADX INFO: renamed from: p */
    public C7997i m43824p(List<C7991c> list, boolean z) {
        return m43813o(0, list, z);
    }

    /* JADX INFO: renamed from: q */
    void m43825q(int i2, InterfaceC8039e interfaceC8039e, int i3, boolean z) throws IOException {
        C8037c c8037c = new C8037c();
        long j2 = i3;
        interfaceC8039e.mo44218Bd(j2);
        interfaceC8039e.mo43613Rb(c8037c, j2);
        if (c8037c.m44265u() == j2) {
            this.f50873D2.execute(new e("OkHttp %s Push Data[%s]", new Object[]{this.f50888y2, Integer.valueOf(i2)}, i2, c8037c, i3, z));
            return;
        }
        throw new IOException(c8037c.m44265u() + " != " + i3);
    }

    /* JADX INFO: renamed from: s */
    void m43826s(int i2, List<C7991c> list, boolean z) {
        try {
            this.f50873D2.execute(new d("OkHttp %s Push Headers[%s]", new Object[]{this.f50888y2, Integer.valueOf(i2)}, i2, list, z));
        } catch (RejectedExecutionException unused) {
        }
    }

    /* JADX INFO: renamed from: t */
    void m43827t(int i2, List<C7991c> list) {
        synchronized (this) {
            if (this.f50884O2.contains(Integer.valueOf(i2))) {
                m43817D(i2, EnumC7990b.PROTOCOL_ERROR);
                return;
            }
            this.f50884O2.add(Integer.valueOf(i2));
            try {
                this.f50873D2.execute(new c("OkHttp %s Push Request[%s]", new Object[]{this.f50888y2, Integer.valueOf(i2)}, i2, list));
            } catch (RejectedExecutionException unused) {
            }
        }
    }

    /* JADX INFO: renamed from: u */
    void m43828u(int i2, EnumC7990b enumC7990b) {
        this.f50873D2.execute(new f("OkHttp %s Push Reset[%s]", new Object[]{this.f50888y2, Integer.valueOf(i2)}, i2, enumC7990b));
    }

    /* JADX INFO: renamed from: v */
    boolean m43829v(int i2) {
        return i2 != 0 && (i2 & 1) == 0;
    }

    /* JADX INFO: renamed from: w */
    synchronized C7997i m43830w(int i2) {
        C7997i c7997iRemove;
        c7997iRemove = this.f50887x2.remove(Integer.valueOf(i2));
        notifyAll();
        return c7997iRemove;
    }

    /* JADX INFO: renamed from: x */
    public void m43831x(EnumC7990b enumC7990b) {
        synchronized (this.f50882M2) {
            synchronized (this) {
                if (this.f50871B2) {
                    return;
                }
                this.f50871B2 = true;
                this.f50882M2.m43898h(this.f50889z2, enumC7990b, C7962c.f50621a);
            }
        }
    }

    /* JADX INFO: renamed from: y */
    public void m43832y() {
        m43833z(true);
    }

    /* JADX INFO: renamed from: z */
    void m43833z(boolean z) {
        if (z) {
            this.f50882M2.m43894d();
            this.f50882M2.m43904p(this.f50878I2);
            int iM43920d = this.f50878I2.m43920d();
            if (iM43920d != 65535) {
                this.f50882M2.m43906s(0, iM43920d - 65535);
            }
        }
        new Thread(this.f50883N2).start();
    }
}
