package p580l.p581f0.p586i;

import java.util.List;
import p590m.InterfaceC8039e;

/* JADX INFO: renamed from: l.f0.i.l */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC8000l {

    /* JADX INFO: renamed from: a */
    public static final InterfaceC8000l f50979a = new a();

    /* JADX INFO: renamed from: l.f0.i.l$a */
    final class a implements InterfaceC8000l {
        a() {
        }

        @Override // p580l.p581f0.p586i.InterfaceC8000l
        /* JADX INFO: renamed from: a */
        public boolean mo43913a(int i2, List<C7991c> list) {
            return true;
        }

        @Override // p580l.p581f0.p586i.InterfaceC8000l
        /* JADX INFO: renamed from: b */
        public boolean mo43914b(int i2, List<C7991c> list, boolean z) {
            return true;
        }

        @Override // p580l.p581f0.p586i.InterfaceC8000l
        /* JADX INFO: renamed from: c */
        public void mo43915c(int i2, EnumC7990b enumC7990b) {
        }

        @Override // p580l.p581f0.p586i.InterfaceC8000l
        /* JADX INFO: renamed from: d */
        public boolean mo43916d(int i2, InterfaceC8039e interfaceC8039e, int i3, boolean z) {
            interfaceC8039e.mo44230M8(i3);
            return true;
        }
    }

    /* JADX INFO: renamed from: a */
    boolean mo43913a(int i2, List<C7991c> list);

    /* JADX INFO: renamed from: b */
    boolean mo43914b(int i2, List<C7991c> list, boolean z);

    /* JADX INFO: renamed from: c */
    void mo43915c(int i2, EnumC7990b enumC7990b);

    /* JADX INFO: renamed from: d */
    boolean mo43916d(int i2, InterfaceC8039e interfaceC8039e, int i3, boolean z);
}
