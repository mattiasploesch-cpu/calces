package p580l.p581f0.p586i;

/* JADX INFO: renamed from: l.f0.i.b */
/* JADX INFO: loaded from: classes2.dex */
public enum EnumC7990b {
    NO_ERROR(0),
    PROTOCOL_ERROR(1),
    INTERNAL_ERROR(2),
    FLOW_CONTROL_ERROR(3),
    REFUSED_STREAM(7),
    CANCEL(8),
    COMPRESSION_ERROR(9),
    CONNECT_ERROR(10),
    ENHANCE_YOUR_CALM(11),
    INADEQUATE_SECURITY(12),
    HTTP_1_1_REQUIRED(13);


    /* JADX INFO: renamed from: G2 */
    public final int f50817G2;

    EnumC7990b(int i2) {
        this.f50817G2 = i2;
    }

    /* JADX INFO: renamed from: c */
    public static EnumC7990b m43773c(int i2) {
        for (EnumC7990b enumC7990b : values()) {
            if (enumC7990b.f50817G2 == i2) {
                return enumC7990b;
            }
        }
        return null;
    }
}
