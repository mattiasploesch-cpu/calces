package p580l.p581f0.p586i;

import p580l.p581f0.C7962c;
import p590m.C8040f;

/* JADX INFO: renamed from: l.f0.i.c */
/* JADX INFO: loaded from: classes2.dex */
public final class C7991c {

    /* JADX INFO: renamed from: a */
    public static final C8040f f50818a = C8040f.m44278r(":");

    /* JADX INFO: renamed from: b */
    public static final C8040f f50819b = C8040f.m44278r(":status");

    /* JADX INFO: renamed from: c */
    public static final C8040f f50820c = C8040f.m44278r(":method");

    /* JADX INFO: renamed from: d */
    public static final C8040f f50821d = C8040f.m44278r(":path");

    /* JADX INFO: renamed from: e */
    public static final C8040f f50822e = C8040f.m44278r(":scheme");

    /* JADX INFO: renamed from: f */
    public static final C8040f f50823f = C8040f.m44278r(":authority");

    /* JADX INFO: renamed from: g */
    public final C8040f f50824g;

    /* JADX INFO: renamed from: h */
    public final C8040f f50825h;

    /* JADX INFO: renamed from: i */
    final int f50826i;

    public C7991c(String str, String str2) {
        this(C8040f.m44278r(str), C8040f.m44278r(str2));
    }

    public C7991c(C8040f c8040f, String str) {
        this(c8040f, C8040f.m44278r(str));
    }

    public C7991c(C8040f c8040f, C8040f c8040f2) {
        this.f50824g = c8040f;
        this.f50825h = c8040f2;
        this.f50826i = c8040f.size() + 32 + c8040f2.size();
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C7991c)) {
            return false;
        }
        C7991c c7991c = (C7991c) obj;
        return this.f50824g.equals(c7991c.f50824g) && this.f50825h.equals(c7991c.f50825h);
    }

    public int hashCode() {
        return ((527 + this.f50824g.hashCode()) * 31) + this.f50825h.hashCode();
    }

    public String toString() {
        return C7962c.m43593o("%s: %s", this.f50824g.mo44281A1(), this.f50825h.mo44281A1());
    }
}
