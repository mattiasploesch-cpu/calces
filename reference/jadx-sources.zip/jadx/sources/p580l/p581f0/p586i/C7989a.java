package p580l.p581f0.p586i;

import java.io.IOException;

/* JADX INFO: renamed from: l.f0.i.a */
/* JADX INFO: loaded from: classes2.dex */
public final class C7989a extends IOException {
}
