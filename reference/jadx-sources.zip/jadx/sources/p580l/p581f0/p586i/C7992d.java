package p580l.p581f0.p586i;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import p148e.p150d.p157n.C5098c;
import p356f.p372c.p470v.InterfaceC7310s;
import p580l.p581f0.C7962c;
import p590m.C8037c;
import p590m.C8040f;
import p590m.C8046l;
import p590m.InterfaceC8039e;
import p590m.InterfaceC8053s;

/* JADX INFO: renamed from: l.f0.i.d */
/* JADX INFO: loaded from: classes2.dex */
final class C7992d {

    /* JADX INFO: renamed from: a */
    static final C7991c[] f50827a;

    /* JADX INFO: renamed from: b */
    static final Map<C8040f, Integer> f50828b;

    /* JADX INFO: renamed from: l.f0.i.d$a */
    static final class a {

        /* JADX INFO: renamed from: a */
        private final List<C7991c> f50829a;

        /* JADX INFO: renamed from: b */
        private final InterfaceC8039e f50830b;

        /* JADX INFO: renamed from: c */
        private final int f50831c;

        /* JADX INFO: renamed from: d */
        private int f50832d;

        /* JADX INFO: renamed from: e */
        C7991c[] f50833e;

        /* JADX INFO: renamed from: f */
        int f50834f;

        /* JADX INFO: renamed from: g */
        int f50835g;

        /* JADX INFO: renamed from: h */
        int f50836h;

        a(int i2, int i3, InterfaceC8053s interfaceC8053s) {
            this.f50829a = new ArrayList();
            C7991c[] c7991cArr = new C7991c[8];
            this.f50833e = c7991cArr;
            this.f50834f = c7991cArr.length - 1;
            this.f50835g = 0;
            this.f50836h = 0;
            this.f50831c = i2;
            this.f50832d = i3;
            this.f50830b = C8046l.m44313d(interfaceC8053s);
        }

        a(int i2, InterfaceC8053s interfaceC8053s) {
            this(i2, i2, interfaceC8053s);
        }

        /* JADX INFO: renamed from: a */
        private void m43776a() {
            int i2 = this.f50832d;
            int i3 = this.f50836h;
            if (i2 < i3) {
                if (i2 == 0) {
                    m43777b();
                } else {
                    m43779d(i3 - i2);
                }
            }
        }

        /* JADX INFO: renamed from: b */
        private void m43777b() {
            Arrays.fill(this.f50833e, (Object) null);
            this.f50834f = this.f50833e.length - 1;
            this.f50835g = 0;
            this.f50836h = 0;
        }

        /* JADX INFO: renamed from: c */
        private int m43778c(int i2) {
            return this.f50834f + 1 + i2;
        }

        /* JADX INFO: renamed from: d */
        private int m43779d(int i2) {
            int i3;
            int i4 = 0;
            if (i2 > 0) {
                int length = this.f50833e.length;
                while (true) {
                    length--;
                    i3 = this.f50834f;
                    if (length < i3 || i2 <= 0) {
                        break;
                    }
                    C7991c[] c7991cArr = this.f50833e;
                    i2 -= c7991cArr[length].f50826i;
                    this.f50836h -= c7991cArr[length].f50826i;
                    this.f50835g--;
                    i4++;
                }
                C7991c[] c7991cArr2 = this.f50833e;
                System.arraycopy(c7991cArr2, i3 + 1, c7991cArr2, i3 + 1 + i4, this.f50835g);
                this.f50834f += i4;
            }
            return i4;
        }

        /* JADX INFO: renamed from: f */
        private C8040f m43780f(int i2) throws IOException {
            C7991c c7991c;
            if (!m43782h(i2)) {
                int iM43778c = m43778c(i2 - C7992d.f50827a.length);
                if (iM43778c >= 0) {
                    C7991c[] c7991cArr = this.f50833e;
                    if (iM43778c < c7991cArr.length) {
                        c7991c = c7991cArr[iM43778c];
                    }
                }
                throw new IOException("Header index too large " + (i2 + 1));
            }
            c7991c = C7992d.f50827a[i2];
            return c7991c.f50824g;
        }

        /* JADX INFO: renamed from: g */
        private void m43781g(int i2, C7991c c7991c) {
            this.f50829a.add(c7991c);
            int i3 = c7991c.f50826i;
            if (i2 != -1) {
                i3 -= this.f50833e[m43778c(i2)].f50826i;
            }
            int i4 = this.f50832d;
            if (i3 > i4) {
                m43777b();
                return;
            }
            int iM43779d = m43779d((this.f50836h + i3) - i4);
            if (i2 == -1) {
                int i5 = this.f50835g + 1;
                C7991c[] c7991cArr = this.f50833e;
                if (i5 > c7991cArr.length) {
                    C7991c[] c7991cArr2 = new C7991c[c7991cArr.length * 2];
                    System.arraycopy(c7991cArr, 0, c7991cArr2, c7991cArr.length, c7991cArr.length);
                    this.f50834f = this.f50833e.length - 1;
                    this.f50833e = c7991cArr2;
                }
                int i6 = this.f50834f;
                this.f50834f = i6 - 1;
                this.f50833e[i6] = c7991c;
                this.f50835g++;
            } else {
                this.f50833e[i2 + m43778c(i2) + iM43779d] = c7991c;
            }
            this.f50836h += i3;
        }

        /* JADX INFO: renamed from: h */
        private boolean m43782h(int i2) {
            return i2 >= 0 && i2 <= C7992d.f50827a.length - 1;
        }

        /* JADX INFO: renamed from: i */
        private int m43783i() {
            return this.f50830b.readByte() & 255;
        }

        /* JADX INFO: renamed from: l */
        private void m43784l(int i2) throws IOException {
            if (m43782h(i2)) {
                this.f50829a.add(C7992d.f50827a[i2]);
                return;
            }
            int iM43778c = m43778c(i2 - C7992d.f50827a.length);
            if (iM43778c >= 0) {
                C7991c[] c7991cArr = this.f50833e;
                if (iM43778c < c7991cArr.length) {
                    this.f50829a.add(c7991cArr[iM43778c]);
                    return;
                }
            }
            throw new IOException("Header index too large " + (i2 + 1));
        }

        /* JADX INFO: renamed from: n */
        private void m43785n(int i2) {
            m43781g(-1, new C7991c(m43780f(i2), m43790j()));
        }

        /* JADX INFO: renamed from: o */
        private void m43786o() {
            m43781g(-1, new C7991c(C7992d.m43774a(m43790j()), m43790j()));
        }

        /* JADX INFO: renamed from: p */
        private void m43787p(int i2) throws IOException {
            this.f50829a.add(new C7991c(m43780f(i2), m43790j()));
        }

        /* JADX INFO: renamed from: q */
        private void m43788q() throws IOException {
            this.f50829a.add(new C7991c(C7992d.m43774a(m43790j()), m43790j()));
        }

        /* JADX INFO: renamed from: e */
        public List<C7991c> m43789e() {
            ArrayList arrayList = new ArrayList(this.f50829a);
            this.f50829a.clear();
            return arrayList;
        }

        /* JADX INFO: renamed from: j */
        C8040f m43790j() {
            int iM43783i = m43783i();
            boolean z = (iM43783i & 128) == 128;
            int iM43792m = m43792m(iM43783i, 127);
            return z ? C8040f.m44272Y(C7999k.m43909f().m43910c(this.f50830b.mo44221Ca(iM43792m))) : this.f50830b.mo44233T1(iM43792m);
        }

        /* JADX INFO: renamed from: k */
        void m43791k() throws IOException {
            while (!this.f50830b.mo44237a4()) {
                int i2 = this.f50830b.readByte() & 255;
                if (i2 == 128) {
                    throw new IOException("index == 0");
                }
                if ((i2 & 128) == 128) {
                    m43784l(m43792m(i2, 127) - 1);
                } else if (i2 == 64) {
                    m43786o();
                } else if ((i2 & 64) == 64) {
                    m43785n(m43792m(i2, 63) - 1);
                } else if ((i2 & 32) == 32) {
                    int iM43792m = m43792m(i2, 31);
                    this.f50832d = iM43792m;
                    if (iM43792m < 0 || iM43792m > this.f50831c) {
                        throw new IOException("Invalid dynamic table size update " + this.f50832d);
                    }
                    m43776a();
                } else if (i2 == 16 || i2 == 0) {
                    m43788q();
                } else {
                    m43787p(m43792m(i2, 15) - 1);
                }
            }
        }

        /* JADX INFO: renamed from: m */
        int m43792m(int i2, int i3) {
            int i4 = i2 & i3;
            if (i4 < i3) {
                return i4;
            }
            int i5 = 0;
            while (true) {
                int iM43783i = m43783i();
                if ((iM43783i & 128) == 0) {
                    return i3 + (iM43783i << i5);
                }
                i3 += (iM43783i & 127) << i5;
                i5 += 7;
            }
        }
    }

    /* JADX INFO: renamed from: l.f0.i.d$b */
    static final class b {

        /* JADX INFO: renamed from: a */
        private final C8037c f50837a;

        /* JADX INFO: renamed from: b */
        private final boolean f50838b;

        /* JADX INFO: renamed from: c */
        private int f50839c;

        /* JADX INFO: renamed from: d */
        private boolean f50840d;

        /* JADX INFO: renamed from: e */
        int f50841e;

        /* JADX INFO: renamed from: f */
        int f50842f;

        /* JADX INFO: renamed from: g */
        C7991c[] f50843g;

        /* JADX INFO: renamed from: h */
        int f50844h;

        /* JADX INFO: renamed from: i */
        int f50845i;

        /* JADX INFO: renamed from: j */
        int f50846j;

        b(int i2, boolean z, C8037c c8037c) {
            this.f50839c = Integer.MAX_VALUE;
            C7991c[] c7991cArr = new C7991c[8];
            this.f50843g = c7991cArr;
            this.f50844h = c7991cArr.length - 1;
            this.f50845i = 0;
            this.f50846j = 0;
            this.f50841e = i2;
            this.f50842f = i2;
            this.f50838b = z;
            this.f50837a = c8037c;
        }

        b(C8037c c8037c) {
            this(InterfaceC7310s.f47471g, true, c8037c);
        }

        /* JADX INFO: renamed from: a */
        private void m43793a() {
            int i2 = this.f50842f;
            int i3 = this.f50846j;
            if (i2 < i3) {
                if (i2 == 0) {
                    m43794b();
                } else {
                    m43795c(i3 - i2);
                }
            }
        }

        /* JADX INFO: renamed from: b */
        private void m43794b() {
            Arrays.fill(this.f50843g, (Object) null);
            this.f50844h = this.f50843g.length - 1;
            this.f50845i = 0;
            this.f50846j = 0;
        }

        /* JADX INFO: renamed from: c */
        private int m43795c(int i2) {
            int i3;
            int i4 = 0;
            if (i2 > 0) {
                int length = this.f50843g.length;
                while (true) {
                    length--;
                    i3 = this.f50844h;
                    if (length < i3 || i2 <= 0) {
                        break;
                    }
                    C7991c[] c7991cArr = this.f50843g;
                    i2 -= c7991cArr[length].f50826i;
                    this.f50846j -= c7991cArr[length].f50826i;
                    this.f50845i--;
                    i4++;
                }
                C7991c[] c7991cArr2 = this.f50843g;
                System.arraycopy(c7991cArr2, i3 + 1, c7991cArr2, i3 + 1 + i4, this.f50845i);
                C7991c[] c7991cArr3 = this.f50843g;
                int i5 = this.f50844h;
                Arrays.fill(c7991cArr3, i5 + 1, i5 + 1 + i4, (Object) null);
                this.f50844h += i4;
            }
            return i4;
        }

        /* JADX INFO: renamed from: d */
        private void m43796d(C7991c c7991c) {
            int i2 = c7991c.f50826i;
            int i3 = this.f50842f;
            if (i2 > i3) {
                m43794b();
                return;
            }
            m43795c((this.f50846j + i2) - i3);
            int i4 = this.f50845i + 1;
            C7991c[] c7991cArr = this.f50843g;
            if (i4 > c7991cArr.length) {
                C7991c[] c7991cArr2 = new C7991c[c7991cArr.length * 2];
                System.arraycopy(c7991cArr, 0, c7991cArr2, c7991cArr.length, c7991cArr.length);
                this.f50844h = this.f50843g.length - 1;
                this.f50843g = c7991cArr2;
            }
            int i5 = this.f50844h;
            this.f50844h = i5 - 1;
            this.f50843g[i5] = c7991c;
            this.f50845i++;
            this.f50846j += i2;
        }

        /* JADX INFO: renamed from: e */
        void m43797e(int i2) {
            this.f50841e = i2;
            int iMin = Math.min(i2, InterfaceC7310s.f47472h);
            int i3 = this.f50842f;
            if (i3 == iMin) {
                return;
            }
            if (iMin < i3) {
                this.f50839c = Math.min(this.f50839c, iMin);
            }
            this.f50840d = true;
            this.f50842f = iMin;
            m43793a();
        }

        /* JADX INFO: renamed from: f */
        void m43798f(C8040f c8040f) {
            int size;
            int i2;
            if (!this.f50838b || C7999k.m43909f().m43912e(c8040f) >= c8040f.size()) {
                size = c8040f.size();
                i2 = 0;
            } else {
                C8037c c8037c = new C8037c();
                C7999k.m43909f().m43911d(c8040f, c8037c);
                c8040f = c8037c.m44251o();
                size = c8040f.size();
                i2 = 128;
            }
            m43800h(size, 127, i2);
            this.f50837a.mo44253ob(c8040f);
        }

        /* JADX WARN: Code duplicated, block: B:22:0x006a  */
        /* JADX INFO: renamed from: g */
        void m43799g(List<C7991c> list) {
            int length;
            int length2;
            if (this.f50840d) {
                int i2 = this.f50839c;
                if (i2 < this.f50842f) {
                    m43800h(i2, 31, 32);
                }
                this.f50840d = false;
                this.f50839c = Integer.MAX_VALUE;
                m43800h(this.f50842f, 31, 32);
            }
            int size = list.size();
            for (int i3 = 0; i3 < size; i3++) {
                C7991c c7991c = list.get(i3);
                C8040f c8040fMo44284P0 = c7991c.f50824g.mo44284P0();
                C8040f c8040f = c7991c.f50825h;
                Integer num = C7992d.f50828b.get(c8040fMo44284P0);
                if (num != null) {
                    length = num.intValue() + 1;
                    if (length <= 1 || length >= 8) {
                        length2 = length;
                        length = -1;
                    } else {
                        C7991c[] c7991cArr = C7992d.f50827a;
                        if (C7962c.m43592n(c7991cArr[length - 1].f50825h, c8040f)) {
                            length2 = length;
                        } else if (C7962c.m43592n(c7991cArr[length].f50825h, c8040f)) {
                            length2 = length;
                            length++;
                        } else {
                            length2 = length;
                            length = -1;
                        }
                    }
                } else {
                    length = -1;
                    length2 = -1;
                }
                if (length == -1) {
                    int length3 = this.f50843g.length;
                    for (int i4 = this.f50844h + 1; i4 < length3; i4++) {
                        if (C7962c.m43592n(this.f50843g[i4].f50824g, c8040fMo44284P0)) {
                            if (C7962c.m43592n(this.f50843g[i4].f50825h, c8040f)) {
                                length = C7992d.f50827a.length + (i4 - this.f50844h);
                                break;
                            } else if (length2 == -1) {
                                length2 = (i4 - this.f50844h) + C7992d.f50827a.length;
                            }
                        }
                    }
                }
                if (length != -1) {
                    m43800h(length, 127, 128);
                } else {
                    if (length2 == -1) {
                        this.f50837a.mo44241e4(64);
                        m43798f(c8040fMo44284P0);
                    } else if (!c8040fMo44284P0.m44280A0(C7991c.f50818a) || C7991c.f50823f.equals(c8040fMo44284P0)) {
                        m43800h(length2, 63, 64);
                    } else {
                        m43800h(length2, 15, 0);
                        m43798f(c8040f);
                    }
                    m43798f(c8040f);
                    m43796d(c7991c);
                }
            }
        }

        /* JADX INFO: renamed from: h */
        void m43800h(int i2, int i3, int i4) {
            int i5;
            C8037c c8037c;
            if (i2 < i3) {
                c8037c = this.f50837a;
                i5 = i2 | i4;
            } else {
                this.f50837a.mo44241e4(i4 | i3);
                i5 = i2 - i3;
                while (i5 >= 128) {
                    this.f50837a.mo44241e4(128 | (i5 & 127));
                    i5 >>>= 7;
                }
                c8037c = this.f50837a;
            }
            c8037c.mo44241e4(i5);
        }
    }

    static {
        C8040f c8040f = C7991c.f50820c;
        C8040f c8040f2 = C7991c.f50821d;
        C8040f c8040f3 = C7991c.f50822e;
        C8040f c8040f4 = C7991c.f50819b;
        f50827a = new C7991c[]{new C7991c(C7991c.f50823f, ""), new C7991c(c8040f, "GET"), new C7991c(c8040f, "POST"), new C7991c(c8040f2, "/"), new C7991c(c8040f2, "/index.html"), new C7991c(c8040f3, "http"), new C7991c(c8040f3, "https"), new C7991c(c8040f4, "200"), new C7991c(c8040f4, "204"), new C7991c(c8040f4, "206"), new C7991c(c8040f4, "304"), new C7991c(c8040f4, "400"), new C7991c(c8040f4, "404"), new C7991c(c8040f4, "500"), new C7991c("accept-charset", ""), new C7991c("accept-encoding", "gzip, deflate"), new C7991c("accept-language", ""), new C7991c("accept-ranges", ""), new C7991c("accept", ""), new C7991c("access-control-allow-origin", ""), new C7991c("age", ""), new C7991c("allow", ""), new C7991c("authorization", ""), new C7991c("cache-control", ""), new C7991c("content-disposition", ""), new C7991c("content-encoding", ""), new C7991c("content-language", ""), new C7991c("content-length", ""), new C7991c("content-location", ""), new C7991c("content-range", ""), new C7991c("content-type", ""), new C7991c("cookie", ""), new C7991c("date", ""), new C7991c("etag", ""), new C7991c("expect", ""), new C7991c("expires", ""), new C7991c("from", ""), new C7991c("host", ""), new C7991c("if-match", ""), new C7991c("if-modified-since", ""), new C7991c("if-none-match", ""), new C7991c("if-range", ""), new C7991c("if-unmodified-since", ""), new C7991c("last-modified", ""), new C7991c(C5098c.f29957x2, ""), new C7991c("location", ""), new C7991c("max-forwards", ""), new C7991c("proxy-authenticate", ""), new C7991c("proxy-authorization", ""), new C7991c("range", ""), new C7991c("referer", ""), new C7991c("refresh", ""), new C7991c("retry-after", ""), new C7991c("server", ""), new C7991c("set-cookie", ""), new C7991c("strict-transport-security", ""), new C7991c("transfer-encoding", ""), new C7991c("user-agent", ""), new C7991c("vary", ""), new C7991c("via", ""), new C7991c("www-authenticate", "")};
        f50828b = m43775b();
    }

    /* JADX INFO: renamed from: a */
    static C8040f m43774a(C8040f c8040f) throws IOException {
        int size = c8040f.size();
        for (int i2 = 0; i2 < size; i2++) {
            byte bMo44279A = c8040f.mo44279A(i2);
            if (bMo44279A >= 65 && bMo44279A <= 90) {
                throw new IOException("PROTOCOL_ERROR response malformed: mixed case name: " + c8040f.mo44281A1());
            }
        }
        return c8040f;
    }

    /* JADX INFO: renamed from: b */
    private static Map<C8040f, Integer> m43775b() {
        LinkedHashMap linkedHashMap = new LinkedHashMap(f50827a.length);
        int i2 = 0;
        while (true) {
            C7991c[] c7991cArr = f50827a;
            if (i2 >= c7991cArr.length) {
                return Collections.unmodifiableMap(linkedHashMap);
            }
            if (!linkedHashMap.containsKey(c7991cArr[i2].f50824g)) {
                linkedHashMap.put(c7991cArr[i2].f50824g, Integer.valueOf(i2));
            }
            i2++;
        }
    }
}
