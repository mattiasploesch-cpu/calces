package p580l.p581f0.p586i;

import java.io.IOException;

/* JADX INFO: renamed from: l.f0.i.n */
/* JADX INFO: loaded from: classes2.dex */
public final class C8002n extends IOException {

    /* JADX INFO: renamed from: u2 */
    public final EnumC7990b f50982u2;

    public C8002n(EnumC7990b enumC7990b) {
        super("stream was reset: " + enumC7990b);
        this.f50982u2 = enumC7990b;
    }
}
