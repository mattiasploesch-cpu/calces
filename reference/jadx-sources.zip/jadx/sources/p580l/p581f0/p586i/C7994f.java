package p580l.p581f0.p586i;

import java.io.IOException;
import java.net.ProtocolException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import p580l.AbstractC7954c0;
import p580l.C7952b0;
import p580l.C8026r;
import p580l.C8031w;
import p580l.C8034z;
import p580l.EnumC8032x;
import p580l.InterfaceC8028t;
import p580l.p581f0.AbstractC7960a;
import p580l.p581f0.C7962c;
import p580l.p581f0.p583f.C7976g;
import p580l.p581f0.p584g.C7981e;
import p580l.p581f0.p584g.C7984h;
import p580l.p581f0.p584g.C7985i;
import p580l.p581f0.p584g.C7987k;
import p580l.p581f0.p584g.InterfaceC7979c;
import p590m.AbstractC8042h;
import p590m.C8037c;
import p590m.C8040f;
import p590m.C8046l;
import p590m.C8054t;
import p590m.InterfaceC8052r;
import p590m.InterfaceC8053s;

/* JADX INFO: renamed from: l.f0.i.f */
/* JADX INFO: loaded from: classes2.dex */
public final class C7994f implements InterfaceC7979c {

    /* JADX INFO: renamed from: a */
    private static final C8040f f50851a;

    /* JADX INFO: renamed from: b */
    private static final C8040f f50852b;

    /* JADX INFO: renamed from: c */
    private static final C8040f f50853c;

    /* JADX INFO: renamed from: d */
    private static final C8040f f50854d;

    /* JADX INFO: renamed from: e */
    private static final C8040f f50855e;

    /* JADX INFO: renamed from: f */
    private static final C8040f f50856f;

    /* JADX INFO: renamed from: g */
    private static final C8040f f50857g;

    /* JADX INFO: renamed from: h */
    private static final C8040f f50858h;

    /* JADX INFO: renamed from: i */
    private static final List<C8040f> f50859i;

    /* JADX INFO: renamed from: j */
    private static final List<C8040f> f50860j;

    /* JADX INFO: renamed from: k */
    private final C8031w f50861k;

    /* JADX INFO: renamed from: l */
    private final InterfaceC8028t.a f50862l;

    /* JADX INFO: renamed from: m */
    final C7976g f50863m;

    /* JADX INFO: renamed from: n */
    private final C7995g f50864n;

    /* JADX INFO: renamed from: o */
    private C7997i f50865o;

    /* JADX INFO: renamed from: l.f0.i.f$a */
    class a extends AbstractC8042h {

        /* JADX INFO: renamed from: v2 */
        boolean f50866v2;

        /* JADX INFO: renamed from: w2 */
        long f50867w2;

        a(InterfaceC8053s interfaceC8053s) {
            super(interfaceC8053s);
            this.f50866v2 = false;
            this.f50867w2 = 0L;
        }

        /* JADX INFO: renamed from: d */
        private void m43807d(IOException iOException) {
            if (this.f50866v2) {
                return;
            }
            this.f50866v2 = true;
            C7994f c7994f = C7994f.this;
            c7994f.f50863m.m43707q(false, c7994f, this.f50867w2, iOException);
        }

        @Override // p590m.AbstractC8042h, p590m.InterfaceC8053s
        /* JADX INFO: renamed from: Rb */
        public long mo43613Rb(C8037c c8037c, long j2) throws IOException {
            try {
                long jMo43613Rb = m44294c().mo43613Rb(c8037c, j2);
                if (jMo43613Rb > 0) {
                    this.f50867w2 += jMo43613Rb;
                }
                return jMo43613Rb;
            } catch (IOException e2) {
                m43807d(e2);
                throw e2;
            }
        }

        @Override // p590m.AbstractC8042h, p590m.InterfaceC8053s, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            super.close();
            m43807d(null);
        }
    }

    static {
        C8040f c8040fM44278r = C8040f.m44278r("connection");
        f50851a = c8040fM44278r;
        C8040f c8040fM44278r2 = C8040f.m44278r("host");
        f50852b = c8040fM44278r2;
        C8040f c8040fM44278r3 = C8040f.m44278r("keep-alive");
        f50853c = c8040fM44278r3;
        C8040f c8040fM44278r4 = C8040f.m44278r("proxy-connection");
        f50854d = c8040fM44278r4;
        C8040f c8040fM44278r5 = C8040f.m44278r("transfer-encoding");
        f50855e = c8040fM44278r5;
        C8040f c8040fM44278r6 = C8040f.m44278r("te");
        f50856f = c8040fM44278r6;
        C8040f c8040fM44278r7 = C8040f.m44278r("encoding");
        f50857g = c8040fM44278r7;
        C8040f c8040fM44278r8 = C8040f.m44278r("upgrade");
        f50858h = c8040fM44278r8;
        f50859i = C7962c.m43596r(c8040fM44278r, c8040fM44278r2, c8040fM44278r3, c8040fM44278r4, c8040fM44278r6, c8040fM44278r5, c8040fM44278r7, c8040fM44278r8, C7991c.f50820c, C7991c.f50821d, C7991c.f50822e, C7991c.f50823f);
        f50860j = C7962c.m43596r(c8040fM44278r, c8040fM44278r2, c8040fM44278r3, c8040fM44278r4, c8040fM44278r6, c8040fM44278r5, c8040fM44278r7, c8040fM44278r8);
    }

    public C7994f(C8031w c8031w, InterfaceC8028t.a aVar, C7976g c7976g, C7995g c7995g) {
        this.f50861k = c8031w;
        this.f50862l = aVar;
        this.f50863m = c7976g;
        this.f50864n = c7995g;
    }

    /* JADX INFO: renamed from: g */
    public static List<C7991c> m43805g(C8034z c8034z) {
        C8026r c8026rM44187e = c8034z.m44187e();
        ArrayList arrayList = new ArrayList(c8026rM44187e.m44067f() + 4);
        arrayList.add(new C7991c(C7991c.f50820c, c8034z.m44189g()));
        arrayList.add(new C7991c(C7991c.f50821d, C7985i.m43751c(c8034z.m44191i())));
        String strM44185c = c8034z.m44185c("Host");
        if (strM44185c != null) {
            arrayList.add(new C7991c(C7991c.f50823f, strM44185c));
        }
        arrayList.add(new C7991c(C7991c.f50822e, c8034z.m44191i().m44094C()));
        int iM44067f = c8026rM44187e.m44067f();
        for (int i2 = 0; i2 < iM44067f; i2++) {
            C8040f c8040fM44278r = C8040f.m44278r(c8026rM44187e.m44065c(i2).toLowerCase(Locale.US));
            if (!f50859i.contains(c8040fM44278r)) {
                arrayList.add(new C7991c(c8040fM44278r, c8026rM44187e.m44068g(i2)));
            }
        }
        return arrayList;
    }

    /* JADX INFO: renamed from: h */
    public static C7952b0.a m43806h(List<C7991c> list) throws ProtocolException {
        C8026r.a aVar = new C8026r.a();
        int size = list.size();
        C7987k c7987kM43760a = null;
        for (int i2 = 0; i2 < size; i2++) {
            C7991c c7991c = list.get(i2);
            if (c7991c != null) {
                C8040f c8040f = c7991c.f50824g;
                String strMo44281A1 = c7991c.f50825h.mo44281A1();
                if (c8040f.equals(C7991c.f50819b)) {
                    c7987kM43760a = C7987k.m43760a("HTTP/1.1 " + strMo44281A1);
                } else if (!f50860j.contains(c8040f)) {
                    AbstractC7960a.f50619a.mo43565b(aVar, c8040f.mo44281A1(), strMo44281A1);
                }
            } else if (c7987kM43760a != null && c7987kM43760a.f50778b == 100) {
                aVar = new C8026r.a();
                c7987kM43760a = null;
            }
        }
        if (c7987kM43760a != null) {
            return new C7952b0.a().m43505m(EnumC8032x.HTTP_2).m43499g(c7987kM43760a.f50778b).m43502j(c7987kM43760a.f50779c).m43501i(aVar.m44074d());
        }
        throw new ProtocolException("Expected ':status' header not present");
    }

    @Override // p580l.p581f0.p584g.InterfaceC7979c
    /* JADX INFO: renamed from: a */
    public void mo43709a() {
        this.f50865o.m43872h().close();
    }

    @Override // p580l.p581f0.p584g.InterfaceC7979c
    /* JADX INFO: renamed from: b */
    public void mo43710b(C8034z c8034z) {
        if (this.f50865o != null) {
            return;
        }
        C7997i c7997iM43824p = this.f50864n.m43824p(m43805g(c8034z), c8034z.m44183a() != null);
        this.f50865o = c7997iM43824p;
        C8054t c8054tM43876l = c7997iM43824p.m43876l();
        long jMo43738a = this.f50862l.mo43738a();
        TimeUnit timeUnit = TimeUnit.MILLISECONDS;
        c8054tM43876l.mo44301g(jMo43738a, timeUnit);
        this.f50865o.m43883s().mo44301g(this.f50862l.mo43739b(), timeUnit);
    }

    @Override // p580l.p581f0.p584g.InterfaceC7979c
    /* JADX INFO: renamed from: c */
    public AbstractC7954c0 mo43711c(C7952b0 c7952b0) {
        C7976g c7976g = this.f50863m;
        c7976g.f50740f.m44050q(c7976g.f50739e);
        return new C7984h(c7952b0.m43481h("Content-Type"), C7981e.m43719b(c7952b0), C8046l.m44313d(new a(this.f50865o.m43873i())));
    }

    @Override // p580l.p581f0.p584g.InterfaceC7979c
    /* JADX INFO: renamed from: d */
    public C7952b0.a mo43712d(boolean z) throws ProtocolException {
        C7952b0.a aVarM43806h = m43806h(this.f50865o.m43881q());
        if (z && AbstractC7960a.f50619a.mo43567d(aVarM43806h) == 100) {
            return null;
        }
        return aVarM43806h;
    }

    @Override // p580l.p581f0.p584g.InterfaceC7979c
    /* JADX INFO: renamed from: e */
    public void mo43713e() {
        this.f50864n.flush();
    }

    @Override // p580l.p581f0.p584g.InterfaceC7979c
    /* JADX INFO: renamed from: f */
    public InterfaceC8052r mo43714f(C8034z c8034z, long j2) {
        return this.f50865o.m43872h();
    }
}
