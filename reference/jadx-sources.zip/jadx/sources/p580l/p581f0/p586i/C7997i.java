package p580l.p581f0.p586i;

import java.io.EOFException;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;
import p590m.C8035a;
import p590m.C8037c;
import p590m.C8054t;
import p590m.InterfaceC8039e;
import p590m.InterfaceC8052r;
import p590m.InterfaceC8053s;

/* JADX INFO: renamed from: l.f0.i.i */
/* JADX INFO: loaded from: classes2.dex */
public final class C7997i {

    /* JADX INFO: renamed from: b */
    long f50943b;

    /* JADX INFO: renamed from: c */
    final int f50944c;

    /* JADX INFO: renamed from: d */
    final C7995g f50945d;

    /* JADX INFO: renamed from: e */
    private final List<C7991c> f50946e;

    /* JADX INFO: renamed from: f */
    private List<C7991c> f50947f;

    /* JADX INFO: renamed from: g */
    private boolean f50948g;

    /* JADX INFO: renamed from: h */
    private final b f50949h;

    /* JADX INFO: renamed from: i */
    final a f50950i;

    /* JADX INFO: renamed from: a */
    long f50942a = 0;

    /* JADX INFO: renamed from: j */
    final c f50951j = new c();

    /* JADX INFO: renamed from: k */
    final c f50952k = new c();

    /* JADX INFO: renamed from: l */
    EnumC7990b f50953l = null;

    /* JADX INFO: renamed from: l.f0.i.i$a */
    final class a implements InterfaceC8052r {

        /* JADX INFO: renamed from: u2 */
        private final C8037c f50954u2 = new C8037c();

        /* JADX INFO: renamed from: v2 */
        boolean f50955v2;

        /* JADX INFO: renamed from: w2 */
        boolean f50956w2;

        a() {
        }

        /* JADX INFO: renamed from: c */
        private void m43884c(boolean z) throws IOException {
            C7997i c7997i;
            long jMin;
            C7997i c7997i2;
            synchronized (C7997i.this) {
                C7997i.this.f50952k.m44206k();
                while (true) {
                    try {
                        c7997i = C7997i.this;
                        if (c7997i.f50943b > 0 || this.f50956w2 || this.f50955v2 || c7997i.f50953l != null) {
                            break;
                        } else {
                            c7997i.m43882r();
                        }
                    } catch (Throwable th) {
                        C7997i.this.f50952k.m43890u();
                        throw th;
                    }
                }
                c7997i.f50952k.m43890u();
                C7997i.this.m43868c();
                jMin = Math.min(C7997i.this.f50943b, this.f50954u2.m44265u());
                c7997i2 = C7997i.this;
                c7997i2.f50943b -= jMin;
            }
            c7997i2.f50952k.m44206k();
            try {
                C7997i c7997i3 = C7997i.this;
                c7997i3.f50945d.m43814A(c7997i3.f50944c, z && jMin == this.f50954u2.m44265u(), this.f50954u2, jMin);
            } finally {
                C7997i.this.f50952k.m43890u();
            }
        }

        @Override // p590m.InterfaceC8052r
        /* JADX INFO: renamed from: S */
        public C8054t mo43771S() {
            return C7997i.this.f50952k;
        }

        @Override // p590m.InterfaceC8052r
        /* JADX INFO: renamed from: Z7 */
        public void mo43652Z7(C8037c c8037c, long j2) throws IOException {
            this.f50954u2.mo43652Z7(c8037c, j2);
            while (this.f50954u2.m44265u() >= 16384) {
                m43884c(false);
            }
        }

        @Override // p590m.InterfaceC8052r, java.io.Closeable, java.lang.AutoCloseable
        public void close() throws IOException {
            synchronized (C7997i.this) {
                if (this.f50955v2) {
                    return;
                }
                if (!C7997i.this.f50950i.f50956w2) {
                    if (this.f50954u2.m44265u() > 0) {
                        while (this.f50954u2.m44265u() > 0) {
                            m43884c(true);
                        }
                    } else {
                        C7997i c7997i = C7997i.this;
                        c7997i.f50945d.m43814A(c7997i.f50944c, true, null, 0L);
                    }
                }
                synchronized (C7997i.this) {
                    this.f50955v2 = true;
                }
                C7997i.this.f50945d.flush();
                C7997i.this.m43867b();
            }
        }

        @Override // p590m.InterfaceC8052r, java.io.Flushable
        public void flush() throws IOException {
            synchronized (C7997i.this) {
                C7997i.this.m43868c();
            }
            while (this.f50954u2.m44265u() > 0) {
                m43884c(false);
                C7997i.this.f50945d.flush();
            }
        }
    }

    /* JADX INFO: renamed from: l.f0.i.i$b */
    private final class b implements InterfaceC8053s {

        /* JADX INFO: renamed from: u2 */
        private final C8037c f50958u2 = new C8037c();

        /* JADX INFO: renamed from: v2 */
        private final C8037c f50959v2 = new C8037c();

        /* JADX INFO: renamed from: w2 */
        private final long f50960w2;

        /* JADX INFO: renamed from: x2 */
        boolean f50961x2;

        /* JADX INFO: renamed from: y2 */
        boolean f50962y2;

        b(long j2) {
            this.f50960w2 = j2;
        }

        /* JADX INFO: renamed from: c */
        private void m43885c() throws IOException {
            if (this.f50961x2) {
                throw new IOException("stream closed");
            }
            if (C7997i.this.f50953l != null) {
                throw new C8002n(C7997i.this.f50953l);
            }
        }

        /* JADX INFO: renamed from: e */
        private void m43886e() throws IOException {
            C7997i.this.f50951j.m44206k();
            while (this.f50959v2.m44265u() == 0 && !this.f50962y2 && !this.f50961x2) {
                try {
                    C7997i c7997i = C7997i.this;
                    if (c7997i.f50953l != null) {
                        break;
                    } else {
                        c7997i.m43882r();
                    }
                } catch (Throwable th) {
                    C7997i.this.f50951j.m43890u();
                    throw th;
                }
            }
            C7997i.this.f50951j.m43890u();
        }

        @Override // p590m.InterfaceC8053s
        /* JADX INFO: renamed from: Rb */
        public long mo43613Rb(C8037c c8037c, long j2) {
            if (j2 < 0) {
                throw new IllegalArgumentException("byteCount < 0: " + j2);
            }
            synchronized (C7997i.this) {
                m43886e();
                m43885c();
                if (this.f50959v2.m44265u() == 0) {
                    return -1L;
                }
                C8037c c8037c2 = this.f50959v2;
                long jMo43613Rb = c8037c2.mo43613Rb(c8037c, Math.min(j2, c8037c2.m44265u()));
                C7997i c7997i = C7997i.this;
                long j3 = c7997i.f50942a + jMo43613Rb;
                c7997i.f50942a = j3;
                if (j3 >= c7997i.f50945d.f50878I2.m43920d() / 2) {
                    C7997i c7997i2 = C7997i.this;
                    c7997i2.f50945d.m43818E(c7997i2.f50944c, c7997i2.f50942a);
                    C7997i.this.f50942a = 0L;
                }
                synchronized (C7997i.this.f50945d) {
                    C7995g c7995g = C7997i.this.f50945d;
                    long j4 = c7995g.f50876G2 + jMo43613Rb;
                    c7995g.f50876G2 = j4;
                    if (j4 >= c7995g.f50878I2.m43920d() / 2) {
                        C7995g c7995g2 = C7997i.this.f50945d;
                        c7995g2.m43818E(0, c7995g2.f50876G2);
                        C7997i.this.f50945d.f50876G2 = 0L;
                    }
                }
                return jMo43613Rb;
            }
        }

        @Override // p590m.InterfaceC8053s
        /* JADX INFO: renamed from: S */
        public C8054t mo43614S() {
            return C7997i.this.f50951j;
        }

        @Override // p590m.InterfaceC8053s, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            synchronized (C7997i.this) {
                this.f50961x2 = true;
                this.f50959v2.m44238c();
                C7997i.this.notifyAll();
            }
            C7997i.this.m43867b();
        }

        /* JADX INFO: renamed from: d */
        void m43887d(InterfaceC8039e interfaceC8039e, long j2) throws EOFException {
            boolean z;
            boolean z2;
            boolean z3;
            while (j2 > 0) {
                synchronized (C7997i.this) {
                    z = this.f50962y2;
                    z2 = true;
                    z3 = this.f50959v2.m44265u() + j2 > this.f50960w2;
                }
                if (z3) {
                    interfaceC8039e.mo44230M8(j2);
                    C7997i.this.m43870f(EnumC7990b.FLOW_CONTROL_ERROR);
                    return;
                }
                if (z) {
                    interfaceC8039e.mo44230M8(j2);
                    return;
                }
                long jMo43613Rb = interfaceC8039e.mo43613Rb(this.f50958u2, j2);
                if (jMo43613Rb == -1) {
                    throw new EOFException();
                }
                j2 -= jMo43613Rb;
                synchronized (C7997i.this) {
                    if (this.f50959v2.m44265u() != 0) {
                        z2 = false;
                    }
                    this.f50959v2.mo44259r8(this.f50958u2);
                    if (z2) {
                        C7997i.this.notifyAll();
                    }
                }
            }
        }
    }

    /* JADX INFO: renamed from: l.f0.i.i$c */
    class c extends C8035a {
        c() {
        }

        @Override // p590m.C8035a
        /* JADX INFO: renamed from: o */
        protected IOException mo43888o(IOException iOException) {
            SocketTimeoutException socketTimeoutException = new SocketTimeoutException("timeout");
            if (iOException != null) {
                socketTimeoutException.initCause(iOException);
            }
            return socketTimeoutException;
        }

        @Override // p590m.C8035a
        /* JADX INFO: renamed from: t */
        protected void mo43889t() {
            C7997i.this.m43870f(EnumC7990b.CANCEL);
        }

        /* JADX INFO: renamed from: u */
        public void m43890u() throws IOException {
            if (m44209n()) {
                throw mo43888o(null);
            }
        }
    }

    C7997i(int i2, C7995g c7995g, boolean z, boolean z2, List<C7991c> list) {
        if (c7995g == null) {
            throw new NullPointerException("connection == null");
        }
        if (list == null) {
            throw new NullPointerException("requestHeaders == null");
        }
        this.f50944c = i2;
        this.f50945d = c7995g;
        this.f50943b = c7995g.f50879J2.m43920d();
        b bVar = new b(c7995g.f50878I2.m43920d());
        this.f50949h = bVar;
        a aVar = new a();
        this.f50950i = aVar;
        bVar.f50962y2 = z2;
        aVar.f50956w2 = z;
        this.f50946e = list;
    }

    /* JADX INFO: renamed from: e */
    private boolean m43865e(EnumC7990b enumC7990b) {
        synchronized (this) {
            if (this.f50953l != null) {
                return false;
            }
            if (this.f50949h.f50962y2 && this.f50950i.f50956w2) {
                return false;
            }
            this.f50953l = enumC7990b;
            notifyAll();
            this.f50945d.m43830w(this.f50944c);
            return true;
        }
    }

    /* JADX INFO: renamed from: a */
    void m43866a(long j2) {
        this.f50943b += j2;
        if (j2 > 0) {
            notifyAll();
        }
    }

    /* JADX WARN: Code duplicated, block: B:12:0x0017  */
    /* JADX INFO: renamed from: b */
    void m43867b() {
        boolean z;
        boolean zM43875k;
        synchronized (this) {
            b bVar = this.f50949h;
            if (bVar.f50962y2 || !bVar.f50961x2) {
                z = false;
            } else {
                a aVar = this.f50950i;
                if (aVar.f50956w2 || aVar.f50955v2) {
                    z = true;
                } else {
                    z = false;
                }
            }
            zM43875k = m43875k();
        }
        if (z) {
            m43869d(EnumC7990b.CANCEL);
        } else {
            if (zM43875k) {
                return;
            }
            this.f50945d.m43830w(this.f50944c);
        }
    }

    /* JADX INFO: renamed from: c */
    void m43868c() throws IOException {
        a aVar = this.f50950i;
        if (aVar.f50955v2) {
            throw new IOException("stream closed");
        }
        if (aVar.f50956w2) {
            throw new IOException("stream finished");
        }
        if (this.f50953l != null) {
            throw new C8002n(this.f50953l);
        }
    }

    /* JADX INFO: renamed from: d */
    public void m43869d(EnumC7990b enumC7990b) {
        if (m43865e(enumC7990b)) {
            this.f50945d.m43816C(this.f50944c, enumC7990b);
        }
    }

    /* JADX INFO: renamed from: f */
    public void m43870f(EnumC7990b enumC7990b) {
        if (m43865e(enumC7990b)) {
            this.f50945d.m43817D(this.f50944c, enumC7990b);
        }
    }

    /* JADX INFO: renamed from: g */
    public int m43871g() {
        return this.f50944c;
    }

    /* JADX INFO: renamed from: h */
    public InterfaceC8052r m43872h() {
        synchronized (this) {
            if (!this.f50948g && !m43874j()) {
                throw new IllegalStateException("reply before requesting the sink");
            }
        }
        return this.f50950i;
    }

    /* JADX INFO: renamed from: i */
    public InterfaceC8053s m43873i() {
        return this.f50949h;
    }

    /* JADX INFO: renamed from: j */
    public boolean m43874j() {
        return this.f50945d.f50885v2 == ((this.f50944c & 1) == 1);
    }

    /* JADX INFO: renamed from: k */
    public synchronized boolean m43875k() {
        if (this.f50953l != null) {
            return false;
        }
        b bVar = this.f50949h;
        if (bVar.f50962y2 || bVar.f50961x2) {
            a aVar = this.f50950i;
            if ((aVar.f50956w2 || aVar.f50955v2) && this.f50948g) {
                return false;
            }
        }
        return true;
    }

    /* JADX INFO: renamed from: l */
    public C8054t m43876l() {
        return this.f50951j;
    }

    /* JADX INFO: renamed from: m */
    void m43877m(InterfaceC8039e interfaceC8039e, int i2) throws EOFException {
        this.f50949h.m43887d(interfaceC8039e, i2);
    }

    /* JADX INFO: renamed from: n */
    void m43878n() {
        boolean zM43875k;
        synchronized (this) {
            this.f50949h.f50962y2 = true;
            zM43875k = m43875k();
            notifyAll();
        }
        if (zM43875k) {
            return;
        }
        this.f50945d.m43830w(this.f50944c);
    }

    /* JADX INFO: renamed from: o */
    void m43879o(List<C7991c> list) {
        boolean zM43875k;
        synchronized (this) {
            zM43875k = true;
            this.f50948g = true;
            if (this.f50947f == null) {
                this.f50947f = list;
                zM43875k = m43875k();
                notifyAll();
            } else {
                ArrayList arrayList = new ArrayList();
                arrayList.addAll(this.f50947f);
                arrayList.add(null);
                arrayList.addAll(list);
                this.f50947f = arrayList;
            }
        }
        if (zM43875k) {
            return;
        }
        this.f50945d.m43830w(this.f50944c);
    }

    /* JADX INFO: renamed from: p */
    synchronized void m43880p(EnumC7990b enumC7990b) {
        if (this.f50953l == null) {
            this.f50953l = enumC7990b;
            notifyAll();
        }
    }

    /* JADX INFO: renamed from: q */
    public synchronized List<C7991c> m43881q() {
        List<C7991c> list;
        if (!m43874j()) {
            throw new IllegalStateException("servers cannot read response headers");
        }
        this.f50951j.m44206k();
        while (this.f50947f == null && this.f50953l == null) {
            try {
                m43882r();
            } catch (Throwable th) {
                this.f50951j.m43890u();
                throw th;
            }
        }
        this.f50951j.m43890u();
        list = this.f50947f;
        if (list == null) {
            throw new C8002n(this.f50953l);
        }
        this.f50947f = null;
        return list;
    }

    /* JADX INFO: renamed from: r */
    void m43882r() throws InterruptedIOException {
        try {
            wait();
        } catch (InterruptedException unused) {
            throw new InterruptedIOException();
        }
    }

    /* JADX INFO: renamed from: s */
    public C8054t m43883s() {
        return this.f50952k;
    }
}
