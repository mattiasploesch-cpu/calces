package p580l.p581f0.p586i;

import java.util.Arrays;

/* JADX INFO: renamed from: l.f0.i.m */
/* JADX INFO: loaded from: classes2.dex */
public final class C8001m {

    /* JADX INFO: renamed from: a */
    private int f50980a;

    /* JADX INFO: renamed from: b */
    private final int[] f50981b = new int[10];

    /* JADX INFO: renamed from: a */
    void m43917a() {
        this.f50980a = 0;
        Arrays.fill(this.f50981b, 0);
    }

    /* JADX INFO: renamed from: b */
    int m43918b(int i2) {
        return this.f50981b[i2];
    }

    /* JADX INFO: renamed from: c */
    int m43919c() {
        if ((this.f50980a & 2) != 0) {
            return this.f50981b[1];
        }
        return -1;
    }

    /* JADX INFO: renamed from: d */
    int m43920d() {
        if ((this.f50980a & 128) != 0) {
            return this.f50981b[7];
        }
        return 65535;
    }

    /* JADX INFO: renamed from: e */
    int m43921e(int i2) {
        return (this.f50980a & 16) != 0 ? this.f50981b[4] : i2;
    }

    /* JADX INFO: renamed from: f */
    int m43922f(int i2) {
        return (this.f50980a & 32) != 0 ? this.f50981b[5] : i2;
    }

    /* JADX INFO: renamed from: g */
    boolean m43923g(int i2) {
        return ((1 << i2) & this.f50980a) != 0;
    }

    /* JADX INFO: renamed from: h */
    void m43924h(C8001m c8001m) {
        for (int i2 = 0; i2 < 10; i2++) {
            if (c8001m.m43923g(i2)) {
                m43925i(i2, c8001m.m43918b(i2));
            }
        }
    }

    /* JADX INFO: renamed from: i */
    C8001m m43925i(int i2, int i3) {
        if (i2 >= 0) {
            int[] iArr = this.f50981b;
            if (i2 < iArr.length) {
                this.f50980a = (1 << i2) | this.f50980a;
                iArr[i2] = i3;
            }
        }
        return this;
    }

    /* JADX INFO: renamed from: j */
    int m43926j() {
        return Integer.bitCount(this.f50980a);
    }
}
