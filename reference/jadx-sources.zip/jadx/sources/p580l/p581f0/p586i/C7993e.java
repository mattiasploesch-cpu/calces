package p580l.p581f0.p586i;

import java.io.IOException;
import p356f.p372c.p375g.p381e.p421f.p422d.C7023a;
import p580l.p581f0.C7962c;
import p590m.C8040f;

/* JADX INFO: renamed from: l.f0.i.e */
/* JADX INFO: loaded from: classes2.dex */
public final class C7993e {

    /* JADX INFO: renamed from: a */
    static final C8040f f50847a = C8040f.m44278r("PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n");

    /* JADX INFO: renamed from: b */
    private static final String[] f50848b = {"DATA", "HEADERS", "PRIORITY", "RST_STREAM", "SETTINGS", "PUSH_PROMISE", "PING", "GOAWAY", "WINDOW_UPDATE", "CONTINUATION"};

    /* JADX INFO: renamed from: c */
    static final String[] f50849c = new String[64];

    /* JADX INFO: renamed from: d */
    static final String[] f50850d = new String[256];

    static {
        int i2 = 0;
        int i3 = 0;
        while (true) {
            String[] strArr = f50850d;
            if (i3 >= strArr.length) {
                break;
            }
            strArr[i3] = C7962c.m43593o("%8s", Integer.toBinaryString(i3)).replace(' ', '0');
            i3++;
        }
        String[] strArr2 = f50849c;
        strArr2[0] = "";
        strArr2[1] = "END_STREAM";
        int[] iArr = {1};
        strArr2[8] = "PADDED";
        for (int i4 = 0; i4 < 1; i4++) {
            int i5 = iArr[i4];
            String[] strArr3 = f50849c;
            strArr3[i5 | 8] = strArr3[i5] + "|PADDED";
        }
        String[] strArr4 = f50849c;
        strArr4[4] = "END_HEADERS";
        strArr4[32] = "PRIORITY";
        strArr4[36] = "END_HEADERS|PRIORITY";
        int[] iArr2 = {4, 32, 36};
        for (int i6 = 0; i6 < 3; i6++) {
            int i7 = iArr2[i6];
            for (int i8 = 0; i8 < 1; i8++) {
                int i9 = iArr[i8];
                String[] strArr5 = f50849c;
                int i10 = i9 | i7;
                strArr5[i10] = strArr5[i9] + '|' + strArr5[i7];
                strArr5[i10 | 8] = strArr5[i9] + '|' + strArr5[i7] + "|PADDED";
            }
        }
        while (true) {
            String[] strArr6 = f50849c;
            if (i2 >= strArr6.length) {
                return;
            }
            if (strArr6[i2] == null) {
                strArr6[i2] = f50850d[i2];
            }
            i2++;
        }
    }

    private C7993e() {
    }

    /* JADX INFO: renamed from: a */
    static String m43801a(byte b2, byte b3) {
        if (b3 == 0) {
            return "";
        }
        if (b2 != 2 && b2 != 3) {
            if (b2 == 4 || b2 == 6) {
                return b3 == 1 ? "ACK" : f50850d[b3];
            }
            if (b2 != 7 && b2 != 8) {
                String[] strArr = f50849c;
                String str = b3 < strArr.length ? strArr[b3] : f50850d[b3];
                if (b2 != 5 || (b3 & 4) == 0) {
                    return (b2 != 0 || (b3 & 32) == 0) ? str : str.replace("PRIORITY", "COMPRESSED");
                }
                return str.replace("HEADERS", "PUSH_PROMISE");
            }
        }
        return f50850d[b3];
    }

    /* JADX INFO: renamed from: b */
    static String m43802b(boolean z, int i2, int i3, byte b2, byte b3) {
        String[] strArr = f50848b;
        String strM43593o = b2 < strArr.length ? strArr[b2] : C7962c.m43593o("0x%02x", Byte.valueOf(b2));
        String strM43801a = m43801a(b2, b3);
        Object[] objArr = new Object[5];
        objArr[0] = z ? C7023a.f45582a : C7023a.f45583b;
        objArr[1] = Integer.valueOf(i2);
        objArr[2] = Integer.valueOf(i3);
        objArr[3] = strM43593o;
        objArr[4] = strM43801a;
        return C7962c.m43593o("%s 0x%08x %5d %-13s %s", objArr);
    }

    /* JADX INFO: renamed from: c */
    static IllegalArgumentException m43803c(String str, Object... objArr) {
        throw new IllegalArgumentException(C7962c.m43593o(str, objArr));
    }

    /* JADX INFO: renamed from: d */
    static IOException m43804d(String str, Object... objArr) throws IOException {
        throw new IOException(C7962c.m43593o(str, objArr));
    }
}
