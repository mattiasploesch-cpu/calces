package p580l.p581f0.p586i;

import java.io.Closeable;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import p356f.p372c.p470v.InterfaceC7310s;
import p580l.p581f0.C7962c;
import p590m.C8037c;
import p590m.InterfaceC8038d;

/* JADX INFO: renamed from: l.f0.i.j */
/* JADX INFO: loaded from: classes2.dex */
final class C7998j implements Closeable {

    /* JADX INFO: renamed from: u2 */
    private static final Logger f50965u2 = Logger.getLogger(C7993e.class.getName());

    /* JADX INFO: renamed from: A2 */
    final C7992d.b f50966A2;

    /* JADX INFO: renamed from: v2 */
    private final InterfaceC8038d f50967v2;

    /* JADX INFO: renamed from: w2 */
    private final boolean f50968w2;

    /* JADX INFO: renamed from: x2 */
    private final C8037c f50969x2;

    /* JADX INFO: renamed from: y2 */
    private int f50970y2;

    /* JADX INFO: renamed from: z2 */
    private boolean f50971z2;

    C7998j(InterfaceC8038d interfaceC8038d, boolean z) {
        this.f50967v2 = interfaceC8038d;
        this.f50968w2 = z;
        C8037c c8037c = new C8037c();
        this.f50969x2 = c8037c;
        this.f50966A2 = new C7992d.b(c8037c);
        this.f50970y2 = InterfaceC7310s.f47472h;
    }

    /* JADX INFO: renamed from: t */
    private void m43891t(int i2, long j2) {
        while (j2 > 0) {
            int iMin = (int) Math.min(this.f50970y2, j2);
            long j3 = iMin;
            j2 -= j3;
            m43897g(i2, iMin, (byte) 9, j2 == 0 ? (byte) 4 : (byte) 0);
            this.f50967v2.mo43652Z7(this.f50969x2, j3);
        }
    }

    /* JADX INFO: renamed from: u */
    private static void m43892u(InterfaceC8038d interfaceC8038d, int i2) {
        interfaceC8038d.mo44241e4((i2 >>> 16) & 255);
        interfaceC8038d.mo44241e4((i2 >>> 8) & 255);
        interfaceC8038d.mo44241e4(i2 & 255);
    }

    /* JADX INFO: renamed from: c */
    public synchronized void m43893c(C8001m c8001m) {
        if (this.f50971z2) {
            throw new IOException("closed");
        }
        this.f50970y2 = c8001m.m43922f(this.f50970y2);
        if (c8001m.m43919c() != -1) {
            this.f50966A2.m43797e(c8001m.m43919c());
        }
        m43897g(0, 0, (byte) 4, (byte) 1);
        this.f50967v2.flush();
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public synchronized void close() {
        this.f50971z2 = true;
        this.f50967v2.close();
    }

    /* JADX INFO: renamed from: d */
    public synchronized void m43894d() {
        if (this.f50971z2) {
            throw new IOException("closed");
        }
        if (this.f50968w2) {
            Logger logger = f50965u2;
            if (logger.isLoggable(Level.FINE)) {
                logger.fine(C7962c.m43593o(">> CONNECTION %s", C7993e.f50847a.mo44282E()));
            }
            this.f50967v2.mo44235Xa(C7993e.f50847a.mo44288cb());
            this.f50967v2.flush();
        }
    }

    /* JADX INFO: renamed from: e */
    public synchronized void m43895e(boolean z, int i2, C8037c c8037c, int i3) {
        if (this.f50971z2) {
            throw new IOException("closed");
        }
        m43896f(i2, z ? (byte) 1 : (byte) 0, c8037c, i3);
    }

    /* JADX INFO: renamed from: f */
    void m43896f(int i2, byte b2, C8037c c8037c, int i3) {
        m43897g(i2, i3, (byte) 0, b2);
        if (i3 > 0) {
            this.f50967v2.mo43652Z7(c8037c, i3);
        }
    }

    public synchronized void flush() {
        if (this.f50971z2) {
            throw new IOException("closed");
        }
        this.f50967v2.flush();
    }

    /* JADX INFO: renamed from: g */
    public void m43897g(int i2, int i3, byte b2, byte b3) {
        Logger logger = f50965u2;
        if (logger.isLoggable(Level.FINE)) {
            logger.fine(C7993e.m43802b(false, i2, i3, b2, b3));
        }
        int i4 = this.f50970y2;
        if (i3 > i4) {
            throw C7993e.m43803c("FRAME_SIZE_ERROR length > %d: %d", Integer.valueOf(i4), Integer.valueOf(i3));
        }
        if ((Integer.MIN_VALUE & i2) != 0) {
            throw C7993e.m43803c("reserved bit set: %s", Integer.valueOf(i2));
        }
        m43892u(this.f50967v2, i3);
        this.f50967v2.mo44241e4(b2 & 255);
        this.f50967v2.mo44241e4(b3 & 255);
        this.f50967v2.mo44236Z2(i2 & Integer.MAX_VALUE);
    }

    /* JADX INFO: renamed from: h */
    public synchronized void m43898h(int i2, EnumC7990b enumC7990b, byte[] bArr) {
        if (this.f50971z2) {
            throw new IOException("closed");
        }
        if (enumC7990b.f50817G2 == -1) {
            throw C7993e.m43803c("errorCode.httpCode == -1", new Object[0]);
        }
        m43897g(0, bArr.length + 8, (byte) 7, (byte) 0);
        this.f50967v2.mo44236Z2(i2);
        this.f50967v2.mo44236Z2(enumC7990b.f50817G2);
        if (bArr.length > 0) {
            this.f50967v2.mo44235Xa(bArr);
        }
        this.f50967v2.flush();
    }

    /* JADX INFO: renamed from: i */
    void m43899i(boolean z, int i2, List<C7991c> list) throws IOException {
        if (this.f50971z2) {
            throw new IOException("closed");
        }
        this.f50966A2.m43799g(list);
        long jM44265u = this.f50969x2.m44265u();
        int iMin = (int) Math.min(this.f50970y2, jM44265u);
        long j2 = iMin;
        byte b2 = jM44265u == j2 ? (byte) 4 : (byte) 0;
        if (z) {
            b2 = (byte) (b2 | 1);
        }
        m43897g(i2, iMin, (byte) 1, b2);
        this.f50967v2.mo43652Z7(this.f50969x2, j2);
        if (jM44265u > j2) {
            m43891t(i2, jM44265u - j2);
        }
    }

    /* JADX INFO: renamed from: j */
    public int m43900j() {
        return this.f50970y2;
    }

    /* JADX INFO: renamed from: k */
    public synchronized void m43901k(boolean z, int i2, int i3) {
        if (this.f50971z2) {
            throw new IOException("closed");
        }
        m43897g(0, 8, (byte) 6, z ? (byte) 1 : (byte) 0);
        this.f50967v2.mo44236Z2(i2);
        this.f50967v2.mo44236Z2(i3);
        this.f50967v2.flush();
    }

    /* JADX INFO: renamed from: l */
    public synchronized void m43902l(int i2, int i3, List<C7991c> list) {
        if (this.f50971z2) {
            throw new IOException("closed");
        }
        this.f50966A2.m43799g(list);
        long jM44265u = this.f50969x2.m44265u();
        int iMin = (int) Math.min(this.f50970y2 - 4, jM44265u);
        long j2 = iMin;
        m43897g(i2, iMin + 4, (byte) 5, jM44265u == j2 ? (byte) 4 : (byte) 0);
        this.f50967v2.mo44236Z2(i3 & Integer.MAX_VALUE);
        this.f50967v2.mo43652Z7(this.f50969x2, j2);
        if (jM44265u > j2) {
            m43891t(i2, jM44265u - j2);
        }
    }

    /* JADX INFO: renamed from: o */
    public synchronized void m43903o(int i2, EnumC7990b enumC7990b) {
        if (this.f50971z2) {
            throw new IOException("closed");
        }
        if (enumC7990b.f50817G2 == -1) {
            throw new IllegalArgumentException();
        }
        m43897g(i2, 4, (byte) 3, (byte) 0);
        this.f50967v2.mo44236Z2(enumC7990b.f50817G2);
        this.f50967v2.flush();
    }

    /* JADX INFO: renamed from: p */
    public synchronized void m43904p(C8001m c8001m) {
        int i2;
        if (this.f50971z2) {
            throw new IOException("closed");
        }
        int i3 = 0;
        m43897g(0, c8001m.m43926j() * 6, (byte) 4, (byte) 0);
        while (i3 < 10) {
            if (c8001m.m43923g(i3)) {
                if (i3 == 4) {
                    i2 = 3;
                } else {
                    i2 = i3 == 7 ? 4 : i3;
                }
                this.f50967v2.mo44217B2(i2);
                this.f50967v2.mo44236Z2(c8001m.m43918b(i3));
            }
            i3++;
        }
        this.f50967v2.flush();
    }

    /* JADX INFO: renamed from: q */
    public synchronized void m43905q(boolean z, int i2, int i3, List<C7991c> list) {
        if (this.f50971z2) {
            throw new IOException("closed");
        }
        m43899i(z, i2, list);
    }

    /* JADX INFO: renamed from: s */
    public synchronized void m43906s(int i2, long j2) {
        if (this.f50971z2) {
            throw new IOException("closed");
        }
        if (j2 == 0 || j2 > 2147483647L) {
            throw C7993e.m43803c("windowSizeIncrement == 0 || windowSizeIncrement > 0x7fffffffL: %s", Long.valueOf(j2));
        }
        m43897g(i2, 4, (byte) 8, (byte) 0);
        this.f50967v2.mo44236Z2((int) j2);
        this.f50967v2.flush();
    }
}
