package p580l.p581f0;

import java.io.Closeable;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.IDN;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;
import javax.annotation.Nullable;
import p580l.AbstractC7950a0;
import p580l.AbstractC7954c0;
import p580l.C8027s;
import p590m.C8037c;
import p590m.C8040f;
import p590m.C8054t;
import p590m.InterfaceC8053s;

/* JADX INFO: renamed from: l.f0.c */
/* JADX INFO: loaded from: classes.dex */
public final class C7962c {

    /* JADX INFO: renamed from: a */
    public static final byte[] f50621a;

    /* JADX INFO: renamed from: c */
    public static final AbstractC7954c0 f50623c;

    /* JADX INFO: renamed from: d */
    public static final AbstractC7950a0 f50624d;

    /* JADX INFO: renamed from: b */
    public static final String[] f50622b = new String[0];

    /* JADX INFO: renamed from: e */
    private static final C8040f f50625e = C8040f.m44275m("efbbbf");

    /* JADX INFO: renamed from: f */
    private static final C8040f f50626f = C8040f.m44275m("feff");

    /* JADX INFO: renamed from: g */
    private static final C8040f f50627g = C8040f.m44275m("fffe");

    /* JADX INFO: renamed from: h */
    private static final C8040f f50628h = C8040f.m44275m("0000ffff");

    /* JADX INFO: renamed from: i */
    private static final C8040f f50629i = C8040f.m44275m("ffff0000");

    /* JADX INFO: renamed from: j */
    public static final Charset f50630j = Charset.forName("UTF-8");

    /* JADX INFO: renamed from: k */
    public static final Charset f50631k = Charset.forName("ISO-8859-1");

    /* JADX INFO: renamed from: l */
    private static final Charset f50632l = Charset.forName("UTF-16BE");

    /* JADX INFO: renamed from: m */
    private static final Charset f50633m = Charset.forName("UTF-16LE");

    /* JADX INFO: renamed from: n */
    private static final Charset f50634n = Charset.forName("UTF-32BE");

    /* JADX INFO: renamed from: o */
    private static final Charset f50635o = Charset.forName("UTF-32LE");

    /* JADX INFO: renamed from: p */
    public static final TimeZone f50636p = TimeZone.getTimeZone("GMT");

    /* JADX INFO: renamed from: q */
    public static final Comparator<String> f50637q = new a();

    /* JADX INFO: renamed from: r */
    private static final Pattern f50638r = Pattern.compile("([0-9a-fA-F]*:[0-9a-fA-F:.]*)|([\\d.]+)");

    /* JADX INFO: renamed from: l.f0.c$a */
    /* JADX INFO: loaded from: classes2.dex */
    final class a implements Comparator<String> {
        a() {
        }

        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(String str, String str2) {
            return str.compareTo(str2);
        }
    }

    /* JADX INFO: renamed from: l.f0.c$b */
    /* JADX INFO: loaded from: classes2.dex */
    final class b implements ThreadFactory {

        /* JADX INFO: renamed from: a */
        final /* synthetic */ String f50639a;

        /* JADX INFO: renamed from: b */
        final /* synthetic */ boolean f50640b;

        b(String str, boolean z) {
            this.f50639a = str;
            this.f50640b = z;
        }

        @Override // java.util.concurrent.ThreadFactory
        public Thread newThread(Runnable runnable) {
            Thread thread = new Thread(runnable, this.f50639a);
            thread.setDaemon(this.f50640b);
            return thread;
        }
    }

    static {
        byte[] bArr = new byte[0];
        f50621a = bArr;
        f50623c = AbstractC7954c0.m43535e(null, bArr);
        f50624d = AbstractC7950a0.m43470e(null, bArr);
    }

    /* JADX INFO: renamed from: A */
    public static int m43575A(String str, int i2, int i3) {
        for (int i4 = i3 - 1; i4 >= i2; i4--) {
            char cCharAt = str.charAt(i4);
            if (cCharAt != '\t' && cCharAt != '\n' && cCharAt != '\f' && cCharAt != '\r' && cCharAt != ' ') {
                return i4 + 1;
            }
        }
        return i2;
    }

    /* JADX INFO: renamed from: B */
    public static ThreadFactory m43576B(String str, boolean z) {
        return new b(str, z);
    }

    /* JADX INFO: renamed from: C */
    public static String m43577C(String str, int i2, int i3) {
        int iM43604z = m43604z(str, i2, i3);
        return str.substring(iM43604z, m43575A(str, iM43604z, i3));
    }

    /* JADX INFO: renamed from: D */
    public static boolean m43578D(String str) {
        return f50638r.matcher(str).matches();
    }

    /* JADX INFO: renamed from: a */
    public static AssertionError m43579a(String str, Exception exc) {
        AssertionError assertionError = new AssertionError(str);
        try {
            assertionError.initCause(exc);
        } catch (IllegalStateException unused) {
        }
        return assertionError;
    }

    /* JADX INFO: renamed from: b */
    public static String m43580b(String str) {
        if (!str.contains(":")) {
            try {
                String lowerCase = IDN.toASCII(str).toLowerCase(Locale.US);
                if (lowerCase.isEmpty() || m43585g(lowerCase)) {
                    return null;
                }
                return lowerCase;
            } catch (IllegalArgumentException unused) {
                return null;
            }
        }
        InetAddress inetAddressM43588j = (str.startsWith("[") && str.endsWith("]")) ? m43588j(str, 1, str.length() - 1) : m43588j(str, 0, str.length());
        if (inetAddressM43588j == null) {
            return null;
        }
        byte[] address = inetAddressM43588j.getAddress();
        if (address.length == 16) {
            return m43599u(address);
        }
        throw new AssertionError("Invalid IPv6 address: '" + str + "'");
    }

    /* JADX INFO: renamed from: c */
    public static void m43581c(long j2, long j3, long j4) {
        if ((j3 | j4) < 0 || j3 > j2 || j2 - j3 < j4) {
            throw new ArrayIndexOutOfBoundsException();
        }
    }

    /* JADX INFO: renamed from: d */
    public static void m43582d(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (RuntimeException e2) {
                throw e2;
            } catch (Exception unused) {
            }
        }
    }

    /* JADX INFO: renamed from: e */
    public static void m43583e(Socket socket) {
        if (socket != null) {
            try {
                socket.close();
            } catch (AssertionError e2) {
                if (!m43601w(e2)) {
                    throw e2;
                }
            } catch (RuntimeException e3) {
                throw e3;
            } catch (Exception unused) {
            }
        }
    }

    /* JADX INFO: renamed from: f */
    public static String[] m43584f(String[] strArr, String str) {
        int length = strArr.length + 1;
        String[] strArr2 = new String[length];
        System.arraycopy(strArr, 0, strArr2, 0, strArr.length);
        strArr2[length - 1] = str;
        return strArr2;
    }

    /* JADX INFO: renamed from: g */
    private static boolean m43585g(String str) {
        for (int i2 = 0; i2 < str.length(); i2++) {
            char cCharAt = str.charAt(i2);
            if (cCharAt <= 31 || cCharAt >= 127 || " #%/:?@[\\]".indexOf(cCharAt) != -1) {
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: renamed from: h */
    public static int m43586h(char c2) {
        if (c2 >= '0' && c2 <= '9') {
            return c2 - '0';
        }
        char c3 = 'a';
        if (c2 < 'a' || c2 > 'f') {
            c3 = 'A';
            if (c2 < 'A' || c2 > 'F') {
                return -1;
            }
        }
        return (c2 - c3) + 10;
    }

    /* JADX INFO: renamed from: i */
    private static boolean m43587i(String str, int i2, int i3, byte[] bArr, int i4) {
        int i5 = i4;
        while (i2 < i3) {
            if (i5 == bArr.length) {
                return false;
            }
            if (i5 != i4) {
                if (str.charAt(i2) != '.') {
                    return false;
                }
                i2++;
            }
            int i6 = i2;
            int i7 = 0;
            while (i6 < i3) {
                char cCharAt = str.charAt(i6);
                if (cCharAt < '0' || cCharAt > '9') {
                    break;
                }
                if ((i7 == 0 && i2 != i6) || (i7 = ((i7 * 10) + cCharAt) - 48) > 255) {
                    return false;
                }
                i6++;
            }
            if (i6 - i2 == 0) {
                return false;
            }
            bArr[i5] = (byte) i7;
            i5++;
            i2 = i6;
        }
        return i5 == i4 + 4;
    }

    /* JADX WARN: Code duplicated, block: B:31:0x004f  */
    /* JADX WARN: Code duplicated, block: B:34:0x005a A[LOOP:1: B:30:0x004d->B:34:0x005a, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:60:0x0060 A[EDGE_INSN: B:60:0x0060->B:35:0x0060 BREAK  A[LOOP:1: B:30:0x004d->B:34:0x005a], SYNTHETIC] */
    @Nullable
    /* JADX INFO: renamed from: j */
    private static InetAddress m43588j(String str, int i2, int i3) {
        int i4;
        int i5;
        int iM43586h;
        byte[] bArr = new byte[16];
        int i6 = 0;
        int i7 = -1;
        int i8 = -1;
        while (i2 < i3) {
            if (i6 == 16) {
                return null;
            }
            int i9 = i2 + 2;
            if (i9 <= i3 && str.regionMatches(i2, "::", 0, 2)) {
                if (i7 != -1) {
                    return null;
                }
                i6 += 2;
                i7 = i6;
                if (i9 == i3) {
                    break;
                }
                i8 = i9;
                i2 = i8;
                i4 = 0;
                while (i2 < i3) {
                    iM43586h = m43586h(str.charAt(i2));
                    if (iM43586h == -1) {
                        break;
                        break;
                    }
                    i4 = (i4 << 4) + iM43586h;
                    i2++;
                }
                i5 = i2 - i8;
                if (i5 != 0) {
                }
                return null;
            }
            if (i6 != 0) {
                if (!str.regionMatches(i2, ":", 0, 1)) {
                    if (!str.regionMatches(i2, ".", 0, 1) || !m43587i(str, i8, i3, bArr, i6 - 2)) {
                        return null;
                    }
                    i6 += 2;
                    break;
                }
                i2++;
            }
            i8 = i2;
            i2 = i8;
            i4 = 0;
            while (i2 < i3) {
                iM43586h = m43586h(str.charAt(i2));
                if (iM43586h == -1) {
                    break;
                }
                i4 = (i4 << 4) + iM43586h;
                i2++;
            }
            i5 = i2 - i8;
            if (i5 != 0 || i5 > 4) {
                return null;
            }
            int i10 = i6 + 1;
            bArr[i6] = (byte) ((i4 >>> 8) & 255);
            i6 = i10 + 1;
            bArr[i10] = (byte) (i4 & 255);
        }
        if (i6 != 16) {
            if (i7 == -1) {
                return null;
            }
            int i11 = i6 - i7;
            System.arraycopy(bArr, i7, bArr, 16 - i11, i11);
            Arrays.fill(bArr, i7, (16 - i6) + i7, (byte) 0);
        }
        try {
            return InetAddress.getByAddress(bArr);
        } catch (UnknownHostException unused) {
            throw new AssertionError();
        }
    }

    /* JADX INFO: renamed from: k */
    public static int m43589k(String str, int i2, int i3, char c2) {
        while (i2 < i3) {
            if (str.charAt(i2) == c2) {
                return i2;
            }
            i2++;
        }
        return i3;
    }

    /* JADX INFO: renamed from: l */
    public static int m43590l(String str, int i2, int i3, String str2) {
        while (i2 < i3) {
            if (str2.indexOf(str.charAt(i2)) != -1) {
                return i2;
            }
            i2++;
        }
        return i3;
    }

    /* JADX INFO: renamed from: m */
    public static boolean m43591m(InterfaceC8053s interfaceC8053s, int i2, TimeUnit timeUnit) {
        try {
            return m43603y(interfaceC8053s, i2, timeUnit);
        } catch (IOException unused) {
            return false;
        }
    }

    /* JADX INFO: renamed from: n */
    public static boolean m43592n(Object obj, Object obj2) {
        return obj == obj2 || (obj != null && obj.equals(obj2));
    }

    /* JADX INFO: renamed from: o */
    public static String m43593o(String str, Object... objArr) {
        return String.format(Locale.US, str, objArr);
    }

    /* JADX INFO: renamed from: p */
    public static String m43594p(C8027s c8027s, boolean z) {
        String strM44102l;
        if (c8027s.m44102l().contains(":")) {
            strM44102l = "[" + c8027s.m44102l() + "]";
        } else {
            strM44102l = c8027s.m44102l();
        }
        if (!z && c8027s.m44106x() == C8027s.m44081d(c8027s.m44094C())) {
            return strM44102l;
        }
        return strM44102l + ":" + c8027s.m44106x();
    }

    /* JADX INFO: renamed from: q */
    public static <T> List<T> m43595q(List<T> list) {
        return Collections.unmodifiableList(new ArrayList(list));
    }

    /* JADX INFO: renamed from: r */
    public static <T> List<T> m43596r(T... tArr) {
        return Collections.unmodifiableList(Arrays.asList((Object[]) tArr.clone()));
    }

    /* JADX INFO: renamed from: s */
    public static int m43597s(Comparator<String> comparator, String[] strArr, String str) {
        int length = strArr.length;
        for (int i2 = 0; i2 < length; i2++) {
            if (comparator.compare(strArr[i2], str) == 0) {
                return i2;
            }
        }
        return -1;
    }

    /* JADX INFO: renamed from: t */
    public static int m43598t(String str) {
        int length = str.length();
        for (int i2 = 0; i2 < length; i2++) {
            char cCharAt = str.charAt(i2);
            if (cCharAt <= 31 || cCharAt >= 127) {
                return i2;
            }
        }
        return -1;
    }

    /* JADX INFO: renamed from: u */
    private static String m43599u(byte[] bArr) {
        int i2 = 0;
        int i3 = -1;
        int i4 = 0;
        int i5 = 0;
        while (i4 < bArr.length) {
            int i6 = i4;
            while (i6 < 16 && bArr[i6] == 0 && bArr[i6 + 1] == 0) {
                i6 += 2;
            }
            int i7 = i6 - i4;
            if (i7 > i5 && i7 >= 4) {
                i3 = i4;
                i5 = i7;
            }
            i4 = i6 + 2;
        }
        C8037c c8037c = new C8037c();
        while (i2 < bArr.length) {
            if (i2 == i3) {
                c8037c.mo44241e4(58);
                i2 += i5;
                if (i2 == 16) {
                    c8037c.mo44241e4(58);
                }
            } else {
                if (i2 > 0) {
                    c8037c.mo44241e4(58);
                }
                c8037c.mo44261s8(((bArr[i2] & 255) << 8) | (bArr[i2 + 1] & 255));
                i2 += 2;
            }
        }
        return c8037c.m44255q();
    }

    /* JADX INFO: renamed from: v */
    public static String[] m43600v(Comparator<? super String> comparator, String[] strArr, String[] strArr2) {
        ArrayList arrayList = new ArrayList();
        for (String str : strArr) {
            for (String str2 : strArr2) {
                if (comparator.compare(str, str2) == 0) {
                    arrayList.add(str);
                    break;
                }
            }
        }
        return (String[]) arrayList.toArray(new String[arrayList.size()]);
    }

    /* JADX INFO: renamed from: w */
    public static boolean m43601w(AssertionError assertionError) {
        return (assertionError.getCause() == null || assertionError.getMessage() == null || !assertionError.getMessage().contains("getsockname failed")) ? false : true;
    }

    /* JADX INFO: renamed from: x */
    public static boolean m43602x(Comparator<String> comparator, String[] strArr, String[] strArr2) {
        if (strArr != null && strArr2 != null && strArr.length != 0 && strArr2.length != 0) {
            for (String str : strArr) {
                for (String str2 : strArr2) {
                    if (comparator.compare(str, str2) == 0) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /* JADX INFO: renamed from: y */
    public static boolean m43603y(InterfaceC8053s interfaceC8053s, int i2, TimeUnit timeUnit) {
        long jNanoTime = System.nanoTime();
        long jMo44297c = interfaceC8053s.mo43614S().mo44299e() ? interfaceC8053s.mo43614S().mo44297c() - jNanoTime : Long.MAX_VALUE;
        interfaceC8053s.mo43614S().mo44298d(Math.min(jMo44297c, timeUnit.toNanos(i2)) + jNanoTime);
        try {
            C8037c c8037c = new C8037c();
            while (interfaceC8053s.mo43613Rb(c8037c, 8192L) != -1) {
                c8037c.m44238c();
            }
            C8054t c8054tMo43614S = interfaceC8053s.mo43614S();
            if (jMo44297c == Long.MAX_VALUE) {
                c8054tMo43614S.mo44295a();
            } else {
                c8054tMo43614S.mo44298d(jNanoTime + jMo44297c);
            }
            return true;
        } catch (InterruptedIOException unused) {
            C8054t c8054tMo43614S2 = interfaceC8053s.mo43614S();
            if (jMo44297c == Long.MAX_VALUE) {
                c8054tMo43614S2.mo44295a();
            } else {
                c8054tMo43614S2.mo44298d(jNanoTime + jMo44297c);
            }
            return false;
        } catch (Throwable th) {
            C8054t c8054tMo43614S3 = interfaceC8053s.mo43614S();
            if (jMo44297c == Long.MAX_VALUE) {
                c8054tMo43614S3.mo44295a();
            } else {
                c8054tMo43614S3.mo44298d(jNanoTime + jMo44297c);
            }
            throw th;
        }
    }

    /* JADX INFO: renamed from: z */
    public static int m43604z(String str, int i2, int i3) {
        while (i2 < i3) {
            char cCharAt = str.charAt(i2);
            if (cCharAt != '\t' && cCharAt != '\n' && cCharAt != '\f' && cCharAt != '\r' && cCharAt != ' ') {
                return i2;
            }
            i2++;
        }
        return i3;
    }
}
