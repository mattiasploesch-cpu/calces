package p580l.p581f0.p582e;

import p590m.InterfaceC8052r;

/* JADX INFO: renamed from: l.f0.e.b */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC7965b {
    /* JADX INFO: renamed from: a */
    void mo43524a();

    /* JADX INFO: renamed from: b */
    InterfaceC8052r mo43525b();
}
