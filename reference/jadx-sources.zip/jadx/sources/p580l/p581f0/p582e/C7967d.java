package p580l.p581f0.p582e;

import java.io.Closeable;
import java.io.EOFException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.Flushable;
import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;
import javax.annotation.Nullable;
import p580l.p581f0.C7962c;
import p580l.p581f0.p587j.InterfaceC8003a;
import p580l.p581f0.p588k.C8009f;
import p590m.C8046l;
import p590m.InterfaceC8038d;
import p590m.InterfaceC8039e;
import p590m.InterfaceC8052r;
import p590m.InterfaceC8053s;

/* JADX INFO: renamed from: l.f0.e.d */
/* JADX INFO: loaded from: classes.dex */
public final class C7967d implements Closeable, Flushable {

    /* JADX INFO: renamed from: u2 */
    static final Pattern f50661u2 = Pattern.compile("[a-z0-9_-]{1,120}");

    /* JADX INFO: renamed from: A2 */
    private final int f50662A2;

    /* JADX INFO: renamed from: B2 */
    private long f50663B2;

    /* JADX INFO: renamed from: C2 */
    final int f50664C2;

    /* JADX INFO: renamed from: E2 */
    InterfaceC8038d f50666E2;

    /* JADX INFO: renamed from: G2 */
    int f50668G2;

    /* JADX INFO: renamed from: H2 */
    boolean f50669H2;

    /* JADX INFO: renamed from: I2 */
    boolean f50670I2;

    /* JADX INFO: renamed from: J2 */
    boolean f50671J2;

    /* JADX INFO: renamed from: K2 */
    boolean f50672K2;

    /* JADX INFO: renamed from: L2 */
    boolean f50673L2;

    /* JADX INFO: renamed from: N2 */
    private final Executor f50675N2;

    /* JADX INFO: renamed from: v2 */
    final InterfaceC8003a f50677v2;

    /* JADX INFO: renamed from: w2 */
    final File f50678w2;

    /* JADX INFO: renamed from: x2 */
    private final File f50679x2;

    /* JADX INFO: renamed from: y2 */
    private final File f50680y2;

    /* JADX INFO: renamed from: z2 */
    private final File f50681z2;

    /* JADX INFO: renamed from: D2 */
    private long f50665D2 = 0;

    /* JADX INFO: renamed from: F2 */
    final LinkedHashMap<String, d> f50667F2 = new LinkedHashMap<>(0, 0.75f, true);

    /* JADX INFO: renamed from: M2 */
    private long f50674M2 = 0;

    /* JADX INFO: renamed from: O2 */
    private final Runnable f50676O2 = new a();

    /* JADX INFO: renamed from: l.f0.e.d$a */
    /* JADX INFO: loaded from: classes2.dex */
    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            synchronized (C7967d.this) {
                C7967d c7967d = C7967d.this;
                if ((!c7967d.f50670I2) || c7967d.f50671J2) {
                    return;
                }
                try {
                    c7967d.m43640w();
                } catch (IOException unused) {
                    C7967d.this.f50672K2 = true;
                }
                try {
                    if (C7967d.this.m43636l()) {
                        C7967d.this.m43637t();
                        C7967d.this.f50668G2 = 0;
                    }
                } catch (IOException unused2) {
                    C7967d c7967d2 = C7967d.this;
                    c7967d2.f50673L2 = true;
                    c7967d2.f50666E2 = C8046l.m44312c(C8046l.m44311b());
                }
            }
        }
    }

    /* JADX INFO: renamed from: l.f0.e.d$b */
    /* JADX INFO: loaded from: classes2.dex */
    class b extends C7968e {
        b(InterfaceC8052r interfaceC8052r) {
            super(interfaceC8052r);
        }

        @Override // p580l.p581f0.p582e.C7968e
        /* JADX INFO: renamed from: c */
        protected void mo43641c(IOException iOException) {
            C7967d.this.f50669H2 = true;
        }
    }

    /* JADX INFO: renamed from: l.f0.e.d$c */
    /* JADX INFO: loaded from: classes2.dex */
    public final class c {

        /* JADX INFO: renamed from: a */
        final d f50684a;

        /* JADX INFO: renamed from: b */
        final boolean[] f50685b;

        /* JADX INFO: renamed from: c */
        private boolean f50686c;

        /* JADX INFO: renamed from: l.f0.e.d$c$a */
        class a extends C7968e {
            a(InterfaceC8052r interfaceC8052r) {
                super(interfaceC8052r);
            }

            @Override // p580l.p581f0.p582e.C7968e
            /* JADX INFO: renamed from: c */
            protected void mo43641c(IOException iOException) {
                synchronized (C7967d.this) {
                    c.this.m43644c();
                }
            }
        }

        c(d dVar) {
            this.f50684a = dVar;
            this.f50685b = dVar.f50693e ? null : new boolean[C7967d.this.f50664C2];
        }

        /* JADX INFO: renamed from: a */
        public void m43642a() {
            synchronized (C7967d.this) {
                if (this.f50686c) {
                    throw new IllegalStateException();
                }
                if (this.f50684a.f50694f == this) {
                    C7967d.this.m43629d(this, false);
                }
                this.f50686c = true;
            }
        }

        /* JADX INFO: renamed from: b */
        public void m43643b() {
            synchronized (C7967d.this) {
                if (this.f50686c) {
                    throw new IllegalStateException();
                }
                if (this.f50684a.f50694f == this) {
                    C7967d.this.m43629d(this, true);
                }
                this.f50686c = true;
            }
        }

        /* JADX INFO: renamed from: c */
        void m43644c() {
            if (this.f50684a.f50694f != this) {
                return;
            }
            int i2 = 0;
            while (true) {
                C7967d c7967d = C7967d.this;
                if (i2 >= c7967d.f50664C2) {
                    this.f50684a.f50694f = null;
                    return;
                } else {
                    try {
                        c7967d.f50677v2.mo43932f(this.f50684a.f50692d[i2]);
                    } catch (IOException unused) {
                    }
                    i2++;
                }
            }
        }

        /* JADX INFO: renamed from: d */
        public InterfaceC8052r m43645d(int i2) {
            synchronized (C7967d.this) {
                if (this.f50686c) {
                    throw new IllegalStateException();
                }
                d dVar = this.f50684a;
                if (dVar.f50694f != this) {
                    return C8046l.m44311b();
                }
                if (!dVar.f50693e) {
                    this.f50685b[i2] = true;
                }
                try {
                    return new a(C7967d.this.f50677v2.mo43928b(dVar.f50692d[i2]));
                } catch (FileNotFoundException unused) {
                    return C8046l.m44311b();
                }
            }
        }
    }

    /* JADX INFO: renamed from: l.f0.e.d$d */
    /* JADX INFO: loaded from: classes2.dex */
    private final class d {

        /* JADX INFO: renamed from: a */
        final String f50689a;

        /* JADX INFO: renamed from: b */
        final long[] f50690b;

        /* JADX INFO: renamed from: c */
        final File[] f50691c;

        /* JADX INFO: renamed from: d */
        final File[] f50692d;

        /* JADX INFO: renamed from: e */
        boolean f50693e;

        /* JADX INFO: renamed from: f */
        c f50694f;

        /* JADX INFO: renamed from: g */
        long f50695g;

        d(String str) {
            this.f50689a = str;
            int i2 = C7967d.this.f50664C2;
            this.f50690b = new long[i2];
            this.f50691c = new File[i2];
            this.f50692d = new File[i2];
            StringBuilder sb = new StringBuilder(str);
            sb.append('.');
            int length = sb.length();
            for (int i3 = 0; i3 < C7967d.this.f50664C2; i3++) {
                sb.append(i3);
                this.f50691c[i3] = new File(C7967d.this.f50678w2, sb.toString());
                sb.append(".tmp");
                this.f50692d[i3] = new File(C7967d.this.f50678w2, sb.toString());
                sb.setLength(length);
            }
        }

        /* JADX INFO: renamed from: a */
        private IOException m43646a(String[] strArr) throws IOException {
            throw new IOException("unexpected journal line: " + Arrays.toString(strArr));
        }

        /* JADX INFO: renamed from: b */
        void m43647b(String[] strArr) throws IOException {
            if (strArr.length != C7967d.this.f50664C2) {
                throw m43646a(strArr);
            }
            for (int i2 = 0; i2 < strArr.length; i2++) {
                try {
                    this.f50690b[i2] = Long.parseLong(strArr[i2]);
                } catch (NumberFormatException unused) {
                    throw m43646a(strArr);
                }
            }
        }

        /* JADX INFO: renamed from: c */
        e m43648c() {
            C7967d c7967d;
            if (!Thread.holdsLock(C7967d.this)) {
                throw new AssertionError();
            }
            InterfaceC8053s[] interfaceC8053sArr = new InterfaceC8053s[C7967d.this.f50664C2];
            long[] jArr = (long[]) this.f50690b.clone();
            int i2 = 0;
            int i3 = 0;
            while (true) {
                try {
                    C7967d c7967d2 = C7967d.this;
                    if (i3 >= c7967d2.f50664C2) {
                        return c7967d2.new e(this.f50689a, this.f50695g, interfaceC8053sArr, jArr);
                    }
                    interfaceC8053sArr[i3] = c7967d2.f50677v2.mo43927a(this.f50691c[i3]);
                    i3++;
                } catch (FileNotFoundException unused) {
                    while (true) {
                        c7967d = C7967d.this;
                        if (i2 >= c7967d.f50664C2 || interfaceC8053sArr[i2] == null) {
                            break;
                        }
                        C7962c.m43582d(interfaceC8053sArr[i2]);
                        i2++;
                    }
                    try {
                        c7967d.m43639v(this);
                        return null;
                    } catch (IOException unused2) {
                        return null;
                    }
                }
            }
        }

        /* JADX INFO: renamed from: d */
        void m43649d(InterfaceC8038d interfaceC8038d) {
            for (long j2 : this.f50690b) {
                interfaceC8038d.mo44241e4(32).mo44232Rd(j2);
            }
        }
    }

    /* JADX INFO: renamed from: l.f0.e.d$e */
    public final class e implements Closeable {

        /* JADX INFO: renamed from: u2 */
        private final String f50697u2;

        /* JADX INFO: renamed from: v2 */
        private final long f50698v2;

        /* JADX INFO: renamed from: w2 */
        private final InterfaceC8053s[] f50699w2;

        /* JADX INFO: renamed from: x2 */
        private final long[] f50700x2;

        e(String str, long j2, InterfaceC8053s[] interfaceC8053sArr, long[] jArr) {
            this.f50697u2 = str;
            this.f50698v2 = j2;
            this.f50699w2 = interfaceC8053sArr;
            this.f50700x2 = jArr;
        }

        @Nullable
        /* JADX INFO: renamed from: c */
        public c m43650c() {
            return C7967d.this.m43632h(this.f50697u2, this.f50698v2);
        }

        @Override // java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            for (InterfaceC8053s interfaceC8053s : this.f50699w2) {
                C7962c.m43582d(interfaceC8053s);
            }
        }

        /* JADX INFO: renamed from: d */
        public InterfaceC8053s m43651d(int i2) {
            return this.f50699w2[i2];
        }
    }

    C7967d(InterfaceC8003a interfaceC8003a, File file, int i2, int i3, long j2, Executor executor) {
        this.f50677v2 = interfaceC8003a;
        this.f50678w2 = file;
        this.f50662A2 = i2;
        this.f50679x2 = new File(file, "journal");
        this.f50680y2 = new File(file, "journal.tmp");
        this.f50681z2 = new File(file, "journal.bkp");
        this.f50664C2 = i3;
        this.f50663B2 = j2;
        this.f50675N2 = executor;
    }

    /* JADX INFO: renamed from: c */
    private synchronized void m43622c() {
        if (m43635k()) {
            throw new IllegalStateException("cache is closed");
        }
    }

    /* JADX INFO: renamed from: e */
    public static C7967d m43623e(InterfaceC8003a interfaceC8003a, File file, int i2, int i3, long j2) {
        if (j2 <= 0) {
            throw new IllegalArgumentException("maxSize <= 0");
        }
        if (i3 > 0) {
            return new C7967d(interfaceC8003a, file, i2, i3, j2, new ThreadPoolExecutor(0, 1, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue(), C7962c.m43576B("OkHttp DiskLruCache", true)));
        }
        throw new IllegalArgumentException("valueCount <= 0");
    }

    /* JADX INFO: renamed from: o */
    private InterfaceC8038d m43624o() {
        return C8046l.m44312c(new b(this.f50677v2.mo43933g(this.f50679x2)));
    }

    /* JADX INFO: renamed from: p */
    private void m43625p() {
        this.f50677v2.mo43932f(this.f50680y2);
        Iterator<d> it = this.f50667F2.values().iterator();
        while (it.hasNext()) {
            d next = it.next();
            int i2 = 0;
            if (next.f50694f == null) {
                while (i2 < this.f50664C2) {
                    this.f50665D2 += next.f50690b[i2];
                    i2++;
                }
            } else {
                next.f50694f = null;
                while (i2 < this.f50664C2) {
                    this.f50677v2.mo43932f(next.f50691c[i2]);
                    this.f50677v2.mo43932f(next.f50692d[i2]);
                    i2++;
                }
                it.remove();
            }
        }
    }

    /* JADX INFO: renamed from: q */
    private void m43626q() {
        InterfaceC8039e interfaceC8039eM44313d = C8046l.m44313d(this.f50677v2.mo43927a(this.f50679x2));
        try {
            String strMo44242ea = interfaceC8039eM44313d.mo44242ea();
            String strMo44242ea2 = interfaceC8039eM44313d.mo44242ea();
            String strMo44242ea3 = interfaceC8039eM44313d.mo44242ea();
            String strMo44242ea4 = interfaceC8039eM44313d.mo44242ea();
            String strMo44242ea5 = interfaceC8039eM44313d.mo44242ea();
            if (!"libcore.io.DiskLruCache".equals(strMo44242ea) || !"1".equals(strMo44242ea2) || !Integer.toString(this.f50662A2).equals(strMo44242ea3) || !Integer.toString(this.f50664C2).equals(strMo44242ea4) || !"".equals(strMo44242ea5)) {
                throw new IOException("unexpected journal header: [" + strMo44242ea + ", " + strMo44242ea2 + ", " + strMo44242ea4 + ", " + strMo44242ea5 + "]");
            }
            int i2 = 0;
            while (true) {
                try {
                    m43627s(interfaceC8039eM44313d.mo44242ea());
                    i2++;
                } catch (EOFException unused) {
                    this.f50668G2 = i2 - this.f50667F2.size();
                    if (interfaceC8039eM44313d.mo44237a4()) {
                        this.f50666E2 = m43624o();
                    } else {
                        m43637t();
                    }
                    C7962c.m43582d(interfaceC8039eM44313d);
                    return;
                }
            }
        } catch (Throwable th) {
            C7962c.m43582d(interfaceC8039eM44313d);
            throw th;
        }
    }

    /* JADX INFO: renamed from: s */
    private void m43627s(String str) throws IOException {
        String strSubstring;
        int iIndexOf = str.indexOf(32);
        if (iIndexOf == -1) {
            throw new IOException("unexpected journal line: " + str);
        }
        int i2 = iIndexOf + 1;
        int iIndexOf2 = str.indexOf(32, i2);
        if (iIndexOf2 == -1) {
            strSubstring = str.substring(i2);
            if (iIndexOf == 6 && str.startsWith("REMOVE")) {
                this.f50667F2.remove(strSubstring);
                return;
            }
        } else {
            strSubstring = str.substring(i2, iIndexOf2);
        }
        d dVar = this.f50667F2.get(strSubstring);
        if (dVar == null) {
            dVar = new d(strSubstring);
            this.f50667F2.put(strSubstring, dVar);
        }
        if (iIndexOf2 != -1 && iIndexOf == 5 && str.startsWith("CLEAN")) {
            String[] strArrSplit = str.substring(iIndexOf2 + 1).split(" ");
            dVar.f50693e = true;
            dVar.f50694f = null;
            dVar.m43647b(strArrSplit);
            return;
        }
        if (iIndexOf2 == -1 && iIndexOf == 5 && str.startsWith("DIRTY")) {
            dVar.f50694f = new c(dVar);
            return;
        }
        if (iIndexOf2 == -1 && iIndexOf == 4 && str.startsWith("READ")) {
            return;
        }
        throw new IOException("unexpected journal line: " + str);
    }

    /* JADX INFO: renamed from: x */
    private void m43628x(String str) {
        if (f50661u2.matcher(str).matches()) {
            return;
        }
        throw new IllegalArgumentException("keys must match regex [a-z0-9_-]{1,120}: \"" + str + "\"");
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public synchronized void close() {
        if (this.f50670I2 && !this.f50671J2) {
            for (d dVar : (d[]) this.f50667F2.values().toArray(new d[this.f50667F2.size()])) {
                c cVar = dVar.f50694f;
                if (cVar != null) {
                    cVar.m43642a();
                }
            }
            m43640w();
            this.f50666E2.close();
            this.f50666E2 = null;
            this.f50671J2 = true;
            return;
        }
        this.f50671J2 = true;
    }

    /* JADX INFO: renamed from: d */
    synchronized void m43629d(c cVar, boolean z) {
        d dVar = cVar.f50684a;
        if (dVar.f50694f != cVar) {
            throw new IllegalStateException();
        }
        if (z && !dVar.f50693e) {
            for (int i2 = 0; i2 < this.f50664C2; i2++) {
                if (!cVar.f50685b[i2]) {
                    cVar.m43642a();
                    throw new IllegalStateException("Newly created entry didn't create value for index " + i2);
                }
                if (!this.f50677v2.mo43930d(dVar.f50692d[i2])) {
                    cVar.m43642a();
                    return;
                }
            }
        }
        for (int i3 = 0; i3 < this.f50664C2; i3++) {
            File file = dVar.f50692d[i3];
            if (!z) {
                this.f50677v2.mo43932f(file);
            } else if (this.f50677v2.mo43930d(file)) {
                File file2 = dVar.f50691c[i3];
                this.f50677v2.mo43931e(file, file2);
                long j2 = dVar.f50690b[i3];
                long jMo43934h = this.f50677v2.mo43934h(file2);
                dVar.f50690b[i3] = jMo43934h;
                this.f50665D2 = (this.f50665D2 - j2) + jMo43934h;
            }
        }
        this.f50668G2++;
        dVar.f50694f = null;
        if (dVar.f50693e || z) {
            dVar.f50693e = true;
            this.f50666E2.mo44234T6("CLEAN").mo44241e4(32);
            this.f50666E2.mo44234T6(dVar.f50689a);
            dVar.m43649d(this.f50666E2);
            this.f50666E2.mo44241e4(10);
            if (z) {
                long j3 = this.f50674M2;
                this.f50674M2 = 1 + j3;
                dVar.f50695g = j3;
            }
        } else {
            this.f50667F2.remove(dVar.f50689a);
            this.f50666E2.mo44234T6("REMOVE").mo44241e4(32);
            this.f50666E2.mo44234T6(dVar.f50689a);
            this.f50666E2.mo44241e4(10);
        }
        this.f50666E2.flush();
        if (this.f50665D2 > this.f50663B2 || m43636l()) {
            this.f50675N2.execute(this.f50676O2);
        }
    }

    /* JADX INFO: renamed from: f */
    public void m43630f() {
        close();
        this.f50677v2.mo43929c(this.f50678w2);
    }

    @Override // java.io.Flushable
    public synchronized void flush() {
        if (this.f50670I2) {
            m43622c();
            m43640w();
            this.f50666E2.flush();
        }
    }

    @Nullable
    /* JADX INFO: renamed from: g */
    public c m43631g(String str) {
        return m43632h(str, -1L);
    }

    /* JADX INFO: renamed from: h */
    synchronized c m43632h(String str, long j2) {
        m43634j();
        m43622c();
        m43628x(str);
        d dVar = this.f50667F2.get(str);
        if (j2 != -1 && (dVar == null || dVar.f50695g != j2)) {
            return null;
        }
        if (dVar != null && dVar.f50694f != null) {
            return null;
        }
        if (!this.f50672K2 && !this.f50673L2) {
            this.f50666E2.mo44234T6("DIRTY").mo44241e4(32).mo44234T6(str).mo44241e4(10);
            this.f50666E2.flush();
            if (this.f50669H2) {
                return null;
            }
            if (dVar == null) {
                dVar = new d(str);
                this.f50667F2.put(str, dVar);
            }
            c cVar = new c(dVar);
            dVar.f50694f = cVar;
            return cVar;
        }
        this.f50675N2.execute(this.f50676O2);
        return null;
    }

    /* JADX INFO: renamed from: i */
    public synchronized e m43633i(String str) {
        m43634j();
        m43622c();
        m43628x(str);
        d dVar = this.f50667F2.get(str);
        if (dVar != null && dVar.f50693e) {
            e eVarM43648c = dVar.m43648c();
            if (eVarM43648c == null) {
                return null;
            }
            this.f50668G2++;
            this.f50666E2.mo44234T6("READ").mo44241e4(32).mo44234T6(str).mo44241e4(10);
            if (m43636l()) {
                this.f50675N2.execute(this.f50676O2);
            }
            return eVarM43648c;
        }
        return null;
    }

    /* JADX INFO: renamed from: j */
    public synchronized void m43634j() {
        if (this.f50670I2) {
            return;
        }
        if (this.f50677v2.mo43930d(this.f50681z2)) {
            if (this.f50677v2.mo43930d(this.f50679x2)) {
                this.f50677v2.mo43932f(this.f50681z2);
            } else {
                this.f50677v2.mo43931e(this.f50681z2, this.f50679x2);
            }
        }
        if (this.f50677v2.mo43930d(this.f50679x2)) {
            try {
                m43626q();
                m43625p();
                this.f50670I2 = true;
                return;
            } catch (IOException e2) {
                C8009f.m43969i().mo43946p(5, "DiskLruCache " + this.f50678w2 + " is corrupt: " + e2.getMessage() + ", removing", e2);
                try {
                    m43630f();
                    this.f50671J2 = false;
                    m43637t();
                    this.f50670I2 = true;
                } catch (Throwable th) {
                    this.f50671J2 = false;
                    throw th;
                }
            }
        }
        m43637t();
        this.f50670I2 = true;
    }

    /* JADX INFO: renamed from: k */
    public synchronized boolean m43635k() {
        return this.f50671J2;
    }

    /* JADX INFO: renamed from: l */
    boolean m43636l() {
        int i2 = this.f50668G2;
        return i2 >= 2000 && i2 >= this.f50667F2.size();
    }

    /* JADX INFO: renamed from: t */
    synchronized void m43637t() {
        InterfaceC8038d interfaceC8038d = this.f50666E2;
        if (interfaceC8038d != null) {
            interfaceC8038d.close();
        }
        InterfaceC8038d interfaceC8038dM44312c = C8046l.m44312c(this.f50677v2.mo43928b(this.f50680y2));
        try {
            interfaceC8038dM44312c.mo44234T6("libcore.io.DiskLruCache").mo44241e4(10);
            interfaceC8038dM44312c.mo44234T6("1").mo44241e4(10);
            interfaceC8038dM44312c.mo44232Rd(this.f50662A2).mo44241e4(10);
            interfaceC8038dM44312c.mo44232Rd(this.f50664C2).mo44241e4(10);
            interfaceC8038dM44312c.mo44241e4(10);
            for (d dVar : this.f50667F2.values()) {
                if (dVar.f50694f != null) {
                    interfaceC8038dM44312c.mo44234T6("DIRTY").mo44241e4(32);
                    interfaceC8038dM44312c.mo44234T6(dVar.f50689a);
                } else {
                    interfaceC8038dM44312c.mo44234T6("CLEAN").mo44241e4(32);
                    interfaceC8038dM44312c.mo44234T6(dVar.f50689a);
                    dVar.m43649d(interfaceC8038dM44312c);
                }
                interfaceC8038dM44312c.mo44241e4(10);
            }
            interfaceC8038dM44312c.close();
            if (this.f50677v2.mo43930d(this.f50679x2)) {
                this.f50677v2.mo43931e(this.f50679x2, this.f50681z2);
            }
            this.f50677v2.mo43931e(this.f50680y2, this.f50679x2);
            this.f50677v2.mo43932f(this.f50681z2);
            this.f50666E2 = m43624o();
            this.f50669H2 = false;
            this.f50673L2 = false;
        } catch (Throwable th) {
            interfaceC8038dM44312c.close();
            throw th;
        }
    }

    /* JADX INFO: renamed from: u */
    public synchronized boolean m43638u(String str) {
        m43634j();
        m43622c();
        m43628x(str);
        d dVar = this.f50667F2.get(str);
        if (dVar == null) {
            return false;
        }
        boolean zM43639v = m43639v(dVar);
        if (zM43639v && this.f50665D2 <= this.f50663B2) {
            this.f50672K2 = false;
        }
        return zM43639v;
    }

    /* JADX INFO: renamed from: v */
    boolean m43639v(d dVar) {
        c cVar = dVar.f50694f;
        if (cVar != null) {
            cVar.m43644c();
        }
        for (int i2 = 0; i2 < this.f50664C2; i2++) {
            this.f50677v2.mo43932f(dVar.f50691c[i2]);
            long j2 = this.f50665D2;
            long[] jArr = dVar.f50690b;
            this.f50665D2 = j2 - jArr[i2];
            jArr[i2] = 0;
        }
        this.f50668G2++;
        this.f50666E2.mo44234T6("REMOVE").mo44241e4(32).mo44234T6(dVar.f50689a).mo44241e4(10);
        this.f50667F2.remove(dVar.f50689a);
        if (m43636l()) {
            this.f50675N2.execute(this.f50676O2);
        }
        return true;
    }

    /* JADX INFO: renamed from: w */
    void m43640w() {
        while (this.f50665D2 > this.f50663B2) {
            m43639v(this.f50667F2.values().iterator().next());
        }
        this.f50672K2 = false;
    }
}
