package p580l.p581f0.p582e;

import p580l.C7952b0;
import p580l.C8034z;

/* JADX INFO: renamed from: l.f0.e.f */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC7969f {
    /* JADX INFO: renamed from: a */
    void mo43518a();

    /* JADX INFO: renamed from: b */
    void mo43519b(C7966c c7966c);

    /* JADX INFO: renamed from: c */
    void mo43520c(C8034z c8034z);

    /* JADX INFO: renamed from: d */
    InterfaceC7965b mo43521d(C7952b0 c7952b0);

    /* JADX INFO: renamed from: e */
    C7952b0 mo43522e(C8034z c8034z);

    /* JADX INFO: renamed from: f */
    void mo43523f(C7952b0 c7952b0, C7952b0 c7952b1);
}
