package p580l.p581f0.p582e;

import java.io.EOFException;
import java.io.IOException;
import p590m.AbstractC8041g;
import p590m.C8037c;
import p590m.InterfaceC8052r;

/* JADX INFO: renamed from: l.f0.e.e */
/* JADX INFO: loaded from: classes2.dex */
class C7968e extends AbstractC8041g {

    /* JADX INFO: renamed from: v2 */
    private boolean f50702v2;

    C7968e(InterfaceC8052r interfaceC8052r) {
        super(interfaceC8052r);
    }

    @Override // p590m.AbstractC8041g, p590m.InterfaceC8052r
    /* JADX INFO: renamed from: Z7 */
    public void mo43652Z7(C8037c c8037c, long j2) throws EOFException {
        if (this.f50702v2) {
            c8037c.mo44230M8(j2);
            return;
        }
        try {
            super.mo43652Z7(c8037c, j2);
        } catch (IOException e2) {
            this.f50702v2 = true;
            mo43641c(e2);
        }
    }

    /* JADX INFO: renamed from: c */
    protected void mo43641c(IOException iOException) {
        throw null;
    }

    @Override // p590m.AbstractC8041g, p590m.InterfaceC8052r, java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        if (this.f50702v2) {
            return;
        }
        try {
            super.close();
        } catch (IOException e2) {
            this.f50702v2 = true;
            mo43641c(e2);
        }
    }

    @Override // p590m.AbstractC8041g, p590m.InterfaceC8052r, java.io.Flushable
    public void flush() {
        if (this.f50702v2) {
            return;
        }
        try {
            super.flush();
        } catch (IOException e2) {
            this.f50702v2 = true;
            mo43641c(e2);
        }
    }
}
