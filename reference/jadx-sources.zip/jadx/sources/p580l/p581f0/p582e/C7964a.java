package p580l.p581f0.p582e;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import p580l.C7952b0;
import p580l.C8026r;
import p580l.C8034z;
import p580l.EnumC8032x;
import p580l.InterfaceC8028t;
import p580l.p581f0.AbstractC7960a;
import p580l.p581f0.C7962c;
import p580l.p581f0.p584g.C7981e;
import p580l.p581f0.p584g.C7982f;
import p580l.p581f0.p584g.C7984h;
import p590m.C8037c;
import p590m.C8046l;
import p590m.C8054t;
import p590m.InterfaceC8038d;
import p590m.InterfaceC8039e;
import p590m.InterfaceC8052r;
import p590m.InterfaceC8053s;

/* JADX INFO: renamed from: l.f0.e.a */
/* JADX INFO: loaded from: classes2.dex */
public final class C7964a implements InterfaceC8028t {

    /* JADX INFO: renamed from: a */
    final InterfaceC7969f f50641a;

    /* JADX INFO: renamed from: l.f0.e.a$a */
    class a implements InterfaceC8053s {

        /* JADX INFO: renamed from: u2 */
        boolean f50642u2;

        /* JADX INFO: renamed from: v2 */
        final /* synthetic */ InterfaceC8039e f50643v2;

        /* JADX INFO: renamed from: w2 */
        final /* synthetic */ InterfaceC7965b f50644w2;

        /* JADX INFO: renamed from: x2 */
        final /* synthetic */ InterfaceC8038d f50645x2;

        a(InterfaceC8039e interfaceC8039e, InterfaceC7965b interfaceC7965b, InterfaceC8038d interfaceC8038d) {
            this.f50643v2 = interfaceC8039e;
            this.f50644w2 = interfaceC7965b;
            this.f50645x2 = interfaceC8038d;
        }

        @Override // p590m.InterfaceC8053s
        /* JADX INFO: renamed from: Rb */
        public long mo43613Rb(C8037c c8037c, long j2) throws IOException {
            try {
                long jMo43613Rb = this.f50643v2.mo43613Rb(c8037c, j2);
                if (jMo43613Rb != -1) {
                    c8037c.m44244f(this.f50645x2.mo44257r(), c8037c.m44265u() - jMo43613Rb, jMo43613Rb);
                    this.f50645x2.mo44258r5();
                    return jMo43613Rb;
                }
                if (!this.f50642u2) {
                    this.f50642u2 = true;
                    this.f50645x2.close();
                }
                return -1L;
            } catch (IOException e2) {
                if (!this.f50642u2) {
                    this.f50642u2 = true;
                    this.f50644w2.mo43524a();
                }
                throw e2;
            }
        }

        @Override // p590m.InterfaceC8053s
        /* JADX INFO: renamed from: S */
        public C8054t mo43614S() {
            return this.f50643v2.mo43614S();
        }

        @Override // p590m.InterfaceC8053s, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            if (!this.f50642u2 && !C7962c.m43591m(this, 100, TimeUnit.MILLISECONDS)) {
                this.f50642u2 = true;
                this.f50644w2.mo43524a();
            }
            this.f50643v2.close();
        }
    }

    public C7964a(InterfaceC7969f interfaceC7969f) {
        this.f50641a = interfaceC7969f;
    }

    /* JADX INFO: renamed from: b */
    private C7952b0 m43607b(InterfaceC7965b interfaceC7965b, C7952b0 c7952b0) {
        InterfaceC8052r interfaceC8052rMo43525b;
        if (interfaceC7965b == null || (interfaceC8052rMo43525b = interfaceC7965b.mo43525b()) == null) {
            return c7952b0;
        }
        return c7952b0.m43487p().m43496b(new C7984h(c7952b0.m43481h("Content-Type"), c7952b0.m43476c().mo43526c(), C8046l.m44313d(new a(c7952b0.m43476c().mo43527f(), interfaceC7965b, C8046l.m44312c(interfaceC8052rMo43525b))))).m43497c();
    }

    /* JADX INFO: renamed from: c */
    private static C8026r m43608c(C8026r c8026r, C8026r c8026r2) {
        C8026r.a aVar = new C8026r.a();
        int iM44067f = c8026r.m44067f();
        for (int i2 = 0; i2 < iM44067f; i2++) {
            String strM44065c = c8026r.m44065c(i2);
            String strM44068g = c8026r.m44068g(i2);
            if ((!"Warning".equalsIgnoreCase(strM44065c) || !strM44068g.startsWith("1")) && (m43609d(strM44065c) || !m43610e(strM44065c) || c8026r2.m44064a(strM44065c) == null)) {
                AbstractC7960a.f50619a.mo43565b(aVar, strM44065c, strM44068g);
            }
        }
        int iM44067f2 = c8026r2.m44067f();
        for (int i3 = 0; i3 < iM44067f2; i3++) {
            String strM44065c2 = c8026r2.m44065c(i3);
            if (!m43609d(strM44065c2) && m43610e(strM44065c2)) {
                AbstractC7960a.f50619a.mo43565b(aVar, strM44065c2, c8026r2.m44068g(i3));
            }
        }
        return aVar.m44074d();
    }

    /* JADX INFO: renamed from: d */
    static boolean m43609d(String str) {
        return "Content-Length".equalsIgnoreCase(str) || "Content-Encoding".equalsIgnoreCase(str) || "Content-Type".equalsIgnoreCase(str);
    }

    /* JADX INFO: renamed from: e */
    static boolean m43610e(String str) {
        return ("Connection".equalsIgnoreCase(str) || "Keep-Alive".equalsIgnoreCase(str) || "Proxy-Authenticate".equalsIgnoreCase(str) || "Proxy-Authorization".equalsIgnoreCase(str) || "TE".equalsIgnoreCase(str) || "Trailers".equalsIgnoreCase(str) || "Transfer-Encoding".equalsIgnoreCase(str) || "Upgrade".equalsIgnoreCase(str)) ? false : true;
    }

    /* JADX INFO: renamed from: f */
    private static C7952b0 m43611f(C7952b0 c7952b0) {
        return (c7952b0 == null || c7952b0.m43476c() == null) ? c7952b0 : c7952b0.m43487p().m43496b(null).m43497c();
    }

    @Override // p580l.InterfaceC8028t
    /* JADX INFO: renamed from: a */
    public C7952b0 mo43612a(InterfaceC8028t.a aVar) {
        InterfaceC7969f interfaceC7969f = this.f50641a;
        C7952b0 c7952b0Mo43522e = interfaceC7969f != null ? interfaceC7969f.mo43522e(aVar.mo43742e()) : null;
        C7966c c7966cM43621c = new C7966c.a(System.currentTimeMillis(), aVar.mo43742e(), c7952b0Mo43522e).m43621c();
        C8034z c8034z = c7966cM43621c.f50647a;
        C7952b0 c7952b0 = c7966cM43621c.f50648b;
        InterfaceC7969f interfaceC7969f2 = this.f50641a;
        if (interfaceC7969f2 != null) {
            interfaceC7969f2.mo43519b(c7966cM43621c);
        }
        if (c7952b0Mo43522e != null && c7952b0 == null) {
            C7962c.m43582d(c7952b0Mo43522e.m43476c());
        }
        if (c8034z == null && c7952b0 == null) {
            return new C7952b0.a().m43507o(aVar.mo43742e()).m43505m(EnumC8032x.HTTP_1_1).m43499g(504).m43502j("Unsatisfiable Request (only-if-cached)").m43496b(C7962c.f50623c).m43508p(-1L).m43506n(System.currentTimeMillis()).m43497c();
        }
        if (c8034z == null) {
            return c7952b0.m43487p().m43498d(m43611f(c7952b0)).m43497c();
        }
        try {
            C7952b0 c7952b0Mo43740c = aVar.mo43740c(c8034z);
            if (c7952b0Mo43740c == null && c7952b0Mo43522e != null) {
                C7962c.m43582d(c7952b0Mo43522e.m43476c());
            }
            if (c7952b0 != null) {
                if (c7952b0Mo43740c.m43479f() == 304) {
                    C7952b0 c7952b0M43497c = c7952b0.m43487p().m43501i(m43608c(c7952b0.m43483j(), c7952b0Mo43740c.m43483j())).m43508p(c7952b0Mo43740c.m43492v()).m43506n(c7952b0Mo43740c.m43490t()).m43498d(m43611f(c7952b0)).m43503k(m43611f(c7952b0Mo43740c)).m43497c();
                    c7952b0Mo43740c.m43476c().close();
                    this.f50641a.mo43518a();
                    this.f50641a.mo43523f(c7952b0, c7952b0M43497c);
                    return c7952b0M43497c;
                }
                C7962c.m43582d(c7952b0.m43476c());
            }
            C7952b0 c7952b0M43497c2 = c7952b0Mo43740c.m43487p().m43498d(m43611f(c7952b0)).m43503k(m43611f(c7952b0Mo43740c)).m43497c();
            if (this.f50641a != null) {
                if (C7981e.m43720c(c7952b0M43497c2) && C7966c.m43615a(c7952b0M43497c2, c8034z)) {
                    return m43607b(this.f50641a.mo43521d(c7952b0M43497c2), c7952b0M43497c2);
                }
                if (C7982f.m43733a(c8034z.m44189g())) {
                    try {
                        this.f50641a.mo43520c(c8034z);
                    } catch (IOException unused) {
                    }
                }
            }
            return c7952b0M43497c2;
        } catch (Throwable th) {
            if (c7952b0Mo43522e != null) {
                C7962c.m43582d(c7952b0Mo43522e.m43476c());
            }
            throw th;
        }
    }
}
