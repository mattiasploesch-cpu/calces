package p580l.p581f0.p582e;

import java.util.Date;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;
import p356f.p372c.p375g.p381e.p421f.C7021b;
import p580l.C7952b0;
import p580l.C7955d;
import p580l.C8026r;
import p580l.C8034z;
import p580l.p581f0.AbstractC7960a;
import p580l.p581f0.p584g.C7980d;
import p580l.p581f0.p584g.C7981e;

/* JADX INFO: renamed from: l.f0.e.c */
/* JADX INFO: loaded from: classes.dex */
public final class C7966c {

    /* JADX INFO: renamed from: a */
    @Nullable
    public final C8034z f50647a;

    /* JADX INFO: renamed from: b */
    @Nullable
    public final C7952b0 f50648b;

    /* JADX INFO: renamed from: l.f0.e.c$a */
    /* JADX INFO: loaded from: classes2.dex */
    public static class a {

        /* JADX INFO: renamed from: a */
        final long f50649a;

        /* JADX INFO: renamed from: b */
        final C8034z f50650b;

        /* JADX INFO: renamed from: c */
        final C7952b0 f50651c;

        /* JADX INFO: renamed from: d */
        private Date f50652d;

        /* JADX INFO: renamed from: e */
        private String f50653e;

        /* JADX INFO: renamed from: f */
        private Date f50654f;

        /* JADX INFO: renamed from: g */
        private String f50655g;

        /* JADX INFO: renamed from: h */
        private Date f50656h;

        /* JADX INFO: renamed from: i */
        private long f50657i;

        /* JADX INFO: renamed from: j */
        private long f50658j;

        /* JADX INFO: renamed from: k */
        private String f50659k;

        /* JADX INFO: renamed from: l */
        private int f50660l;

        public a(long j2, C8034z c8034z, C7952b0 c7952b0) {
            this.f50660l = -1;
            this.f50649a = j2;
            this.f50650b = c8034z;
            this.f50651c = c7952b0;
            if (c7952b0 != null) {
                this.f50657i = c7952b0.m43492v();
                this.f50658j = c7952b0.m43490t();
                C8026r c8026rM43483j = c7952b0.m43483j();
                int iM44067f = c8026rM43483j.m44067f();
                for (int i2 = 0; i2 < iM44067f; i2++) {
                    String strM44065c = c8026rM43483j.m44065c(i2);
                    String strM44068g = c8026rM43483j.m44068g(i2);
                    if ("Date".equalsIgnoreCase(strM44065c)) {
                        this.f50652d = C7980d.m43716b(strM44068g);
                        this.f50653e = strM44068g;
                    } else if ("Expires".equalsIgnoreCase(strM44065c)) {
                        this.f50656h = C7980d.m43716b(strM44068g);
                    } else if ("Last-Modified".equalsIgnoreCase(strM44065c)) {
                        this.f50654f = C7980d.m43716b(strM44068g);
                        this.f50655g = strM44068g;
                    } else if ("ETag".equalsIgnoreCase(strM44065c)) {
                        this.f50659k = strM44068g;
                    } else if ("Age".equalsIgnoreCase(strM44065c)) {
                        this.f50660l = C7981e.m43723f(strM44068g, -1);
                    }
                }
            }
        }

        /* JADX INFO: renamed from: a */
        private long m43616a() {
            Date date = this.f50652d;
            long jMax = date != null ? Math.max(0L, this.f50658j - date.getTime()) : 0L;
            int i2 = this.f50660l;
            if (i2 != -1) {
                jMax = Math.max(jMax, TimeUnit.SECONDS.toMillis(i2));
            }
            long j2 = this.f50658j;
            return jMax + (j2 - this.f50657i) + (this.f50649a - j2);
        }

        /* JADX INFO: renamed from: b */
        private long m43617b() {
            C7955d c7955dM43477d = this.f50651c.m43477d();
            if (c7955dM43477d.m43541e() != -1) {
                return TimeUnit.SECONDS.toMillis(c7955dM43477d.m43541e());
            }
            if (this.f50656h != null) {
                Date date = this.f50652d;
                long time = this.f50656h.getTime() - (date != null ? date.getTime() : this.f50658j);
                if (time > 0) {
                    return time;
                }
                return 0L;
            }
            if (this.f50654f == null || this.f50651c.m43491u().m44191i().m44107y() != null) {
                return 0L;
            }
            Date date2 = this.f50652d;
            long time2 = (date2 != null ? date2.getTime() : this.f50657i) - this.f50654f.getTime();
            if (time2 > 0) {
                return time2 / 10;
            }
            return 0L;
        }

        /* JADX INFO: renamed from: d */
        private C7966c m43618d() {
            if (this.f50651c == null) {
                return new C7966c(this.f50650b, null);
            }
            if ((!this.f50650b.m44188f() || this.f50651c.m43480g() != null) && C7966c.m43615a(this.f50651c, this.f50650b)) {
                C7955d c7955dM44184b = this.f50650b.m44184b();
                if (c7955dM44184b.m43545i() || m43619e(this.f50650b)) {
                    return new C7966c(this.f50650b, null);
                }
                C7955d c7955dM43477d = this.f50651c.m43477d();
                if (c7955dM43477d.m43538b()) {
                    return new C7966c(null, this.f50651c);
                }
                long jM43616a = m43616a();
                long jM43617b = m43617b();
                if (c7955dM44184b.m43541e() != -1) {
                    jM43617b = Math.min(jM43617b, TimeUnit.SECONDS.toMillis(c7955dM44184b.m43541e()));
                }
                long millis = 0;
                long millis2 = c7955dM44184b.m43543g() != -1 ? TimeUnit.SECONDS.toMillis(c7955dM44184b.m43543g()) : 0L;
                if (!c7955dM43477d.m43544h() && c7955dM44184b.m43542f() != -1) {
                    millis = TimeUnit.SECONDS.toMillis(c7955dM44184b.m43542f());
                }
                if (!c7955dM43477d.m43545i()) {
                    long j2 = millis2 + jM43616a;
                    if (j2 < millis + jM43617b) {
                        C7952b0.a aVarM43487p = this.f50651c.m43487p();
                        if (j2 >= jM43617b) {
                            aVarM43487p.m43495a("Warning", "110 HttpURLConnection \"Response is stale\"");
                        }
                        if (jM43616a > 86400000 && m43620f()) {
                            aVarM43487p.m43495a("Warning", "113 HttpURLConnection \"Heuristic expiration\"");
                        }
                        return new C7966c(null, aVarM43487p.m43497c());
                    }
                }
                String str = this.f50659k;
                String str2 = "If-Modified-Since";
                if (str != null) {
                    str2 = "If-None-Match";
                } else if (this.f50654f != null) {
                    str = this.f50655g;
                } else {
                    if (this.f50652d == null) {
                        return new C7966c(this.f50650b, null);
                    }
                    str = this.f50653e;
                }
                C8026r.a aVarM44066d = this.f50650b.m44187e().m44066d();
                AbstractC7960a.f50619a.mo43565b(aVarM44066d, str2, str);
                return new C7966c(this.f50650b.m44190h().m44195d(aVarM44066d.m44074d()).m44192a(), this.f50651c);
            }
            return new C7966c(this.f50650b, null);
        }

        /* JADX INFO: renamed from: e */
        private static boolean m43619e(C8034z c8034z) {
            return (c8034z.m44185c("If-Modified-Since") == null && c8034z.m44185c("If-None-Match") == null) ? false : true;
        }

        /* JADX INFO: renamed from: f */
        private boolean m43620f() {
            return this.f50651c.m43477d().m43541e() == -1 && this.f50656h == null;
        }

        /* JADX INFO: renamed from: c */
        public C7966c m43621c() {
            C7966c c7966cM43618d = m43618d();
            return (c7966cM43618d.f50647a == null || !this.f50650b.m44184b().m43547k()) ? c7966cM43618d : new C7966c(null, null);
        }
    }

    C7966c(C8034z c8034z, C7952b0 c7952b0) {
        this.f50647a = c8034z;
        this.f50648b = c7952b0;
    }

    /* JADX WARN: Code restructure failed: missing block: B:31:0x0056, code lost:
    
        if (r3.m43477d().m43539c() == false) goto L33;
     */
    /* JADX INFO: renamed from: a */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static boolean m43615a(C7952b0 c7952b0, C8034z c8034z) {
        int iM43479f = c7952b0.m43479f();
        if (iM43479f != 200 && iM43479f != 410 && iM43479f != 414 && iM43479f != 501 && iM43479f != 203 && iM43479f != 204) {
            if (iM43479f != 307) {
                if (iM43479f != 308 && iM43479f != 404 && iM43479f != 405) {
                    switch (iM43479f) {
                        case C7021b.f45409a /* 300 */:
                        case 301:
                            break;
                        case 302:
                            break;
                        default:
                            return false;
                    }
                }
            }
            if (c7952b0.m43481h("Expires") == null) {
                if (c7952b0.m43477d().m43541e() == -1) {
                    if (!c7952b0.m43477d().m43540d()) {
                    }
                }
            }
        }
        return (c7952b0.m43477d().m43546j() || c8034z.m44184b().m43546j()) ? false : true;
    }
}
