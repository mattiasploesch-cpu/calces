package p580l.p581f0.p589l;

import java.security.GeneralSecurityException;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.net.ssl.SSLPeerUnverifiedException;

/* JADX INFO: renamed from: l.f0.l.a */
/* JADX INFO: loaded from: classes2.dex */
public final class C8010a extends AbstractC8012c {

    /* JADX INFO: renamed from: a */
    private final InterfaceC8014e f51012a;

    public C8010a(InterfaceC8014e interfaceC8014e) {
        this.f51012a = interfaceC8014e;
    }

    /* JADX INFO: renamed from: c */
    private boolean m43972c(X509Certificate x509Certificate, X509Certificate x509Certificate2) {
        if (!x509Certificate.getIssuerDN().equals(x509Certificate2.getSubjectDN())) {
            return false;
        }
        try {
            x509Certificate.verify(x509Certificate2.getPublicKey());
            return true;
        } catch (GeneralSecurityException unused) {
            return false;
        }
    }

    @Override // p580l.p581f0.p589l.AbstractC8012c
    /* JADX INFO: renamed from: a */
    public List<Certificate> mo43948a(List<Certificate> list, String str) throws SSLPeerUnverifiedException {
        X509Certificate x509Certificate;
        ArrayDeque arrayDeque = new ArrayDeque(list);
        ArrayList arrayList = new ArrayList();
        arrayList.add(arrayDeque.removeFirst());
        boolean z = false;
        for (int i2 = 0; i2 < 9; i2++) {
            X509Certificate x509Certificate2 = (X509Certificate) arrayList.get(arrayList.size() - 1);
            X509Certificate x509CertificateMo43949a = this.f51012a.mo43949a(x509Certificate2);
            if (x509CertificateMo43949a != null) {
                if (arrayList.size() > 1 || !x509Certificate2.equals(x509CertificateMo43949a)) {
                    arrayList.add(x509CertificateMo43949a);
                }
                if (m43972c(x509CertificateMo43949a, x509CertificateMo43949a)) {
                    return arrayList;
                }
                z = true;
            } else {
                Iterator it = arrayDeque.iterator();
                do {
                    if (!it.hasNext()) {
                        if (z) {
                            return arrayList;
                        }
                        throw new SSLPeerUnverifiedException("Failed to find a trusted cert that signed " + x509Certificate2);
                    }
                    x509Certificate = (X509Certificate) it.next();
                } while (!m43972c(x509Certificate2, x509Certificate));
                it.remove();
                arrayList.add(x509Certificate);
            }
        }
        throw new SSLPeerUnverifiedException("Certificate chain too long: " + arrayList);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        return (obj instanceof C8010a) && ((C8010a) obj).f51012a.equals(this.f51012a);
    }

    public int hashCode() {
        return this.f51012a.hashCode();
    }
}
