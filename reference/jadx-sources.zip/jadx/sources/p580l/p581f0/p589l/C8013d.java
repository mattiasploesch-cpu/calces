package p580l.p581f0.p589l;

import java.security.cert.CertificateParsingException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSession;
import p580l.p581f0.C7962c;

/* JADX INFO: renamed from: l.f0.l.d */
/* JADX INFO: loaded from: classes2.dex */
public final class C8013d implements HostnameVerifier {

    /* JADX INFO: renamed from: a */
    public static final C8013d f51014a = new C8013d();

    private C8013d() {
    }

    /* JADX INFO: renamed from: a */
    public static List<String> m43974a(X509Certificate x509Certificate) {
        List<String> listM43975b = m43975b(x509Certificate, 7);
        List<String> listM43975b2 = m43975b(x509Certificate, 2);
        ArrayList arrayList = new ArrayList(listM43975b.size() + listM43975b2.size());
        arrayList.addAll(listM43975b);
        arrayList.addAll(listM43975b2);
        return arrayList;
    }

    /* JADX INFO: renamed from: b */
    private static List<String> m43975b(X509Certificate x509Certificate, int i2) {
        Integer num;
        String str;
        ArrayList arrayList = new ArrayList();
        try {
            Collection<List<?>> subjectAlternativeNames = x509Certificate.getSubjectAlternativeNames();
            if (subjectAlternativeNames == null) {
                return Collections.emptyList();
            }
            for (List<?> list : subjectAlternativeNames) {
                if (list != null && list.size() >= 2 && (num = (Integer) list.get(0)) != null && num.intValue() == i2 && (str = (String) list.get(1)) != null) {
                    arrayList.add(str);
                }
            }
            return arrayList;
        } catch (CertificateParsingException unused) {
            return Collections.emptyList();
        }
    }

    /* JADX INFO: renamed from: e */
    private boolean m43976e(String str, X509Certificate x509Certificate) {
        String lowerCase = str.toLowerCase(Locale.US);
        Iterator<String> it = m43975b(x509Certificate, 2).iterator();
        while (it.hasNext()) {
            if (m43979d(lowerCase, it.next())) {
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: renamed from: f */
    private boolean m43977f(String str, X509Certificate x509Certificate) {
        List<String> listM43975b = m43975b(x509Certificate, 7);
        int size = listM43975b.size();
        for (int i2 = 0; i2 < size; i2++) {
            if (str.equalsIgnoreCase(listM43975b.get(i2))) {
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: renamed from: c */
    public boolean m43978c(String str, X509Certificate x509Certificate) {
        return C7962c.m43578D(str) ? m43977f(str, x509Certificate) : m43976e(str, x509Certificate);
    }

    /* JADX INFO: renamed from: d */
    public boolean m43979d(String str, String str2) {
        if (str != null && str.length() != 0 && !str.startsWith(".") && !str.endsWith("..") && str2 != null && str2.length() != 0 && !str2.startsWith(".") && !str2.endsWith("..")) {
            if (!str.endsWith(".")) {
                str = str + '.';
            }
            if (!str2.endsWith(".")) {
                str2 = str2 + '.';
            }
            String lowerCase = str2.toLowerCase(Locale.US);
            if (!lowerCase.contains("*")) {
                return str.equals(lowerCase);
            }
            if (!lowerCase.startsWith("*.") || lowerCase.indexOf(42, 1) != -1 || str.length() < lowerCase.length() || "*.".equals(lowerCase)) {
                return false;
            }
            String strSubstring = lowerCase.substring(1);
            if (!str.endsWith(strSubstring)) {
                return false;
            }
            int length = str.length() - strSubstring.length();
            return length <= 0 || str.lastIndexOf(46, length - 1) == -1;
        }
        return false;
    }

    @Override // javax.net.ssl.HostnameVerifier
    public boolean verify(String str, SSLSession sSLSession) {
        try {
            return m43978c(str, (X509Certificate) sSLSession.getPeerCertificates()[0]);
        } catch (SSLException unused) {
            return false;
        }
    }
}
