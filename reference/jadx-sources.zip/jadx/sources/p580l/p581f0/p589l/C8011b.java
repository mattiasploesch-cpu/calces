package p580l.p581f0.p589l;

import java.security.cert.X509Certificate;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import javax.security.auth.x500.X500Principal;

/* JADX INFO: renamed from: l.f0.l.b */
/* JADX INFO: loaded from: classes2.dex */
public final class C8011b implements InterfaceC8014e {

    /* JADX INFO: renamed from: a */
    private final Map<X500Principal, Set<X509Certificate>> f51013a = new LinkedHashMap();

    public C8011b(X509Certificate... x509CertificateArr) {
        for (X509Certificate x509Certificate : x509CertificateArr) {
            X500Principal subjectX500Principal = x509Certificate.getSubjectX500Principal();
            Set<X509Certificate> linkedHashSet = this.f51013a.get(subjectX500Principal);
            if (linkedHashSet == null) {
                linkedHashSet = new LinkedHashSet<>(1);
                this.f51013a.put(subjectX500Principal, linkedHashSet);
            }
            linkedHashSet.add(x509Certificate);
        }
    }

    @Override // p580l.p581f0.p589l.InterfaceC8014e
    /* JADX INFO: renamed from: a */
    public X509Certificate mo43949a(X509Certificate x509Certificate) {
        Set<X509Certificate> set = this.f51013a.get(x509Certificate.getIssuerX500Principal());
        if (set == null) {
            return null;
        }
        for (X509Certificate x509Certificate2 : set) {
            try {
                x509Certificate.verify(x509Certificate2.getPublicKey());
                return x509Certificate2;
            } catch (Exception unused) {
            }
        }
        return null;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        return (obj instanceof C8011b) && ((C8011b) obj).f51013a.equals(this.f51013a);
    }

    public int hashCode() {
        return this.f51013a.hashCode();
    }
}
