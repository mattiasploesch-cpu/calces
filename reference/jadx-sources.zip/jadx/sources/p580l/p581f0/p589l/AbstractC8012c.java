package p580l.p581f0.p589l;

import java.security.cert.Certificate;
import java.util.List;
import javax.net.ssl.X509TrustManager;
import p580l.p581f0.p588k.C8009f;

/* JADX INFO: renamed from: l.f0.l.c */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC8012c {
    /* JADX INFO: renamed from: b */
    public static AbstractC8012c m43973b(X509TrustManager x509TrustManager) {
        return C8009f.m43969i().mo43939c(x509TrustManager);
    }

    /* JADX INFO: renamed from: a */
    public abstract List<Certificate> mo43948a(List<Certificate> list, String str);
}
