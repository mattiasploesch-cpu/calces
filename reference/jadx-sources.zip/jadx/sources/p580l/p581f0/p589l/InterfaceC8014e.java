package p580l.p581f0.p589l;

import java.security.cert.X509Certificate;

/* JADX INFO: renamed from: l.f0.l.e */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC8014e {
    /* JADX INFO: renamed from: a */
    X509Certificate mo43949a(X509Certificate x509Certificate);
}
