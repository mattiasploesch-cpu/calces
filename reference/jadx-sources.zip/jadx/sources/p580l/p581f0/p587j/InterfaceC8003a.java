package p580l.p581f0.p587j;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import p590m.C8046l;
import p590m.InterfaceC8052r;
import p590m.InterfaceC8053s;

/* JADX INFO: renamed from: l.f0.j.a */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC8003a {

    /* JADX INFO: renamed from: a */
    public static final InterfaceC8003a f50983a = new a();

    /* JADX INFO: renamed from: l.f0.j.a$a */
    final class a implements InterfaceC8003a {
        a() {
        }

        @Override // p580l.p581f0.p587j.InterfaceC8003a
        /* JADX INFO: renamed from: a */
        public InterfaceC8053s mo43927a(File file) {
            return C8046l.m44319j(file);
        }

        @Override // p580l.p581f0.p587j.InterfaceC8003a
        /* JADX INFO: renamed from: b */
        public InterfaceC8052r mo43928b(File file) {
            try {
                return C8046l.m44315f(file);
            } catch (FileNotFoundException unused) {
                file.getParentFile().mkdirs();
                return C8046l.m44315f(file);
            }
        }

        @Override // p580l.p581f0.p587j.InterfaceC8003a
        /* JADX INFO: renamed from: c */
        public void mo43929c(File file) throws IOException {
            File[] fileArrListFiles = file.listFiles();
            if (fileArrListFiles == null) {
                throw new IOException("not a readable directory: " + file);
            }
            for (File file2 : fileArrListFiles) {
                if (file2.isDirectory()) {
                    mo43929c(file2);
                }
                if (!file2.delete()) {
                    throw new IOException("failed to delete " + file2);
                }
            }
        }

        @Override // p580l.p581f0.p587j.InterfaceC8003a
        /* JADX INFO: renamed from: d */
        public boolean mo43930d(File file) {
            return file.exists();
        }

        @Override // p580l.p581f0.p587j.InterfaceC8003a
        /* JADX INFO: renamed from: e */
        public void mo43931e(File file, File file2) throws IOException {
            mo43932f(file2);
            if (file.renameTo(file2)) {
                return;
            }
            throw new IOException("failed to rename " + file + " to " + file2);
        }

        @Override // p580l.p581f0.p587j.InterfaceC8003a
        /* JADX INFO: renamed from: f */
        public void mo43932f(File file) throws IOException {
            if (file.delete() || !file.exists()) {
                return;
            }
            throw new IOException("failed to delete " + file);
        }

        @Override // p580l.p581f0.p587j.InterfaceC8003a
        /* JADX INFO: renamed from: g */
        public InterfaceC8052r mo43933g(File file) {
            try {
                return C8046l.m44310a(file);
            } catch (FileNotFoundException unused) {
                file.getParentFile().mkdirs();
                return C8046l.m44310a(file);
            }
        }

        @Override // p580l.p581f0.p587j.InterfaceC8003a
        /* JADX INFO: renamed from: h */
        public long mo43934h(File file) {
            return file.length();
        }
    }

    /* JADX INFO: renamed from: a */
    InterfaceC8053s mo43927a(File file);

    /* JADX INFO: renamed from: b */
    InterfaceC8052r mo43928b(File file);

    /* JADX INFO: renamed from: c */
    void mo43929c(File file);

    /* JADX INFO: renamed from: d */
    boolean mo43930d(File file);

    /* JADX INFO: renamed from: e */
    void mo43931e(File file, File file2);

    /* JADX INFO: renamed from: f */
    void mo43932f(File file);

    /* JADX INFO: renamed from: g */
    InterfaceC8052r mo43933g(File file);

    /* JADX INFO: renamed from: h */
    long mo43934h(File file);
}
