package p580l.p581f0.p584g;

import p580l.AbstractC7954c0;
import p580l.C7952b0;
import p580l.C8034z;
import p590m.InterfaceC8052r;

/* JADX INFO: renamed from: l.f0.g.c */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC7979c {
    /* JADX INFO: renamed from: a */
    void mo43709a();

    /* JADX INFO: renamed from: b */
    void mo43710b(C8034z c8034z);

    /* JADX INFO: renamed from: c */
    AbstractC7954c0 mo43711c(C7952b0 c7952b0);

    /* JADX INFO: renamed from: d */
    C7952b0.a mo43712d(boolean z);

    /* JADX INFO: renamed from: e */
    void mo43713e();

    /* JADX INFO: renamed from: f */
    InterfaceC8052r mo43714f(C8034z c8034z, long j2);
}
