package p580l.p581f0.p584g;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Pattern;
import p580l.C7952b0;
import p580l.C8020l;
import p580l.C8026r;
import p580l.C8027s;
import p580l.C8034z;
import p580l.InterfaceC8021m;
import p580l.p581f0.C7962c;

/* JADX INFO: renamed from: l.f0.g.e */
/* JADX INFO: loaded from: classes2.dex */
public final class C7981e {

    /* JADX INFO: renamed from: a */
    private static final Pattern f50756a = Pattern.compile(" +([^ \"=]*)=(:?\"([^\"]*)\"|([^ \"=]*)) *(:?,|$)");

    /* JADX INFO: renamed from: a */
    public static long m43718a(C8026r c8026r) {
        return m43727j(c8026r.m44064a("Content-Length"));
    }

    /* JADX INFO: renamed from: b */
    public static long m43719b(C7952b0 c7952b0) {
        return m43718a(c7952b0.m43483j());
    }

    /* JADX INFO: renamed from: c */
    public static boolean m43720c(C7952b0 c7952b0) {
        if (c7952b0.m43491u().m44189g().equals("HEAD")) {
            return false;
        }
        int iM43479f = c7952b0.m43479f();
        return (((iM43479f >= 100 && iM43479f < 200) || iM43479f == 204 || iM43479f == 304) && m43719b(c7952b0) == -1 && !"chunked".equalsIgnoreCase(c7952b0.m43481h("Transfer-Encoding"))) ? false : true;
    }

    /* JADX INFO: renamed from: d */
    public static boolean m43721d(C8026r c8026r) {
        return m43728k(c8026r).contains("*");
    }

    /* JADX INFO: renamed from: e */
    public static boolean m43722e(C7952b0 c7952b0) {
        return m43721d(c7952b0.m43483j());
    }

    /* JADX INFO: renamed from: f */
    public static int m43723f(String str, int i2) {
        try {
            long j2 = Long.parseLong(str);
            if (j2 > 2147483647L) {
                return Integer.MAX_VALUE;
            }
            if (j2 < 0) {
                return 0;
            }
            return (int) j2;
        } catch (NumberFormatException unused) {
            return i2;
        }
    }

    /* JADX INFO: renamed from: g */
    public static void m43724g(InterfaceC8021m interfaceC8021m, C8027s c8027s, C8026r c8026r) {
        if (interfaceC8021m == InterfaceC8021m.f51171a) {
            return;
        }
        List<C8020l> listM44016f = C8020l.m44016f(c8027s, c8026r);
        if (listM44016f.isEmpty()) {
            return;
        }
        interfaceC8021m.mo44023a(c8027s, listM44016f);
    }

    /* JADX INFO: renamed from: h */
    public static int m43725h(String str, int i2, String str2) {
        while (i2 < str.length() && str2.indexOf(str.charAt(i2)) == -1) {
            i2++;
        }
        return i2;
    }

    /* JADX INFO: renamed from: i */
    public static int m43726i(String str, int i2) {
        char cCharAt;
        while (i2 < str.length() && ((cCharAt = str.charAt(i2)) == ' ' || cCharAt == '\t')) {
            i2++;
        }
        return i2;
    }

    /* JADX INFO: renamed from: j */
    private static long m43727j(String str) {
        if (str == null) {
            return -1L;
        }
        try {
            return Long.parseLong(str);
        } catch (NumberFormatException unused) {
            return -1L;
        }
    }

    /* JADX INFO: renamed from: k */
    public static Set<String> m43728k(C8026r c8026r) {
        Set<String> setEmptySet = Collections.emptySet();
        int iM44067f = c8026r.m44067f();
        for (int i2 = 0; i2 < iM44067f; i2++) {
            if ("Vary".equalsIgnoreCase(c8026r.m44065c(i2))) {
                String strM44068g = c8026r.m44068g(i2);
                if (setEmptySet.isEmpty()) {
                    setEmptySet = new TreeSet<>((Comparator<? super String>) String.CASE_INSENSITIVE_ORDER);
                }
                for (String str : strM44068g.split(",")) {
                    setEmptySet.add(str.trim());
                }
            }
        }
        return setEmptySet;
    }

    /* JADX INFO: renamed from: l */
    private static Set<String> m43729l(C7952b0 c7952b0) {
        return m43728k(c7952b0.m43483j());
    }

    /* JADX INFO: renamed from: m */
    public static C8026r m43730m(C8026r c8026r, C8026r c8026r2) {
        Set<String> setM43728k = m43728k(c8026r2);
        if (setM43728k.isEmpty()) {
            return new C8026r.a().m44074d();
        }
        C8026r.a aVar = new C8026r.a();
        int iM44067f = c8026r.m44067f();
        for (int i2 = 0; i2 < iM44067f; i2++) {
            String strM44065c = c8026r.m44065c(i2);
            if (setM43728k.contains(strM44065c)) {
                aVar.m44071a(strM44065c, c8026r.m44068g(i2));
            }
        }
        return aVar.m44074d();
    }

    /* JADX INFO: renamed from: n */
    public static C8026r m43731n(C7952b0 c7952b0) {
        return m43730m(c7952b0.m43486o().m43491u().m44187e(), c7952b0.m43483j());
    }

    /* JADX INFO: renamed from: o */
    public static boolean m43732o(C7952b0 c7952b0, C8026r c8026r, C8034z c8034z) {
        for (String str : m43729l(c7952b0)) {
            if (!C7962c.m43592n(c8026r.m44069h(str), c8034z.m44186d(str))) {
                return false;
            }
        }
        return true;
    }
}
