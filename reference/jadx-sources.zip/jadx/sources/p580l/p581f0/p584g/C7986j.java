package p580l.p581f0.p584g;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.ProtocolException;
import java.net.Proxy;
import java.net.SocketTimeoutException;
import java.security.cert.CertificateException;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSocketFactory;
import p356f.p372c.p375g.p381e.p421f.C7021b;
import p580l.AbstractC8024p;
import p580l.C7949a;
import p580l.C7952b0;
import p580l.C7956d0;
import p580l.C8015g;
import p580l.C8027s;
import p580l.C8031w;
import p580l.C8034z;
import p580l.InterfaceC7957e;
import p580l.InterfaceC8028t;
import p580l.p581f0.C7962c;
import p580l.p581f0.p583f.C7974e;
import p580l.p581f0.p583f.C7976g;
import p580l.p581f0.p586i.C7989a;

/* JADX INFO: renamed from: l.f0.g.j */
/* JADX INFO: loaded from: classes2.dex */
public final class C7986j implements InterfaceC8028t {

    /* JADX INFO: renamed from: a */
    private final C8031w f50772a;

    /* JADX INFO: renamed from: b */
    private final boolean f50773b;

    /* JADX INFO: renamed from: c */
    private volatile C7976g f50774c;

    /* JADX INFO: renamed from: d */
    private Object f50775d;

    /* JADX INFO: renamed from: e */
    private volatile boolean f50776e;

    public C7986j(C8031w c8031w, boolean z) {
        this.f50772a = c8031w;
        this.f50773b = z;
    }

    /* JADX INFO: renamed from: b */
    private C7949a m43752b(C8027s c8027s) {
        SSLSocketFactory sSLSocketFactory;
        HostnameVerifier hostnameVerifierM44158o;
        C8015g c8015gM44148d;
        if (c8027s.m44103m()) {
            SSLSocketFactory sSLSocketFactoryM44144A = this.f50772a.m44144A();
            hostnameVerifierM44158o = this.f50772a.m44158o();
            sSLSocketFactory = sSLSocketFactoryM44144A;
            c8015gM44148d = this.f50772a.m44148d();
        } else {
            sSLSocketFactory = null;
            hostnameVerifierM44158o = null;
            c8015gM44148d = null;
        }
        return new C7949a(c8027s.m44102l(), c8027s.m44106x(), this.f50772a.m44154j(), this.f50772a.m44169z(), sSLSocketFactory, hostnameVerifierM44158o, c8015gM44148d, this.f50772a.m44165v(), this.f50772a.m44164u(), this.f50772a.m44163t(), this.f50772a.m44151g(), this.f50772a.m44166w());
    }

    /* JADX INFO: renamed from: c */
    private C8034z m43753c(C7952b0 c7952b0, C7956d0 c7956d0) throws ProtocolException {
        String strM43481h;
        C8027s c8027sM44093B;
        if (c7952b0 == null) {
            throw new IllegalStateException();
        }
        int iM43479f = c7952b0.m43479f();
        String strM44189g = c7952b0.m43491u().m44189g();
        if (iM43479f == 307 || iM43479f == 308) {
            if (!strM44189g.equals("GET") && !strM44189g.equals("HEAD")) {
                return null;
            }
        } else {
            if (iM43479f == 401) {
                return this.f50772a.m44146b().mo43475a(c7956d0, c7952b0);
            }
            if (iM43479f == 503) {
                if ((c7952b0.m43488q() == null || c7952b0.m43488q().m43479f() != 503) && m43756g(c7952b0, Integer.MAX_VALUE) == 0) {
                    return c7952b0.m43491u();
                }
                return null;
            }
            if (iM43479f == 407) {
                if ((c7956d0 != null ? c7956d0.m43554b() : this.f50772a.m44164u()).type() == Proxy.Type.HTTP) {
                    return this.f50772a.m44165v().mo43475a(c7956d0, c7952b0);
                }
                throw new ProtocolException("Received HTTP_PROXY_AUTH (407) code while not using proxy");
            }
            if (iM43479f == 408) {
                if (!this.f50772a.m44168y()) {
                    return null;
                }
                c7952b0.m43491u().m44183a();
                if ((c7952b0.m43488q() == null || c7952b0.m43488q().m43479f() != 408) && m43756g(c7952b0, 0) <= 0) {
                    return c7952b0.m43491u();
                }
                return null;
            }
            switch (iM43479f) {
                case C7021b.f45409a /* 300 */:
                case 301:
                case 302:
                case 303:
                    break;
                default:
                    return null;
            }
        }
        if (!this.f50772a.m44156m() || (strM43481h = c7952b0.m43481h("Location")) == null || (c8027sM44093B = c7952b0.m43491u().m44191i().m44093B(strM43481h)) == null) {
            return null;
        }
        if (!c8027sM44093B.m44094C().equals(c7952b0.m43491u().m44191i().m44094C()) && !this.f50772a.m44157n()) {
            return null;
        }
        C8034z.a aVarM44190h = c7952b0.m43491u().m44190h();
        if (C7982f.m43734b(strM44189g)) {
            boolean zM43736d = C7982f.m43736d(strM44189g);
            if (C7982f.m43735c(strM44189g)) {
                aVarM44190h.m44196e("GET", null);
            } else {
                aVarM44190h.m44196e(strM44189g, zM43736d ? c7952b0.m43491u().m44183a() : null);
            }
            if (!zM43736d) {
                aVarM44190h.m44198g("Transfer-Encoding");
                aVarM44190h.m44198g("Content-Length");
                aVarM44190h.m44198g("Content-Type");
            }
        }
        if (!m43757h(c7952b0, c8027sM44093B)) {
            aVarM44190h.m44198g("Authorization");
        }
        return aVarM44190h.m44201j(c8027sM44093B).m44192a();
    }

    /* JADX INFO: renamed from: e */
    private boolean m43754e(IOException iOException, boolean z) {
        if (iOException instanceof ProtocolException) {
            return false;
        }
        if (iOException instanceof InterruptedIOException) {
            return (iOException instanceof SocketTimeoutException) && !z;
        }
        return (((iOException instanceof SSLHandshakeException) && (iOException.getCause() instanceof CertificateException)) || (iOException instanceof SSLPeerUnverifiedException)) ? false : true;
    }

    /* JADX INFO: renamed from: f */
    private boolean m43755f(IOException iOException, C7976g c7976g, boolean z, C8034z c8034z) {
        c7976g.m43706p(iOException);
        if (!this.f50772a.m44168y()) {
            return false;
        }
        if (z) {
            c8034z.m44183a();
        }
        return m43754e(iOException, z) && c7976g.m43700g();
    }

    /* JADX INFO: renamed from: g */
    private int m43756g(C7952b0 c7952b0, int i2) {
        String strM43481h = c7952b0.m43481h("Retry-After");
        if (strM43481h == null) {
            return i2;
        }
        if (strM43481h.matches("\\d+")) {
            return Integer.valueOf(strM43481h).intValue();
        }
        return Integer.MAX_VALUE;
    }

    /* JADX INFO: renamed from: h */
    private boolean m43757h(C7952b0 c7952b0, C8027s c8027s) {
        C8027s c8027sM44191i = c7952b0.m43491u().m44191i();
        return c8027sM44191i.m44102l().equals(c8027s.m44102l()) && c8027sM44191i.m44106x() == c8027s.m44106x() && c8027sM44191i.m44094C().equals(c8027s.m44094C());
    }

    @Override // p580l.InterfaceC8028t
    /* JADX INFO: renamed from: a */
    public C7952b0 mo43612a(InterfaceC8028t.a aVar) throws IOException {
        C8034z c8034zMo43742e = aVar.mo43742e();
        C7983g c7983g = (C7983g) aVar;
        InterfaceC7957e interfaceC7957eM43743f = c7983g.m43743f();
        AbstractC8024p abstractC8024pM43745h = c7983g.m43745h();
        C7976g c7976g = new C7976g(this.f50772a.m44150f(), m43752b(c8034zMo43742e.m44191i()), interfaceC7957eM43743f, abstractC8024pM43745h, this.f50775d);
        this.f50774c = c7976g;
        C7952b0 c7952b0 = null;
        int i2 = 0;
        while (!this.f50776e) {
            try {
                try {
                    C7952b0 c7952b0M43747j = c7983g.m43747j(c8034zMo43742e, c7976g, null, null);
                    if (c7952b0 != null) {
                        c7952b0M43747j = c7952b0M43747j.m43487p().m43504l(c7952b0.m43487p().m43496b(null).m43497c()).m43497c();
                    }
                    C8034z c8034zM43753c = m43753c(c7952b0M43747j, c7976g.m43705n());
                    if (c8034zM43753c == null) {
                        if (!this.f50773b) {
                            c7976g.m43703j();
                        }
                        return c7952b0M43747j;
                    }
                    C7962c.m43582d(c7952b0M43747j.m43476c());
                    int i3 = i2 + 1;
                    if (i3 > 20) {
                        c7976g.m43703j();
                        throw new ProtocolException("Too many follow-up requests: " + i3);
                    }
                    c8034zM43753c.m44183a();
                    if (!m43757h(c7952b0M43747j, c8034zM43753c.m44191i())) {
                        c7976g.m43703j();
                        c7976g = new C7976g(this.f50772a.m44150f(), m43752b(c8034zM43753c.m44191i()), interfaceC7957eM43743f, abstractC8024pM43745h, this.f50775d);
                        this.f50774c = c7976g;
                    } else if (c7976g.m43698b() != null) {
                        throw new IllegalStateException("Closing the body of " + c7952b0M43747j + " didn't close its backing stream. Bad interceptor?");
                    }
                    c7952b0 = c7952b0M43747j;
                    c8034zMo43742e = c8034zM43753c;
                    i2 = i3;
                } catch (IOException e2) {
                    if (!m43755f(e2, c7976g, !(e2 instanceof C7989a), c8034zMo43742e)) {
                        throw e2;
                    }
                } catch (C7974e e3) {
                    if (!m43755f(e3.m43679c(), c7976g, false, c8034zMo43742e)) {
                        throw e3.m43679c();
                    }
                }
            } catch (Throwable th) {
                c7976g.m43706p(null);
                c7976g.m43703j();
                throw th;
            }
        }
        c7976g.m43703j();
        throw new IOException("Canceled");
    }

    /* JADX INFO: renamed from: d */
    public boolean m43758d() {
        return this.f50776e;
    }

    /* JADX INFO: renamed from: i */
    public void m43759i(Object obj) {
        this.f50775d = obj;
    }
}
