package p580l.p581f0.p584g;

import java.util.List;
import p580l.AbstractC8024p;
import p580l.C7952b0;
import p580l.C8034z;
import p580l.InterfaceC7957e;
import p580l.InterfaceC8017i;
import p580l.InterfaceC8028t;
import p580l.p581f0.p583f.C7972c;
import p580l.p581f0.p583f.C7976g;

/* JADX INFO: renamed from: l.f0.g.g */
/* JADX INFO: loaded from: classes2.dex */
public final class C7983g implements InterfaceC8028t.a {

    /* JADX INFO: renamed from: a */
    private final List<InterfaceC8028t> f50757a;

    /* JADX INFO: renamed from: b */
    private final C7976g f50758b;

    /* JADX INFO: renamed from: c */
    private final InterfaceC7979c f50759c;

    /* JADX INFO: renamed from: d */
    private final C7972c f50760d;

    /* JADX INFO: renamed from: e */
    private final int f50761e;

    /* JADX INFO: renamed from: f */
    private final C8034z f50762f;

    /* JADX INFO: renamed from: g */
    private final InterfaceC7957e f50763g;

    /* JADX INFO: renamed from: h */
    private final AbstractC8024p f50764h;

    /* JADX INFO: renamed from: i */
    private final int f50765i;

    /* JADX INFO: renamed from: j */
    private final int f50766j;

    /* JADX INFO: renamed from: k */
    private final int f50767k;

    /* JADX INFO: renamed from: l */
    private int f50768l;

    public C7983g(List<InterfaceC8028t> list, C7976g c7976g, InterfaceC7979c interfaceC7979c, C7972c c7972c, int i2, C8034z c8034z, InterfaceC7957e interfaceC7957e, AbstractC8024p abstractC8024p, int i3, int i4, int i5) {
        this.f50757a = list;
        this.f50760d = c7972c;
        this.f50758b = c7976g;
        this.f50759c = interfaceC7979c;
        this.f50761e = i2;
        this.f50762f = c8034z;
        this.f50763g = interfaceC7957e;
        this.f50764h = abstractC8024p;
        this.f50765i = i3;
        this.f50766j = i4;
        this.f50767k = i5;
    }

    @Override // p580l.InterfaceC8028t.a
    /* JADX INFO: renamed from: a */
    public int mo43738a() {
        return this.f50766j;
    }

    @Override // p580l.InterfaceC8028t.a
    /* JADX INFO: renamed from: b */
    public int mo43739b() {
        return this.f50767k;
    }

    @Override // p580l.InterfaceC8028t.a
    /* JADX INFO: renamed from: c */
    public C7952b0 mo43740c(C8034z c8034z) {
        return m43747j(c8034z, this.f50758b, this.f50759c, this.f50760d);
    }

    @Override // p580l.InterfaceC8028t.a
    /* JADX INFO: renamed from: d */
    public int mo43741d() {
        return this.f50765i;
    }

    @Override // p580l.InterfaceC8028t.a
    /* JADX INFO: renamed from: e */
    public C8034z mo43742e() {
        return this.f50762f;
    }

    /* JADX INFO: renamed from: f */
    public InterfaceC7957e m43743f() {
        return this.f50763g;
    }

    /* JADX INFO: renamed from: g */
    public InterfaceC8017i m43744g() {
        return this.f50760d;
    }

    /* JADX INFO: renamed from: h */
    public AbstractC8024p m43745h() {
        return this.f50764h;
    }

    /* JADX INFO: renamed from: i */
    public InterfaceC7979c m43746i() {
        return this.f50759c;
    }

    /* JADX INFO: renamed from: j */
    public C7952b0 m43747j(C8034z c8034z, C7976g c7976g, InterfaceC7979c interfaceC7979c, C7972c c7972c) {
        if (this.f50761e >= this.f50757a.size()) {
            throw new AssertionError();
        }
        this.f50768l++;
        if (this.f50759c != null && !this.f50760d.m43673r(c8034z.m44191i())) {
            throw new IllegalStateException("network interceptor " + this.f50757a.get(this.f50761e - 1) + " must retain the same host and port");
        }
        if (this.f50759c != null && this.f50768l > 1) {
            throw new IllegalStateException("network interceptor " + this.f50757a.get(this.f50761e - 1) + " must call proceed() exactly once");
        }
        C7983g c7983g = new C7983g(this.f50757a, c7976g, interfaceC7979c, c7972c, this.f50761e + 1, c8034z, this.f50763g, this.f50764h, this.f50765i, this.f50766j, this.f50767k);
        InterfaceC8028t interfaceC8028t = this.f50757a.get(this.f50761e);
        C7952b0 c7952b0Mo43612a = interfaceC8028t.mo43612a(c7983g);
        if (interfaceC7979c != null && this.f50761e + 1 < this.f50757a.size() && c7983g.f50768l != 1) {
            throw new IllegalStateException("network interceptor " + interfaceC8028t + " must call proceed() exactly once");
        }
        if (c7952b0Mo43612a == null) {
            throw new NullPointerException("interceptor " + interfaceC8028t + " returned null");
        }
        if (c7952b0Mo43612a.m43476c() != null) {
            return c7952b0Mo43612a;
        }
        throw new IllegalStateException("interceptor " + interfaceC8028t + " returned a response with no body");
    }

    /* JADX INFO: renamed from: k */
    public C7976g m43748k() {
        return this.f50758b;
    }
}
