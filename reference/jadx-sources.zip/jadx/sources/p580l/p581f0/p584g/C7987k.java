package p580l.p581f0.p584g;

import java.net.ProtocolException;
import p580l.EnumC8032x;

/* JADX INFO: renamed from: l.f0.g.k */
/* JADX INFO: loaded from: classes2.dex */
public final class C7987k {

    /* JADX INFO: renamed from: a */
    public final EnumC8032x f50777a;

    /* JADX INFO: renamed from: b */
    public final int f50778b;

    /* JADX INFO: renamed from: c */
    public final String f50779c;

    public C7987k(EnumC8032x enumC8032x, int i2, String str) {
        this.f50777a = enumC8032x;
        this.f50778b = i2;
        this.f50779c = str;
    }

    /* JADX INFO: renamed from: a */
    public static C7987k m43760a(String str) throws ProtocolException {
        EnumC8032x enumC8032x;
        String strSubstring;
        int i2 = 9;
        if (str.startsWith("HTTP/1.")) {
            if (str.length() < 9 || str.charAt(8) != ' ') {
                throw new ProtocolException("Unexpected status line: " + str);
            }
            int iCharAt = str.charAt(7) - '0';
            if (iCharAt == 0) {
                enumC8032x = EnumC8032x.HTTP_1_0;
            } else {
                if (iCharAt != 1) {
                    throw new ProtocolException("Unexpected status line: " + str);
                }
                enumC8032x = EnumC8032x.HTTP_1_1;
            }
        } else {
            if (!str.startsWith("ICY ")) {
                throw new ProtocolException("Unexpected status line: " + str);
            }
            enumC8032x = EnumC8032x.HTTP_1_0;
            i2 = 4;
        }
        int i3 = i2 + 3;
        if (str.length() < i3) {
            throw new ProtocolException("Unexpected status line: " + str);
        }
        try {
            int i4 = Integer.parseInt(str.substring(i2, i3));
            if (str.length() <= i3) {
                strSubstring = "";
            } else {
                if (str.charAt(i3) != ' ') {
                    throw new ProtocolException("Unexpected status line: " + str);
                }
                strSubstring = str.substring(i2 + 4);
            }
            return new C7987k(enumC8032x, i4, strSubstring);
        } catch (NumberFormatException unused) {
            throw new ProtocolException("Unexpected status line: " + str);
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.f50777a == EnumC8032x.HTTP_1_0 ? "HTTP/1.0" : "HTTP/1.1");
        sb.append(' ');
        sb.append(this.f50778b);
        if (this.f50779c != null) {
            sb.append(' ');
            sb.append(this.f50779c);
        }
        return sb.toString();
    }
}
