package p580l.p581f0.p584g;

import java.net.Proxy;
import p580l.C8027s;
import p580l.C8034z;

/* JADX INFO: renamed from: l.f0.g.i */
/* JADX INFO: loaded from: classes2.dex */
public final class C7985i {
    /* JADX INFO: renamed from: a */
    public static String m43749a(C8034z c8034z, Proxy.Type type) {
        StringBuilder sb = new StringBuilder();
        sb.append(c8034z.m44189g());
        sb.append(' ');
        boolean zM43750b = m43750b(c8034z, type);
        C8027s c8027sM44191i = c8034z.m44191i();
        if (zM43750b) {
            sb.append(c8027sM44191i);
        } else {
            sb.append(m43751c(c8027sM44191i));
        }
        sb.append(" HTTP/1.1");
        return sb.toString();
    }

    /* JADX INFO: renamed from: b */
    private static boolean m43750b(C8034z c8034z, Proxy.Type type) {
        return !c8034z.m44188f() && type == Proxy.Type.HTTP;
    }

    /* JADX INFO: renamed from: c */
    public static String m43751c(C8027s c8027s) {
        String strM44098g = c8027s.m44098g();
        String strM44100i = c8027s.m44100i();
        if (strM44100i == null) {
            return strM44098g;
        }
        return strM44098g + '?' + strM44100i;
    }
}
