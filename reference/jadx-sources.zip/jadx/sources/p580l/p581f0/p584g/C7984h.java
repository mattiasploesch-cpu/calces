package p580l.p581f0.p584g;

import javax.annotation.Nullable;
import p580l.AbstractC7954c0;
import p590m.InterfaceC8039e;

/* JADX INFO: renamed from: l.f0.g.h */
/* JADX INFO: loaded from: classes.dex */
public final class C7984h extends AbstractC7954c0 {

    /* JADX INFO: renamed from: u2 */
    @Nullable
    private final String f50769u2;

    /* JADX INFO: renamed from: v2 */
    private final long f50770v2;

    /* JADX INFO: renamed from: w2 */
    private final InterfaceC8039e f50771w2;

    public C7984h(@Nullable String str, long j2, InterfaceC8039e interfaceC8039e) {
        this.f50769u2 = str;
        this.f50770v2 = j2;
        this.f50771w2 = interfaceC8039e;
    }

    @Override // p580l.AbstractC7954c0
    /* JADX INFO: renamed from: c */
    public long mo43526c() {
        return this.f50770v2;
    }

    @Override // p580l.AbstractC7954c0
    /* JADX INFO: renamed from: f */
    public InterfaceC8039e mo43527f() {
        return this.f50771w2;
    }
}
