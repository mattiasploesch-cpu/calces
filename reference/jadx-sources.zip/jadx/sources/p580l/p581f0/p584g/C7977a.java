package p580l.p581f0.p584g;

import java.util.List;
import p580l.AbstractC7950a0;
import p580l.C7952b0;
import p580l.C8020l;
import p580l.C8029u;
import p580l.C8034z;
import p580l.InterfaceC8021m;
import p580l.InterfaceC8028t;
import p580l.p581f0.C7962c;
import p580l.p581f0.C7963d;
import p590m.C8044j;
import p590m.C8046l;

/* JADX INFO: renamed from: l.f0.g.a */
/* JADX INFO: loaded from: classes2.dex */
public final class C7977a implements InterfaceC8028t {

    /* JADX INFO: renamed from: a */
    private final InterfaceC8021m f50750a;

    public C7977a(InterfaceC8021m interfaceC8021m) {
        this.f50750a = interfaceC8021m;
    }

    /* JADX INFO: renamed from: b */
    private String m43708b(List<C8020l> list) {
        StringBuilder sb = new StringBuilder();
        int size = list.size();
        for (int i2 = 0; i2 < size; i2++) {
            if (i2 > 0) {
                sb.append("; ");
            }
            C8020l c8020l = list.get(i2);
            sb.append(c8020l.m44020c());
            sb.append('=');
            sb.append(c8020l.m44022k());
        }
        return sb.toString();
    }

    @Override // p580l.InterfaceC8028t
    /* JADX INFO: renamed from: a */
    public C7952b0 mo43612a(InterfaceC8028t.a aVar) {
        C8034z c8034zMo43742e = aVar.mo43742e();
        C8034z.a aVarM44190h = c8034zMo43742e.m44190h();
        AbstractC7950a0 abstractC7950a0M44183a = c8034zMo43742e.m44183a();
        if (abstractC7950a0M44183a != null) {
            C8029u c8029uMo43473b = abstractC7950a0M44183a.mo43473b();
            if (c8029uMo43473b != null) {
                aVarM44190h.m44194c("Content-Type", c8029uMo43473b.toString());
            }
            long jMo43472a = abstractC7950a0M44183a.mo43472a();
            if (jMo43472a != -1) {
                aVarM44190h.m44194c("Content-Length", Long.toString(jMo43472a));
                aVarM44190h.m44198g("Transfer-Encoding");
            } else {
                aVarM44190h.m44194c("Transfer-Encoding", "chunked");
                aVarM44190h.m44198g("Content-Length");
            }
        }
        boolean z = false;
        if (c8034zMo43742e.m44185c("Host") == null) {
            aVarM44190h.m44194c("Host", C7962c.m43594p(c8034zMo43742e.m44191i(), false));
        }
        if (c8034zMo43742e.m44185c("Connection") == null) {
            aVarM44190h.m44194c("Connection", "Keep-Alive");
        }
        if (c8034zMo43742e.m44185c("Accept-Encoding") == null && c8034zMo43742e.m44185c("Range") == null) {
            z = true;
            aVarM44190h.m44194c("Accept-Encoding", "gzip");
        }
        List<C8020l> listMo44024b = this.f50750a.mo44024b(c8034zMo43742e.m44191i());
        if (!listMo44024b.isEmpty()) {
            aVarM44190h.m44194c("Cookie", m43708b(listMo44024b));
        }
        if (c8034zMo43742e.m44185c("User-Agent") == null) {
            aVarM44190h.m44194c("User-Agent", C7963d.m43606a());
        }
        C7952b0 c7952b0Mo43740c = aVar.mo43740c(aVarM44190h.m44192a());
        C7981e.m43724g(this.f50750a, c8034zMo43742e.m44191i(), c7952b0Mo43740c.m43483j());
        C7952b0.a aVarM43507o = c7952b0Mo43740c.m43487p().m43507o(c8034zMo43742e);
        if (z && "gzip".equalsIgnoreCase(c7952b0Mo43740c.m43481h("Content-Encoding")) && C7981e.m43720c(c7952b0Mo43740c)) {
            C8044j c8044j = new C8044j(c7952b0Mo43740c.m43476c().mo43527f());
            aVarM43507o.m43501i(c7952b0Mo43740c.m43483j().m44066d().m44076g("Content-Encoding").m44076g("Content-Length").m44074d());
            aVarM43507o.m43496b(new C7984h(c7952b0Mo43740c.m43481h("Content-Type"), -1L, C8046l.m44313d(c8044j)));
        }
        return aVarM43507o.m43497c();
    }
}
