package p580l.p581f0.p584g;

/* JADX INFO: renamed from: l.f0.g.f */
/* JADX INFO: loaded from: classes2.dex */
public final class C7982f {
    /* JADX INFO: renamed from: a */
    public static boolean m43733a(String str) {
        return str.equals("POST") || str.equals("PATCH") || str.equals("PUT") || str.equals("DELETE") || str.equals("MOVE");
    }

    /* JADX INFO: renamed from: b */
    public static boolean m43734b(String str) {
        return (str.equals("GET") || str.equals("HEAD")) ? false : true;
    }

    /* JADX INFO: renamed from: c */
    public static boolean m43735c(String str) {
        return !str.equals("PROPFIND");
    }

    /* JADX INFO: renamed from: d */
    public static boolean m43736d(String str) {
        return str.equals("PROPFIND");
    }

    /* JADX INFO: renamed from: e */
    public static boolean m43737e(String str) {
        return str.equals("POST") || str.equals("PUT") || str.equals("PATCH") || str.equals("PROPPATCH") || str.equals("REPORT");
    }
}
