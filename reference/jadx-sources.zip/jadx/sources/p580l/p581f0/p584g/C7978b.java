package p580l.p581f0.p584g;

import java.net.ProtocolException;
import p580l.AbstractC7954c0;
import p580l.C7952b0;
import p580l.C8034z;
import p580l.InterfaceC8028t;
import p580l.p581f0.C7962c;
import p580l.p581f0.p583f.C7972c;
import p580l.p581f0.p583f.C7976g;
import p590m.AbstractC8041g;
import p590m.C8037c;
import p590m.C8046l;
import p590m.InterfaceC8038d;
import p590m.InterfaceC8052r;

/* JADX INFO: renamed from: l.f0.g.b */
/* JADX INFO: loaded from: classes2.dex */
public final class C7978b implements InterfaceC8028t {

    /* JADX INFO: renamed from: a */
    private final boolean f50751a;

    /* JADX INFO: renamed from: l.f0.g.b$a */
    static final class a extends AbstractC8041g {

        /* JADX INFO: renamed from: v2 */
        long f50752v2;

        a(InterfaceC8052r interfaceC8052r) {
            super(interfaceC8052r);
        }

        @Override // p590m.AbstractC8041g, p590m.InterfaceC8052r
        /* JADX INFO: renamed from: Z7 */
        public void mo43652Z7(C8037c c8037c, long j2) {
            super.mo43652Z7(c8037c, j2);
            this.f50752v2 += j2;
        }
    }

    public C7978b(boolean z) {
        this.f50751a = z;
    }

    @Override // p580l.InterfaceC8028t
    /* JADX INFO: renamed from: a */
    public C7952b0 mo43612a(InterfaceC8028t.a aVar) throws ProtocolException {
        C7952b0.a aVarM43487p;
        AbstractC7954c0 abstractC7954c0Mo43711c;
        C7983g c7983g = (C7983g) aVar;
        InterfaceC7979c interfaceC7979cM43746i = c7983g.m43746i();
        C7976g c7976gM43748k = c7983g.m43748k();
        C7972c c7972c = (C7972c) c7983g.m43744g();
        C8034z c8034zMo43742e = c7983g.mo43742e();
        long jCurrentTimeMillis = System.currentTimeMillis();
        c7983g.m43745h().m44048o(c7983g.m43743f());
        interfaceC7979cM43746i.mo43710b(c8034zMo43742e);
        c7983g.m43745h().m44047n(c7983g.m43743f(), c8034zMo43742e);
        C7952b0.a aVarMo43712d = null;
        if (C7982f.m43734b(c8034zMo43742e.m44189g()) && c8034zMo43742e.m44183a() != null) {
            if ("100-continue".equalsIgnoreCase(c8034zMo43742e.m44185c("Expect"))) {
                interfaceC7979cM43746i.mo43713e();
                c7983g.m43745h().m44052s(c7983g.m43743f());
                aVarMo43712d = interfaceC7979cM43746i.mo43712d(true);
            }
            if (aVarMo43712d == null) {
                c7983g.m43745h().m44046m(c7983g.m43743f());
                a aVar2 = new a(interfaceC7979cM43746i.mo43714f(c8034zMo43742e, c8034zMo43742e.m44183a().mo43472a()));
                InterfaceC8038d interfaceC8038dM44312c = C8046l.m44312c(aVar2);
                c8034zMo43742e.m44183a().mo43474g(interfaceC8038dM44312c);
                interfaceC8038dM44312c.close();
                c7983g.m43745h().m44045l(c7983g.m43743f(), aVar2.f50752v2);
            } else if (!c7972c.m43669m()) {
                c7976gM43748k.m43702i();
            }
        }
        interfaceC7979cM43746i.mo43709a();
        if (aVarMo43712d == null) {
            c7983g.m43745h().m44052s(c7983g.m43743f());
            aVarMo43712d = interfaceC7979cM43746i.mo43712d(false);
        }
        C7952b0 c7952b0M43497c = aVarMo43712d.m43507o(c8034zMo43742e).m43500h(c7976gM43748k.m43699c().m43666j()).m43508p(jCurrentTimeMillis).m43506n(System.currentTimeMillis()).m43497c();
        int iM43479f = c7952b0M43497c.m43479f();
        if (iM43479f == 100) {
            c7952b0M43497c = interfaceC7979cM43746i.mo43712d(false).m43507o(c8034zMo43742e).m43500h(c7976gM43748k.m43699c().m43666j()).m43508p(jCurrentTimeMillis).m43506n(System.currentTimeMillis()).m43497c();
            iM43479f = c7952b0M43497c.m43479f();
        }
        c7983g.m43745h().m44051r(c7983g.m43743f(), c7952b0M43497c);
        if (this.f50751a && iM43479f == 101) {
            aVarM43487p = c7952b0M43497c.m43487p();
            abstractC7954c0Mo43711c = C7962c.f50623c;
        } else {
            aVarM43487p = c7952b0M43497c.m43487p();
            abstractC7954c0Mo43711c = interfaceC7979cM43746i.mo43711c(c7952b0M43497c);
        }
        C7952b0 c7952b0M43497c2 = aVarM43487p.m43496b(abstractC7954c0Mo43711c).m43497c();
        if ("close".equalsIgnoreCase(c7952b0M43497c2.m43491u().m44185c("Connection")) || "close".equalsIgnoreCase(c7952b0M43497c2.m43481h("Connection"))) {
            c7976gM43748k.m43702i();
        }
        if ((iM43479f != 204 && iM43479f != 205) || c7952b0M43497c2.m43476c().mo43526c() <= 0) {
            return c7952b0M43497c2;
        }
        throw new ProtocolException("HTTP " + iM43479f + " had non-zero Content-Length: " + c7952b0M43497c2.m43476c().mo43526c());
    }
}
