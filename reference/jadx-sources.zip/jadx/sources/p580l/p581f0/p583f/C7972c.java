package p580l.p581f0.p583f;

import java.io.IOException;
import java.lang.ref.Reference;
import java.net.ConnectException;
import java.net.ProtocolException;
import java.net.Proxy;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownServiceException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import p580l.AbstractC8024p;
import p580l.C7949a;
import p580l.C7952b0;
import p580l.C7956d0;
import p580l.C8015g;
import p580l.C8018j;
import p580l.C8019k;
import p580l.C8025q;
import p580l.C8027s;
import p580l.C8031w;
import p580l.C8034z;
import p580l.EnumC8032x;
import p580l.InterfaceC7957e;
import p580l.InterfaceC8017i;
import p580l.InterfaceC8028t;
import p580l.p581f0.AbstractC7960a;
import p580l.p581f0.C7962c;
import p580l.p581f0.C7963d;
import p580l.p581f0.p584g.C7981e;
import p580l.p581f0.p584g.InterfaceC7979c;
import p580l.p581f0.p585h.C7988a;
import p580l.p581f0.p586i.C7994f;
import p580l.p581f0.p586i.C7995g;
import p580l.p581f0.p586i.C7997i;
import p580l.p581f0.p586i.EnumC7990b;
import p580l.p581f0.p588k.C8009f;
import p580l.p581f0.p589l.C8013d;
import p590m.C8046l;
import p590m.C8054t;
import p590m.InterfaceC8038d;
import p590m.InterfaceC8039e;
import p590m.InterfaceC8053s;

/* JADX INFO: renamed from: l.f0.f.c */
/* JADX INFO: loaded from: classes.dex */
public final class C7972c extends C7995g.h implements InterfaceC8017i {

    /* JADX INFO: renamed from: b */
    private final C8018j f50708b;

    /* JADX INFO: renamed from: c */
    private final C7956d0 f50709c;

    /* JADX INFO: renamed from: d */
    private Socket f50710d;

    /* JADX INFO: renamed from: e */
    private Socket f50711e;

    /* JADX INFO: renamed from: f */
    private C8025q f50712f;

    /* JADX INFO: renamed from: g */
    private EnumC8032x f50713g;

    /* JADX INFO: renamed from: h */
    private C7995g f50714h;

    /* JADX INFO: renamed from: i */
    private InterfaceC8039e f50715i;

    /* JADX INFO: renamed from: j */
    private InterfaceC8038d f50716j;

    /* JADX INFO: renamed from: k */
    public boolean f50717k;

    /* JADX INFO: renamed from: l */
    public int f50718l;

    /* JADX INFO: renamed from: m */
    public int f50719m = 1;

    /* JADX INFO: renamed from: n */
    public final List<Reference<C7976g>> f50720n = new ArrayList();

    /* JADX INFO: renamed from: o */
    public long f50721o = Long.MAX_VALUE;

    public C7972c(C8018j c8018j, C7956d0 c7956d0) {
        this.f50708b = c8018j;
        this.f50709c = c7956d0;
    }

    /* JADX INFO: renamed from: d */
    private void m43656d(int i2, int i3, InterfaceC7957e interfaceC7957e, AbstractC8024p abstractC8024p) throws IOException {
        Proxy proxyM43554b = this.f50709c.m43554b();
        this.f50710d = (proxyM43554b.type() == Proxy.Type.DIRECT || proxyM43554b.type() == Proxy.Type.HTTP) ? this.f50709c.m43553a().m43465j().createSocket() : new Socket(proxyM43554b);
        abstractC8024p.m44040f(interfaceC7957e, this.f50709c.m43556d(), proxyM43554b);
        this.f50710d.setSoTimeout(i3);
        try {
            C8009f.m43969i().mo43942g(this.f50710d, this.f50709c.m43556d(), i2);
            try {
                this.f50715i = C8046l.m44313d(C8046l.m44322m(this.f50710d));
                this.f50716j = C8046l.m44312c(C8046l.m44318i(this.f50710d));
            } catch (NullPointerException e2) {
                if ("throw with null exception".equals(e2.getMessage())) {
                    throw new IOException(e2);
                }
            }
        } catch (ConnectException e3) {
            ConnectException connectException = new ConnectException("Failed to connect to " + this.f50709c.m43556d());
            connectException.initCause(e3);
            throw connectException;
        }
    }

    /* JADX INFO: renamed from: e */
    private void m43657e(C7971b c7971b) throws Throwable {
        C7949a c7949aM43553a = this.f50709c.m43553a();
        SSLSocket sSLSocket = null;
        try {
            try {
                SSLSocket sSLSocket2 = (SSLSocket) c7949aM43553a.m43466k().createSocket(this.f50710d, c7949aM43553a.m43467l().m44102l(), c7949aM43553a.m43467l().m44106x(), true);
                try {
                    C8019k c8019kM43654a = c7971b.m43654a(sSLSocket2);
                    if (c8019kM43654a.m44004f()) {
                        C8009f.m43969i().mo43941f(sSLSocket2, c7949aM43553a.m43467l().m44102l(), c7949aM43553a.m43461f());
                    }
                    sSLSocket2.startHandshake();
                    SSLSession session = sSLSocket2.getSession();
                    if (!m43662n(session)) {
                        throw new IOException("a valid ssl session was not established");
                    }
                    C8025q c8025qM44056b = C8025q.m44056b(session);
                    if (c7949aM43553a.m43460e().verify(c7949aM43553a.m43467l().m44102l(), session)) {
                        c7949aM43553a.m43456a().m43983a(c7949aM43553a.m43467l().m44102l(), c8025qM44056b.m44060e());
                        String strMo43943l = c8019kM43654a.m44004f() ? C8009f.m43969i().mo43943l(sSLSocket2) : null;
                        this.f50711e = sSLSocket2;
                        this.f50715i = C8046l.m44313d(C8046l.m44322m(sSLSocket2));
                        this.f50716j = C8046l.m44312c(C8046l.m44318i(this.f50711e));
                        this.f50712f = c8025qM44056b;
                        this.f50713g = strMo43943l != null ? EnumC8032x.m44172c(strMo43943l) : EnumC8032x.HTTP_1_1;
                        C8009f.m43969i().mo43958a(sSLSocket2);
                        return;
                    }
                    X509Certificate x509Certificate = (X509Certificate) c8025qM44056b.m44060e().get(0);
                    throw new SSLPeerUnverifiedException("Hostname " + c7949aM43553a.m43467l().m44102l() + " not verified:\n    certificate: " + C8015g.m43980c(x509Certificate) + "\n    DN: " + x509Certificate.getSubjectDN().getName() + "\n    subjectAltNames: " + C8013d.m43974a(x509Certificate));
                } catch (AssertionError e2) {
                    e = e2;
                    if (!C7962c.m43601w(e)) {
                        throw e;
                    }
                    throw new IOException(e);
                } catch (Throwable th) {
                    th = th;
                    sSLSocket = sSLSocket2;
                    if (sSLSocket != null) {
                        C8009f.m43969i().mo43958a(sSLSocket);
                    }
                    C7962c.m43583e(sSLSocket);
                    throw th;
                }
            } catch (Throwable th2) {
                th = th2;
            }
        } catch (AssertionError e3) {
            e = e3;
        }
    }

    /* JADX INFO: renamed from: f */
    private void m43658f(int i2, int i3, int i4, InterfaceC7957e interfaceC7957e, AbstractC8024p abstractC8024p) throws IOException {
        C8034z c8034zM43660h = m43660h();
        C8027s c8027sM44191i = c8034zM43660h.m44191i();
        for (int i5 = 0; i5 < 21; i5++) {
            m43656d(i2, i3, interfaceC7957e, abstractC8024p);
            c8034zM43660h = m43659g(i3, i4, c8034zM43660h, c8027sM44191i);
            if (c8034zM43660h == null) {
                return;
            }
            C7962c.m43583e(this.f50710d);
            this.f50710d = null;
            this.f50716j = null;
            this.f50715i = null;
            abstractC8024p.m44038d(interfaceC7957e, this.f50709c.m43556d(), this.f50709c.m43554b(), null);
        }
    }

    /* JADX INFO: renamed from: g */
    private C8034z m43659g(int i2, int i3, C8034z c8034z, C8027s c8027s) throws IOException {
        String str = "CONNECT " + C7962c.m43594p(c8027s, true) + " HTTP/1.1";
        while (true) {
            C7988a c7988a = new C7988a(null, null, this.f50715i, this.f50716j);
            TimeUnit timeUnit = TimeUnit.MILLISECONDS;
            this.f50715i.mo43614S().mo44301g(i2, timeUnit);
            this.f50716j.mo43771S().mo44301g(i3, timeUnit);
            c7988a.m43769o(c8034z.m44187e(), str);
            c7988a.mo43709a();
            C7952b0 c7952b0M43497c = c7988a.mo43712d(false).m43507o(c8034z).m43497c();
            long jM43719b = C7981e.m43719b(c7952b0M43497c);
            if (jM43719b == -1) {
                jM43719b = 0;
            }
            InterfaceC8053s interfaceC8053sM43766k = c7988a.m43766k(jM43719b);
            C7962c.m43603y(interfaceC8053sM43766k, Integer.MAX_VALUE, timeUnit);
            interfaceC8053sM43766k.close();
            int iM43479f = c7952b0M43497c.m43479f();
            if (iM43479f == 200) {
                if (this.f50715i.mo44257r().mo44237a4() && this.f50716j.mo44257r().mo44237a4()) {
                    return null;
                }
                throw new IOException("TLS tunnel buffered too many bytes!");
            }
            if (iM43479f != 407) {
                throw new IOException("Unexpected response code for CONNECT: " + c7952b0M43497c.m43479f());
            }
            C8034z c8034zMo43475a = this.f50709c.m43553a().m43463h().mo43475a(this.f50709c, c7952b0M43497c);
            if (c8034zMo43475a == null) {
                throw new IOException("Failed to authenticate with proxy");
            }
            if ("close".equalsIgnoreCase(c7952b0M43497c.m43481h("Connection"))) {
                return c8034zMo43475a;
            }
            c8034z = c8034zMo43475a;
        }
    }

    /* JADX INFO: renamed from: h */
    private C8034z m43660h() {
        return new C8034z.a().m44201j(this.f50709c.m43553a().m43467l()).m44194c("Host", C7962c.m43594p(this.f50709c.m43553a().m43467l(), true)).m44194c("Proxy-Connection", "Keep-Alive").m44194c("User-Agent", C7963d.m43606a()).m44192a();
    }

    /* JADX INFO: renamed from: i */
    private void m43661i(C7971b c7971b, int i2, InterfaceC7957e interfaceC7957e, AbstractC8024p abstractC8024p) throws Throwable {
        if (this.f50709c.m43553a().m43466k() == null) {
            this.f50713g = EnumC8032x.HTTP_1_1;
            this.f50711e = this.f50710d;
            return;
        }
        abstractC8024p.m44054u(interfaceC7957e);
        m43657e(c7971b);
        abstractC8024p.m44053t(interfaceC7957e, this.f50712f);
        if (this.f50713g == EnumC8032x.HTTP_2) {
            this.f50711e.setSoTimeout(0);
            C7995g c7995gM43834a = new C7995g.g(true).m43837d(this.f50711e, this.f50709c.m43553a().m43467l().m44102l(), this.f50715i, this.f50716j).m43835b(this).m43836c(i2).m43834a();
            this.f50714h = c7995gM43834a;
            c7995gM43834a.m43832y();
        }
    }

    /* JADX INFO: renamed from: n */
    private boolean m43662n(SSLSession sSLSession) {
        return ("NONE".equals(sSLSession.getProtocol()) || "SSL_NULL_WITH_NULL_NULL".equals(sSLSession.getCipherSuite())) ? false : true;
    }

    @Override // p580l.p581f0.p586i.C7995g.h
    /* JADX INFO: renamed from: a */
    public void mo43663a(C7995g c7995g) {
        synchronized (this.f50708b) {
            this.f50719m = c7995g.m43823l();
        }
    }

    @Override // p580l.p581f0.p586i.C7995g.h
    /* JADX INFO: renamed from: b */
    public void mo43664b(C7997i c7997i) {
        c7997i.m43869d(EnumC7990b.REFUSED_STREAM);
    }

    /* JADX WARN: Code duplicated, block: B:53:0x011d  */
    /* JADX WARN: Code duplicated, block: B:54:0x0123  */
    /* JADX WARN: Code duplicated, block: B:56:0x0128  */
    /* JADX WARN: Code duplicated, block: B:73:0x0130 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:74:0x0130 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:75:? A[LOOP:0: B:63:0x0076->B:75:?, LOOP_END, SYNTHETIC] */
    /* JADX INFO: renamed from: c */
    public void m43665c(int i2, int i3, int i4, int i5, boolean z, InterfaceC7957e interfaceC7957e, AbstractC8024p abstractC8024p) throws Throwable {
        if (this.f50713g != null) {
            throw new IllegalStateException("already connected");
        }
        List<C8019k> listM43457b = this.f50709c.m43553a().m43457b();
        C7971b c7971b = new C7971b(listM43457b);
        if (this.f50709c.m43553a().m43466k() == null) {
            if (!listM43457b.contains(C8019k.f51149d)) {
                throw new C7974e(new UnknownServiceException("CLEARTEXT communication not enabled for client"));
            }
            String strM44102l = this.f50709c.m43553a().m43467l().m44102l();
            if (!C8009f.m43969i().mo43945n(strM44102l)) {
                throw new C7974e(new UnknownServiceException("CLEARTEXT communication to " + strM44102l + " not permitted by network security policy"));
            }
        }
        C7974e c7974e = null;
        while (true) {
            try {
                if (this.f50709c.m43555c()) {
                    m43658f(i2, i3, i4, interfaceC7957e, abstractC8024p);
                    if (this.f50710d == null) {
                        break;
                    }
                } else {
                    try {
                        m43656d(i2, i3, interfaceC7957e, abstractC8024p);
                    } catch (IOException e2) {
                        e = e2;
                        C7962c.m43583e(this.f50711e);
                        C7962c.m43583e(this.f50710d);
                        this.f50711e = null;
                        this.f50710d = null;
                        this.f50715i = null;
                        this.f50716j = null;
                        this.f50712f = null;
                        this.f50713g = null;
                        this.f50714h = null;
                        abstractC8024p.m44039e(interfaceC7957e, this.f50709c.m43556d(), this.f50709c.m43554b(), null, e);
                        if (c7974e == null) {
                            c7974e = new C7974e(e);
                        } else {
                            c7974e.m43678a(e);
                        }
                        if (z) {
                            throw c7974e;
                        }
                        if (c7971b.m43655b(e)) {
                            throw c7974e;
                        }
                    }
                }
                try {
                    m43661i(c7971b, i5, interfaceC7957e, abstractC8024p);
                    abstractC8024p.m44038d(interfaceC7957e, this.f50709c.m43556d(), this.f50709c.m43554b(), this.f50713g);
                    break;
                } catch (IOException e3) {
                    e = e3;
                    C7962c.m43583e(this.f50711e);
                    C7962c.m43583e(this.f50710d);
                    this.f50711e = null;
                    this.f50710d = null;
                    this.f50715i = null;
                    this.f50716j = null;
                    this.f50712f = null;
                    this.f50713g = null;
                    this.f50714h = null;
                    abstractC8024p.m44039e(interfaceC7957e, this.f50709c.m43556d(), this.f50709c.m43554b(), null, e);
                    if (c7974e == null) {
                        c7974e = new C7974e(e);
                    } else {
                        c7974e.m43678a(e);
                    }
                    if (z) {
                        throw c7974e;
                    }
                    if (c7971b.m43655b(e)) {
                        throw c7974e;
                    }
                }
            } catch (IOException e4) {
                e = e4;
            }
        }
        if (this.f50709c.m43555c() && this.f50710d == null) {
            throw new C7974e(new ProtocolException("Too many tunnel connections attempted: 21"));
        }
        if (this.f50714h != null) {
            synchronized (this.f50708b) {
                this.f50719m = this.f50714h.m43823l();
            }
        }
    }

    /* JADX INFO: renamed from: j */
    public C8025q m43666j() {
        return this.f50712f;
    }

    /* JADX INFO: renamed from: k */
    public boolean m43667k(C7949a c7949a, @Nullable C7956d0 c7956d0) {
        if (this.f50720n.size() >= this.f50719m || this.f50717k || !AbstractC7960a.f50619a.mo43570g(this.f50709c.m43553a(), c7949a)) {
            return false;
        }
        if (c7949a.m43467l().m44102l().equals(m43671p().m43553a().m43467l().m44102l())) {
            return true;
        }
        if (this.f50714h == null || c7956d0 == null || c7956d0.m43554b().type() != Proxy.Type.DIRECT || this.f50709c.m43554b().type() != Proxy.Type.DIRECT || !this.f50709c.m43556d().equals(c7956d0.m43556d()) || c7956d0.m43553a().m43460e() != C8013d.f51014a || !m43673r(c7949a.m43467l())) {
            return false;
        }
        try {
            c7949a.m43456a().m43983a(c7949a.m43467l().m44102l(), m43666j().m44060e());
            return true;
        } catch (SSLPeerUnverifiedException unused) {
            return false;
        }
    }

    /* JADX INFO: renamed from: l */
    public boolean m43668l(boolean z) {
        if (this.f50711e.isClosed() || this.f50711e.isInputShutdown() || this.f50711e.isOutputShutdown()) {
            return false;
        }
        C7995g c7995g = this.f50714h;
        if (c7995g != null) {
            return !c7995g.m43822k();
        }
        if (z) {
            try {
                int soTimeout = this.f50711e.getSoTimeout();
                try {
                    this.f50711e.setSoTimeout(1);
                    if (this.f50715i.mo44237a4()) {
                        this.f50711e.setSoTimeout(soTimeout);
                        return false;
                    }
                    this.f50711e.setSoTimeout(soTimeout);
                    return true;
                } catch (Throwable th) {
                    this.f50711e.setSoTimeout(soTimeout);
                    throw th;
                }
            } catch (SocketTimeoutException unused) {
            } catch (IOException unused2) {
                return false;
            }
        }
        return true;
    }

    /* JADX INFO: renamed from: m */
    public boolean m43669m() {
        return this.f50714h != null;
    }

    /* JADX INFO: renamed from: o */
    public InterfaceC7979c m43670o(C8031w c8031w, InterfaceC8028t.a aVar, C7976g c7976g) throws SocketException {
        if (this.f50714h != null) {
            return new C7994f(c8031w, aVar, c7976g, this.f50714h);
        }
        this.f50711e.setSoTimeout(aVar.mo43738a());
        C8054t c8054tMo43614S = this.f50715i.mo43614S();
        long jMo43738a = aVar.mo43738a();
        TimeUnit timeUnit = TimeUnit.MILLISECONDS;
        c8054tMo43614S.mo44301g(jMo43738a, timeUnit);
        this.f50716j.mo43771S().mo44301g(aVar.mo43739b(), timeUnit);
        return new C7988a(c8031w, c7976g, this.f50715i, this.f50716j);
    }

    /* JADX INFO: renamed from: p */
    public C7956d0 m43671p() {
        return this.f50709c;
    }

    /* JADX INFO: renamed from: q */
    public Socket m43672q() {
        return this.f50711e;
    }

    /* JADX INFO: renamed from: r */
    public boolean m43673r(C8027s c8027s) {
        if (c8027s.m44106x() != this.f50709c.m43553a().m43467l().m44106x()) {
            return false;
        }
        if (c8027s.m44102l().equals(this.f50709c.m43553a().m43467l().m44102l())) {
            return true;
        }
        return this.f50712f != null && C8013d.f51014a.m43978c(c8027s.m44102l(), (X509Certificate) this.f50712f.m44060e().get(0));
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Connection{");
        sb.append(this.f50709c.m43553a().m43467l().m44102l());
        sb.append(":");
        sb.append(this.f50709c.m43553a().m43467l().m44106x());
        sb.append(", proxy=");
        sb.append(this.f50709c.m43554b());
        sb.append(" hostAddress=");
        sb.append(this.f50709c.m43556d());
        sb.append(" cipherSuite=");
        C8025q c8025q = this.f50712f;
        sb.append(c8025q != null ? c8025q.m44058a() : "none");
        sb.append(" protocol=");
        sb.append(this.f50713g);
        sb.append('}');
        return sb.toString();
    }
}
