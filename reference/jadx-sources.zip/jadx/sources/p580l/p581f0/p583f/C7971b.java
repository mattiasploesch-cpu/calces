package p580l.p581f0.p583f;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.ProtocolException;
import java.net.UnknownServiceException;
import java.security.cert.CertificateException;
import java.util.Arrays;
import java.util.List;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLProtocolException;
import javax.net.ssl.SSLSocket;
import p580l.C8019k;
import p580l.p581f0.AbstractC7960a;

/* JADX INFO: renamed from: l.f0.f.b */
/* JADX INFO: loaded from: classes2.dex */
public final class C7971b {

    /* JADX INFO: renamed from: a */
    private final List<C8019k> f50704a;

    /* JADX INFO: renamed from: b */
    private int f50705b = 0;

    /* JADX INFO: renamed from: c */
    private boolean f50706c;

    /* JADX INFO: renamed from: d */
    private boolean f50707d;

    public C7971b(List<C8019k> list) {
        this.f50704a = list;
    }

    /* JADX INFO: renamed from: c */
    private boolean m43653c(SSLSocket sSLSocket) {
        for (int i2 = this.f50705b; i2 < this.f50704a.size(); i2++) {
            if (this.f50704a.get(i2).m44002c(sSLSocket)) {
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: renamed from: a */
    public C8019k m43654a(SSLSocket sSLSocket) throws UnknownServiceException {
        C8019k c8019k;
        int i2 = this.f50705b;
        int size = this.f50704a.size();
        while (true) {
            if (i2 >= size) {
                c8019k = null;
                break;
            }
            c8019k = this.f50704a.get(i2);
            i2++;
            if (c8019k.m44002c(sSLSocket)) {
                this.f50705b = i2;
                break;
            }
        }
        if (c8019k != null) {
            this.f50706c = m43653c(sSLSocket);
            AbstractC7960a.f50619a.mo43566c(c8019k, sSLSocket, this.f50707d);
            return c8019k;
        }
        throw new UnknownServiceException("Unable to find acceptable protocols. isFallback=" + this.f50707d + ", modes=" + this.f50704a + ", supported protocols=" + Arrays.toString(sSLSocket.getEnabledProtocols()));
    }

    /* JADX INFO: renamed from: b */
    public boolean m43655b(IOException iOException) {
        this.f50707d = true;
        if (!this.f50706c || (iOException instanceof ProtocolException) || (iOException instanceof InterruptedIOException)) {
            return false;
        }
        boolean z = iOException instanceof SSLHandshakeException;
        if ((z && (iOException.getCause() instanceof CertificateException)) || (iOException instanceof SSLPeerUnverifiedException)) {
            return false;
        }
        return z || (iOException instanceof SSLProtocolException);
    }
}
