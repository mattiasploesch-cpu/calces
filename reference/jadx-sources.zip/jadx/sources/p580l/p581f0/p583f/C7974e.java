package p580l.p581f0.p583f;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* JADX INFO: renamed from: l.f0.f.e */
/* JADX INFO: loaded from: classes2.dex */
public final class C7974e extends RuntimeException {

    /* JADX INFO: renamed from: u2 */
    private static final Method f50723u2;

    /* JADX INFO: renamed from: v2 */
    private IOException f50724v2;

    static {
        Method declaredMethod;
        try {
            declaredMethod = Throwable.class.getDeclaredMethod("addSuppressed", Throwable.class);
        } catch (Exception unused) {
            declaredMethod = null;
        }
        f50723u2 = declaredMethod;
    }

    public C7974e(IOException iOException) {
        super(iOException);
        this.f50724v2 = iOException;
    }

    /* JADX INFO: renamed from: b */
    private void m43677b(IOException iOException, IOException iOException2) {
        Method method = f50723u2;
        if (method != null) {
            try {
                method.invoke(iOException, iOException2);
            } catch (IllegalAccessException | InvocationTargetException unused) {
            }
        }
    }

    /* JADX INFO: renamed from: a */
    public void m43678a(IOException iOException) {
        m43677b(iOException, this.f50724v2);
        this.f50724v2 = iOException;
    }

    /* JADX INFO: renamed from: c */
    public IOException m43679c() {
        return this.f50724v2;
    }
}
