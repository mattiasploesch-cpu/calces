package p580l.p581f0.p583f;

import p580l.C7952b0;
import p580l.C8031w;
import p580l.C8034z;
import p580l.InterfaceC8028t;
import p580l.p581f0.p584g.C7983g;

/* JADX INFO: renamed from: l.f0.f.a */
/* JADX INFO: loaded from: classes2.dex */
public final class C7970a implements InterfaceC8028t {

    /* JADX INFO: renamed from: a */
    public final C8031w f50703a;

    public C7970a(C8031w c8031w) {
        this.f50703a = c8031w;
    }

    @Override // p580l.InterfaceC8028t
    /* JADX INFO: renamed from: a */
    public C7952b0 mo43612a(InterfaceC8028t.a aVar) {
        C7983g c7983g = (C7983g) aVar;
        C8034z c8034zMo43742e = c7983g.mo43742e();
        C7976g c7976gM43748k = c7983g.m43748k();
        return c7983g.m43747j(c8034zMo43742e, c7976gM43748k, c7976gM43748k.m43701h(this.f50703a, aVar, !c8034zMo43742e.m44189g().equals("GET")), c7976gM43748k.m43699c());
    }
}
