package p580l.p581f0.p583f;

import java.util.LinkedHashSet;
import java.util.Set;
import p580l.C7956d0;

/* JADX INFO: renamed from: l.f0.f.d */
/* JADX INFO: loaded from: classes2.dex */
public final class C7973d {

    /* JADX INFO: renamed from: a */
    private final Set<C7956d0> f50722a = new LinkedHashSet();

    /* JADX INFO: renamed from: a */
    public synchronized void m43674a(C7956d0 c7956d0) {
        this.f50722a.remove(c7956d0);
    }

    /* JADX INFO: renamed from: b */
    public synchronized void m43675b(C7956d0 c7956d0) {
        this.f50722a.add(c7956d0);
    }

    /* JADX INFO: renamed from: c */
    public synchronized boolean m43676c(C7956d0 c7956d0) {
        return this.f50722a.contains(c7956d0);
    }
}
