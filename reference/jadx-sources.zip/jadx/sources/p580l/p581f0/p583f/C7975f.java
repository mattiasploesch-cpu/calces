package p580l.p581f0.p583f;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;
import p580l.AbstractC8024p;
import p580l.C7949a;
import p580l.C7956d0;
import p580l.C8027s;
import p580l.InterfaceC7957e;
import p580l.p581f0.C7962c;

/* JADX INFO: renamed from: l.f0.f.f */
/* JADX INFO: loaded from: classes2.dex */
public final class C7975f {

    /* JADX INFO: renamed from: a */
    private final C7949a f50725a;

    /* JADX INFO: renamed from: b */
    private final C7973d f50726b;

    /* JADX INFO: renamed from: c */
    private final InterfaceC7957e f50727c;

    /* JADX INFO: renamed from: d */
    private final AbstractC8024p f50728d;

    /* JADX INFO: renamed from: f */
    private int f50730f;

    /* JADX INFO: renamed from: e */
    private List<Proxy> f50729e = Collections.emptyList();

    /* JADX INFO: renamed from: g */
    private List<InetSocketAddress> f50731g = Collections.emptyList();

    /* JADX INFO: renamed from: h */
    private final List<C7956d0> f50732h = new ArrayList();

    /* JADX INFO: renamed from: l.f0.f.f$a */
    public static final class a {

        /* JADX INFO: renamed from: a */
        private final List<C7956d0> f50733a;

        /* JADX INFO: renamed from: b */
        private int f50734b = 0;

        a(List<C7956d0> list) {
            this.f50733a = list;
        }

        /* JADX INFO: renamed from: a */
        public List<C7956d0> m43688a() {
            return new ArrayList(this.f50733a);
        }

        /* JADX INFO: renamed from: b */
        public boolean m43689b() {
            return this.f50734b < this.f50733a.size();
        }

        /* JADX INFO: renamed from: c */
        public C7956d0 m43690c() {
            if (!m43689b()) {
                throw new NoSuchElementException();
            }
            List<C7956d0> list = this.f50733a;
            int i2 = this.f50734b;
            this.f50734b = i2 + 1;
            return list.get(i2);
        }
    }

    public C7975f(C7949a c7949a, C7973d c7973d, InterfaceC7957e interfaceC7957e, AbstractC8024p abstractC8024p) {
        this.f50725a = c7949a;
        this.f50726b = c7973d;
        this.f50727c = interfaceC7957e;
        this.f50728d = abstractC8024p;
        m43684h(c7949a.m43467l(), c7949a.m43462g());
    }

    /* JADX INFO: renamed from: b */
    static String m43680b(InetSocketAddress inetSocketAddress) {
        InetAddress address = inetSocketAddress.getAddress();
        return address == null ? inetSocketAddress.getHostName() : address.getHostAddress();
    }

    /* JADX INFO: renamed from: d */
    private boolean m43681d() {
        return this.f50730f < this.f50729e.size();
    }

    /* JADX INFO: renamed from: f */
    private Proxy m43682f() throws SocketException, UnknownHostException {
        if (m43681d()) {
            List<Proxy> list = this.f50729e;
            int i2 = this.f50730f;
            this.f50730f = i2 + 1;
            Proxy proxy = list.get(i2);
            m43683g(proxy);
            return proxy;
        }
        throw new SocketException("No route to " + this.f50725a.m43467l().m44102l() + "; exhausted proxy configurations: " + this.f50729e);
    }

    /* JADX INFO: renamed from: g */
    private void m43683g(Proxy proxy) throws SocketException, UnknownHostException {
        String strM44102l;
        int iM44106x;
        this.f50731g = new ArrayList();
        if (proxy.type() == Proxy.Type.DIRECT || proxy.type() == Proxy.Type.SOCKS) {
            strM44102l = this.f50725a.m43467l().m44102l();
            iM44106x = this.f50725a.m43467l().m44106x();
        } else {
            SocketAddress socketAddressAddress = proxy.address();
            if (!(socketAddressAddress instanceof InetSocketAddress)) {
                throw new IllegalArgumentException("Proxy.address() is not an InetSocketAddress: " + socketAddressAddress.getClass());
            }
            InetSocketAddress inetSocketAddress = (InetSocketAddress) socketAddressAddress;
            strM44102l = m43680b(inetSocketAddress);
            iM44106x = inetSocketAddress.getPort();
        }
        if (iM44106x < 1 || iM44106x > 65535) {
            throw new SocketException("No route to " + strM44102l + ":" + iM44106x + "; port is out of range");
        }
        if (proxy.type() == Proxy.Type.SOCKS) {
            this.f50731g.add(InetSocketAddress.createUnresolved(strM44102l, iM44106x));
            return;
        }
        this.f50728d.m44044j(this.f50727c, strM44102l);
        List<InetAddress> listMo44033a = this.f50725a.m43458c().mo44033a(strM44102l);
        if (listMo44033a.isEmpty()) {
            throw new UnknownHostException(this.f50725a.m43458c() + " returned no addresses for " + strM44102l);
        }
        this.f50728d.m44043i(this.f50727c, strM44102l, listMo44033a);
        int size = listMo44033a.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.f50731g.add(new InetSocketAddress(listMo44033a.get(i2), iM44106x));
        }
    }

    /* JADX INFO: renamed from: h */
    private void m43684h(C8027s c8027s, Proxy proxy) {
        List<Proxy> listM43596r;
        if (proxy != null) {
            listM43596r = Collections.singletonList(proxy);
        } else {
            List<Proxy> listSelect = this.f50725a.m43464i().select(c8027s.m44095D());
            listM43596r = (listSelect == null || listSelect.isEmpty()) ? C7962c.m43596r(Proxy.NO_PROXY) : C7962c.m43595q(listSelect);
        }
        this.f50729e = listM43596r;
        this.f50730f = 0;
    }

    /* JADX INFO: renamed from: a */
    public void m43685a(C7956d0 c7956d0, IOException iOException) {
        if (c7956d0.m43554b().type() != Proxy.Type.DIRECT && this.f50725a.m43464i() != null) {
            this.f50725a.m43464i().connectFailed(this.f50725a.m43467l().m44095D(), c7956d0.m43554b().address(), iOException);
        }
        this.f50726b.m43675b(c7956d0);
    }

    /* JADX INFO: renamed from: c */
    public boolean m43686c() {
        return m43681d() || !this.f50732h.isEmpty();
    }

    /* JADX INFO: renamed from: e */
    public a m43687e() throws SocketException, UnknownHostException {
        if (!m43686c()) {
            throw new NoSuchElementException();
        }
        ArrayList arrayList = new ArrayList();
        while (m43681d()) {
            Proxy proxyM43682f = m43682f();
            int size = this.f50731g.size();
            for (int i2 = 0; i2 < size; i2++) {
                C7956d0 c7956d0 = new C7956d0(this.f50725a, proxyM43682f, this.f50731g.get(i2));
                if (this.f50726b.m43676c(c7956d0)) {
                    this.f50732h.add(c7956d0);
                } else {
                    arrayList.add(c7956d0);
                }
            }
            if (!arrayList.isEmpty()) {
                break;
            }
        }
        if (arrayList.isEmpty()) {
            arrayList.addAll(this.f50732h);
            this.f50732h.clear();
        }
        return new a(arrayList);
    }
}
