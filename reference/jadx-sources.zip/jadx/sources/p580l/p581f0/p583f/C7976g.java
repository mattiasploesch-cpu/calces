package p580l.p581f0.p583f;

import java.io.IOException;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.net.Socket;
import java.util.List;
import p580l.AbstractC8024p;
import p580l.C7949a;
import p580l.C7956d0;
import p580l.C8018j;
import p580l.C8031w;
import p580l.InterfaceC7957e;
import p580l.InterfaceC8028t;
import p580l.p581f0.AbstractC7960a;
import p580l.p581f0.C7962c;
import p580l.p581f0.p584g.InterfaceC7979c;
import p580l.p581f0.p586i.C7989a;
import p580l.p581f0.p586i.C8002n;
import p580l.p581f0.p586i.EnumC7990b;

/* JADX INFO: renamed from: l.f0.f.g */
/* JADX INFO: loaded from: classes2.dex */
public final class C7976g {

    /* JADX INFO: renamed from: a */
    public final C7949a f50735a;

    /* JADX INFO: renamed from: b */
    private C7975f.a f50736b;

    /* JADX INFO: renamed from: c */
    private C7956d0 f50737c;

    /* JADX INFO: renamed from: d */
    private final C8018j f50738d;

    /* JADX INFO: renamed from: e */
    public final InterfaceC7957e f50739e;

    /* JADX INFO: renamed from: f */
    public final AbstractC8024p f50740f;

    /* JADX INFO: renamed from: g */
    private final Object f50741g;

    /* JADX INFO: renamed from: h */
    private final C7975f f50742h;

    /* JADX INFO: renamed from: i */
    private int f50743i;

    /* JADX INFO: renamed from: j */
    private C7972c f50744j;

    /* JADX INFO: renamed from: k */
    private boolean f50745k;

    /* JADX INFO: renamed from: l */
    private boolean f50746l;

    /* JADX INFO: renamed from: m */
    private boolean f50747m;

    /* JADX INFO: renamed from: n */
    private InterfaceC7979c f50748n;

    /* JADX INFO: renamed from: l.f0.f.g$a */
    public static final class a extends WeakReference<C7976g> {

        /* JADX INFO: renamed from: a */
        public final Object f50749a;

        a(C7976g c7976g, Object obj) {
            super(c7976g);
            this.f50749a = obj;
        }
    }

    public C7976g(C8018j c8018j, C7949a c7949a, InterfaceC7957e interfaceC7957e, AbstractC8024p abstractC8024p, Object obj) {
        this.f50738d = c8018j;
        this.f50735a = c7949a;
        this.f50739e = interfaceC7957e;
        this.f50740f = abstractC8024p;
        this.f50742h = new C7975f(c7949a, m43696o(), interfaceC7957e, abstractC8024p);
        this.f50741g = obj;
    }

    /* JADX WARN: Code duplicated, block: B:23:0x0046  */
    /* JADX INFO: renamed from: d */
    private Socket m43691d(boolean z, boolean z2, boolean z3) {
        Socket socketM43672q;
        if (z3) {
            this.f50748n = null;
        }
        if (z2) {
            this.f50746l = true;
        }
        C7972c c7972c = this.f50744j;
        if (c7972c == null) {
            return null;
        }
        if (z) {
            c7972c.f50717k = true;
        }
        if (this.f50748n != null) {
            return null;
        }
        if (!this.f50746l && !c7972c.f50717k) {
            return null;
        }
        m43694k(c7972c);
        if (this.f50744j.f50720n.isEmpty()) {
            this.f50744j.f50721o = System.nanoTime();
            if (AbstractC7960a.f50619a.mo43568e(this.f50738d, this.f50744j)) {
                socketM43672q = this.f50744j.m43672q();
            } else {
                socketM43672q = null;
            }
        } else {
            socketM43672q = null;
        }
        this.f50744j = null;
        return socketM43672q;
    }

    /* JADX INFO: renamed from: e */
    private C7972c m43692e(int i2, int i3, int i4, int i5, boolean z) throws Throwable {
        C7972c c7972c;
        Socket socketM43695m;
        C7972c c7972c2;
        Socket socketMo43569f;
        C7956d0 c7956d0M43690c;
        boolean z2;
        boolean z3;
        C7975f.a aVar;
        synchronized (this.f50738d) {
            if (this.f50746l) {
                throw new IllegalStateException("released");
            }
            if (this.f50748n != null) {
                throw new IllegalStateException("codec != null");
            }
            if (this.f50747m) {
                throw new IOException("Canceled");
            }
            c7972c = this.f50744j;
            socketM43695m = m43695m();
            c7972c2 = this.f50744j;
            socketMo43569f = null;
            if (c7972c2 != null) {
                c7972c = null;
            } else {
                c7972c2 = null;
            }
            if (!this.f50745k) {
                c7972c = null;
            }
            if (c7972c2 == null) {
                AbstractC7960a.f50619a.mo43571h(this.f50738d, this.f50735a, this, null);
                C7972c c7972c3 = this.f50744j;
                if (c7972c3 != null) {
                    c7972c2 = c7972c3;
                    z2 = true;
                    c7956d0M43690c = null;
                } else {
                    c7956d0M43690c = this.f50737c;
                }
            } else {
                c7956d0M43690c = null;
            }
            z2 = false;
        }
        C7962c.m43583e(socketM43695m);
        if (c7972c != null) {
            this.f50740f.m44042h(this.f50739e, c7972c);
        }
        if (z2) {
            this.f50740f.m44041g(this.f50739e, c7972c2);
        }
        if (c7972c2 != null) {
            return c7972c2;
        }
        if (c7956d0M43690c != null || ((aVar = this.f50736b) != null && aVar.m43689b())) {
            z3 = false;
        } else {
            this.f50736b = this.f50742h.m43687e();
            z3 = true;
        }
        synchronized (this.f50738d) {
            if (this.f50747m) {
                throw new IOException("Canceled");
            }
            if (z3) {
                List<C7956d0> listM43688a = this.f50736b.m43688a();
                int size = listM43688a.size();
                for (int i6 = 0; i6 < size; i6++) {
                    C7956d0 c7956d0 = listM43688a.get(i6);
                    AbstractC7960a.f50619a.mo43571h(this.f50738d, this.f50735a, this, c7956d0);
                    C7972c c7972c4 = this.f50744j;
                    if (c7972c4 != null) {
                        this.f50737c = c7956d0;
                        c7972c2 = c7972c4;
                        z2 = true;
                        break;
                    }
                }
            }
            if (!z2) {
                if (c7956d0M43690c == null) {
                    c7956d0M43690c = this.f50736b.m43690c();
                }
                this.f50737c = c7956d0M43690c;
                this.f50743i = 0;
                c7972c2 = new C7972c(this.f50738d, c7956d0M43690c);
                m43697a(c7972c2, false);
            }
        }
        if (!z2) {
            c7972c2.m43665c(i2, i3, i4, i5, z, this.f50739e, this.f50740f);
            m43696o().m43674a(c7972c2.m43671p());
            synchronized (this.f50738d) {
                this.f50745k = true;
                AbstractC7960a.f50619a.mo43572i(this.f50738d, c7972c2);
                if (c7972c2.m43669m()) {
                    socketMo43569f = AbstractC7960a.f50619a.mo43569f(this.f50738d, this.f50735a, this);
                    c7972c2 = this.f50744j;
                }
            }
            C7962c.m43583e(socketMo43569f);
        }
        this.f50740f.m44041g(this.f50739e, c7972c2);
        return c7972c2;
    }

    /* JADX INFO: renamed from: f */
    private C7972c m43693f(int i2, int i3, int i4, int i5, boolean z, boolean z2) throws Throwable {
        while (true) {
            C7972c c7972cM43692e = m43692e(i2, i3, i4, i5, z);
            synchronized (this.f50738d) {
                if (c7972cM43692e.f50718l == 0) {
                    return c7972cM43692e;
                }
                if (c7972cM43692e.m43668l(z2)) {
                    return c7972cM43692e;
                }
                m43702i();
            }
        }
    }

    /* JADX INFO: renamed from: k */
    private void m43694k(C7972c c7972c) {
        int size = c7972c.f50720n.size();
        for (int i2 = 0; i2 < size; i2++) {
            if (c7972c.f50720n.get(i2).get() == this) {
                c7972c.f50720n.remove(i2);
                return;
            }
        }
        throw new IllegalStateException();
    }

    /* JADX INFO: renamed from: m */
    private Socket m43695m() {
        C7972c c7972c = this.f50744j;
        if (c7972c == null || !c7972c.f50717k) {
            return null;
        }
        return m43691d(false, false, true);
    }

    /* JADX INFO: renamed from: o */
    private C7973d m43696o() {
        return AbstractC7960a.f50619a.mo43573j(this.f50738d);
    }

    /* JADX INFO: renamed from: a */
    public void m43697a(C7972c c7972c, boolean z) {
        if (this.f50744j != null) {
            throw new IllegalStateException();
        }
        this.f50744j = c7972c;
        this.f50745k = z;
        c7972c.f50720n.add(new a(this, this.f50741g));
    }

    /* JADX INFO: renamed from: b */
    public InterfaceC7979c m43698b() {
        InterfaceC7979c interfaceC7979c;
        synchronized (this.f50738d) {
            interfaceC7979c = this.f50748n;
        }
        return interfaceC7979c;
    }

    /* JADX INFO: renamed from: c */
    public synchronized C7972c m43699c() {
        return this.f50744j;
    }

    /* JADX INFO: renamed from: g */
    public boolean m43700g() {
        C7975f.a aVar;
        return this.f50737c != null || ((aVar = this.f50736b) != null && aVar.m43689b()) || this.f50742h.m43686c();
    }

    /* JADX INFO: renamed from: h */
    public InterfaceC7979c m43701h(C8031w c8031w, InterfaceC8028t.a aVar, boolean z) {
        try {
            InterfaceC7979c interfaceC7979cM43670o = m43693f(aVar.mo43741d(), aVar.mo43738a(), aVar.mo43739b(), c8031w.m44162s(), c8031w.m44168y(), z).m43670o(c8031w, aVar, this);
            synchronized (this.f50738d) {
                this.f50748n = interfaceC7979cM43670o;
            }
            return interfaceC7979cM43670o;
        } catch (IOException e2) {
            throw new C7974e(e2);
        }
    }

    /* JADX INFO: renamed from: i */
    public void m43702i() {
        C7972c c7972c;
        Socket socketM43691d;
        synchronized (this.f50738d) {
            c7972c = this.f50744j;
            socketM43691d = m43691d(true, false, false);
            if (this.f50744j != null) {
                c7972c = null;
            }
        }
        C7962c.m43583e(socketM43691d);
        if (c7972c != null) {
            this.f50740f.m44042h(this.f50739e, c7972c);
        }
    }

    /* JADX INFO: renamed from: j */
    public void m43703j() {
        C7972c c7972c;
        Socket socketM43691d;
        synchronized (this.f50738d) {
            c7972c = this.f50744j;
            socketM43691d = m43691d(false, true, false);
            if (this.f50744j != null) {
                c7972c = null;
            }
        }
        C7962c.m43583e(socketM43691d);
        if (c7972c != null) {
            this.f50740f.m44042h(this.f50739e, c7972c);
        }
    }

    /* JADX INFO: renamed from: l */
    public Socket m43704l(C7972c c7972c) {
        if (this.f50748n != null || this.f50744j.f50720n.size() != 1) {
            throw new IllegalStateException();
        }
        Reference<C7976g> reference = this.f50744j.f50720n.get(0);
        Socket socketM43691d = m43691d(true, false, false);
        this.f50744j = c7972c;
        c7972c.f50720n.add(reference);
        return socketM43691d;
    }

    /* JADX INFO: renamed from: n */
    public C7956d0 m43705n() {
        return this.f50737c;
    }

    /* JADX WARN: Code duplicated, block: B:27:0x0041  */
    /* JADX INFO: renamed from: p */
    public void m43706p(IOException iOException) {
        C7972c c7972c;
        boolean z;
        C7972c c7972c2;
        Socket socketM43691d;
        synchronized (this.f50738d) {
            c7972c = null;
            if (iOException instanceof C8002n) {
                EnumC7990b enumC7990b = ((C8002n) iOException).f50982u2;
                EnumC7990b enumC7990b2 = EnumC7990b.REFUSED_STREAM;
                if (enumC7990b == enumC7990b2) {
                    this.f50743i++;
                }
                if (enumC7990b != enumC7990b2 || this.f50743i > 1) {
                    this.f50737c = null;
                    z = true;
                } else {
                    z = false;
                }
                c7972c2 = this.f50744j;
                socketM43691d = m43691d(z, false, true);
                if (this.f50744j == null && this.f50745k) {
                    c7972c = c7972c2;
                }
            } else {
                C7972c c7972c3 = this.f50744j;
                if (c7972c3 == null || (c7972c3.m43669m() && !(iOException instanceof C7989a))) {
                    z = false;
                } else {
                    if (this.f50744j.f50718l == 0) {
                        C7956d0 c7956d0 = this.f50737c;
                        if (c7956d0 != null && iOException != null) {
                            this.f50742h.m43685a(c7956d0, iOException);
                        }
                        this.f50737c = null;
                    }
                    z = true;
                }
                c7972c2 = this.f50744j;
                socketM43691d = m43691d(z, false, true);
                if (this.f50744j == null) {
                    c7972c = c7972c2;
                }
            }
            throw th;
        }
        C7962c.m43583e(socketM43691d);
        if (c7972c != null) {
            this.f50740f.m44042h(this.f50739e, c7972c);
        }
    }

    /* JADX INFO: renamed from: q */
    public void m43707q(boolean z, InterfaceC7979c interfaceC7979c, long j2, IOException iOException) {
        C7972c c7972c;
        Socket socketM43691d;
        boolean z2;
        this.f50740f.m44049p(this.f50739e, j2);
        synchronized (this.f50738d) {
            if (interfaceC7979c != null) {
                if (interfaceC7979c == this.f50748n) {
                    if (!z) {
                        this.f50744j.f50718l++;
                    }
                    c7972c = this.f50744j;
                    socketM43691d = m43691d(z, false, true);
                    if (this.f50744j != null) {
                        c7972c = null;
                    }
                    z2 = this.f50746l;
                }
            }
            throw new IllegalStateException("expected " + this.f50748n + " but was " + interfaceC7979c);
        }
        C7962c.m43583e(socketM43691d);
        if (c7972c != null) {
            this.f50740f.m44042h(this.f50739e, c7972c);
        }
        if (iOException != null) {
            this.f50740f.m44036b(this.f50739e, iOException);
        } else if (z2) {
            this.f50740f.m44035a(this.f50739e);
        }
    }

    public String toString() {
        C7972c c7972cM43699c = m43699c();
        return c7972cM43699c != null ? c7972cM43699c.toString() : this.f50735a.toString();
    }
}
