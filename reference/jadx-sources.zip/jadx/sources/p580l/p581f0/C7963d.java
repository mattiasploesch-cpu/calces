package p580l.p581f0;

/* JADX INFO: renamed from: l.f0.d */
/* JADX INFO: loaded from: classes2.dex */
public final class C7963d {
    /* JADX INFO: renamed from: a */
    public static String m43606a() {
        return "okhttp/3.10.0";
    }
}
