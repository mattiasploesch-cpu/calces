package p580l.p581f0.p585h;

import java.io.EOFException;
import java.io.IOException;
import java.net.ProtocolException;
import java.util.concurrent.TimeUnit;
import p580l.AbstractC7954c0;
import p580l.C7952b0;
import p580l.C8026r;
import p580l.C8027s;
import p580l.C8031w;
import p580l.C8034z;
import p580l.p581f0.AbstractC7960a;
import p580l.p581f0.C7962c;
import p580l.p581f0.p583f.C7976g;
import p580l.p581f0.p584g.C7981e;
import p580l.p581f0.p584g.C7984h;
import p580l.p581f0.p584g.C7985i;
import p580l.p581f0.p584g.C7987k;
import p580l.p581f0.p584g.InterfaceC7979c;
import p590m.C8037c;
import p590m.C8043i;
import p590m.C8046l;
import p590m.C8054t;
import p590m.InterfaceC8038d;
import p590m.InterfaceC8039e;
import p590m.InterfaceC8052r;
import p590m.InterfaceC8053s;

/* JADX INFO: renamed from: l.f0.h.a */
/* JADX INFO: loaded from: classes2.dex */
public final class C7988a implements InterfaceC7979c {

    /* JADX INFO: renamed from: a */
    final C8031w f50780a;

    /* JADX INFO: renamed from: b */
    final C7976g f50781b;

    /* JADX INFO: renamed from: c */
    final InterfaceC8039e f50782c;

    /* JADX INFO: renamed from: d */
    final InterfaceC8038d f50783d;

    /* JADX INFO: renamed from: e */
    int f50784e = 0;

    /* JADX INFO: renamed from: f */
    private long f50785f = 262144;

    /* JADX INFO: renamed from: l.f0.h.a$b */
    private abstract class b implements InterfaceC8053s {

        /* JADX INFO: renamed from: u2 */
        protected final C8043i f50786u2;

        /* JADX INFO: renamed from: v2 */
        protected boolean f50787v2;

        /* JADX INFO: renamed from: w2 */
        protected long f50788w2;

        private b() {
            this.f50786u2 = new C8043i(C7988a.this.f50782c.mo43614S());
            this.f50788w2 = 0L;
        }

        @Override // p590m.InterfaceC8053s
        /* JADX INFO: renamed from: Rb */
        public long mo43613Rb(C8037c c8037c, long j2) throws IOException {
            try {
                long jMo43613Rb = C7988a.this.f50782c.mo43613Rb(c8037c, j2);
                if (jMo43613Rb > 0) {
                    this.f50788w2 += jMo43613Rb;
                }
                return jMo43613Rb;
            } catch (IOException e2) {
                m43770c(false, e2);
                throw e2;
            }
        }

        @Override // p590m.InterfaceC8053s
        /* JADX INFO: renamed from: S */
        public C8054t mo43614S() {
            return this.f50786u2;
        }

        /* JADX INFO: renamed from: c */
        protected final void m43770c(boolean z, IOException iOException) {
            C7988a c7988a = C7988a.this;
            int i2 = c7988a.f50784e;
            if (i2 == 6) {
                return;
            }
            if (i2 != 5) {
                throw new IllegalStateException("state: " + C7988a.this.f50784e);
            }
            c7988a.m43762g(this.f50786u2);
            C7988a c7988a2 = C7988a.this;
            c7988a2.f50784e = 6;
            C7976g c7976g = c7988a2.f50781b;
            if (c7976g != null) {
                c7976g.m43707q(!z, c7988a2, this.f50788w2, iOException);
            }
        }
    }

    /* JADX INFO: renamed from: l.f0.h.a$c */
    private final class c implements InterfaceC8052r {

        /* JADX INFO: renamed from: u2 */
        private final C8043i f50790u2;

        /* JADX INFO: renamed from: v2 */
        private boolean f50791v2;

        c() {
            this.f50790u2 = new C8043i(C7988a.this.f50783d.mo43771S());
        }

        @Override // p590m.InterfaceC8052r
        /* JADX INFO: renamed from: S */
        public C8054t mo43771S() {
            return this.f50790u2;
        }

        @Override // p590m.InterfaceC8052r
        /* JADX INFO: renamed from: Z7 */
        public void mo43652Z7(C8037c c8037c, long j2) {
            if (this.f50791v2) {
                throw new IllegalStateException("closed");
            }
            if (j2 == 0) {
                return;
            }
            C7988a.this.f50783d.mo44261s8(j2);
            C7988a.this.f50783d.mo44234T6("\r\n");
            C7988a.this.f50783d.mo43652Z7(c8037c, j2);
            C7988a.this.f50783d.mo44234T6("\r\n");
        }

        @Override // p590m.InterfaceC8052r, java.io.Closeable, java.lang.AutoCloseable
        public synchronized void close() {
            if (this.f50791v2) {
                return;
            }
            this.f50791v2 = true;
            C7988a.this.f50783d.mo44234T6("0\r\n\r\n");
            C7988a.this.m43762g(this.f50790u2);
            C7988a.this.f50784e = 3;
        }

        @Override // p590m.InterfaceC8052r, java.io.Flushable
        public synchronized void flush() {
            if (this.f50791v2) {
                return;
            }
            C7988a.this.f50783d.flush();
        }
    }

    /* JADX INFO: renamed from: l.f0.h.a$d */
    private class d extends b {

        /* JADX INFO: renamed from: A2 */
        private boolean f50793A2;

        /* JADX INFO: renamed from: y2 */
        private final C8027s f50795y2;

        /* JADX INFO: renamed from: z2 */
        private long f50796z2;

        d(C8027s c8027s) {
            super();
            this.f50796z2 = -1L;
            this.f50793A2 = true;
            this.f50795y2 = c8027s;
        }

        /* JADX INFO: renamed from: d */
        private void m43772d() throws ProtocolException {
            if (this.f50796z2 != -1) {
                C7988a.this.f50782c.mo44242ea();
            }
            try {
                this.f50796z2 = C7988a.this.f50782c.mo44249je();
                String strTrim = C7988a.this.f50782c.mo44242ea().trim();
                if (this.f50796z2 < 0 || !(strTrim.isEmpty() || strTrim.startsWith(";"))) {
                    throw new ProtocolException("expected chunk size and optional extensions but was \"" + this.f50796z2 + strTrim + "\"");
                }
                if (this.f50796z2 == 0) {
                    this.f50793A2 = false;
                    C7981e.m43724g(C7988a.this.f50780a.m44152h(), this.f50795y2, C7988a.this.m43768n());
                    m43770c(true, null);
                }
            } catch (NumberFormatException e2) {
                throw new ProtocolException(e2.getMessage());
            }
        }

        @Override // p580l.p581f0.p585h.C7988a.b, p590m.InterfaceC8053s
        /* JADX INFO: renamed from: Rb */
        public long mo43613Rb(C8037c c8037c, long j2) throws IOException {
            if (j2 < 0) {
                throw new IllegalArgumentException("byteCount < 0: " + j2);
            }
            if (this.f50787v2) {
                throw new IllegalStateException("closed");
            }
            if (!this.f50793A2) {
                return -1L;
            }
            long j3 = this.f50796z2;
            if (j3 == 0 || j3 == -1) {
                m43772d();
                if (!this.f50793A2) {
                    return -1L;
                }
            }
            long jMo43613Rb = super.mo43613Rb(c8037c, Math.min(j2, this.f50796z2));
            if (jMo43613Rb != -1) {
                this.f50796z2 -= jMo43613Rb;
                return jMo43613Rb;
            }
            ProtocolException protocolException = new ProtocolException("unexpected end of stream");
            m43770c(false, protocolException);
            throw protocolException;
        }

        @Override // p590m.InterfaceC8053s, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            if (this.f50787v2) {
                return;
            }
            if (this.f50793A2 && !C7962c.m43591m(this, 100, TimeUnit.MILLISECONDS)) {
                m43770c(false, null);
            }
            this.f50787v2 = true;
        }
    }

    /* JADX INFO: renamed from: l.f0.h.a$e */
    private final class e implements InterfaceC8052r {

        /* JADX INFO: renamed from: u2 */
        private final C8043i f50797u2;

        /* JADX INFO: renamed from: v2 */
        private boolean f50798v2;

        /* JADX INFO: renamed from: w2 */
        private long f50799w2;

        e(long j2) {
            this.f50797u2 = new C8043i(C7988a.this.f50783d.mo43771S());
            this.f50799w2 = j2;
        }

        @Override // p590m.InterfaceC8052r
        /* JADX INFO: renamed from: S */
        public C8054t mo43771S() {
            return this.f50797u2;
        }

        @Override // p590m.InterfaceC8052r
        /* JADX INFO: renamed from: Z7 */
        public void mo43652Z7(C8037c c8037c, long j2) throws ProtocolException {
            if (this.f50798v2) {
                throw new IllegalStateException("closed");
            }
            C7962c.m43581c(c8037c.m44265u(), 0L, j2);
            if (j2 <= this.f50799w2) {
                C7988a.this.f50783d.mo43652Z7(c8037c, j2);
                this.f50799w2 -= j2;
                return;
            }
            throw new ProtocolException("expected " + this.f50799w2 + " bytes but received " + j2);
        }

        @Override // p590m.InterfaceC8052r, java.io.Closeable, java.lang.AutoCloseable
        public void close() throws ProtocolException {
            if (this.f50798v2) {
                return;
            }
            this.f50798v2 = true;
            if (this.f50799w2 > 0) {
                throw new ProtocolException("unexpected end of stream");
            }
            C7988a.this.m43762g(this.f50797u2);
            C7988a.this.f50784e = 3;
        }

        @Override // p590m.InterfaceC8052r, java.io.Flushable
        public void flush() {
            if (this.f50798v2) {
                return;
            }
            C7988a.this.f50783d.flush();
        }
    }

    /* JADX INFO: renamed from: l.f0.h.a$f */
    private class f extends b {

        /* JADX INFO: renamed from: y2 */
        private long f50801y2;

        f(long j2) {
            super();
            this.f50801y2 = j2;
            if (j2 == 0) {
                m43770c(true, null);
            }
        }

        @Override // p580l.p581f0.p585h.C7988a.b, p590m.InterfaceC8053s
        /* JADX INFO: renamed from: Rb */
        public long mo43613Rb(C8037c c8037c, long j2) throws IOException {
            if (j2 < 0) {
                throw new IllegalArgumentException("byteCount < 0: " + j2);
            }
            if (this.f50787v2) {
                throw new IllegalStateException("closed");
            }
            long j3 = this.f50801y2;
            if (j3 == 0) {
                return -1L;
            }
            long jMo43613Rb = super.mo43613Rb(c8037c, Math.min(j3, j2));
            if (jMo43613Rb == -1) {
                ProtocolException protocolException = new ProtocolException("unexpected end of stream");
                m43770c(false, protocolException);
                throw protocolException;
            }
            long j4 = this.f50801y2 - jMo43613Rb;
            this.f50801y2 = j4;
            if (j4 == 0) {
                m43770c(true, null);
            }
            return jMo43613Rb;
        }

        @Override // p590m.InterfaceC8053s, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            if (this.f50787v2) {
                return;
            }
            if (this.f50801y2 != 0 && !C7962c.m43591m(this, 100, TimeUnit.MILLISECONDS)) {
                m43770c(false, null);
            }
            this.f50787v2 = true;
        }
    }

    /* JADX INFO: renamed from: l.f0.h.a$g */
    private class g extends b {

        /* JADX INFO: renamed from: y2 */
        private boolean f50803y2;

        g() {
            super();
        }

        @Override // p580l.p581f0.p585h.C7988a.b, p590m.InterfaceC8053s
        /* JADX INFO: renamed from: Rb */
        public long mo43613Rb(C8037c c8037c, long j2) throws IOException {
            if (j2 < 0) {
                throw new IllegalArgumentException("byteCount < 0: " + j2);
            }
            if (this.f50787v2) {
                throw new IllegalStateException("closed");
            }
            if (this.f50803y2) {
                return -1L;
            }
            long jMo43613Rb = super.mo43613Rb(c8037c, j2);
            if (jMo43613Rb != -1) {
                return jMo43613Rb;
            }
            this.f50803y2 = true;
            m43770c(true, null);
            return -1L;
        }

        @Override // p590m.InterfaceC8053s, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            if (this.f50787v2) {
                return;
            }
            if (!this.f50803y2) {
                m43770c(false, null);
            }
            this.f50787v2 = true;
        }
    }

    public C7988a(C8031w c8031w, C7976g c7976g, InterfaceC8039e interfaceC8039e, InterfaceC8038d interfaceC8038d) {
        this.f50780a = c8031w;
        this.f50781b = c7976g;
        this.f50782c = interfaceC8039e;
        this.f50783d = interfaceC8038d;
    }

    /* JADX INFO: renamed from: m */
    private String m43761m() {
        String strMo44220C5 = this.f50782c.mo44220C5(this.f50785f);
        this.f50785f -= (long) strMo44220C5.length();
        return strMo44220C5;
    }

    @Override // p580l.p581f0.p584g.InterfaceC7979c
    /* JADX INFO: renamed from: a */
    public void mo43709a() {
        this.f50783d.flush();
    }

    @Override // p580l.p581f0.p584g.InterfaceC7979c
    /* JADX INFO: renamed from: b */
    public void mo43710b(C8034z c8034z) {
        m43769o(c8034z.m44187e(), C7985i.m43749a(c8034z, this.f50781b.m43699c().m43671p().m43554b().type()));
    }

    @Override // p580l.p581f0.p584g.InterfaceC7979c
    /* JADX INFO: renamed from: c */
    public AbstractC7954c0 mo43711c(C7952b0 c7952b0) {
        C7976g c7976g = this.f50781b;
        c7976g.f50740f.m44050q(c7976g.f50739e);
        String strM43481h = c7952b0.m43481h("Content-Type");
        if (!C7981e.m43720c(c7952b0)) {
            return new C7984h(strM43481h, 0L, C8046l.m44313d(m43766k(0L)));
        }
        if ("chunked".equalsIgnoreCase(c7952b0.m43481h("Transfer-Encoding"))) {
            return new C7984h(strM43481h, -1L, C8046l.m44313d(m43764i(c7952b0.m43491u().m44191i())));
        }
        long jM43719b = C7981e.m43719b(c7952b0);
        return jM43719b != -1 ? new C7984h(strM43481h, jM43719b, C8046l.m44313d(m43766k(jM43719b))) : new C7984h(strM43481h, -1L, C8046l.m44313d(m43767l()));
    }

    @Override // p580l.p581f0.p584g.InterfaceC7979c
    /* JADX INFO: renamed from: d */
    public C7952b0.a mo43712d(boolean z) throws IOException {
        int i2 = this.f50784e;
        if (i2 != 1 && i2 != 3) {
            throw new IllegalStateException("state: " + this.f50784e);
        }
        try {
            C7987k c7987kM43760a = C7987k.m43760a(m43761m());
            C7952b0.a aVarM43501i = new C7952b0.a().m43505m(c7987kM43760a.f50777a).m43499g(c7987kM43760a.f50778b).m43502j(c7987kM43760a.f50779c).m43501i(m43768n());
            if (z && c7987kM43760a.f50778b == 100) {
                return null;
            }
            if (c7987kM43760a.f50778b == 100) {
                this.f50784e = 3;
                return aVarM43501i;
            }
            this.f50784e = 4;
            return aVarM43501i;
        } catch (EOFException e2) {
            IOException iOException = new IOException("unexpected end of stream on " + this.f50781b);
            iOException.initCause(e2);
            throw iOException;
        }
    }

    @Override // p580l.p581f0.p584g.InterfaceC7979c
    /* JADX INFO: renamed from: e */
    public void mo43713e() {
        this.f50783d.flush();
    }

    @Override // p580l.p581f0.p584g.InterfaceC7979c
    /* JADX INFO: renamed from: f */
    public InterfaceC8052r mo43714f(C8034z c8034z, long j2) {
        if ("chunked".equalsIgnoreCase(c8034z.m44185c("Transfer-Encoding"))) {
            return m43763h();
        }
        if (j2 != -1) {
            return m43765j(j2);
        }
        throw new IllegalStateException("Cannot stream a request body without chunked encoding or a known content length!");
    }

    /* JADX INFO: renamed from: g */
    void m43762g(C8043i c8043i) {
        C8054t c8054tM44302i = c8043i.m44302i();
        c8043i.m44303j(C8054t.f51375a);
        c8054tM44302i.mo44295a();
        c8054tM44302i.mo44296b();
    }

    /* JADX INFO: renamed from: h */
    public InterfaceC8052r m43763h() {
        if (this.f50784e == 1) {
            this.f50784e = 2;
            return new c();
        }
        throw new IllegalStateException("state: " + this.f50784e);
    }

    /* JADX INFO: renamed from: i */
    public InterfaceC8053s m43764i(C8027s c8027s) {
        if (this.f50784e == 4) {
            this.f50784e = 5;
            return new d(c8027s);
        }
        throw new IllegalStateException("state: " + this.f50784e);
    }

    /* JADX INFO: renamed from: j */
    public InterfaceC8052r m43765j(long j2) {
        if (this.f50784e == 1) {
            this.f50784e = 2;
            return new e(j2);
        }
        throw new IllegalStateException("state: " + this.f50784e);
    }

    /* JADX INFO: renamed from: k */
    public InterfaceC8053s m43766k(long j2) {
        if (this.f50784e == 4) {
            this.f50784e = 5;
            return new f(j2);
        }
        throw new IllegalStateException("state: " + this.f50784e);
    }

    /* JADX INFO: renamed from: l */
    public InterfaceC8053s m43767l() {
        if (this.f50784e != 4) {
            throw new IllegalStateException("state: " + this.f50784e);
        }
        C7976g c7976g = this.f50781b;
        if (c7976g == null) {
            throw new IllegalStateException("streamAllocation == null");
        }
        this.f50784e = 5;
        c7976g.m43702i();
        return new g();
    }

    /* JADX INFO: renamed from: n */
    public C8026r m43768n() {
        C8026r.a aVar = new C8026r.a();
        while (true) {
            String strM43761m = m43761m();
            if (strM43761m.length() == 0) {
                return aVar.m44074d();
            }
            AbstractC7960a.f50619a.mo43564a(aVar, strM43761m);
        }
    }

    /* JADX INFO: renamed from: o */
    public void m43769o(C8026r c8026r, String str) {
        if (this.f50784e != 0) {
            throw new IllegalStateException("state: " + this.f50784e);
        }
        this.f50783d.mo44234T6(str).mo44234T6("\r\n");
        int iM44067f = c8026r.m44067f();
        for (int i2 = 0; i2 < iM44067f; i2++) {
            this.f50783d.mo44234T6(c8026r.m44065c(i2)).mo44234T6(": ").mo44234T6(c8026r.m44068g(i2)).mo44234T6("\r\n");
        }
        this.f50783d.mo44234T6("\r\n");
        this.f50784e = 1;
    }
}
