package p580l.p581f0.p588k;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import javax.annotation.Nullable;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import p580l.EnumC8032x;
import p580l.p581f0.C7962c;

/* JADX INFO: renamed from: l.f0.k.c */
/* JADX INFO: loaded from: classes.dex */
final class C8006c extends C8009f {

    /* JADX INFO: renamed from: c */
    final Method f50997c;

    /* JADX INFO: renamed from: d */
    final Method f50998d;

    C8006c(Method method, Method method2) {
        this.f50997c = method;
        this.f50998d = method2;
    }

    /* JADX INFO: renamed from: r */
    public static C8006c m43956r() {
        try {
            return new C8006c(SSLParameters.class.getMethod("setApplicationProtocols", String[].class), SSLSocket.class.getMethod("getApplicationProtocol", new Class[0]));
        } catch (NoSuchMethodException unused) {
            return null;
        }
    }

    @Override // p580l.p581f0.p588k.C8009f
    /* JADX INFO: renamed from: f */
    public void mo43941f(SSLSocket sSLSocket, String str, List<EnumC8032x> list) {
        try {
            SSLParameters sSLParameters = sSLSocket.getSSLParameters();
            List<String> listM43966b = C8009f.m43966b(list);
            this.f50997c.invoke(sSLParameters, listM43966b.toArray(new String[listM43966b.size()]));
            sSLSocket.setSSLParameters(sSLParameters);
        } catch (IllegalAccessException | InvocationTargetException e2) {
            throw C7962c.m43579a("unable to set ssl parameters", e2);
        }
    }

    @Override // p580l.p581f0.p588k.C8009f
    @Nullable
    /* JADX INFO: renamed from: l */
    public String mo43943l(SSLSocket sSLSocket) {
        try {
            String str = (String) this.f50998d.invoke(sSLSocket, new Object[0]);
            if (str == null || str.equals("")) {
                return null;
            }
            return str;
        } catch (IllegalAccessException | InvocationTargetException e2) {
            throw C7962c.m43579a("unable to get selected protocols", e2);
        }
    }
}
