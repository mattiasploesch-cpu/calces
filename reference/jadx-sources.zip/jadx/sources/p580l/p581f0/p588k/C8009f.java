package p580l.p581f0.p588k;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.NoSuchAlgorithmException;
import java.security.Security;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Nullable;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.X509TrustManager;
import p580l.C8031w;
import p580l.EnumC8032x;
import p580l.p581f0.p589l.AbstractC8012c;
import p580l.p581f0.p589l.C8010a;
import p580l.p581f0.p589l.C8011b;
import p580l.p581f0.p589l.InterfaceC8014e;
import p590m.C8037c;

/* JADX INFO: renamed from: l.f0.k.f */
/* JADX INFO: loaded from: classes.dex */
public class C8009f {

    /* JADX INFO: renamed from: a */
    private static final C8009f f51010a = m43968h();

    /* JADX INFO: renamed from: b */
    private static final Logger f51011b = Logger.getLogger(C8031w.class.getName());

    /* JADX INFO: renamed from: b */
    public static List<String> m43966b(List<EnumC8032x> list) {
        ArrayList arrayList = new ArrayList(list.size());
        int size = list.size();
        for (int i2 = 0; i2 < size; i2++) {
            EnumC8032x enumC8032x = list.get(i2);
            if (enumC8032x != EnumC8032x.HTTP_1_0) {
                arrayList.add(enumC8032x.toString());
            }
        }
        return arrayList;
    }

    /* JADX INFO: renamed from: e */
    static byte[] m43967e(List<EnumC8032x> list) {
        C8037c c8037c = new C8037c();
        int size = list.size();
        for (int i2 = 0; i2 < size; i2++) {
            EnumC8032x enumC8032x = list.get(i2);
            if (enumC8032x != EnumC8032x.HTTP_1_0) {
                c8037c.mo44241e4(enumC8032x.toString().length());
                c8037c.mo44234T6(enumC8032x.toString());
            }
        }
        return c8037c.mo44226G3();
    }

    /* JADX INFO: renamed from: h */
    private static C8009f m43968h() {
        C8009f c8009fM43953r;
        C8009f c8009fM43937t = C8004a.m43937t();
        if (c8009fM43937t != null) {
            return c8009fM43937t;
        }
        if (m43970o() && (c8009fM43953r = C8005b.m43953r()) != null) {
            return c8009fM43953r;
        }
        C8006c c8006cM43956r = C8006c.m43956r();
        if (c8006cM43956r != null) {
            return c8006cM43956r;
        }
        C8009f c8009fM43957r = C8007d.m43957r();
        return c8009fM43957r != null ? c8009fM43957r : new C8009f();
    }

    /* JADX INFO: renamed from: i */
    public static C8009f m43969i() {
        return f51010a;
    }

    /* JADX INFO: renamed from: o */
    public static boolean m43970o() {
        if ("conscrypt".equals(System.getProperty("okhttp.platform"))) {
            return true;
        }
        return "Conscrypt".equals(Security.getProviders()[0].getName());
    }

    /* JADX INFO: renamed from: a */
    public void mo43958a(SSLSocket sSLSocket) {
    }

    /* JADX INFO: renamed from: c */
    public AbstractC8012c mo43939c(X509TrustManager x509TrustManager) {
        return new C8010a(mo43940d(x509TrustManager));
    }

    /* JADX INFO: renamed from: d */
    public InterfaceC8014e mo43940d(X509TrustManager x509TrustManager) {
        return new C8011b(x509TrustManager.getAcceptedIssuers());
    }

    /* JADX INFO: renamed from: f */
    public void mo43941f(SSLSocket sSLSocket, String str, List<EnumC8032x> list) {
    }

    /* JADX INFO: renamed from: g */
    public void mo43942g(Socket socket, InetSocketAddress inetSocketAddress, int i2) throws IOException {
        socket.connect(inetSocketAddress, i2);
    }

    /* JADX INFO: renamed from: j */
    public String m43971j() {
        return "OkHttp";
    }

    /* JADX INFO: renamed from: k */
    public SSLContext mo43955k() {
        try {
            return SSLContext.getInstance("TLS");
        } catch (NoSuchAlgorithmException e2) {
            throw new IllegalStateException("No TLS provider", e2);
        }
    }

    @Nullable
    /* JADX INFO: renamed from: l */
    public String mo43943l(SSLSocket sSLSocket) {
        return null;
    }

    /* JADX INFO: renamed from: m */
    public Object mo43944m(String str) {
        if (f51011b.isLoggable(Level.FINE)) {
            return new Throwable(str);
        }
        return null;
    }

    /* JADX INFO: renamed from: n */
    public boolean mo43945n(String str) {
        return true;
    }

    /* JADX INFO: renamed from: p */
    public void mo43946p(int i2, String str, Throwable th) {
        f51011b.log(i2 == 5 ? Level.WARNING : Level.INFO, str, th);
    }

    /* JADX INFO: renamed from: q */
    public void mo43947q(String str, Object obj) {
        if (obj == null) {
            str = str + " To see where this was allocated, set the OkHttpClient logger level to FINE: Logger.getLogger(OkHttpClient.class.getName()).setLevel(Level.FINE);";
        }
        mo43946p(5, str, (Throwable) obj);
    }
}
