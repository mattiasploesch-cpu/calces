package p580l.p581f0.p588k;

import android.os.Build;
import android.util.Log;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.Security;
import java.security.cert.Certificate;
import java.security.cert.TrustAnchor;
import java.security.cert.X509Certificate;
import java.util.List;
import javax.annotation.Nullable;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.X509TrustManager;
import p580l.EnumC8032x;
import p580l.p581f0.C7962c;
import p580l.p581f0.p589l.AbstractC8012c;
import p580l.p581f0.p589l.InterfaceC8014e;

/* JADX INFO: renamed from: l.f0.k.a */
/* JADX INFO: loaded from: classes.dex */
class C8004a extends C8009f {

    /* JADX INFO: renamed from: c */
    private final Class<?> f50984c;

    /* JADX INFO: renamed from: d */
    private final C8008e<Socket> f50985d;

    /* JADX INFO: renamed from: e */
    private final C8008e<Socket> f50986e;

    /* JADX INFO: renamed from: f */
    private final C8008e<Socket> f50987f;

    /* JADX INFO: renamed from: g */
    private final C8008e<Socket> f50988g;

    /* JADX INFO: renamed from: h */
    private final c f50989h = c.m43950b();

    /* JADX INFO: renamed from: l.f0.k.a$a */
    /* JADX INFO: loaded from: classes2.dex */
    static final class a extends AbstractC8012c {

        /* JADX INFO: renamed from: a */
        private final Object f50990a;

        /* JADX INFO: renamed from: b */
        private final Method f50991b;

        a(Object obj, Method method) {
            this.f50990a = obj;
            this.f50991b = method;
        }

        @Override // p580l.p581f0.p589l.AbstractC8012c
        /* JADX INFO: renamed from: a */
        public List<Certificate> mo43948a(List<Certificate> list, String str) throws SSLPeerUnverifiedException {
            try {
                return (List) this.f50991b.invoke(this.f50990a, (X509Certificate[]) list.toArray(new X509Certificate[list.size()]), "RSA", str);
            } catch (IllegalAccessException e2) {
                throw new AssertionError(e2);
            } catch (InvocationTargetException e3) {
                SSLPeerUnverifiedException sSLPeerUnverifiedException = new SSLPeerUnverifiedException(e3.getMessage());
                sSLPeerUnverifiedException.initCause(e3);
                throw sSLPeerUnverifiedException;
            }
        }

        public boolean equals(Object obj) {
            return obj instanceof a;
        }

        public int hashCode() {
            return 0;
        }
    }

    /* JADX INFO: renamed from: l.f0.k.a$b */
    /* JADX INFO: loaded from: classes2.dex */
    static final class b implements InterfaceC8014e {

        /* JADX INFO: renamed from: a */
        private final X509TrustManager f50992a;

        /* JADX INFO: renamed from: b */
        private final Method f50993b;

        b(X509TrustManager x509TrustManager, Method method) {
            this.f50993b = method;
            this.f50992a = x509TrustManager;
        }

        @Override // p580l.p581f0.p589l.InterfaceC8014e
        /* JADX INFO: renamed from: a */
        public X509Certificate mo43949a(X509Certificate x509Certificate) {
            try {
                TrustAnchor trustAnchor = (TrustAnchor) this.f50993b.invoke(this.f50992a, x509Certificate);
                if (trustAnchor != null) {
                    return trustAnchor.getTrustedCert();
                }
                return null;
            } catch (IllegalAccessException e2) {
                throw C7962c.m43579a("unable to get issues and signature", e2);
            } catch (InvocationTargetException unused) {
                return null;
            }
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof b)) {
                return false;
            }
            b bVar = (b) obj;
            return this.f50992a.equals(bVar.f50992a) && this.f50993b.equals(bVar.f50993b);
        }

        public int hashCode() {
            return this.f50992a.hashCode() + (this.f50993b.hashCode() * 31);
        }
    }

    /* JADX INFO: renamed from: l.f0.k.a$c */
    /* JADX INFO: loaded from: classes2.dex */
    static final class c {

        /* JADX INFO: renamed from: a */
        private final Method f50994a;

        /* JADX INFO: renamed from: b */
        private final Method f50995b;

        /* JADX INFO: renamed from: c */
        private final Method f50996c;

        c(Method method, Method method2, Method method3) {
            this.f50994a = method;
            this.f50995b = method2;
            this.f50996c = method3;
        }

        /* JADX INFO: renamed from: b */
        static c m43950b() throws NoSuchMethodException {
            Method method;
            Method method2;
            Method method3 = null;
            try {
                Class<?> cls = Class.forName("dalvik.system.CloseGuard");
                Method method4 = cls.getMethod("get", new Class[0]);
                method2 = cls.getMethod("open", String.class);
                method = cls.getMethod("warnIfOpen", new Class[0]);
                method3 = method4;
            } catch (Exception unused) {
                method = null;
                method2 = null;
            }
            return new c(method3, method2, method);
        }

        /* JADX INFO: renamed from: a */
        Object m43951a(String str) {
            Method method = this.f50994a;
            if (method != null) {
                try {
                    Object objInvoke = method.invoke(null, new Object[0]);
                    this.f50995b.invoke(objInvoke, str);
                    return objInvoke;
                } catch (Exception unused) {
                }
            }
            return null;
        }

        /* JADX INFO: renamed from: c */
        boolean m43952c(Object obj) {
            if (obj == null) {
                return false;
            }
            try {
                this.f50996c.invoke(obj, new Object[0]);
                return true;
            } catch (Exception unused) {
                return false;
            }
        }
    }

    C8004a(Class<?> cls, C8008e<Socket> c8008e, C8008e<Socket> c8008e2, C8008e<Socket> c8008e3, C8008e<Socket> c8008e4) {
        this.f50984c = cls;
        this.f50985d = c8008e;
        this.f50986e = c8008e2;
        this.f50987f = c8008e3;
        this.f50988g = c8008e4;
    }

    /* JADX INFO: renamed from: r */
    private boolean m43935r(String str, Class<?> cls, Object obj) {
        try {
            return ((Boolean) cls.getMethod("isCleartextTrafficPermitted", new Class[0]).invoke(obj, new Object[0])).booleanValue();
        } catch (NoSuchMethodException unused) {
            return super.mo43945n(str);
        }
    }

    /* JADX INFO: renamed from: s */
    private boolean m43936s(String str, Class<?> cls, Object obj) {
        try {
            return ((Boolean) cls.getMethod("isCleartextTrafficPermitted", String.class).invoke(obj, str)).booleanValue();
        } catch (NoSuchMethodException unused) {
            return m43935r(str, cls, obj);
        }
    }

    /* JADX INFO: renamed from: t */
    public static C8009f m43937t() {
        Class<?> cls;
        C8008e c8008e;
        C8008e c8008e2;
        try {
            try {
                cls = Class.forName("com.android.org.conscrypt.SSLParametersImpl");
            } catch (ClassNotFoundException unused) {
                cls = Class.forName("org.apache.harmony.xnet.provider.jsse.SSLParametersImpl");
            }
            Class<?> cls2 = cls;
            C8008e c8008e3 = new C8008e(null, "setUseSessionTickets", Boolean.TYPE);
            C8008e c8008e4 = new C8008e(null, "setHostname", String.class);
            if (m43938u()) {
                C8008e c8008e5 = new C8008e(byte[].class, "getAlpnSelectedProtocol", new Class[0]);
                c8008e2 = new C8008e(null, "setAlpnProtocols", byte[].class);
                c8008e = c8008e5;
            } else {
                c8008e = null;
                c8008e2 = null;
            }
            return new C8004a(cls2, c8008e3, c8008e4, c8008e, c8008e2);
        } catch (ClassNotFoundException unused2) {
            return null;
        }
    }

    /* JADX INFO: renamed from: u */
    private static boolean m43938u() {
        if (Security.getProvider("GMSCore_OpenSSL") != null) {
            return true;
        }
        try {
            Class.forName("android.net.Network");
            return true;
        } catch (ClassNotFoundException unused) {
            return false;
        }
    }

    @Override // p580l.p581f0.p588k.C8009f
    /* JADX INFO: renamed from: c */
    public AbstractC8012c mo43939c(X509TrustManager x509TrustManager) {
        try {
            Class<?> cls = Class.forName("android.net.http.X509TrustManagerExtensions");
            return new a(cls.getConstructor(X509TrustManager.class).newInstance(x509TrustManager), cls.getMethod("checkServerTrusted", X509Certificate[].class, String.class, String.class));
        } catch (Exception unused) {
            return super.mo43939c(x509TrustManager);
        }
    }

    @Override // p580l.p581f0.p588k.C8009f
    /* JADX INFO: renamed from: d */
    public InterfaceC8014e mo43940d(X509TrustManager x509TrustManager) {
        try {
            Method declaredMethod = x509TrustManager.getClass().getDeclaredMethod("findTrustAnchorByIssuerAndSignature", X509Certificate.class);
            declaredMethod.setAccessible(true);
            return new b(x509TrustManager, declaredMethod);
        } catch (NoSuchMethodException unused) {
            return super.mo43940d(x509TrustManager);
        }
    }

    @Override // p580l.p581f0.p588k.C8009f
    /* JADX INFO: renamed from: f */
    public void mo43941f(SSLSocket sSLSocket, String str, List<EnumC8032x> list) {
        if (str != null) {
            this.f50985d.m43963e(sSLSocket, Boolean.TRUE);
            this.f50986e.m43963e(sSLSocket, str);
        }
        C8008e<Socket> c8008e = this.f50988g;
        if (c8008e == null || !c8008e.m43965g(sSLSocket)) {
            return;
        }
        this.f50988g.m43964f(sSLSocket, C8009f.m43967e(list));
    }

    @Override // p580l.p581f0.p588k.C8009f
    /* JADX INFO: renamed from: g */
    public void mo43942g(Socket socket, InetSocketAddress inetSocketAddress, int i2) throws IOException {
        try {
            socket.connect(inetSocketAddress, i2);
        } catch (AssertionError e2) {
            if (!C7962c.m43601w(e2)) {
                throw e2;
            }
            throw new IOException(e2);
        } catch (ClassCastException e3) {
            if (Build.VERSION.SDK_INT != 26) {
                throw e3;
            }
            IOException iOException = new IOException("Exception in connect");
            iOException.initCause(e3);
            throw iOException;
        } catch (SecurityException e4) {
            IOException iOException2 = new IOException("Exception in connect");
            iOException2.initCause(e4);
            throw iOException2;
        }
    }

    @Override // p580l.p581f0.p588k.C8009f
    @Nullable
    /* JADX INFO: renamed from: l */
    public String mo43943l(SSLSocket sSLSocket) {
        byte[] bArr;
        C8008e<Socket> c8008e = this.f50987f;
        if (c8008e == null || !c8008e.m43965g(sSLSocket) || (bArr = (byte[]) this.f50987f.m43964f(sSLSocket, new Object[0])) == null) {
            return null;
        }
        return new String(bArr, C7962c.f50630j);
    }

    @Override // p580l.p581f0.p588k.C8009f
    /* JADX INFO: renamed from: m */
    public Object mo43944m(String str) {
        return this.f50989h.m43951a(str);
    }

    @Override // p580l.p581f0.p588k.C8009f
    /* JADX INFO: renamed from: n */
    public boolean mo43945n(String str) {
        try {
            Class<?> cls = Class.forName("android.security.NetworkSecurityPolicy");
            return m43936s(str, cls, cls.getMethod("getInstance", new Class[0]).invoke(null, new Object[0]));
        } catch (ClassNotFoundException | NoSuchMethodException unused) {
            return super.mo43945n(str);
        } catch (IllegalAccessException e2) {
            e = e2;
            throw C7962c.m43579a("unable to determine cleartext support", e);
        } catch (IllegalArgumentException e3) {
            e = e3;
            throw C7962c.m43579a("unable to determine cleartext support", e);
        } catch (InvocationTargetException e4) {
            e = e4;
            throw C7962c.m43579a("unable to determine cleartext support", e);
        }
    }

    @Override // p580l.p581f0.p588k.C8009f
    /* JADX INFO: renamed from: p */
    public void mo43946p(int i2, String str, Throwable th) {
        int iMin;
        int i3 = i2 != 5 ? 3 : 5;
        if (th != null) {
            str = str + '\n' + Log.getStackTraceString(th);
        }
        int i4 = 0;
        int length = str.length();
        while (i4 < length) {
            int iIndexOf = str.indexOf(10, i4);
            if (iIndexOf == -1) {
                iIndexOf = length;
            }
            while (true) {
                iMin = Math.min(iIndexOf, i4 + 4000);
                Log.println(i3, "OkHttp", str.substring(i4, iMin));
                if (iMin >= iIndexOf) {
                    break;
                } else {
                    i4 = iMin;
                }
            }
            i4 = iMin + 1;
        }
    }

    @Override // p580l.p581f0.p588k.C8009f
    /* JADX INFO: renamed from: q */
    public void mo43947q(String str, Object obj) {
        if (this.f50989h.m43952c(obj)) {
            return;
        }
        mo43946p(5, str, null);
    }
}
