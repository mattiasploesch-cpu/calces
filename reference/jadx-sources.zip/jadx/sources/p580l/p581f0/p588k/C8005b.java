package p580l.p581f0.p588k;

import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.util.List;
import javax.annotation.Nullable;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import org.conscrypt.Conscrypt;
import org.conscrypt.OpenSSLProvider;
import p580l.EnumC8032x;

/* JADX INFO: renamed from: l.f0.k.b */
/* JADX INFO: loaded from: classes.dex */
public class C8005b extends C8009f {
    private C8005b() {
    }

    /* JADX INFO: renamed from: r */
    public static C8009f m43953r() {
        try {
            Class.forName("org.conscrypt.ConscryptEngineSocket");
            if (!Conscrypt.isAvailable()) {
                return null;
            }
            Conscrypt.setUseEngineSocketByDefault(true);
            return new C8005b();
        } catch (ClassNotFoundException unused) {
            return null;
        }
    }

    /* JADX INFO: renamed from: s */
    private Provider m43954s() {
        return new OpenSSLProvider();
    }

    @Override // p580l.p581f0.p588k.C8009f
    /* JADX INFO: renamed from: f */
    public void mo43941f(SSLSocket sSLSocket, String str, List<EnumC8032x> list) {
        if (!Conscrypt.isConscrypt(sSLSocket)) {
            super.mo43941f(sSLSocket, str, list);
            return;
        }
        if (str != null) {
            Conscrypt.setUseSessionTickets(sSLSocket, true);
            Conscrypt.setHostname(sSLSocket, str);
        }
        Conscrypt.setApplicationProtocols(sSLSocket, (String[]) C8009f.m43966b(list).toArray(new String[0]));
    }

    @Override // p580l.p581f0.p588k.C8009f
    /* JADX INFO: renamed from: k */
    public SSLContext mo43955k() {
        try {
            return SSLContext.getInstance("TLS", m43954s());
        } catch (NoSuchAlgorithmException e2) {
            throw new IllegalStateException("No TLS provider", e2);
        }
    }

    @Override // p580l.p581f0.p588k.C8009f
    @Nullable
    /* JADX INFO: renamed from: l */
    public String mo43943l(SSLSocket sSLSocket) {
        return Conscrypt.isConscrypt(sSLSocket) ? Conscrypt.getApplicationProtocol(sSLSocket) : super.mo43943l(sSLSocket);
    }
}
