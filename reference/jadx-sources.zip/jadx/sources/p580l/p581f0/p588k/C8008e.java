package p580l.p581f0.p588k;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* JADX INFO: renamed from: l.f0.k.e */
/* JADX INFO: loaded from: classes2.dex */
class C8008e<T> {

    /* JADX INFO: renamed from: a */
    private final Class<?> f51007a;

    /* JADX INFO: renamed from: b */
    private final String f51008b;

    /* JADX INFO: renamed from: c */
    private final Class[] f51009c;

    C8008e(Class<?> cls, String str, Class... clsArr) {
        this.f51007a = cls;
        this.f51008b = str;
        this.f51009c = clsArr;
    }

    /* JADX INFO: renamed from: a */
    private Method m43959a(Class<?> cls) {
        Class<?> cls2;
        String str = this.f51008b;
        if (str == null) {
            return null;
        }
        Method methodM43960b = m43960b(cls, str, this.f51009c);
        if (methodM43960b == null || (cls2 = this.f51007a) == null || cls2.isAssignableFrom(methodM43960b.getReturnType())) {
            return methodM43960b;
        }
        return null;
    }

    /* JADX INFO: renamed from: b */
    private static Method m43960b(Class<?> cls, String str, Class[] clsArr) {
        try {
            Method method = cls.getMethod(str, clsArr);
            try {
                if ((method.getModifiers() & 1) == 0) {
                    return null;
                }
            } catch (NoSuchMethodException unused) {
            }
            return method;
        } catch (NoSuchMethodException unused2) {
            return null;
        }
    }

    /* JADX INFO: renamed from: c */
    public Object m43961c(T t, Object... objArr) {
        Method methodM43959a = m43959a(t.getClass());
        if (methodM43959a == null) {
            throw new AssertionError("Method " + this.f51008b + " not supported for object " + t);
        }
        try {
            return methodM43959a.invoke(t, objArr);
        } catch (IllegalAccessException e2) {
            AssertionError assertionError = new AssertionError("Unexpectedly could not call: " + methodM43959a);
            assertionError.initCause(e2);
            throw assertionError;
        }
    }

    /* JADX INFO: renamed from: d */
    public Object m43962d(T t, Object... objArr) {
        Method methodM43959a = m43959a(t.getClass());
        if (methodM43959a == null) {
            return null;
        }
        try {
            return methodM43959a.invoke(t, objArr);
        } catch (IllegalAccessException unused) {
            return null;
        }
    }

    /* JADX INFO: renamed from: e */
    public Object m43963e(T t, Object... objArr) {
        try {
            return m43962d(t, objArr);
        } catch (InvocationTargetException e2) {
            Throwable targetException = e2.getTargetException();
            if (targetException instanceof RuntimeException) {
                throw ((RuntimeException) targetException);
            }
            AssertionError assertionError = new AssertionError("Unexpected exception");
            assertionError.initCause(targetException);
            throw assertionError;
        }
    }

    /* JADX INFO: renamed from: f */
    public Object m43964f(T t, Object... objArr) {
        try {
            return m43961c(t, objArr);
        } catch (InvocationTargetException e2) {
            Throwable targetException = e2.getTargetException();
            if (targetException instanceof RuntimeException) {
                throw ((RuntimeException) targetException);
            }
            AssertionError assertionError = new AssertionError("Unexpected exception");
            assertionError.initCause(targetException);
            throw assertionError;
        }
    }

    /* JADX INFO: renamed from: g */
    public boolean m43965g(T t) {
        return m43959a(t.getClass()) != null;
    }
}
