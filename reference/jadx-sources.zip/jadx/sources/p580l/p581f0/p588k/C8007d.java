package p580l.p581f0.p588k;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.List;
import javax.annotation.Nullable;
import javax.net.ssl.SSLSocket;
import p580l.EnumC8032x;
import p580l.p581f0.C7962c;

/* JADX INFO: renamed from: l.f0.k.d */
/* JADX INFO: loaded from: classes.dex */
class C8007d extends C8009f {

    /* JADX INFO: renamed from: c */
    private final Method f50999c;

    /* JADX INFO: renamed from: d */
    private final Method f51000d;

    /* JADX INFO: renamed from: e */
    private final Method f51001e;

    /* JADX INFO: renamed from: f */
    private final Class<?> f51002f;

    /* JADX INFO: renamed from: g */
    private final Class<?> f51003g;

    /* JADX INFO: renamed from: l.f0.k.d$a */
    /* JADX INFO: loaded from: classes2.dex */
    private static class a implements InvocationHandler {

        /* JADX INFO: renamed from: a */
        private final List<String> f51004a;

        /* JADX INFO: renamed from: b */
        boolean f51005b;

        /* JADX INFO: renamed from: c */
        String f51006c;

        a(List<String> list) {
            this.f51004a = list;
        }

        @Override // java.lang.reflect.InvocationHandler
        public Object invoke(Object obj, Method method, Object[] objArr) {
            Object obj2;
            String name = method.getName();
            Class<?> returnType = method.getReturnType();
            if (objArr == null) {
                objArr = C7962c.f50622b;
            }
            if (name.equals("supports") && Boolean.TYPE == returnType) {
                return Boolean.TRUE;
            }
            if (name.equals("unsupported") && Void.TYPE == returnType) {
                this.f51005b = true;
                return null;
            }
            if (name.equals("protocols") && objArr.length == 0) {
                return this.f51004a;
            }
            if ((!name.equals("selectProtocol") && !name.equals("select")) || String.class != returnType || objArr.length != 1 || !(objArr[0] instanceof List)) {
                if ((!name.equals("protocolSelected") && !name.equals("selected")) || objArr.length != 1) {
                    return method.invoke(this, objArr);
                }
                this.f51006c = (String) objArr[0];
                return null;
            }
            List list = (List) objArr[0];
            int size = list.size();
            for (int i2 = 0; i2 < size; i2++) {
                if (this.f51004a.contains(list.get(i2))) {
                    obj2 = list.get(i2);
                    String str = (String) obj2;
                    this.f51006c = str;
                    return str;
                }
            }
            obj2 = this.f51004a.get(0);
            String str2 = (String) obj2;
            this.f51006c = str2;
            return str2;
        }
    }

    C8007d(Method method, Method method2, Method method3, Class<?> cls, Class<?> cls2) {
        this.f50999c = method;
        this.f51000d = method2;
        this.f51001e = method3;
        this.f51002f = cls;
        this.f51003g = cls2;
    }

    /* JADX INFO: renamed from: r */
    public static C8009f m43957r() {
        try {
            Class<?> cls = Class.forName("org.eclipse.jetty.alpn.ALPN");
            Class<?> cls2 = Class.forName("org.eclipse.jetty.alpn.ALPN$Provider");
            return new C8007d(cls.getMethod("put", SSLSocket.class, cls2), cls.getMethod("get", SSLSocket.class), cls.getMethod("remove", SSLSocket.class), Class.forName("org.eclipse.jetty.alpn.ALPN$ClientProvider"), Class.forName("org.eclipse.jetty.alpn.ALPN$ServerProvider"));
        } catch (ClassNotFoundException | NoSuchMethodException unused) {
            return null;
        }
    }

    @Override // p580l.p581f0.p588k.C8009f
    /* JADX INFO: renamed from: a */
    public void mo43958a(SSLSocket sSLSocket) {
        try {
            this.f51001e.invoke(null, sSLSocket);
        } catch (IllegalAccessException | InvocationTargetException e2) {
            throw C7962c.m43579a("unable to remove alpn", e2);
        }
    }

    @Override // p580l.p581f0.p588k.C8009f
    /* JADX INFO: renamed from: f */
    public void mo43941f(SSLSocket sSLSocket, String str, List<EnumC8032x> list) {
        try {
            this.f50999c.invoke(null, sSLSocket, Proxy.newProxyInstance(C8009f.class.getClassLoader(), new Class[]{this.f51002f, this.f51003g}, new a(C8009f.m43966b(list))));
        } catch (IllegalAccessException | InvocationTargetException e2) {
            throw C7962c.m43579a("unable to set alpn", e2);
        }
    }

    @Override // p580l.p581f0.p588k.C8009f
    @Nullable
    /* JADX INFO: renamed from: l */
    public String mo43943l(SSLSocket sSLSocket) {
        try {
            a aVar = (a) Proxy.getInvocationHandler(this.f51000d.invoke(null, sSLSocket));
            boolean z = aVar.f51005b;
            if (!z && aVar.f51006c == null) {
                C8009f.m43969i().mo43946p(4, "ALPN callback dropped: HTTP/2 is disabled. Is alpn-boot on the boot class path?", null);
                return null;
            }
            if (z) {
                return null;
            }
            return aVar.f51006c;
        } catch (IllegalAccessException | InvocationTargetException e2) {
            throw C7962c.m43579a("unable to get selected protocol", e2);
        }
    }
}
