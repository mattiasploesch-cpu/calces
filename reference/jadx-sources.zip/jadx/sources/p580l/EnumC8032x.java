package p580l;

import java.io.IOException;

/* JADX INFO: renamed from: l.x */
/* JADX INFO: loaded from: classes2.dex */
public enum EnumC8032x {
    HTTP_1_0("http/1.0"),
    HTTP_1_1("http/1.1"),
    SPDY_3("spdy/3.1"),
    HTTP_2("h2"),
    QUIC("quic");


    /* JADX INFO: renamed from: A2 */
    private final String f51298A2;

    EnumC8032x(String str) {
        this.f51298A2 = str;
    }

    /* JADX INFO: renamed from: c */
    public static EnumC8032x m44172c(String str) throws IOException {
        EnumC8032x enumC8032x = HTTP_1_0;
        if (str.equals(enumC8032x.f51298A2)) {
            return enumC8032x;
        }
        EnumC8032x enumC8032x2 = HTTP_1_1;
        if (str.equals(enumC8032x2.f51298A2)) {
            return enumC8032x2;
        }
        EnumC8032x enumC8032x3 = HTTP_2;
        if (str.equals(enumC8032x3.f51298A2)) {
            return enumC8032x3;
        }
        EnumC8032x enumC8032x4 = SPDY_3;
        if (str.equals(enumC8032x4.f51298A2)) {
            return enumC8032x4;
        }
        EnumC8032x enumC8032x5 = QUIC;
        if (str.equals(enumC8032x5.f51298A2)) {
            return enumC8032x5;
        }
        throw new IOException("Unexpected protocol: " + str);
    }

    @Override // java.lang.Enum
    public String toString() {
        return this.f51298A2;
    }
}
