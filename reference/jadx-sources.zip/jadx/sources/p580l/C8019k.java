package p580l;

import java.util.Arrays;
import java.util.List;
import javax.annotation.Nullable;
import javax.net.ssl.SSLSocket;
import p580l.p581f0.C7962c;

/* JADX INFO: renamed from: l.k */
/* JADX INFO: loaded from: classes.dex */
public final class C8019k {

    /* JADX INFO: renamed from: a */
    private static final C8016h[] f51146a;

    /* JADX INFO: renamed from: b */
    public static final C8019k f51147b;

    /* JADX INFO: renamed from: c */
    public static final C8019k f51148c;

    /* JADX INFO: renamed from: d */
    public static final C8019k f51149d;

    /* JADX INFO: renamed from: e */
    final boolean f51150e;

    /* JADX INFO: renamed from: f */
    final boolean f51151f;

    /* JADX INFO: renamed from: g */
    @Nullable
    final String[] f51152g;

    /* JADX INFO: renamed from: h */
    @Nullable
    final String[] f51153h;

    /* JADX INFO: renamed from: l.k$a */
    public static final class a {

        /* JADX INFO: renamed from: a */
        boolean f51154a;

        /* JADX INFO: renamed from: b */
        @Nullable
        String[] f51155b;

        /* JADX INFO: renamed from: c */
        @Nullable
        String[] f51156c;

        /* JADX INFO: renamed from: d */
        boolean f51157d;

        public a(C8019k c8019k) {
            this.f51154a = c8019k.f51150e;
            this.f51155b = c8019k.f51152g;
            this.f51156c = c8019k.f51153h;
            this.f51157d = c8019k.f51151f;
        }

        a(boolean z) {
            this.f51154a = z;
        }

        /* JADX INFO: renamed from: a */
        public C8019k m44006a() {
            return new C8019k(this);
        }

        /* JADX INFO: renamed from: b */
        public a m44007b(String... strArr) {
            if (!this.f51154a) {
                throw new IllegalStateException("no cipher suites for cleartext connections");
            }
            if (strArr.length == 0) {
                throw new IllegalArgumentException("At least one cipher suite is required");
            }
            this.f51155b = (String[]) strArr.clone();
            return this;
        }

        /* JADX INFO: renamed from: c */
        public a m44008c(C8016h... c8016hArr) {
            if (!this.f51154a) {
                throw new IllegalStateException("no cipher suites for cleartext connections");
            }
            String[] strArr = new String[c8016hArr.length];
            for (int i2 = 0; i2 < c8016hArr.length; i2++) {
                strArr[i2] = c8016hArr[i2].f51137k1;
            }
            return m44007b(strArr);
        }

        /* JADX INFO: renamed from: d */
        public a m44009d(boolean z) {
            if (!this.f51154a) {
                throw new IllegalStateException("no TLS extensions for cleartext connections");
            }
            this.f51157d = z;
            return this;
        }

        /* JADX INFO: renamed from: e */
        public a m44010e(String... strArr) {
            if (!this.f51154a) {
                throw new IllegalStateException("no TLS versions for cleartext connections");
            }
            if (strArr.length == 0) {
                throw new IllegalArgumentException("At least one TLS version is required");
            }
            this.f51156c = (String[]) strArr.clone();
            return this;
        }

        /* JADX INFO: renamed from: f */
        public a m44011f(EnumC7958e0... enumC7958e0Arr) {
            if (!this.f51154a) {
                throw new IllegalStateException("no TLS versions for cleartext connections");
            }
            String[] strArr = new String[enumC7958e0Arr.length];
            for (int i2 = 0; i2 < enumC7958e0Arr.length; i2++) {
                strArr[i2] = enumC7958e0Arr[i2].f50618A2;
            }
            return m44010e(strArr);
        }
    }

    static {
        C8016h[] c8016hArr = {C8016h.f51072Y0, C8016h.f51083c1, C8016h.f51074Z0, C8016h.f51086d1, C8016h.f51104j1, C8016h.f51101i1, C8016h.f51042J0, C8016h.f51044K0, C8016h.f51097h0, C8016h.f51100i0, C8016h.f51033F, C8016h.f51041J, C8016h.f51102j};
        f51146a = c8016hArr;
        a aVarM44008c = new a(true).m44008c(c8016hArr);
        EnumC7958e0 enumC7958e0 = EnumC7958e0.TLS_1_0;
        C8019k c8019kM44006a = aVarM44008c.m44011f(EnumC7958e0.TLS_1_3, EnumC7958e0.TLS_1_2, EnumC7958e0.TLS_1_1, enumC7958e0).m44009d(true).m44006a();
        f51147b = c8019kM44006a;
        f51148c = new a(c8019kM44006a).m44011f(enumC7958e0).m44009d(true).m44006a();
        f51149d = new a(false).m44006a();
    }

    C8019k(a aVar) {
        this.f51150e = aVar.f51154a;
        this.f51152g = aVar.f51155b;
        this.f51153h = aVar.f51156c;
        this.f51151f = aVar.f51157d;
    }

    /* JADX INFO: renamed from: e */
    private C8019k m43999e(SSLSocket sSLSocket, boolean z) {
        String[] strArrM43600v = this.f51152g != null ? C7962c.m43600v(C8016h.f51075a, sSLSocket.getEnabledCipherSuites(), this.f51152g) : sSLSocket.getEnabledCipherSuites();
        String[] strArrM43600v2 = this.f51153h != null ? C7962c.m43600v(C7962c.f50637q, sSLSocket.getEnabledProtocols(), this.f51153h) : sSLSocket.getEnabledProtocols();
        String[] supportedCipherSuites = sSLSocket.getSupportedCipherSuites();
        int iM43597s = C7962c.m43597s(C8016h.f51075a, supportedCipherSuites, "TLS_FALLBACK_SCSV");
        if (z && iM43597s != -1) {
            strArrM43600v = C7962c.m43584f(strArrM43600v, supportedCipherSuites[iM43597s]);
        }
        return new a(this).m44007b(strArrM43600v).m44010e(strArrM43600v2).m44006a();
    }

    /* JADX INFO: renamed from: a */
    void m44000a(SSLSocket sSLSocket, boolean z) {
        C8019k c8019kM43999e = m43999e(sSLSocket, z);
        String[] strArr = c8019kM43999e.f51153h;
        if (strArr != null) {
            sSLSocket.setEnabledProtocols(strArr);
        }
        String[] strArr2 = c8019kM43999e.f51152g;
        if (strArr2 != null) {
            sSLSocket.setEnabledCipherSuites(strArr2);
        }
    }

    @Nullable
    /* JADX INFO: renamed from: b */
    public List<C8016h> m44001b() {
        String[] strArr = this.f51152g;
        if (strArr != null) {
            return C8016h.m43989b(strArr);
        }
        return null;
    }

    /* JADX INFO: renamed from: c */
    public boolean m44002c(SSLSocket sSLSocket) {
        if (!this.f51150e) {
            return false;
        }
        String[] strArr = this.f51153h;
        if (strArr != null && !C7962c.m43602x(C7962c.f50637q, strArr, sSLSocket.getEnabledProtocols())) {
            return false;
        }
        String[] strArr2 = this.f51152g;
        return strArr2 == null || C7962c.m43602x(C8016h.f51075a, strArr2, sSLSocket.getEnabledCipherSuites());
    }

    /* JADX INFO: renamed from: d */
    public boolean m44003d() {
        return this.f51150e;
    }

    public boolean equals(@Nullable Object obj) {
        if (!(obj instanceof C8019k)) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        C8019k c8019k = (C8019k) obj;
        boolean z = this.f51150e;
        if (z != c8019k.f51150e) {
            return false;
        }
        return !z || (Arrays.equals(this.f51152g, c8019k.f51152g) && Arrays.equals(this.f51153h, c8019k.f51153h) && this.f51151f == c8019k.f51151f);
    }

    /* JADX INFO: renamed from: f */
    public boolean m44004f() {
        return this.f51151f;
    }

    @Nullable
    /* JADX INFO: renamed from: g */
    public List<EnumC7958e0> m44005g() {
        String[] strArr = this.f51153h;
        if (strArr != null) {
            return EnumC7958e0.m43560e(strArr);
        }
        return null;
    }

    public int hashCode() {
        if (this.f51150e) {
            return ((((527 + Arrays.hashCode(this.f51152g)) * 31) + Arrays.hashCode(this.f51153h)) * 31) + (!this.f51151f ? 1 : 0);
        }
        return 17;
    }

    public String toString() {
        if (!this.f51150e) {
            return "ConnectionSpec()";
        }
        return "ConnectionSpec(cipherSuites=" + (this.f51152g != null ? m44001b().toString() : "[all enabled]") + ", tlsVersions=" + (this.f51153h != null ? m44005g().toString() : "[all enabled]") + ", supportsTlsExtensions=" + this.f51151f + ")";
    }
}
