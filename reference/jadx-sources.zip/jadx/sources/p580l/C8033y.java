package p580l;

import java.io.IOException;
import java.util.ArrayList;
import p580l.p581f0.AbstractRunnableC7961b;
import p580l.p581f0.p582e.C7964a;
import p580l.p581f0.p583f.C7970a;
import p580l.p581f0.p584g.C7977a;
import p580l.p581f0.p584g.C7978b;
import p580l.p581f0.p584g.C7983g;
import p580l.p581f0.p584g.C7986j;
import p580l.p581f0.p588k.C8009f;

/* JADX INFO: renamed from: l.y */
/* JADX INFO: loaded from: classes2.dex */
final class C8033y implements InterfaceC7957e {

    /* JADX INFO: renamed from: u2 */
    final C8031w f51299u2;

    /* JADX INFO: renamed from: v2 */
    final C7986j f51300v2;

    /* JADX INFO: renamed from: w2 */
    private AbstractC8024p f51301w2;

    /* JADX INFO: renamed from: x2 */
    final C8034z f51302x2;

    /* JADX INFO: renamed from: y2 */
    final boolean f51303y2;

    /* JADX INFO: renamed from: z2 */
    private boolean f51304z2;

    /* JADX INFO: renamed from: l.y$a */
    final class a extends AbstractRunnableC7961b {

        /* JADX INFO: renamed from: v2 */
        private final InterfaceC7959f f51305v2;

        /* JADX INFO: renamed from: w2 */
        final /* synthetic */ C8033y f51306w2;

        @Override // p580l.p581f0.AbstractRunnableC7961b
        /* JADX INFO: renamed from: k */
        protected void mo43574k() {
            IOException e2;
            boolean z = true;
            try {
                try {
                    C7952b0 c7952b0M44177d = this.f51306w2.m44177d();
                    try {
                        if (this.f51306w2.f51300v2.m43758d()) {
                            this.f51305v2.m43563b(this.f51306w2, new IOException("Canceled"));
                        } else {
                            this.f51305v2.m43562a(this.f51306w2, c7952b0M44177d);
                        }
                    } catch (IOException e3) {
                        e2 = e3;
                        if (z) {
                            C8009f.m43969i().mo43946p(4, "Callback failure for " + this.f51306w2.m44180h(), e2);
                        } else {
                            this.f51306w2.f51301w2.m44036b(this.f51306w2, e2);
                            this.f51305v2.m43563b(this.f51306w2, e2);
                        }
                    }
                } catch (IOException e4) {
                    e2 = e4;
                    z = false;
                }
            } finally {
                this.f51306w2.f51299u2.m44153i().m44030d(this);
            }
        }

        /* JADX INFO: renamed from: l */
        C8033y m44181l() {
            return this.f51306w2;
        }

        /* JADX INFO: renamed from: m */
        String m44182m() {
            return this.f51306w2.f51302x2.m44191i().m44102l();
        }
    }

    private C8033y(C8031w c8031w, C8034z c8034z, boolean z) {
        this.f51299u2 = c8031w;
        this.f51302x2 = c8034z;
        this.f51303y2 = z;
        this.f51300v2 = new C7986j(c8031w, z);
    }

    /* JADX INFO: renamed from: b */
    private void m44174b() {
        this.f51300v2.m43759i(C8009f.m43969i().mo43944m("response.body().close()"));
    }

    /* JADX INFO: renamed from: f */
    static C8033y m44175f(C8031w c8031w, C8034z c8034z, boolean z) {
        C8033y c8033y = new C8033y(c8031w, c8034z, z);
        c8033y.f51301w2 = c8031w.m44155k().mo44055a(c8033y);
        return c8033y;
    }

    @Override // p580l.InterfaceC7957e
    /* JADX INFO: renamed from: A0 */
    public C7952b0 mo43557A0() {
        synchronized (this) {
            if (this.f51304z2) {
                throw new IllegalStateException("Already Executed");
            }
            this.f51304z2 = true;
        }
        m44174b();
        this.f51301w2.m44037c(this);
        try {
            try {
                this.f51299u2.m44153i().m44028a(this);
                C7952b0 c7952b0M44177d = m44177d();
                if (c7952b0M44177d == null) {
                    throw new IOException("Canceled");
                }
                this.f51299u2.m44153i().m44031e(this);
                return c7952b0M44177d;
            } catch (IOException e2) {
                this.f51301w2.m44036b(this, e2);
                throw e2;
            }
        } catch (Throwable th) {
            this.f51299u2.m44153i().m44031e(this);
            throw th;
        }
    }

    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public C8033y clone() {
        return m44175f(this.f51299u2, this.f51302x2, this.f51303y2);
    }

    /* JADX INFO: renamed from: d */
    C7952b0 m44177d() {
        ArrayList arrayList = new ArrayList();
        arrayList.addAll(this.f51299u2.m44159p());
        arrayList.add(this.f51300v2);
        arrayList.add(new C7977a(this.f51299u2.m44152h()));
        arrayList.add(new C7964a(this.f51299u2.m44160q()));
        arrayList.add(new C7970a(this.f51299u2));
        if (!this.f51303y2) {
            arrayList.addAll(this.f51299u2.m44161r());
        }
        arrayList.add(new C7978b(this.f51303y2));
        return new C7983g(arrayList, null, null, null, 0, this.f51302x2, this, this.f51301w2, this.f51299u2.m44149e(), this.f51299u2.m44167x(), this.f51299u2.m44145D()).mo43740c(this.f51302x2);
    }

    /* JADX INFO: renamed from: e */
    public boolean m44178e() {
        return this.f51300v2.m43758d();
    }

    /* JADX INFO: renamed from: g */
    String m44179g() {
        return this.f51302x2.m44191i().m44092A();
    }

    /* JADX INFO: renamed from: h */
    String m44180h() {
        StringBuilder sb = new StringBuilder();
        sb.append(m44178e() ? "canceled " : "");
        sb.append(this.f51303y2 ? "web socket" : "call");
        sb.append(" to ");
        sb.append(m44179g());
        return sb.toString();
    }
}
