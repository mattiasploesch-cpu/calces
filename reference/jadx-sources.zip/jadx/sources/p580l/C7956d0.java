package p580l;

import java.net.InetSocketAddress;
import java.net.Proxy;
import javax.annotation.Nullable;

/* JADX INFO: renamed from: l.d0 */
/* JADX INFO: loaded from: classes.dex */
public final class C7956d0 {

    /* JADX INFO: renamed from: a */
    final C7949a f50609a;

    /* JADX INFO: renamed from: b */
    final Proxy f50610b;

    /* JADX INFO: renamed from: c */
    final InetSocketAddress f50611c;

    public C7956d0(C7949a c7949a, Proxy proxy, InetSocketAddress inetSocketAddress) {
        if (c7949a == null) {
            throw new NullPointerException("address == null");
        }
        if (proxy == null) {
            throw new NullPointerException("proxy == null");
        }
        if (inetSocketAddress == null) {
            throw new NullPointerException("inetSocketAddress == null");
        }
        this.f50609a = c7949a;
        this.f50610b = proxy;
        this.f50611c = inetSocketAddress;
    }

    /* JADX INFO: renamed from: a */
    public C7949a m43553a() {
        return this.f50609a;
    }

    /* JADX INFO: renamed from: b */
    public Proxy m43554b() {
        return this.f50610b;
    }

    /* JADX INFO: renamed from: c */
    public boolean m43555c() {
        return this.f50609a.f50514i != null && this.f50610b.type() == Proxy.Type.HTTP;
    }

    /* JADX INFO: renamed from: d */
    public InetSocketAddress m43556d() {
        return this.f50611c;
    }

    public boolean equals(@Nullable Object obj) {
        if (obj instanceof C7956d0) {
            C7956d0 c7956d0 = (C7956d0) obj;
            if (c7956d0.f50609a.equals(this.f50609a) && c7956d0.f50610b.equals(this.f50610b) && c7956d0.f50611c.equals(this.f50611c)) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        return ((((527 + this.f50609a.hashCode()) * 31) + this.f50610b.hashCode()) * 31) + this.f50611c.hashCode();
    }

    public String toString() {
        return "Route{" + this.f50611c + "}";
    }
}
