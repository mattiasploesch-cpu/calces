package p580l;

import java.net.URL;
import java.util.List;
import javax.annotation.Nullable;
import p580l.p581f0.p584g.C7982f;

/* JADX INFO: renamed from: l.z */
/* JADX INFO: loaded from: classes.dex */
public final class C8034z {

    /* JADX INFO: renamed from: a */
    final C8027s f51307a;

    /* JADX INFO: renamed from: b */
    final String f51308b;

    /* JADX INFO: renamed from: c */
    final C8026r f51309c;

    /* JADX INFO: renamed from: d */
    @Nullable
    final AbstractC7950a0 f51310d;

    /* JADX INFO: renamed from: e */
    final Object f51311e;

    /* JADX INFO: renamed from: f */
    private volatile C7955d f51312f;

    /* JADX INFO: renamed from: l.z$a */
    public static class a {

        /* JADX INFO: renamed from: a */
        C8027s f51313a;

        /* JADX INFO: renamed from: b */
        String f51314b;

        /* JADX INFO: renamed from: c */
        C8026r.a f51315c;

        /* JADX INFO: renamed from: d */
        AbstractC7950a0 f51316d;

        /* JADX INFO: renamed from: e */
        Object f51317e;

        public a() {
            this.f51314b = "GET";
            this.f51315c = new C8026r.a();
        }

        a(C8034z c8034z) {
            this.f51313a = c8034z.f51307a;
            this.f51314b = c8034z.f51308b;
            this.f51316d = c8034z.f51310d;
            this.f51317e = c8034z.f51311e;
            this.f51315c = c8034z.f51309c.m44066d();
        }

        /* JADX INFO: renamed from: a */
        public C8034z m44192a() {
            if (this.f51313a != null) {
                return new C8034z(this);
            }
            throw new IllegalStateException("url == null");
        }

        /* JADX INFO: renamed from: b */
        public a m44193b(C7955d c7955d) {
            String string = c7955d.toString();
            return string.isEmpty() ? m44198g("Cache-Control") : m44194c("Cache-Control", string);
        }

        /* JADX INFO: renamed from: c */
        public a m44194c(String str, String str2) {
            this.f51315c.m44077h(str, str2);
            return this;
        }

        /* JADX INFO: renamed from: d */
        public a m44195d(C8026r c8026r) {
            this.f51315c = c8026r.m44066d();
            return this;
        }

        /* JADX INFO: renamed from: e */
        public a m44196e(String str, @Nullable AbstractC7950a0 abstractC7950a0) {
            if (str == null) {
                throw new NullPointerException("method == null");
            }
            if (str.length() == 0) {
                throw new IllegalArgumentException("method.length() == 0");
            }
            if (abstractC7950a0 != null && !C7982f.m43734b(str)) {
                throw new IllegalArgumentException("method " + str + " must not have a request body.");
            }
            if (abstractC7950a0 != null || !C7982f.m43737e(str)) {
                this.f51314b = str;
                this.f51316d = abstractC7950a0;
                return this;
            }
            throw new IllegalArgumentException("method " + str + " must have a request body.");
        }

        /* JADX INFO: renamed from: f */
        public a m44197f(AbstractC7950a0 abstractC7950a0) {
            return m44196e("POST", abstractC7950a0);
        }

        /* JADX INFO: renamed from: g */
        public a m44198g(String str) {
            this.f51315c.m44076g(str);
            return this;
        }

        /* JADX WARN: Code duplicated, block: B:12:0x0045  */
        /* JADX WARN: Code duplicated, block: B:14:0x004a  */
        /* JADX WARN: Instruction removed from duplicated block: B:14:0x004a, please report this as an issue */
        /* JADX INFO: renamed from: h */
        public a m44199h(String str) {
            StringBuilder sb;
            int i2;
            C8027s c8027sM44084q;
            if (str == null) {
                throw new NullPointerException("url == null");
            }
            if (!str.regionMatches(true, 0, "ws:", 0, 3)) {
                if (str.regionMatches(true, 0, "wss:", 0, 4)) {
                    sb = new StringBuilder();
                    sb.append("https:");
                    i2 = 4;
                }
                c8027sM44084q = C8027s.m44084q(str);
                if (c8027sM44084q != null) {
                    return m44201j(c8027sM44084q);
                }
                throw new IllegalArgumentException("unexpected url: " + str);
            }
            sb = new StringBuilder();
            sb.append("http:");
            i2 = 3;
            sb.append(str.substring(i2));
            str = sb.toString();
            c8027sM44084q = C8027s.m44084q(str);
            if (c8027sM44084q != null) {
                return m44201j(c8027sM44084q);
            }
            throw new IllegalArgumentException("unexpected url: " + str);
        }

        /* JADX INFO: renamed from: i */
        public a m44200i(URL url) {
            if (url == null) {
                throw new NullPointerException("url == null");
            }
            C8027s c8027sM44082k = C8027s.m44082k(url);
            if (c8027sM44082k != null) {
                return m44201j(c8027sM44082k);
            }
            throw new IllegalArgumentException("unexpected url: " + url);
        }

        /* JADX INFO: renamed from: j */
        public a m44201j(C8027s c8027s) {
            if (c8027s == null) {
                throw new NullPointerException("url == null");
            }
            this.f51313a = c8027s;
            return this;
        }
    }

    C8034z(a aVar) {
        this.f51307a = aVar.f51313a;
        this.f51308b = aVar.f51314b;
        this.f51309c = aVar.f51315c.m44074d();
        this.f51310d = aVar.f51316d;
        Object obj = aVar.f51317e;
        this.f51311e = obj == null ? this : obj;
    }

    @Nullable
    /* JADX INFO: renamed from: a */
    public AbstractC7950a0 m44183a() {
        return this.f51310d;
    }

    /* JADX INFO: renamed from: b */
    public C7955d m44184b() {
        C7955d c7955d = this.f51312f;
        if (c7955d != null) {
            return c7955d;
        }
        C7955d c7955dM43537l = C7955d.m43537l(this.f51309c);
        this.f51312f = c7955dM43537l;
        return c7955dM43537l;
    }

    @Nullable
    /* JADX INFO: renamed from: c */
    public String m44185c(String str) {
        return this.f51309c.m44064a(str);
    }

    /* JADX INFO: renamed from: d */
    public List<String> m44186d(String str) {
        return this.f51309c.m44069h(str);
    }

    /* JADX INFO: renamed from: e */
    public C8026r m44187e() {
        return this.f51309c;
    }

    /* JADX INFO: renamed from: f */
    public boolean m44188f() {
        return this.f51307a.m44103m();
    }

    /* JADX INFO: renamed from: g */
    public String m44189g() {
        return this.f51308b;
    }

    /* JADX INFO: renamed from: h */
    public a m44190h() {
        return new a(this);
    }

    /* JADX INFO: renamed from: i */
    public C8027s m44191i() {
        return this.f51307a;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Request{method=");
        sb.append(this.f51308b);
        sb.append(", url=");
        sb.append(this.f51307a);
        sb.append(", tag=");
        Object obj = this.f51311e;
        if (obj == this) {
            obj = null;
        }
        sb.append(obj);
        sb.append('}');
        return sb.toString();
    }
}
