package p580l;

import java.io.Closeable;
import java.io.File;
import java.io.Flushable;
import java.io.IOException;
import java.security.cert.Certificate;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import p580l.p581f0.C7962c;
import p580l.p581f0.p582e.C7966c;
import p580l.p581f0.p582e.C7967d;
import p580l.p581f0.p582e.InterfaceC7965b;
import p580l.p581f0.p582e.InterfaceC7969f;
import p580l.p581f0.p584g.C7981e;
import p580l.p581f0.p584g.C7982f;
import p580l.p581f0.p584g.C7987k;
import p580l.p581f0.p587j.InterfaceC8003a;
import p580l.p581f0.p588k.C8009f;
import p590m.AbstractC8041g;
import p590m.AbstractC8042h;
import p590m.C8037c;
import p590m.C8040f;
import p590m.C8046l;
import p590m.InterfaceC8038d;
import p590m.InterfaceC8039e;
import p590m.InterfaceC8052r;
import p590m.InterfaceC8053s;

/* JADX INFO: renamed from: l.c */
/* JADX INFO: loaded from: classes.dex */
public final class C7953c implements Closeable, Flushable {

    /* JADX INFO: renamed from: A2 */
    private int f50549A2;

    /* JADX INFO: renamed from: u2 */
    final InterfaceC7969f f50550u2;

    /* JADX INFO: renamed from: v2 */
    final C7967d f50551v2;

    /* JADX INFO: renamed from: w2 */
    int f50552w2;

    /* JADX INFO: renamed from: x2 */
    int f50553x2;

    /* JADX INFO: renamed from: y2 */
    private int f50554y2;

    /* JADX INFO: renamed from: z2 */
    private int f50555z2;

    /* JADX INFO: renamed from: l.c$a */
    /* JADX INFO: loaded from: classes2.dex */
    class a implements InterfaceC7969f {
        a() {
        }

        @Override // p580l.p581f0.p582e.InterfaceC7969f
        /* JADX INFO: renamed from: a */
        public void mo43518a() {
            C7953c.this.m43515i();
        }

        @Override // p580l.p581f0.p582e.InterfaceC7969f
        /* JADX INFO: renamed from: b */
        public void mo43519b(C7966c c7966c) {
            C7953c.this.m43516j(c7966c);
        }

        @Override // p580l.p581f0.p582e.InterfaceC7969f
        /* JADX INFO: renamed from: c */
        public void mo43520c(C8034z c8034z) {
            C7953c.this.m43514h(c8034z);
        }

        @Override // p580l.p581f0.p582e.InterfaceC7969f
        /* JADX INFO: renamed from: d */
        public InterfaceC7965b mo43521d(C7952b0 c7952b0) {
            return C7953c.this.m43513f(c7952b0);
        }

        @Override // p580l.p581f0.p582e.InterfaceC7969f
        /* JADX INFO: renamed from: e */
        public C7952b0 mo43522e(C8034z c8034z) {
            return C7953c.this.m43512d(c8034z);
        }

        @Override // p580l.p581f0.p582e.InterfaceC7969f
        /* JADX INFO: renamed from: f */
        public void mo43523f(C7952b0 c7952b0, C7952b0 c7952b1) {
            C7953c.this.m43517k(c7952b0, c7952b1);
        }
    }

    /* JADX INFO: renamed from: l.c$b */
    /* JADX INFO: loaded from: classes2.dex */
    private final class b implements InterfaceC7965b {

        /* JADX INFO: renamed from: a */
        private final C7967d.c f50557a;

        /* JADX INFO: renamed from: b */
        private InterfaceC8052r f50558b;

        /* JADX INFO: renamed from: c */
        private InterfaceC8052r f50559c;

        /* JADX INFO: renamed from: d */
        boolean f50560d;

        /* JADX INFO: renamed from: l.c$b$a */
        class a extends AbstractC8041g {

            /* JADX INFO: renamed from: v2 */
            final /* synthetic */ C7953c f50562v2;

            /* JADX INFO: renamed from: w2 */
            final /* synthetic */ C7967d.c f50563w2;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            a(InterfaceC8052r interfaceC8052r, C7953c c7953c, C7967d.c cVar) {
                super(interfaceC8052r);
                this.f50562v2 = c7953c;
                this.f50563w2 = cVar;
            }

            @Override // p590m.AbstractC8041g, p590m.InterfaceC8052r, java.io.Closeable, java.lang.AutoCloseable
            public void close() {
                synchronized (C7953c.this) {
                    b bVar = b.this;
                    if (bVar.f50560d) {
                        return;
                    }
                    bVar.f50560d = true;
                    C7953c.this.f50552w2++;
                    super.close();
                    this.f50563w2.m43643b();
                }
            }
        }

        b(C7967d.c cVar) {
            this.f50557a = cVar;
            InterfaceC8052r interfaceC8052rM43645d = cVar.m43645d(1);
            this.f50558b = interfaceC8052rM43645d;
            this.f50559c = new a(interfaceC8052rM43645d, C7953c.this, cVar);
        }

        @Override // p580l.p581f0.p582e.InterfaceC7965b
        /* JADX INFO: renamed from: a */
        public void mo43524a() {
            synchronized (C7953c.this) {
                if (this.f50560d) {
                    return;
                }
                this.f50560d = true;
                C7953c.this.f50553x2++;
                C7962c.m43582d(this.f50558b);
                try {
                    this.f50557a.m43642a();
                } catch (IOException unused) {
                }
            }
        }

        @Override // p580l.p581f0.p582e.InterfaceC7965b
        /* JADX INFO: renamed from: b */
        public InterfaceC8052r mo43525b() {
            return this.f50559c;
        }
    }

    /* JADX INFO: renamed from: l.c$c */
    private static class c extends AbstractC7954c0 {

        /* JADX INFO: renamed from: u2 */
        final C7967d.e f50565u2;

        /* JADX INFO: renamed from: v2 */
        private final InterfaceC8039e f50566v2;

        /* JADX INFO: renamed from: w2 */
        @Nullable
        private final String f50567w2;

        /* JADX INFO: renamed from: x2 */
        @Nullable
        private final String f50568x2;

        /* JADX INFO: renamed from: l.c$c$a */
        /* JADX INFO: loaded from: classes2.dex */
        class a extends AbstractC8042h {

            /* JADX INFO: renamed from: v2 */
            final /* synthetic */ C7967d.e f50569v2;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            a(InterfaceC8053s interfaceC8053s, C7967d.e eVar) {
                super(interfaceC8053s);
                this.f50569v2 = eVar;
            }

            @Override // p590m.AbstractC8042h, p590m.InterfaceC8053s, java.io.Closeable, java.lang.AutoCloseable
            public void close() {
                this.f50569v2.close();
                super.close();
            }
        }

        c(C7967d.e eVar, String str, String str2) {
            this.f50565u2 = eVar;
            this.f50567w2 = str;
            this.f50568x2 = str2;
            this.f50566v2 = C8046l.m44313d(new a(eVar.m43651d(1), eVar));
        }

        @Override // p580l.AbstractC7954c0
        /* JADX INFO: renamed from: c */
        public long mo43526c() {
            try {
                String str = this.f50568x2;
                if (str != null) {
                    return Long.parseLong(str);
                }
                return -1L;
            } catch (NumberFormatException unused) {
                return -1L;
            }
        }

        @Override // p580l.AbstractC7954c0
        /* JADX INFO: renamed from: f */
        public InterfaceC8039e mo43527f() {
            return this.f50566v2;
        }
    }

    /* JADX INFO: renamed from: l.c$d */
    private static final class d {

        /* JADX INFO: renamed from: a */
        private static final String f50571a = C8009f.m43969i().m43971j() + "-Sent-Millis";

        /* JADX INFO: renamed from: b */
        private static final String f50572b = C8009f.m43969i().m43971j() + "-Received-Millis";

        /* JADX INFO: renamed from: c */
        private final String f50573c;

        /* JADX INFO: renamed from: d */
        private final C8026r f50574d;

        /* JADX INFO: renamed from: e */
        private final String f50575e;

        /* JADX INFO: renamed from: f */
        private final EnumC8032x f50576f;

        /* JADX INFO: renamed from: g */
        private final int f50577g;

        /* JADX INFO: renamed from: h */
        private final String f50578h;

        /* JADX INFO: renamed from: i */
        private final C8026r f50579i;

        /* JADX INFO: renamed from: j */
        @Nullable
        private final C8025q f50580j;

        /* JADX INFO: renamed from: k */
        private final long f50581k;

        /* JADX INFO: renamed from: l */
        private final long f50582l;

        d(C7952b0 c7952b0) {
            this.f50573c = c7952b0.m43491u().m44191i().toString();
            this.f50574d = C7981e.m43731n(c7952b0);
            this.f50575e = c7952b0.m43491u().m44189g();
            this.f50576f = c7952b0.m43489s();
            this.f50577g = c7952b0.m43479f();
            this.f50578h = c7952b0.m43485l();
            this.f50579i = c7952b0.m43483j();
            this.f50580j = c7952b0.m43480g();
            this.f50581k = c7952b0.m43492v();
            this.f50582l = c7952b0.m43490t();
        }

        d(InterfaceC8053s interfaceC8053s) {
            try {
                InterfaceC8039e interfaceC8039eM44313d = C8046l.m44313d(interfaceC8053s);
                this.f50573c = interfaceC8039eM44313d.mo44242ea();
                this.f50575e = interfaceC8039eM44313d.mo44242ea();
                C8026r.a aVar = new C8026r.a();
                int iM43511g = C7953c.m43511g(interfaceC8039eM44313d);
                for (int i2 = 0; i2 < iM43511g; i2++) {
                    aVar.m44072b(interfaceC8039eM44313d.mo44242ea());
                }
                this.f50574d = aVar.m44074d();
                C7987k c7987kM43760a = C7987k.m43760a(interfaceC8039eM44313d.mo44242ea());
                this.f50576f = c7987kM43760a.f50777a;
                this.f50577g = c7987kM43760a.f50778b;
                this.f50578h = c7987kM43760a.f50779c;
                C8026r.a aVar2 = new C8026r.a();
                int iM43511g2 = C7953c.m43511g(interfaceC8039eM44313d);
                for (int i3 = 0; i3 < iM43511g2; i3++) {
                    aVar2.m44072b(interfaceC8039eM44313d.mo44242ea());
                }
                String str = f50571a;
                String strM44075f = aVar2.m44075f(str);
                String str2 = f50572b;
                String strM44075f2 = aVar2.m44075f(str2);
                aVar2.m44076g(str);
                aVar2.m44076g(str2);
                this.f50581k = strM44075f != null ? Long.parseLong(strM44075f) : 0L;
                this.f50582l = strM44075f2 != null ? Long.parseLong(strM44075f2) : 0L;
                this.f50579i = aVar2.m44074d();
                if (m43528a()) {
                    String strMo44242ea = interfaceC8039eM44313d.mo44242ea();
                    if (strMo44242ea.length() > 0) {
                        throw new IOException("expected \"\" but was \"" + strMo44242ea + "\"");
                    }
                    this.f50580j = C8025q.m44057c(!interfaceC8039eM44313d.mo44237a4() ? EnumC7958e0.m43559c(interfaceC8039eM44313d.mo44242ea()) : EnumC7958e0.SSL_3_0, C8016h.m43988a(interfaceC8039eM44313d.mo44242ea()), m43529c(interfaceC8039eM44313d), m43529c(interfaceC8039eM44313d));
                } else {
                    this.f50580j = null;
                }
                interfaceC8053s.close();
            } catch (Throwable th) {
                interfaceC8053s.close();
                throw th;
            }
        }

        /* JADX INFO: renamed from: a */
        private boolean m43528a() {
            return this.f50573c.startsWith("https://");
        }

        /* JADX INFO: renamed from: c */
        private List<Certificate> m43529c(InterfaceC8039e interfaceC8039e) throws IOException {
            int iM43511g = C7953c.m43511g(interfaceC8039e);
            if (iM43511g == -1) {
                return Collections.emptyList();
            }
            try {
                CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
                ArrayList arrayList = new ArrayList(iM43511g);
                for (int i2 = 0; i2 < iM43511g; i2++) {
                    String strMo44242ea = interfaceC8039e.mo44242ea();
                    C8037c c8037c = new C8037c();
                    c8037c.mo44253ob(C8040f.m44274l(strMo44242ea));
                    arrayList.add(certificateFactory.generateCertificate(c8037c.mo44263se()));
                }
                return arrayList;
            } catch (CertificateException e2) {
                throw new IOException(e2.getMessage());
            }
        }

        /* JADX INFO: renamed from: e */
        private void m43530e(InterfaceC8038d interfaceC8038d, List<Certificate> list) throws IOException {
            try {
                interfaceC8038d.mo44232Rd(list.size()).mo44241e4(10);
                int size = list.size();
                for (int i2 = 0; i2 < size; i2++) {
                    interfaceC8038d.mo44234T6(C8040f.m44272Y(list.get(i2).getEncoded()).mo44287c()).mo44241e4(10);
                }
            } catch (CertificateEncodingException e2) {
                throw new IOException(e2.getMessage());
            }
        }

        /* JADX INFO: renamed from: b */
        public boolean m43531b(C8034z c8034z, C7952b0 c7952b0) {
            return this.f50573c.equals(c8034z.m44191i().toString()) && this.f50575e.equals(c8034z.m44189g()) && C7981e.m43732o(c7952b0, this.f50574d, c8034z);
        }

        /* JADX INFO: renamed from: d */
        public C7952b0 m43532d(C7967d.e eVar) {
            String strM44064a = this.f50579i.m44064a("Content-Type");
            String strM44064a2 = this.f50579i.m44064a("Content-Length");
            return new C7952b0.a().m43507o(new C8034z.a().m44199h(this.f50573c).m44196e(this.f50575e, null).m44195d(this.f50574d).m44192a()).m43505m(this.f50576f).m43499g(this.f50577g).m43502j(this.f50578h).m43501i(this.f50579i).m43496b(new c(eVar, strM44064a, strM44064a2)).m43500h(this.f50580j).m43508p(this.f50581k).m43506n(this.f50582l).m43497c();
        }

        /* JADX INFO: renamed from: f */
        public void m43533f(C7967d.c cVar) throws IOException {
            InterfaceC8038d interfaceC8038dM44312c = C8046l.m44312c(cVar.m43645d(0));
            interfaceC8038dM44312c.mo44234T6(this.f50573c).mo44241e4(10);
            interfaceC8038dM44312c.mo44234T6(this.f50575e).mo44241e4(10);
            interfaceC8038dM44312c.mo44232Rd(this.f50574d.m44067f()).mo44241e4(10);
            int iM44067f = this.f50574d.m44067f();
            for (int i2 = 0; i2 < iM44067f; i2++) {
                interfaceC8038dM44312c.mo44234T6(this.f50574d.m44065c(i2)).mo44234T6(": ").mo44234T6(this.f50574d.m44068g(i2)).mo44241e4(10);
            }
            interfaceC8038dM44312c.mo44234T6(new C7987k(this.f50576f, this.f50577g, this.f50578h).toString()).mo44241e4(10);
            interfaceC8038dM44312c.mo44232Rd(this.f50579i.m44067f() + 2).mo44241e4(10);
            int iM44067f2 = this.f50579i.m44067f();
            for (int i3 = 0; i3 < iM44067f2; i3++) {
                interfaceC8038dM44312c.mo44234T6(this.f50579i.m44065c(i3)).mo44234T6(": ").mo44234T6(this.f50579i.m44068g(i3)).mo44241e4(10);
            }
            interfaceC8038dM44312c.mo44234T6(f50571a).mo44234T6(": ").mo44232Rd(this.f50581k).mo44241e4(10);
            interfaceC8038dM44312c.mo44234T6(f50572b).mo44234T6(": ").mo44232Rd(this.f50582l).mo44241e4(10);
            if (m43528a()) {
                interfaceC8038dM44312c.mo44241e4(10);
                interfaceC8038dM44312c.mo44234T6(this.f50580j.m44058a().m43991c()).mo44241e4(10);
                m43530e(interfaceC8038dM44312c, this.f50580j.m44060e());
                m43530e(interfaceC8038dM44312c, this.f50580j.m44059d());
                interfaceC8038dM44312c.mo44234T6(this.f50580j.m44061f().m43561i()).mo44241e4(10);
            }
            interfaceC8038dM44312c.close();
        }
    }

    public C7953c(File file, long j2) {
        this(file, j2, InterfaceC8003a.f50983a);
    }

    C7953c(File file, long j2, InterfaceC8003a interfaceC8003a) {
        this.f50550u2 = new a();
        this.f50551v2 = C7967d.m43623e(interfaceC8003a, file, 201105, 2, j2);
    }

    /* JADX INFO: renamed from: c */
    private void m43509c(@Nullable C7967d.c cVar) {
        if (cVar != null) {
            try {
                cVar.m43642a();
            } catch (IOException unused) {
            }
        }
    }

    /* JADX INFO: renamed from: e */
    public static String m43510e(C8027s c8027s) {
        return C8040f.m44278r(c8027s.toString()).mo44285Q().mo44282E();
    }

    /* JADX INFO: renamed from: g */
    static int m43511g(InterfaceC8039e interfaceC8039e) throws IOException {
        try {
            long jMo44266u5 = interfaceC8039e.mo44266u5();
            String strMo44242ea = interfaceC8039e.mo44242ea();
            if (jMo44266u5 >= 0 && jMo44266u5 <= 2147483647L && strMo44242ea.isEmpty()) {
                return (int) jMo44266u5;
            }
            throw new IOException("expected an int but was \"" + jMo44266u5 + strMo44242ea + "\"");
        } catch (NumberFormatException e2) {
            throw new IOException(e2.getMessage());
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        this.f50551v2.close();
    }

    @Nullable
    /* JADX INFO: renamed from: d */
    C7952b0 m43512d(C8034z c8034z) {
        try {
            C7967d.e eVarM43633i = this.f50551v2.m43633i(m43510e(c8034z.m44191i()));
            if (eVarM43633i == null) {
                return null;
            }
            try {
                d dVar = new d(eVarM43633i.m43651d(0));
                C7952b0 c7952b0M43532d = dVar.m43532d(eVarM43633i);
                if (dVar.m43531b(c8034z, c7952b0M43532d)) {
                    return c7952b0M43532d;
                }
                C7962c.m43582d(c7952b0M43532d.m43476c());
                return null;
            } catch (IOException unused) {
                C7962c.m43582d(eVarM43633i);
                return null;
            }
        } catch (IOException unused2) {
        }
    }

    @Nullable
    /* JADX INFO: renamed from: f */
    InterfaceC7965b m43513f(C7952b0 c7952b0) {
        C7967d.c cVarM43631g;
        String strM44189g = c7952b0.m43491u().m44189g();
        if (C7982f.m43733a(c7952b0.m43491u().m44189g())) {
            try {
                m43514h(c7952b0.m43491u());
            } catch (IOException unused) {
            }
            return null;
        }
        if (!strM44189g.equals("GET") || C7981e.m43722e(c7952b0)) {
            return null;
        }
        d dVar = new d(c7952b0);
        try {
            cVarM43631g = this.f50551v2.m43631g(m43510e(c7952b0.m43491u().m44191i()));
            if (cVarM43631g == null) {
                return null;
            }
            try {
                dVar.m43533f(cVarM43631g);
                return new b(cVarM43631g);
            } catch (IOException unused2) {
                m43509c(cVarM43631g);
                return null;
            }
        } catch (IOException unused3) {
            cVarM43631g = null;
        }
    }

    @Override // java.io.Flushable
    public void flush() {
        this.f50551v2.flush();
    }

    /* JADX INFO: renamed from: h */
    void m43514h(C8034z c8034z) {
        this.f50551v2.m43638u(m43510e(c8034z.m44191i()));
    }

    /* JADX INFO: renamed from: i */
    synchronized void m43515i() {
        this.f50555z2++;
    }

    /* JADX INFO: renamed from: j */
    synchronized void m43516j(C7966c c7966c) {
        this.f50549A2++;
        if (c7966c.f50647a != null) {
            this.f50554y2++;
        } else if (c7966c.f50648b != null) {
            this.f50555z2++;
        }
    }

    /* JADX INFO: renamed from: k */
    void m43517k(C7952b0 c7952b0, C7952b0 c7952b1) {
        C7967d.c cVarM43650c;
        d dVar = new d(c7952b1);
        try {
            cVarM43650c = ((c) c7952b0.m43476c()).f50565u2.m43650c();
            if (cVarM43650c != null) {
                try {
                    dVar.m43533f(cVarM43650c);
                    cVarM43650c.m43643b();
                } catch (IOException unused) {
                    m43509c(cVarM43650c);
                }
            }
        } catch (IOException unused2) {
            cVarM43650c = null;
        }
    }
}
