package p580l;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import p356f.p372c.p375g.p381e.p421f.C7021b;

/* JADX INFO: renamed from: l.h */
/* JADX INFO: loaded from: classes2.dex */
public final class C8016h {

    /* JADX INFO: renamed from: A */
    public static final C8016h f51023A;

    /* JADX INFO: renamed from: A0 */
    public static final C8016h f51024A0;

    /* JADX INFO: renamed from: B */
    public static final C8016h f51025B;

    /* JADX INFO: renamed from: B0 */
    public static final C8016h f51026B0;

    /* JADX INFO: renamed from: C */
    public static final C8016h f51027C;

    /* JADX INFO: renamed from: C0 */
    public static final C8016h f51028C0;

    /* JADX INFO: renamed from: D */
    public static final C8016h f51029D;

    /* JADX INFO: renamed from: D0 */
    public static final C8016h f51030D0;

    /* JADX INFO: renamed from: E */
    public static final C8016h f51031E;

    /* JADX INFO: renamed from: E0 */
    public static final C8016h f51032E0;

    /* JADX INFO: renamed from: F */
    public static final C8016h f51033F;

    /* JADX INFO: renamed from: F0 */
    public static final C8016h f51034F0;

    /* JADX INFO: renamed from: G */
    public static final C8016h f51035G;

    /* JADX INFO: renamed from: G0 */
    public static final C8016h f51036G0;

    /* JADX INFO: renamed from: H */
    public static final C8016h f51037H;

    /* JADX INFO: renamed from: H0 */
    public static final C8016h f51038H0;

    /* JADX INFO: renamed from: I */
    public static final C8016h f51039I;

    /* JADX INFO: renamed from: I0 */
    public static final C8016h f51040I0;

    /* JADX INFO: renamed from: J */
    public static final C8016h f51041J;

    /* JADX INFO: renamed from: J0 */
    public static final C8016h f51042J0;

    /* JADX INFO: renamed from: K */
    public static final C8016h f51043K;

    /* JADX INFO: renamed from: K0 */
    public static final C8016h f51044K0;

    /* JADX INFO: renamed from: L */
    public static final C8016h f51045L;

    /* JADX INFO: renamed from: L0 */
    public static final C8016h f51046L0;

    /* JADX INFO: renamed from: M */
    public static final C8016h f51047M;

    /* JADX INFO: renamed from: M0 */
    public static final C8016h f51048M0;

    /* JADX INFO: renamed from: N */
    public static final C8016h f51049N;

    /* JADX INFO: renamed from: N0 */
    public static final C8016h f51050N0;

    /* JADX INFO: renamed from: O */
    public static final C8016h f51051O;

    /* JADX INFO: renamed from: O0 */
    public static final C8016h f51052O0;

    /* JADX INFO: renamed from: P */
    public static final C8016h f51053P;

    /* JADX INFO: renamed from: P0 */
    public static final C8016h f51054P0;

    /* JADX INFO: renamed from: Q */
    public static final C8016h f51055Q;

    /* JADX INFO: renamed from: Q0 */
    public static final C8016h f51056Q0;

    /* JADX INFO: renamed from: R */
    public static final C8016h f51057R;

    /* JADX INFO: renamed from: R0 */
    public static final C8016h f51058R0;

    /* JADX INFO: renamed from: S */
    public static final C8016h f51059S;

    /* JADX INFO: renamed from: S0 */
    public static final C8016h f51060S0;

    /* JADX INFO: renamed from: T */
    public static final C8016h f51061T;

    /* JADX INFO: renamed from: T0 */
    public static final C8016h f51062T0;

    /* JADX INFO: renamed from: U */
    public static final C8016h f51063U;

    /* JADX INFO: renamed from: U0 */
    public static final C8016h f51064U0;

    /* JADX INFO: renamed from: V */
    public static final C8016h f51065V;

    /* JADX INFO: renamed from: V0 */
    public static final C8016h f51066V0;

    /* JADX INFO: renamed from: W */
    public static final C8016h f51067W;

    /* JADX INFO: renamed from: W0 */
    public static final C8016h f51068W0;

    /* JADX INFO: renamed from: X */
    public static final C8016h f51069X;

    /* JADX INFO: renamed from: X0 */
    public static final C8016h f51070X0;

    /* JADX INFO: renamed from: Y */
    public static final C8016h f51071Y;

    /* JADX INFO: renamed from: Y0 */
    public static final C8016h f51072Y0;

    /* JADX INFO: renamed from: Z */
    public static final C8016h f51073Z;

    /* JADX INFO: renamed from: Z0 */
    public static final C8016h f51074Z0;

    /* JADX INFO: renamed from: a */
    static final Comparator<String> f51075a;

    /* JADX INFO: renamed from: a0 */
    public static final C8016h f51076a0;

    /* JADX INFO: renamed from: a1 */
    public static final C8016h f51077a1;

    /* JADX INFO: renamed from: b */
    private static final Map<String, C8016h> f51078b;

    /* JADX INFO: renamed from: b0 */
    public static final C8016h f51079b0;

    /* JADX INFO: renamed from: b1 */
    public static final C8016h f51080b1;

    /* JADX INFO: renamed from: c */
    public static final C8016h f51081c;

    /* JADX INFO: renamed from: c0 */
    public static final C8016h f51082c0;

    /* JADX INFO: renamed from: c1 */
    public static final C8016h f51083c1;

    /* JADX INFO: renamed from: d */
    public static final C8016h f51084d;

    /* JADX INFO: renamed from: d0 */
    public static final C8016h f51085d0;

    /* JADX INFO: renamed from: d1 */
    public static final C8016h f51086d1;

    /* JADX INFO: renamed from: e */
    public static final C8016h f51087e;

    /* JADX INFO: renamed from: e0 */
    public static final C8016h f51088e0;

    /* JADX INFO: renamed from: e1 */
    public static final C8016h f51089e1;

    /* JADX INFO: renamed from: f */
    public static final C8016h f51090f;

    /* JADX INFO: renamed from: f0 */
    public static final C8016h f51091f0;

    /* JADX INFO: renamed from: f1 */
    public static final C8016h f51092f1;

    /* JADX INFO: renamed from: g */
    public static final C8016h f51093g;

    /* JADX INFO: renamed from: g0 */
    public static final C8016h f51094g0;

    /* JADX INFO: renamed from: g1 */
    public static final C8016h f51095g1;

    /* JADX INFO: renamed from: h */
    public static final C8016h f51096h;

    /* JADX INFO: renamed from: h0 */
    public static final C8016h f51097h0;

    /* JADX INFO: renamed from: h1 */
    public static final C8016h f51098h1;

    /* JADX INFO: renamed from: i */
    public static final C8016h f51099i;

    /* JADX INFO: renamed from: i0 */
    public static final C8016h f51100i0;

    /* JADX INFO: renamed from: i1 */
    public static final C8016h f51101i1;

    /* JADX INFO: renamed from: j */
    public static final C8016h f51102j;

    /* JADX INFO: renamed from: j0 */
    public static final C8016h f51103j0;

    /* JADX INFO: renamed from: j1 */
    public static final C8016h f51104j1;

    /* JADX INFO: renamed from: k */
    public static final C8016h f51105k;

    /* JADX INFO: renamed from: k0 */
    public static final C8016h f51106k0;

    /* JADX INFO: renamed from: l */
    public static final C8016h f51107l;

    /* JADX INFO: renamed from: l0 */
    public static final C8016h f51108l0;

    /* JADX INFO: renamed from: m */
    public static final C8016h f51109m;

    /* JADX INFO: renamed from: m0 */
    public static final C8016h f51110m0;

    /* JADX INFO: renamed from: n */
    public static final C8016h f51111n;

    /* JADX INFO: renamed from: n0 */
    public static final C8016h f51112n0;

    /* JADX INFO: renamed from: o */
    public static final C8016h f51113o;

    /* JADX INFO: renamed from: o0 */
    public static final C8016h f51114o0;

    /* JADX INFO: renamed from: p */
    public static final C8016h f51115p;

    /* JADX INFO: renamed from: p0 */
    public static final C8016h f51116p0;

    /* JADX INFO: renamed from: q */
    public static final C8016h f51117q;

    /* JADX INFO: renamed from: q0 */
    public static final C8016h f51118q0;

    /* JADX INFO: renamed from: r */
    public static final C8016h f51119r;

    /* JADX INFO: renamed from: r0 */
    public static final C8016h f51120r0;

    /* JADX INFO: renamed from: s */
    public static final C8016h f51121s;

    /* JADX INFO: renamed from: s0 */
    public static final C8016h f51122s0;

    /* JADX INFO: renamed from: t */
    public static final C8016h f51123t;

    /* JADX INFO: renamed from: t0 */
    public static final C8016h f51124t0;

    /* JADX INFO: renamed from: u */
    public static final C8016h f51125u;

    /* JADX INFO: renamed from: u0 */
    public static final C8016h f51126u0;

    /* JADX INFO: renamed from: v */
    public static final C8016h f51127v;

    /* JADX INFO: renamed from: v0 */
    public static final C8016h f51128v0;

    /* JADX INFO: renamed from: w */
    public static final C8016h f51129w;

    /* JADX INFO: renamed from: w0 */
    public static final C8016h f51130w0;

    /* JADX INFO: renamed from: x */
    public static final C8016h f51131x;

    /* JADX INFO: renamed from: x0 */
    public static final C8016h f51132x0;

    /* JADX INFO: renamed from: y */
    public static final C8016h f51133y;

    /* JADX INFO: renamed from: y0 */
    public static final C8016h f51134y0;

    /* JADX INFO: renamed from: z */
    public static final C8016h f51135z;

    /* JADX INFO: renamed from: z0 */
    public static final C8016h f51136z0;

    /* JADX INFO: renamed from: k1 */
    final String f51137k1;

    /* JADX INFO: renamed from: l.h$a */
    final class a implements Comparator<String> {
        a() {
        }

        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(String str, String str2) {
            int iMin = Math.min(str.length(), str2.length());
            for (int i2 = 4; i2 < iMin; i2++) {
                char cCharAt = str.charAt(i2);
                char cCharAt2 = str2.charAt(i2);
                if (cCharAt != cCharAt2) {
                    return cCharAt < cCharAt2 ? -1 : 1;
                }
            }
            int length = str.length();
            int length2 = str2.length();
            if (length != length2) {
                return length < length2 ? -1 : 1;
            }
            return 0;
        }
    }

    static {
        a aVar = new a();
        f51075a = aVar;
        f51078b = new TreeMap(aVar);
        f51081c = m43990d("SSL_RSA_WITH_NULL_MD5", 1);
        f51084d = m43990d("SSL_RSA_WITH_NULL_SHA", 2);
        f51087e = m43990d("SSL_RSA_EXPORT_WITH_RC4_40_MD5", 3);
        f51090f = m43990d("SSL_RSA_WITH_RC4_128_MD5", 4);
        f51093g = m43990d("SSL_RSA_WITH_RC4_128_SHA", 5);
        f51096h = m43990d("SSL_RSA_EXPORT_WITH_DES40_CBC_SHA", 8);
        f51099i = m43990d("SSL_RSA_WITH_DES_CBC_SHA", 9);
        f51102j = m43990d("SSL_RSA_WITH_3DES_EDE_CBC_SHA", 10);
        f51105k = m43990d("SSL_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA", 17);
        f51107l = m43990d("SSL_DHE_DSS_WITH_DES_CBC_SHA", 18);
        f51109m = m43990d("SSL_DHE_DSS_WITH_3DES_EDE_CBC_SHA", 19);
        f51111n = m43990d("SSL_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA", 20);
        f51113o = m43990d("SSL_DHE_RSA_WITH_DES_CBC_SHA", 21);
        f51115p = m43990d("SSL_DHE_RSA_WITH_3DES_EDE_CBC_SHA", 22);
        f51117q = m43990d("SSL_DH_anon_EXPORT_WITH_RC4_40_MD5", 23);
        f51119r = m43990d("SSL_DH_anon_WITH_RC4_128_MD5", 24);
        f51121s = m43990d("SSL_DH_anon_EXPORT_WITH_DES40_CBC_SHA", 25);
        f51123t = m43990d("SSL_DH_anon_WITH_DES_CBC_SHA", 26);
        f51125u = m43990d("SSL_DH_anon_WITH_3DES_EDE_CBC_SHA", 27);
        f51127v = m43990d("TLS_KRB5_WITH_DES_CBC_SHA", 30);
        f51129w = m43990d("TLS_KRB5_WITH_3DES_EDE_CBC_SHA", 31);
        f51131x = m43990d("TLS_KRB5_WITH_RC4_128_SHA", 32);
        f51133y = m43990d("TLS_KRB5_WITH_DES_CBC_MD5", 34);
        f51135z = m43990d("TLS_KRB5_WITH_3DES_EDE_CBC_MD5", 35);
        f51023A = m43990d("TLS_KRB5_WITH_RC4_128_MD5", 36);
        f51025B = m43990d("TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA", 38);
        f51027C = m43990d("TLS_KRB5_EXPORT_WITH_RC4_40_SHA", 40);
        f51029D = m43990d("TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5", 41);
        f51031E = m43990d("TLS_KRB5_EXPORT_WITH_RC4_40_MD5", 43);
        f51033F = m43990d("TLS_RSA_WITH_AES_128_CBC_SHA", 47);
        f51035G = m43990d("TLS_DHE_DSS_WITH_AES_128_CBC_SHA", 50);
        f51037H = m43990d("TLS_DHE_RSA_WITH_AES_128_CBC_SHA", 51);
        f51039I = m43990d("TLS_DH_anon_WITH_AES_128_CBC_SHA", 52);
        f51041J = m43990d("TLS_RSA_WITH_AES_256_CBC_SHA", 53);
        f51043K = m43990d("TLS_DHE_DSS_WITH_AES_256_CBC_SHA", 56);
        f51045L = m43990d("TLS_DHE_RSA_WITH_AES_256_CBC_SHA", 57);
        f51047M = m43990d("TLS_DH_anon_WITH_AES_256_CBC_SHA", 58);
        f51049N = m43990d("TLS_RSA_WITH_NULL_SHA256", 59);
        f51051O = m43990d("TLS_RSA_WITH_AES_128_CBC_SHA256", 60);
        f51053P = m43990d("TLS_RSA_WITH_AES_256_CBC_SHA256", 61);
        f51055Q = m43990d("TLS_DHE_DSS_WITH_AES_128_CBC_SHA256", 64);
        f51057R = m43990d("TLS_RSA_WITH_CAMELLIA_128_CBC_SHA", 65);
        f51059S = m43990d("TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA", 68);
        f51061T = m43990d("TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA", 69);
        f51063U = m43990d("TLS_DHE_RSA_WITH_AES_128_CBC_SHA256", 103);
        f51065V = m43990d("TLS_DHE_DSS_WITH_AES_256_CBC_SHA256", 106);
        f51067W = m43990d("TLS_DHE_RSA_WITH_AES_256_CBC_SHA256", 107);
        f51069X = m43990d("TLS_DH_anon_WITH_AES_128_CBC_SHA256", 108);
        f51071Y = m43990d("TLS_DH_anon_WITH_AES_256_CBC_SHA256", 109);
        f51073Z = m43990d("TLS_RSA_WITH_CAMELLIA_256_CBC_SHA", 132);
        f51076a0 = m43990d("TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA", 135);
        f51079b0 = m43990d("TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA", 136);
        f51082c0 = m43990d("TLS_PSK_WITH_RC4_128_SHA", 138);
        f51085d0 = m43990d("TLS_PSK_WITH_3DES_EDE_CBC_SHA", 139);
        f51088e0 = m43990d("TLS_PSK_WITH_AES_128_CBC_SHA", 140);
        f51091f0 = m43990d("TLS_PSK_WITH_AES_256_CBC_SHA", 141);
        f51094g0 = m43990d("TLS_RSA_WITH_SEED_CBC_SHA", 150);
        f51097h0 = m43990d("TLS_RSA_WITH_AES_128_GCM_SHA256", C7021b.f45417i);
        f51100i0 = m43990d("TLS_RSA_WITH_AES_256_GCM_SHA384", C7021b.f45416h);
        f51103j0 = m43990d("TLS_DHE_RSA_WITH_AES_128_GCM_SHA256", 158);
        f51106k0 = m43990d("TLS_DHE_RSA_WITH_AES_256_GCM_SHA384", 159);
        f51108l0 = m43990d("TLS_DHE_DSS_WITH_AES_128_GCM_SHA256", 162);
        f51110m0 = m43990d("TLS_DHE_DSS_WITH_AES_256_GCM_SHA384", 163);
        f51112n0 = m43990d("TLS_DH_anon_WITH_AES_128_GCM_SHA256", 166);
        f51114o0 = m43990d("TLS_DH_anon_WITH_AES_256_GCM_SHA384", 167);
        f51116p0 = m43990d("TLS_EMPTY_RENEGOTIATION_INFO_SCSV", 255);
        f51118q0 = m43990d("TLS_FALLBACK_SCSV", 22016);
        f51120r0 = m43990d("TLS_ECDH_ECDSA_WITH_NULL_SHA", 49153);
        f51122s0 = m43990d("TLS_ECDH_ECDSA_WITH_RC4_128_SHA", 49154);
        f51124t0 = m43990d("TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA", 49155);
        f51126u0 = m43990d("TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA", 49156);
        f51128v0 = m43990d("TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA", 49157);
        f51130w0 = m43990d("TLS_ECDHE_ECDSA_WITH_NULL_SHA", 49158);
        f51132x0 = m43990d("TLS_ECDHE_ECDSA_WITH_RC4_128_SHA", 49159);
        f51134y0 = m43990d("TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA", 49160);
        f51136z0 = m43990d("TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA", 49161);
        f51024A0 = m43990d("TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA", 49162);
        f51026B0 = m43990d("TLS_ECDH_RSA_WITH_NULL_SHA", 49163);
        f51028C0 = m43990d("TLS_ECDH_RSA_WITH_RC4_128_SHA", 49164);
        f51030D0 = m43990d("TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA", 49165);
        f51032E0 = m43990d("TLS_ECDH_RSA_WITH_AES_128_CBC_SHA", 49166);
        f51034F0 = m43990d("TLS_ECDH_RSA_WITH_AES_256_CBC_SHA", 49167);
        f51036G0 = m43990d("TLS_ECDHE_RSA_WITH_NULL_SHA", 49168);
        f51038H0 = m43990d("TLS_ECDHE_RSA_WITH_RC4_128_SHA", 49169);
        f51040I0 = m43990d("TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA", 49170);
        f51042J0 = m43990d("TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA", 49171);
        f51044K0 = m43990d("TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA", 49172);
        f51046L0 = m43990d("TLS_ECDH_anon_WITH_NULL_SHA", 49173);
        f51048M0 = m43990d("TLS_ECDH_anon_WITH_RC4_128_SHA", 49174);
        f51050N0 = m43990d("TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA", 49175);
        f51052O0 = m43990d("TLS_ECDH_anon_WITH_AES_128_CBC_SHA", 49176);
        f51054P0 = m43990d("TLS_ECDH_anon_WITH_AES_256_CBC_SHA", 49177);
        f51056Q0 = m43990d("TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256", 49187);
        f51058R0 = m43990d("TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384", 49188);
        f51060S0 = m43990d("TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256", 49189);
        f51062T0 = m43990d("TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384", 49190);
        f51064U0 = m43990d("TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256", 49191);
        f51066V0 = m43990d("TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384", 49192);
        f51068W0 = m43990d("TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256", 49193);
        f51070X0 = m43990d("TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384", 49194);
        f51072Y0 = m43990d("TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256", 49195);
        f51074Z0 = m43990d("TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384", 49196);
        f51077a1 = m43990d("TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256", 49197);
        f51080b1 = m43990d("TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384", 49198);
        f51083c1 = m43990d("TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256", 49199);
        f51086d1 = m43990d("TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384", 49200);
        f51089e1 = m43990d("TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256", 49201);
        f51092f1 = m43990d("TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384", 49202);
        f51095g1 = m43990d("TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA", 49205);
        f51098h1 = m43990d("TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA", 49206);
        f51101i1 = m43990d("TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256", 52392);
        f51104j1 = m43990d("TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256", 52393);
    }

    private C8016h(String str) {
        str.getClass();
        this.f51137k1 = str;
    }

    /* JADX INFO: renamed from: a */
    public static synchronized C8016h m43988a(String str) {
        C8016h c8016h;
        Map<String, C8016h> map = f51078b;
        c8016h = map.get(str);
        if (c8016h == null) {
            c8016h = new C8016h(str);
            map.put(str, c8016h);
        }
        return c8016h;
    }

    /* JADX INFO: renamed from: b */
    static List<C8016h> m43989b(String... strArr) {
        ArrayList arrayList = new ArrayList(strArr.length);
        for (String str : strArr) {
            arrayList.add(m43988a(str));
        }
        return Collections.unmodifiableList(arrayList);
    }

    /* JADX INFO: renamed from: d */
    private static C8016h m43990d(String str, int i2) {
        return m43988a(str);
    }

    /* JADX INFO: renamed from: c */
    public String m43991c() {
        return this.f51137k1;
    }

    public String toString() {
        return this.f51137k1;
    }
}
