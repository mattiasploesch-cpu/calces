package p580l;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.List;
import javax.annotation.Nullable;

/* JADX INFO: renamed from: l.p */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC8024p {

    /* JADX INFO: renamed from: a */
    public static final AbstractC8024p f51180a = new a();

    /* JADX INFO: renamed from: l.p$a */
    /* JADX INFO: loaded from: classes2.dex */
    final class a extends AbstractC8024p {
        a() {
        }
    }

    /* JADX INFO: renamed from: l.p$b */
    /* JADX INFO: loaded from: classes2.dex */
    final class b implements c {
        b() {
        }

        @Override // p580l.AbstractC8024p.c
        /* JADX INFO: renamed from: a */
        public AbstractC8024p mo44055a(InterfaceC7957e interfaceC7957e) {
            return AbstractC8024p.this;
        }
    }

    /* JADX INFO: renamed from: l.p$c */
    /* JADX INFO: loaded from: classes2.dex */
    public interface c {
        /* JADX INFO: renamed from: a */
        AbstractC8024p mo44055a(InterfaceC7957e interfaceC7957e);
    }

    /* JADX INFO: renamed from: k */
    static c m44034k(AbstractC8024p abstractC8024p) {
        return abstractC8024p.new b();
    }

    /* JADX INFO: renamed from: a */
    public void m44035a(InterfaceC7957e interfaceC7957e) {
    }

    /* JADX INFO: renamed from: b */
    public void m44036b(InterfaceC7957e interfaceC7957e, IOException iOException) {
    }

    /* JADX INFO: renamed from: c */
    public void m44037c(InterfaceC7957e interfaceC7957e) {
    }

    /* JADX INFO: renamed from: d */
    public void m44038d(InterfaceC7957e interfaceC7957e, InetSocketAddress inetSocketAddress, Proxy proxy, @Nullable EnumC8032x enumC8032x) {
    }

    /* JADX INFO: renamed from: e */
    public void m44039e(InterfaceC7957e interfaceC7957e, InetSocketAddress inetSocketAddress, Proxy proxy, @Nullable EnumC8032x enumC8032x, IOException iOException) {
    }

    /* JADX INFO: renamed from: f */
    public void m44040f(InterfaceC7957e interfaceC7957e, InetSocketAddress inetSocketAddress, Proxy proxy) {
    }

    /* JADX INFO: renamed from: g */
    public void m44041g(InterfaceC7957e interfaceC7957e, InterfaceC8017i interfaceC8017i) {
    }

    /* JADX INFO: renamed from: h */
    public void m44042h(InterfaceC7957e interfaceC7957e, InterfaceC8017i interfaceC8017i) {
    }

    /* JADX INFO: renamed from: i */
    public void m44043i(InterfaceC7957e interfaceC7957e, String str, List<InetAddress> list) {
    }

    /* JADX INFO: renamed from: j */
    public void m44044j(InterfaceC7957e interfaceC7957e, String str) {
    }

    /* JADX INFO: renamed from: l */
    public void m44045l(InterfaceC7957e interfaceC7957e, long j2) {
    }

    /* JADX INFO: renamed from: m */
    public void m44046m(InterfaceC7957e interfaceC7957e) {
    }

    /* JADX INFO: renamed from: n */
    public void m44047n(InterfaceC7957e interfaceC7957e, C8034z c8034z) {
    }

    /* JADX INFO: renamed from: o */
    public void m44048o(InterfaceC7957e interfaceC7957e) {
    }

    /* JADX INFO: renamed from: p */
    public void m44049p(InterfaceC7957e interfaceC7957e, long j2) {
    }

    /* JADX INFO: renamed from: q */
    public void m44050q(InterfaceC7957e interfaceC7957e) {
    }

    /* JADX INFO: renamed from: r */
    public void m44051r(InterfaceC7957e interfaceC7957e, C7952b0 c7952b0) {
    }

    /* JADX INFO: renamed from: s */
    public void m44052s(InterfaceC7957e interfaceC7957e) {
    }

    /* JADX INFO: renamed from: t */
    public void m44053t(InterfaceC7957e interfaceC7957e, @Nullable C8025q c8025q) {
    }

    /* JADX INFO: renamed from: u */
    public void m44054u(InterfaceC7957e interfaceC7957e) {
    }
}
