package p580l;

import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import javax.annotation.Nullable;
import javax.net.ssl.SSLPeerUnverifiedException;
import p580l.p581f0.C7962c;
import p580l.p581f0.p589l.AbstractC8012c;
import p590m.C8040f;

/* JADX INFO: renamed from: l.g */
/* JADX INFO: loaded from: classes.dex */
public final class C8015g {

    /* JADX INFO: renamed from: a */
    public static final C8015g f51015a = new a().m43986a();

    /* JADX INFO: renamed from: b */
    private final Set<b> f51016b;

    /* JADX INFO: renamed from: c */
    @Nullable
    private final AbstractC8012c f51017c;

    /* JADX INFO: renamed from: l.g$a */
    /* JADX INFO: loaded from: classes2.dex */
    public static final class a {

        /* JADX INFO: renamed from: a */
        private final List<b> f51018a = new ArrayList();

        /* JADX INFO: renamed from: a */
        public C8015g m43986a() {
            return new C8015g(new LinkedHashSet(this.f51018a), null);
        }
    }

    /* JADX INFO: renamed from: l.g$b */
    /* JADX INFO: loaded from: classes2.dex */
    static final class b {

        /* JADX INFO: renamed from: a */
        final String f51019a;

        /* JADX INFO: renamed from: b */
        final String f51020b;

        /* JADX INFO: renamed from: c */
        final String f51021c;

        /* JADX INFO: renamed from: d */
        final C8040f f51022d;

        /* JADX INFO: renamed from: a */
        boolean m43987a(String str) {
            if (!this.f51019a.startsWith("*.")) {
                return str.equals(this.f51020b);
            }
            int iIndexOf = str.indexOf(46);
            if ((str.length() - iIndexOf) - 1 == this.f51020b.length()) {
                String str2 = this.f51020b;
                if (str.regionMatches(false, iIndexOf + 1, str2, 0, str2.length())) {
                    return true;
                }
            }
            return false;
        }

        public boolean equals(Object obj) {
            if (obj instanceof b) {
                b bVar = (b) obj;
                if (this.f51019a.equals(bVar.f51019a) && this.f51021c.equals(bVar.f51021c) && this.f51022d.equals(bVar.f51022d)) {
                    return true;
                }
            }
            return false;
        }

        public int hashCode() {
            return ((((527 + this.f51019a.hashCode()) * 31) + this.f51021c.hashCode()) * 31) + this.f51022d.hashCode();
        }

        public String toString() {
            return this.f51021c + this.f51022d.mo44287c();
        }
    }

    C8015g(Set<b> set, @Nullable AbstractC8012c abstractC8012c) {
        this.f51016b = set;
        this.f51017c = abstractC8012c;
    }

    /* JADX INFO: renamed from: c */
    public static String m43980c(Certificate certificate) {
        if (!(certificate instanceof X509Certificate)) {
            throw new IllegalArgumentException("Certificate pinning requires X509 certificates");
        }
        return "sha256/" + m43982e((X509Certificate) certificate).mo44287c();
    }

    /* JADX INFO: renamed from: d */
    static C8040f m43981d(X509Certificate x509Certificate) {
        return C8040f.m44272Y(x509Certificate.getPublicKey().getEncoded()).mo44292m0();
    }

    /* JADX INFO: renamed from: e */
    static C8040f m43982e(X509Certificate x509Certificate) {
        return C8040f.m44272Y(x509Certificate.getPublicKey().getEncoded()).mo44293t0();
    }

    /* JADX INFO: renamed from: a */
    public void m43983a(String str, List<Certificate> list) {
        List<b> listM43984b = m43984b(str);
        if (listM43984b.isEmpty()) {
            return;
        }
        AbstractC8012c abstractC8012c = this.f51017c;
        if (abstractC8012c != null) {
            list = abstractC8012c.mo43948a(list, str);
        }
        int size = list.size();
        for (int i2 = 0; i2 < size; i2++) {
            X509Certificate x509Certificate = (X509Certificate) list.get(i2);
            int size2 = listM43984b.size();
            C8040f c8040fM43982e = null;
            C8040f c8040fM43981d = null;
            for (int i3 = 0; i3 < size2; i3++) {
                b bVar = listM43984b.get(i3);
                if (bVar.f51021c.equals("sha256/")) {
                    if (c8040fM43982e == null) {
                        c8040fM43982e = m43982e(x509Certificate);
                    }
                    if (bVar.f51022d.equals(c8040fM43982e)) {
                        return;
                    }
                } else {
                    if (!bVar.f51021c.equals("sha1/")) {
                        throw new AssertionError("unsupported hashAlgorithm: " + bVar.f51021c);
                    }
                    if (c8040fM43981d == null) {
                        c8040fM43981d = m43981d(x509Certificate);
                    }
                    if (bVar.f51022d.equals(c8040fM43981d)) {
                        return;
                    }
                }
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Certificate pinning failure!");
        sb.append("\n  Peer certificate chain:");
        int size3 = list.size();
        for (int i4 = 0; i4 < size3; i4++) {
            X509Certificate x509Certificate2 = (X509Certificate) list.get(i4);
            sb.append("\n    ");
            sb.append(m43980c(x509Certificate2));
            sb.append(": ");
            sb.append(x509Certificate2.getSubjectDN().getName());
        }
        sb.append("\n  Pinned certificates for ");
        sb.append(str);
        sb.append(":");
        int size4 = listM43984b.size();
        for (int i5 = 0; i5 < size4; i5++) {
            b bVar2 = listM43984b.get(i5);
            sb.append("\n    ");
            sb.append(bVar2);
        }
        throw new SSLPeerUnverifiedException(sb.toString());
    }

    /* JADX INFO: renamed from: b */
    List<b> m43984b(String str) {
        List<b> listEmptyList = Collections.emptyList();
        for (b bVar : this.f51016b) {
            if (bVar.m43987a(str)) {
                if (listEmptyList.isEmpty()) {
                    listEmptyList = new ArrayList<>();
                }
                listEmptyList.add(bVar);
            }
        }
        return listEmptyList;
    }

    public boolean equals(@Nullable Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof C8015g) {
            C8015g c8015g = (C8015g) obj;
            if (C7962c.m43592n(this.f51017c, c8015g.f51017c) && this.f51016b.equals(c8015g.f51016b)) {
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: renamed from: f */
    C8015g m43985f(@Nullable AbstractC8012c abstractC8012c) {
        return C7962c.m43592n(this.f51017c, abstractC8012c) ? this : new C8015g(this.f51016b, abstractC8012c);
    }

    public int hashCode() {
        AbstractC8012c abstractC8012c = this.f51017c;
        return ((abstractC8012c != null ? abstractC8012c.hashCode() : 0) * 31) + this.f51016b.hashCode();
    }
}
