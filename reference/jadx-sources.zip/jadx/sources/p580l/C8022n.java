package p580l;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;
import p580l.p581f0.C7962c;

/* JADX INFO: renamed from: l.n */
/* JADX INFO: loaded from: classes.dex */
public final class C8022n {

    /* JADX INFO: renamed from: c */
    @Nullable
    private Runnable f51174c;

    /* JADX INFO: renamed from: d */
    @Nullable
    private ExecutorService f51175d;

    /* JADX INFO: renamed from: a */
    private int f51172a = 64;

    /* JADX INFO: renamed from: b */
    private int f51173b = 5;

    /* JADX INFO: renamed from: e */
    private final Deque<C8033y.a> f51176e = new ArrayDeque();

    /* JADX INFO: renamed from: f */
    private final Deque<C8033y.a> f51177f = new ArrayDeque();

    /* JADX INFO: renamed from: g */
    private final Deque<C8033y> f51178g = new ArrayDeque();

    /* JADX INFO: renamed from: c */
    private <T> void m44025c(Deque<T> deque, T t, boolean z) {
        int iM44032g;
        Runnable runnable;
        synchronized (this) {
            if (!deque.remove(t)) {
                throw new AssertionError("Call wasn't in-flight!");
            }
            if (z) {
                m44026f();
            }
            iM44032g = m44032g();
            runnable = this.f51174c;
        }
        if (iM44032g != 0 || runnable == null) {
            return;
        }
        runnable.run();
    }

    /* JADX INFO: renamed from: f */
    private void m44026f() {
        if (this.f51177f.size() < this.f51172a && !this.f51176e.isEmpty()) {
            Iterator<C8033y.a> it = this.f51176e.iterator();
            while (it.hasNext()) {
                C8033y.a next = it.next();
                if (m44027h(next) < this.f51173b) {
                    it.remove();
                    this.f51177f.add(next);
                    m44029b().execute(next);
                }
                if (this.f51177f.size() >= this.f51172a) {
                    return;
                }
            }
        }
    }

    /* JADX INFO: renamed from: h */
    private int m44027h(C8033y.a aVar) {
        int i2 = 0;
        for (C8033y.a aVar2 : this.f51177f) {
            if (!aVar2.m44181l().f51303y2 && aVar2.m44182m().equals(aVar.m44182m())) {
                i2++;
            }
        }
        return i2;
    }

    /* JADX INFO: renamed from: a */
    synchronized void m44028a(C8033y c8033y) {
        this.f51178g.add(c8033y);
    }

    /* JADX INFO: renamed from: b */
    public synchronized ExecutorService m44029b() {
        if (this.f51175d == null) {
            this.f51175d = new ThreadPoolExecutor(0, Integer.MAX_VALUE, 60L, TimeUnit.SECONDS, new SynchronousQueue(), C7962c.m43576B("OkHttp Dispatcher", false));
        }
        return this.f51175d;
    }

    /* JADX INFO: renamed from: d */
    void m44030d(C8033y.a aVar) {
        m44025c(this.f51177f, aVar, true);
    }

    /* JADX INFO: renamed from: e */
    void m44031e(C8033y c8033y) {
        m44025c(this.f51178g, c8033y, false);
    }

    /* JADX INFO: renamed from: g */
    public synchronized int m44032g() {
        return this.f51177f.size() + this.f51178g.size();
    }
}
