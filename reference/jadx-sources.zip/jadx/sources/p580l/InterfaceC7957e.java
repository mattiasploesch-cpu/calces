package p580l;

/* JADX INFO: renamed from: l.e */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC7957e extends Cloneable {

    /* JADX INFO: renamed from: l.e$a */
    /* JADX INFO: loaded from: classes.dex */
    public interface a {
        /* JADX INFO: renamed from: a */
        InterfaceC7957e mo43558a(C8034z c8034z);
    }

    /* JADX INFO: renamed from: A0 */
    C7952b0 mo43557A0();
}
