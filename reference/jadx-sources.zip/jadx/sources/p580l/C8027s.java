package p580l;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import p580l.p581f0.C7962c;
import p590m.C8037c;

/* JADX INFO: renamed from: l.s */
/* JADX INFO: loaded from: classes.dex */
public final class C8027s {

    /* JADX INFO: renamed from: a */
    private static final char[] f51188a = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

    /* JADX INFO: renamed from: b */
    final String f51189b;

    /* JADX INFO: renamed from: c */
    private final String f51190c;

    /* JADX INFO: renamed from: d */
    private final String f51191d;

    /* JADX INFO: renamed from: e */
    final String f51192e;

    /* JADX INFO: renamed from: f */
    final int f51193f;

    /* JADX INFO: renamed from: g */
    private final List<String> f51194g;

    /* JADX INFO: renamed from: h */
    @Nullable
    private final List<String> f51195h;

    /* JADX INFO: renamed from: i */
    @Nullable
    private final String f51196i;

    /* JADX INFO: renamed from: j */
    private final String f51197j;

    /* JADX INFO: renamed from: l.s$a */
    public static final class a {

        /* JADX INFO: renamed from: a */
        @Nullable
        String f51198a;

        /* JADX INFO: renamed from: d */
        @Nullable
        String f51201d;

        /* JADX INFO: renamed from: f */
        final List<String> f51203f;

        /* JADX INFO: renamed from: g */
        @Nullable
        List<String> f51204g;

        /* JADX INFO: renamed from: h */
        @Nullable
        String f51205h;

        /* JADX INFO: renamed from: b */
        String f51199b = "";

        /* JADX INFO: renamed from: c */
        String f51200c = "";

        /* JADX INFO: renamed from: e */
        int f51202e = -1;

        /* JADX INFO: renamed from: l.s$a$a, reason: collision with other inner class name */
        /* JADX INFO: loaded from: classes2.dex */
        enum EnumC10188a {
            SUCCESS,
            MISSING_SCHEME,
            UNSUPPORTED_SCHEME,
            INVALID_PORT,
            INVALID_HOST
        }

        public a() {
            ArrayList arrayList = new ArrayList();
            this.f51203f = arrayList;
            arrayList.add("");
        }

        /* JADX INFO: renamed from: b */
        private static String m44108b(String str, int i2, int i3) {
            return C7962c.m43580b(C8027s.m44086s(str, i2, i3, false));
        }

        /* JADX INFO: renamed from: f */
        private boolean m44109f(String str) {
            return str.equals(".") || str.equalsIgnoreCase("%2e");
        }

        /* JADX INFO: renamed from: g */
        private boolean m44110g(String str) {
            return str.equals("..") || str.equalsIgnoreCase("%2e.") || str.equalsIgnoreCase(".%2e") || str.equalsIgnoreCase("%2e%2e");
        }

        /* JADX INFO: renamed from: i */
        private static int m44111i(String str, int i2, int i3) {
            try {
                int i4 = Integer.parseInt(C8027s.m44078a(str, i2, i3, "", false, false, false, true, null));
                if (i4 <= 0 || i4 > 65535) {
                    return -1;
                }
                return i4;
            } catch (NumberFormatException unused) {
            }
        }

        /* JADX INFO: renamed from: k */
        private void m44112k() {
            List<String> list = this.f51203f;
            if (!list.remove(list.size() - 1).isEmpty() || this.f51203f.isEmpty()) {
                this.f51203f.add("");
            } else {
                List<String> list2 = this.f51203f;
                list2.set(list2.size() - 1, "");
            }
        }

        /* JADX INFO: renamed from: m */
        private static int m44113m(String str, int i2, int i3) {
            while (i2 < i3) {
                char cCharAt = str.charAt(i2);
                if (cCharAt == ':') {
                    return i2;
                }
                if (cCharAt == '[') {
                    do {
                        i2++;
                        if (i2 >= i3) {
                            break;
                        }
                    } while (str.charAt(i2) != ']');
                }
                i2++;
            }
            return i3;
        }

        /* JADX INFO: renamed from: n */
        private void m44114n(String str, int i2, int i3, boolean z, boolean z2) {
            String strM44078a = C8027s.m44078a(str, i2, i3, " \"<>^`{}|/\\?#", z2, false, false, true, null);
            if (m44109f(strM44078a)) {
                return;
            }
            if (m44110g(strM44078a)) {
                m44112k();
                return;
            }
            List<String> list = this.f51203f;
            if (list.get(list.size() - 1).isEmpty()) {
                List<String> list2 = this.f51203f;
                list2.set(list2.size() - 1, strM44078a);
            } else {
                this.f51203f.add(strM44078a);
            }
            if (z) {
                this.f51203f.add("");
            }
        }

        /* JADX INFO: renamed from: p */
        private void m44115p(String str, int i2, int i3) {
            if (i2 == i3) {
                return;
            }
            char cCharAt = str.charAt(i2);
            if (cCharAt == '/' || cCharAt == '\\') {
                this.f51203f.clear();
                this.f51203f.add("");
                i2++;
            } else {
                List<String> list = this.f51203f;
                list.set(list.size() - 1, "");
            }
            while (true) {
                int i4 = i2;
                if (i4 >= i3) {
                    return;
                }
                i2 = C7962c.m43590l(str, i4, i3, "/\\");
                boolean z = i2 < i3;
                m44114n(str, i4, i2, z, true);
                if (z) {
                    i2++;
                }
            }
        }

        /* JADX INFO: renamed from: r */
        private static int m44116r(String str, int i2, int i3) {
            if (i3 - i2 < 2) {
                return -1;
            }
            char cCharAt = str.charAt(i2);
            if ((cCharAt >= 'a' && cCharAt <= 'z') || (cCharAt >= 'A' && cCharAt <= 'Z')) {
                while (true) {
                    i2++;
                    if (i2 >= i3) {
                        break;
                    }
                    char cCharAt2 = str.charAt(i2);
                    if (cCharAt2 < 'a' || cCharAt2 > 'z') {
                        if (cCharAt2 < 'A' || cCharAt2 > 'Z') {
                            if (cCharAt2 < '0' || cCharAt2 > '9') {
                                if (cCharAt2 != '+' && cCharAt2 != '-' && cCharAt2 != '.') {
                                    if (cCharAt2 == ':') {
                                        return i2;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return -1;
        }

        /* JADX INFO: renamed from: s */
        private static int m44117s(String str, int i2, int i3) {
            int i4 = 0;
            while (i2 < i3) {
                char cCharAt = str.charAt(i2);
                if (cCharAt != '\\' && cCharAt != '/') {
                    break;
                }
                i4++;
                i2++;
            }
            return i4;
        }

        /* JADX INFO: renamed from: a */
        public C8027s m44118a() {
            if (this.f51198a == null) {
                throw new IllegalStateException("scheme == null");
            }
            if (this.f51201d != null) {
                return new C8027s(this);
            }
            throw new IllegalStateException("host == null");
        }

        /* JADX INFO: renamed from: c */
        int m44119c() {
            int i2 = this.f51202e;
            return i2 != -1 ? i2 : C8027s.m44081d(this.f51198a);
        }

        /* JADX INFO: renamed from: d */
        public a m44120d(@Nullable String str) {
            this.f51204g = str != null ? C8027s.m44091z(C8027s.m44079b(str, " \"'<>#", true, false, true, true)) : null;
            return this;
        }

        /* JADX INFO: renamed from: e */
        public a m44121e(String str) {
            if (str == null) {
                throw new NullPointerException("host == null");
            }
            String strM44108b = m44108b(str, 0, str.length());
            if (strM44108b != null) {
                this.f51201d = strM44108b;
                return this;
            }
            throw new IllegalArgumentException("unexpected host: " + str);
        }

        /* JADX INFO: renamed from: h */
        EnumC10188a m44122h(@Nullable C8027s c8027s, String str) {
            int iM43590l;
            int i2;
            int iM43604z = C7962c.m43604z(str, 0, str.length());
            int iM43575A = C7962c.m43575A(str, iM43604z, str.length());
            if (m44116r(str, iM43604z, iM43575A) != -1) {
                if (str.regionMatches(true, iM43604z, "https:", 0, 6)) {
                    this.f51198a = "https";
                    iM43604z += 6;
                } else {
                    if (!str.regionMatches(true, iM43604z, "http:", 0, 5)) {
                        return EnumC10188a.UNSUPPORTED_SCHEME;
                    }
                    this.f51198a = "http";
                    iM43604z += 5;
                }
            } else {
                if (c8027s == null) {
                    return EnumC10188a.MISSING_SCHEME;
                }
                this.f51198a = c8027s.f51189b;
            }
            int iM44117s = m44117s(str, iM43604z, iM43575A);
            char c2 = '?';
            char c3 = '#';
            if (iM44117s >= 2 || c8027s == null || !c8027s.f51189b.equals(this.f51198a)) {
                int i3 = iM43604z + iM44117s;
                boolean z = false;
                boolean z2 = false;
                while (true) {
                    iM43590l = C7962c.m43590l(str, i3, iM43575A, "@/\\?#");
                    byte bCharAt = iM43590l != iM43575A ? str.charAt(iM43590l) : (byte) -1;
                    if (bCharAt == -1 || bCharAt == c3 || bCharAt == 47 || bCharAt == 92 || bCharAt == c2) {
                        break;
                    }
                    if (bCharAt == 64) {
                        if (z) {
                            i2 = iM43590l;
                            this.f51200c += "%40" + C8027s.m44078a(str, i3, i2, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true, null);
                        } else {
                            int iM43589k = C7962c.m43589k(str, i3, iM43590l, ':');
                            i2 = iM43590l;
                            String strM44078a = C8027s.m44078a(str, i3, iM43589k, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true, null);
                            if (z2) {
                                strM44078a = this.f51199b + "%40" + strM44078a;
                            }
                            this.f51199b = strM44078a;
                            if (iM43589k != i2) {
                                this.f51200c = C8027s.m44078a(str, iM43589k + 1, i2, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true, null);
                                z = true;
                            }
                            z2 = true;
                        }
                        i3 = i2 + 1;
                    }
                    c2 = '?';
                    c3 = '#';
                }
                int iM44113m = m44113m(str, i3, iM43590l);
                int i4 = iM44113m + 1;
                this.f51201d = m44108b(str, i3, iM44113m);
                if (i4 < iM43590l) {
                    int iM44111i = m44111i(str, i4, iM43590l);
                    this.f51202e = iM44111i;
                    if (iM44111i == -1) {
                        return EnumC10188a.INVALID_PORT;
                    }
                } else {
                    this.f51202e = C8027s.m44081d(this.f51198a);
                }
                if (this.f51201d == null) {
                    return EnumC10188a.INVALID_HOST;
                }
                iM43604z = iM43590l;
            } else {
                this.f51199b = c8027s.m44101j();
                this.f51200c = c8027s.m44097f();
                this.f51201d = c8027s.f51192e;
                this.f51202e = c8027s.f51193f;
                this.f51203f.clear();
                this.f51203f.addAll(c8027s.m44099h());
                if (iM43604z == iM43575A || str.charAt(iM43604z) == '#') {
                    m44120d(c8027s.m44100i());
                }
            }
            int iM43590l2 = C7962c.m43590l(str, iM43604z, iM43575A, "?#");
            m44115p(str, iM43604z, iM43590l2);
            if (iM43590l2 < iM43575A && str.charAt(iM43590l2) == '?') {
                int iM43589k2 = C7962c.m43589k(str, iM43590l2, iM43575A, '#');
                this.f51204g = C8027s.m44091z(C8027s.m44078a(str, iM43590l2 + 1, iM43589k2, " \"'<>#", true, false, true, true, null));
                iM43590l2 = iM43589k2;
            }
            if (iM43590l2 < iM43575A && str.charAt(iM43590l2) == '#') {
                this.f51205h = C8027s.m44078a(str, 1 + iM43590l2, iM43575A, "", true, false, false, false, null);
            }
            return EnumC10188a.SUCCESS;
        }

        /* JADX INFO: renamed from: j */
        public a m44123j(String str) {
            if (str == null) {
                throw new NullPointerException("password == null");
            }
            this.f51200c = C8027s.m44079b(str, " \"':;<=>@[]^`{}|/\\?#", false, false, false, true);
            return this;
        }

        /* JADX INFO: renamed from: l */
        public a m44124l(int i2) {
            if (i2 > 0 && i2 <= 65535) {
                this.f51202e = i2;
                return this;
            }
            throw new IllegalArgumentException("unexpected port: " + i2);
        }

        /* JADX INFO: renamed from: o */
        a m44125o() {
            int size = this.f51203f.size();
            for (int i2 = 0; i2 < size; i2++) {
                this.f51203f.set(i2, C8027s.m44079b(this.f51203f.get(i2), "[]", true, true, false, true));
            }
            List<String> list = this.f51204g;
            if (list != null) {
                int size2 = list.size();
                for (int i3 = 0; i3 < size2; i3++) {
                    String str = this.f51204g.get(i3);
                    if (str != null) {
                        this.f51204g.set(i3, C8027s.m44079b(str, "\\^`{|}", true, true, true, true));
                    }
                }
            }
            String str2 = this.f51205h;
            if (str2 != null) {
                this.f51205h = C8027s.m44079b(str2, " \"#<>\\^`{|}", true, true, false, false);
            }
            return this;
        }

        /* JADX INFO: renamed from: q */
        public a m44126q(String str) {
            if (str == null) {
                throw new NullPointerException("scheme == null");
            }
            String str2 = "http";
            if (!str.equalsIgnoreCase("http")) {
                str2 = "https";
                if (!str.equalsIgnoreCase("https")) {
                    throw new IllegalArgumentException("unexpected scheme: " + str);
                }
            }
            this.f51198a = str2;
            return this;
        }

        /* JADX INFO: renamed from: t */
        public a m44127t(String str) {
            if (str == null) {
                throw new NullPointerException("username == null");
            }
            this.f51199b = C8027s.m44079b(str, " \"':;<=>@[]^`{}|/\\?#", false, false, false, true);
            return this;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(this.f51198a);
            sb.append("://");
            if (!this.f51199b.isEmpty() || !this.f51200c.isEmpty()) {
                sb.append(this.f51199b);
                if (!this.f51200c.isEmpty()) {
                    sb.append(':');
                    sb.append(this.f51200c);
                }
                sb.append('@');
            }
            if (this.f51201d.indexOf(58) != -1) {
                sb.append('[');
                sb.append(this.f51201d);
                sb.append(']');
            } else {
                sb.append(this.f51201d);
            }
            int iM44119c = m44119c();
            if (iM44119c != C8027s.m44081d(this.f51198a)) {
                sb.append(':');
                sb.append(iM44119c);
            }
            C8027s.m44085r(sb, this.f51203f);
            if (this.f51204g != null) {
                sb.append('?');
                C8027s.m44083n(sb, this.f51204g);
            }
            if (this.f51205h != null) {
                sb.append('#');
                sb.append(this.f51205h);
            }
            return sb.toString();
        }
    }

    C8027s(a aVar) {
        this.f51189b = aVar.f51198a;
        this.f51190c = m44087t(aVar.f51199b, false);
        this.f51191d = m44087t(aVar.f51200c, false);
        this.f51192e = aVar.f51201d;
        this.f51193f = aVar.m44119c();
        this.f51194g = m44088u(aVar.f51203f, false);
        List<String> list = aVar.f51204g;
        this.f51195h = list != null ? m44088u(list, true) : null;
        String str = aVar.f51205h;
        this.f51196i = str != null ? m44087t(str, false) : null;
        this.f51197j = aVar.toString();
    }

    /* JADX INFO: renamed from: a */
    static String m44078a(String str, int i2, int i3, String str2, boolean z, boolean z2, boolean z3, boolean z4, Charset charset) {
        int iCharCount = i2;
        while (iCharCount < i3) {
            int iCodePointAt = str.codePointAt(iCharCount);
            if (iCodePointAt >= 32 && iCodePointAt != 127 && (iCodePointAt < 128 || !z4)) {
                if (str2.indexOf(iCodePointAt) == -1 && ((iCodePointAt != 37 || (z && (!z2 || m44090w(str, iCharCount, i3)))) && (iCodePointAt != 43 || !z3))) {
                    iCharCount += Character.charCount(iCodePointAt);
                }
            }
            C8037c c8037c = new C8037c();
            c8037c.m44228I(str, i2, iCharCount);
            m44080c(c8037c, str, iCharCount, i3, str2, z, z2, z3, z4, charset);
            return c8037c.m44255q();
        }
        return str.substring(i2, i3);
    }

    /* JADX INFO: renamed from: b */
    static String m44079b(String str, String str2, boolean z, boolean z2, boolean z3, boolean z4) {
        return m44078a(str, 0, str.length(), str2, z, z2, z3, z4, null);
    }

    /* JADX INFO: renamed from: c */
    static void m44080c(C8037c c8037c, String str, int i2, int i3, String str2, boolean z, boolean z2, boolean z3, boolean z4, Charset charset) {
        C8037c c8037c2 = null;
        while (i2 < i3) {
            int iCodePointAt = str.codePointAt(i2);
            if (!z || (iCodePointAt != 9 && iCodePointAt != 10 && iCodePointAt != 12 && iCodePointAt != 13)) {
                if (iCodePointAt == 43 && z3) {
                    c8037c.mo44234T6(z ? "+" : "%2B");
                } else if (iCodePointAt < 32 || iCodePointAt == 127 || ((iCodePointAt >= 128 && z4) || str2.indexOf(iCodePointAt) != -1 || (iCodePointAt == 37 && (!z || (z2 && !m44090w(str, i2, i3)))))) {
                    if (c8037c2 == null) {
                        c8037c2 = new C8037c();
                    }
                    if (charset == null || charset.equals(C7962c.f50630j)) {
                        c8037c2.m44229J(iCodePointAt);
                    } else {
                        c8037c2.m44225G(str, i2, Character.charCount(iCodePointAt) + i2, charset);
                    }
                    while (!c8037c2.mo44237a4()) {
                        int i4 = c8037c2.readByte() & 255;
                        c8037c.mo44241e4(37);
                        char[] cArr = f51188a;
                        c8037c.mo44241e4(cArr[(i4 >> 4) & 15]);
                        c8037c.mo44241e4(cArr[i4 & 15]);
                    }
                } else {
                    c8037c.m44229J(iCodePointAt);
                }
            }
            i2 += Character.charCount(iCodePointAt);
        }
    }

    /* JADX INFO: renamed from: d */
    public static int m44081d(String str) {
        if (str.equals("http")) {
            return 80;
        }
        return str.equals("https") ? 443 : -1;
    }

    @Nullable
    /* JADX INFO: renamed from: k */
    public static C8027s m44082k(URL url) {
        return m44084q(url.toString());
    }

    /* JADX INFO: renamed from: n */
    static void m44083n(StringBuilder sb, List<String> list) {
        int size = list.size();
        for (int i2 = 0; i2 < size; i2 += 2) {
            String str = list.get(i2);
            String str2 = list.get(i2 + 1);
            if (i2 > 0) {
                sb.append('&');
            }
            sb.append(str);
            if (str2 != null) {
                sb.append('=');
                sb.append(str2);
            }
        }
    }

    @Nullable
    /* JADX INFO: renamed from: q */
    public static C8027s m44084q(String str) {
        a aVar = new a();
        if (aVar.m44122h(null, str) == a.EnumC10188a.SUCCESS) {
            return aVar.m44118a();
        }
        return null;
    }

    /* JADX INFO: renamed from: r */
    static void m44085r(StringBuilder sb, List<String> list) {
        int size = list.size();
        for (int i2 = 0; i2 < size; i2++) {
            sb.append('/');
            sb.append(list.get(i2));
        }
    }

    /* JADX INFO: renamed from: s */
    static String m44086s(String str, int i2, int i3, boolean z) {
        for (int i4 = i2; i4 < i3; i4++) {
            char cCharAt = str.charAt(i4);
            if (cCharAt == '%' || (cCharAt == '+' && z)) {
                C8037c c8037c = new C8037c();
                c8037c.m44228I(str, i2, i4);
                m44089v(c8037c, str, i4, i3, z);
                return c8037c.m44255q();
            }
        }
        return str.substring(i2, i3);
    }

    /* JADX INFO: renamed from: t */
    static String m44087t(String str, boolean z) {
        return m44086s(str, 0, str.length(), z);
    }

    /* JADX INFO: renamed from: u */
    private List<String> m44088u(List<String> list, boolean z) {
        int size = list.size();
        ArrayList arrayList = new ArrayList(size);
        for (int i2 = 0; i2 < size; i2++) {
            String str = list.get(i2);
            arrayList.add(str != null ? m44087t(str, z) : null);
        }
        return Collections.unmodifiableList(arrayList);
    }

    /* JADX WARN: Code duplicated, block: B:15:0x0039  */
    /* JADX INFO: renamed from: v */
    static void m44089v(C8037c c8037c, String str, int i2, int i3, boolean z) {
        int i4;
        while (i2 < i3) {
            int iCodePointAt = str.codePointAt(i2);
            if (iCodePointAt == 37 && (i4 = i2 + 2) < i3) {
                int iM43586h = C7962c.m43586h(str.charAt(i2 + 1));
                int iM43586h2 = C7962c.m43586h(str.charAt(i4));
                if (iM43586h == -1 || iM43586h2 == -1) {
                    c8037c.m44229J(iCodePointAt);
                } else {
                    c8037c.mo44241e4((iM43586h << 4) + iM43586h2);
                    i2 = i4;
                }
            } else if (iCodePointAt == 43 && z) {
                c8037c.mo44241e4(32);
            } else {
                c8037c.m44229J(iCodePointAt);
            }
            i2 += Character.charCount(iCodePointAt);
        }
    }

    /* JADX INFO: renamed from: w */
    static boolean m44090w(String str, int i2, int i3) {
        int i4 = i2 + 2;
        return i4 < i3 && str.charAt(i2) == '%' && C7962c.m43586h(str.charAt(i2 + 1)) != -1 && C7962c.m43586h(str.charAt(i4)) != -1;
    }

    /* JADX INFO: renamed from: z */
    static List<String> m44091z(String str) {
        String strSubstring;
        ArrayList arrayList = new ArrayList();
        int i2 = 0;
        while (i2 <= str.length()) {
            int iIndexOf = str.indexOf(38, i2);
            if (iIndexOf == -1) {
                iIndexOf = str.length();
            }
            int iIndexOf2 = str.indexOf(61, i2);
            if (iIndexOf2 == -1 || iIndexOf2 > iIndexOf) {
                arrayList.add(str.substring(i2, iIndexOf));
                strSubstring = null;
            } else {
                arrayList.add(str.substring(i2, iIndexOf2));
                strSubstring = str.substring(iIndexOf2 + 1, iIndexOf);
            }
            arrayList.add(strSubstring);
            i2 = iIndexOf + 1;
        }
        return arrayList;
    }

    /* JADX INFO: renamed from: A */
    public String m44092A() {
        return m44105p("/...").m44127t("").m44123j("").m44118a().toString();
    }

    @Nullable
    /* JADX INFO: renamed from: B */
    public C8027s m44093B(String str) {
        a aVarM44105p = m44105p(str);
        if (aVarM44105p != null) {
            return aVarM44105p.m44118a();
        }
        return null;
    }

    /* JADX INFO: renamed from: C */
    public String m44094C() {
        return this.f51189b;
    }

    /* JADX INFO: renamed from: D */
    public URI m44095D() {
        String string = m44104o().m44125o().toString();
        try {
            return new URI(string);
        } catch (URISyntaxException e2) {
            try {
                return URI.create(string.replaceAll("[\\u0000-\\u001F\\u007F-\\u009F\\p{javaWhitespace}]", ""));
            } catch (Exception unused) {
                throw new RuntimeException(e2);
            }
        }
    }

    @Nullable
    /* JADX INFO: renamed from: e */
    public String m44096e() {
        if (this.f51196i == null) {
            return null;
        }
        return this.f51197j.substring(this.f51197j.indexOf(35) + 1);
    }

    public boolean equals(@Nullable Object obj) {
        return (obj instanceof C8027s) && ((C8027s) obj).f51197j.equals(this.f51197j);
    }

    /* JADX INFO: renamed from: f */
    public String m44097f() {
        if (this.f51191d.isEmpty()) {
            return "";
        }
        return this.f51197j.substring(this.f51197j.indexOf(58, this.f51189b.length() + 3) + 1, this.f51197j.indexOf(64));
    }

    /* JADX INFO: renamed from: g */
    public String m44098g() {
        int iIndexOf = this.f51197j.indexOf(47, this.f51189b.length() + 3);
        String str = this.f51197j;
        return this.f51197j.substring(iIndexOf, C7962c.m43590l(str, iIndexOf, str.length(), "?#"));
    }

    /* JADX INFO: renamed from: h */
    public List<String> m44099h() {
        int iIndexOf = this.f51197j.indexOf(47, this.f51189b.length() + 3);
        String str = this.f51197j;
        int iM43590l = C7962c.m43590l(str, iIndexOf, str.length(), "?#");
        ArrayList arrayList = new ArrayList();
        while (iIndexOf < iM43590l) {
            int i2 = iIndexOf + 1;
            int iM43589k = C7962c.m43589k(this.f51197j, i2, iM43590l, '/');
            arrayList.add(this.f51197j.substring(i2, iM43589k));
            iIndexOf = iM43589k;
        }
        return arrayList;
    }

    public int hashCode() {
        return this.f51197j.hashCode();
    }

    @Nullable
    /* JADX INFO: renamed from: i */
    public String m44100i() {
        if (this.f51195h == null) {
            return null;
        }
        int iIndexOf = this.f51197j.indexOf(63) + 1;
        String str = this.f51197j;
        return this.f51197j.substring(iIndexOf, C7962c.m43589k(str, iIndexOf, str.length(), '#'));
    }

    /* JADX INFO: renamed from: j */
    public String m44101j() {
        if (this.f51190c.isEmpty()) {
            return "";
        }
        int length = this.f51189b.length() + 3;
        String str = this.f51197j;
        return this.f51197j.substring(length, C7962c.m43590l(str, length, str.length(), ":@"));
    }

    /* JADX INFO: renamed from: l */
    public String m44102l() {
        return this.f51192e;
    }

    /* JADX INFO: renamed from: m */
    public boolean m44103m() {
        return this.f51189b.equals("https");
    }

    /* JADX INFO: renamed from: o */
    public a m44104o() {
        a aVar = new a();
        aVar.f51198a = this.f51189b;
        aVar.f51199b = m44101j();
        aVar.f51200c = m44097f();
        aVar.f51201d = this.f51192e;
        aVar.f51202e = this.f51193f != m44081d(this.f51189b) ? this.f51193f : -1;
        aVar.f51203f.clear();
        aVar.f51203f.addAll(m44099h());
        aVar.m44120d(m44100i());
        aVar.f51205h = m44096e();
        return aVar;
    }

    @Nullable
    /* JADX INFO: renamed from: p */
    public a m44105p(String str) {
        a aVar = new a();
        if (aVar.m44122h(this, str) == a.EnumC10188a.SUCCESS) {
            return aVar;
        }
        return null;
    }

    public String toString() {
        return this.f51197j;
    }

    /* JADX INFO: renamed from: x */
    public int m44106x() {
        return this.f51193f;
    }

    @Nullable
    /* JADX INFO: renamed from: y */
    public String m44107y() {
        if (this.f51195h == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        m44083n(sb, this.f51195h);
        return sb.toString();
    }
}
