package p580l;

import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;
import p580l.p581f0.p584g.C7981e;

/* JADX INFO: renamed from: l.d */
/* JADX INFO: loaded from: classes.dex */
public final class C7955d {

    /* JADX INFO: renamed from: a */
    public static final C7955d f50586a = new a().m43550c().m43548a();

    /* JADX INFO: renamed from: b */
    public static final C7955d f50587b = new a().m43552e().m43549b(Integer.MAX_VALUE, TimeUnit.SECONDS).m43548a();

    /* JADX INFO: renamed from: c */
    private final boolean f50588c;

    /* JADX INFO: renamed from: d */
    private final boolean f50589d;

    /* JADX INFO: renamed from: e */
    private final int f50590e;

    /* JADX INFO: renamed from: f */
    private final int f50591f;

    /* JADX INFO: renamed from: g */
    private final boolean f50592g;

    /* JADX INFO: renamed from: h */
    private final boolean f50593h;

    /* JADX INFO: renamed from: i */
    private final boolean f50594i;

    /* JADX INFO: renamed from: j */
    private final int f50595j;

    /* JADX INFO: renamed from: k */
    private final int f50596k;

    /* JADX INFO: renamed from: l */
    private final boolean f50597l;

    /* JADX INFO: renamed from: m */
    private final boolean f50598m;

    /* JADX INFO: renamed from: n */
    private final boolean f50599n;

    /* JADX INFO: renamed from: o */
    @Nullable
    String f50600o;

    /* JADX INFO: renamed from: l.d$a */
    /* JADX INFO: loaded from: classes2.dex */
    public static final class a {

        /* JADX INFO: renamed from: a */
        boolean f50601a;

        /* JADX INFO: renamed from: b */
        boolean f50602b;

        /* JADX INFO: renamed from: c */
        int f50603c = -1;

        /* JADX INFO: renamed from: d */
        int f50604d = -1;

        /* JADX INFO: renamed from: e */
        int f50605e = -1;

        /* JADX INFO: renamed from: f */
        boolean f50606f;

        /* JADX INFO: renamed from: g */
        boolean f50607g;

        /* JADX INFO: renamed from: h */
        boolean f50608h;

        /* JADX INFO: renamed from: a */
        public C7955d m43548a() {
            return new C7955d(this);
        }

        /* JADX INFO: renamed from: b */
        public a m43549b(int i2, TimeUnit timeUnit) {
            if (i2 >= 0) {
                long seconds = timeUnit.toSeconds(i2);
                this.f50604d = seconds > 2147483647L ? Integer.MAX_VALUE : (int) seconds;
                return this;
            }
            throw new IllegalArgumentException("maxStale < 0: " + i2);
        }

        /* JADX INFO: renamed from: c */
        public a m43550c() {
            this.f50601a = true;
            return this;
        }

        /* JADX INFO: renamed from: d */
        public a m43551d() {
            this.f50602b = true;
            return this;
        }

        /* JADX INFO: renamed from: e */
        public a m43552e() {
            this.f50606f = true;
            return this;
        }
    }

    C7955d(a aVar) {
        this.f50588c = aVar.f50601a;
        this.f50589d = aVar.f50602b;
        this.f50590e = aVar.f50603c;
        this.f50591f = -1;
        this.f50592g = false;
        this.f50593h = false;
        this.f50594i = false;
        this.f50595j = aVar.f50604d;
        this.f50596k = aVar.f50605e;
        this.f50597l = aVar.f50606f;
        this.f50598m = aVar.f50607g;
        this.f50599n = aVar.f50608h;
    }

    private C7955d(boolean z, boolean z2, int i2, int i3, boolean z3, boolean z4, boolean z5, int i4, int i5, boolean z6, boolean z7, boolean z8, @Nullable String str) {
        this.f50588c = z;
        this.f50589d = z2;
        this.f50590e = i2;
        this.f50591f = i3;
        this.f50592g = z3;
        this.f50593h = z4;
        this.f50594i = z5;
        this.f50595j = i4;
        this.f50596k = i5;
        this.f50597l = z6;
        this.f50598m = z7;
        this.f50599n = z8;
        this.f50600o = str;
    }

    /* JADX INFO: renamed from: a */
    private String m43536a() {
        StringBuilder sb = new StringBuilder();
        if (this.f50588c) {
            sb.append("no-cache, ");
        }
        if (this.f50589d) {
            sb.append("no-store, ");
        }
        if (this.f50590e != -1) {
            sb.append("max-age=");
            sb.append(this.f50590e);
            sb.append(", ");
        }
        if (this.f50591f != -1) {
            sb.append("s-maxage=");
            sb.append(this.f50591f);
            sb.append(", ");
        }
        if (this.f50592g) {
            sb.append("private, ");
        }
        if (this.f50593h) {
            sb.append("public, ");
        }
        if (this.f50594i) {
            sb.append("must-revalidate, ");
        }
        if (this.f50595j != -1) {
            sb.append("max-stale=");
            sb.append(this.f50595j);
            sb.append(", ");
        }
        if (this.f50596k != -1) {
            sb.append("min-fresh=");
            sb.append(this.f50596k);
            sb.append(", ");
        }
        if (this.f50597l) {
            sb.append("only-if-cached, ");
        }
        if (this.f50598m) {
            sb.append("no-transform, ");
        }
        if (this.f50599n) {
            sb.append("immutable, ");
        }
        if (sb.length() == 0) {
            return "";
        }
        sb.delete(sb.length() - 2, sb.length());
        return sb.toString();
    }

    /* JADX WARN: Code duplicated, block: B:15:0x0041  */
    /* JADX WARN: Code duplicated, block: B:28:0x0099  */
    /* JADX WARN: Code duplicated, block: B:31:0x00a5  */
    /* JADX WARN: Code duplicated, block: B:32:0x00a9  */
    /* JADX WARN: Code duplicated, block: B:34:0x00b1  */
    /* JADX WARN: Code duplicated, block: B:35:0x00b5  */
    /* JADX WARN: Code duplicated, block: B:37:0x00bd  */
    /* JADX WARN: Code duplicated, block: B:38:0x00c4  */
    /* JADX WARN: Code duplicated, block: B:40:0x00cc  */
    /* JADX WARN: Code duplicated, block: B:41:0x00d2  */
    /* JADX WARN: Code duplicated, block: B:43:0x00da  */
    /* JADX WARN: Code duplicated, block: B:44:0x00dd  */
    /* JADX WARN: Code duplicated, block: B:46:0x00e5  */
    /* JADX WARN: Code duplicated, block: B:47:0x00e8  */
    /* JADX WARN: Code duplicated, block: B:49:0x00f0  */
    /* JADX WARN: Code duplicated, block: B:50:0x00f3  */
    /* JADX WARN: Code duplicated, block: B:52:0x00fb  */
    /* JADX WARN: Code duplicated, block: B:53:0x0104  */
    /* JADX WARN: Code duplicated, block: B:55:0x010c  */
    /* JADX WARN: Code duplicated, block: B:56:0x0112  */
    /* JADX WARN: Code duplicated, block: B:58:0x011b  */
    /* JADX WARN: Code duplicated, block: B:59:0x011e  */
    /* JADX WARN: Code duplicated, block: B:61:0x0126  */
    /* JADX WARN: Code duplicated, block: B:62:0x0129  */
    /* JADX WARN: Code duplicated, block: B:64:0x0131  */
    /* JADX WARN: Code duplicated, block: B:87:0x0133 A[SYNTHETIC] */
    /* JADX INFO: renamed from: l */
    public static C7955d m43537l(C8026r c8026r) {
        int i2;
        int iM43725h;
        String strTrim;
        int iM43725h2;
        String strTrim2;
        int iM44067f = c8026r.m44067f();
        boolean z = true;
        String str = null;
        boolean z2 = false;
        boolean z3 = false;
        int iM43723f = -1;
        int iM43723f2 = -1;
        boolean z4 = false;
        boolean z5 = false;
        boolean z6 = false;
        int iM43723f3 = -1;
        int iM43723f4 = -1;
        boolean z7 = false;
        boolean z8 = false;
        boolean z9 = false;
        for (int i3 = 0; i3 < iM44067f; i3++) {
            String strM44065c = c8026r.m44065c(i3);
            String strM44068g = c8026r.m44068g(i3);
            if (strM44065c.equalsIgnoreCase("Cache-Control")) {
                if (str == null) {
                    str = strM44068g;
                }
                for (i2 = 0; i2 < strM44068g.length(); i2 = iM43725h2) {
                    iM43725h = C7981e.m43725h(strM44068g, i2, "=,;");
                    strTrim = strM44068g.substring(i2, iM43725h).trim();
                    if (iM43725h != strM44068g.length() || strM44068g.charAt(iM43725h) == ',' || strM44068g.charAt(iM43725h) == ';') {
                        iM43725h2 = iM43725h + 1;
                        strTrim2 = null;
                    } else {
                        int iM43726i = C7981e.m43726i(strM44068g, iM43725h + 1);
                        if (iM43726i >= strM44068g.length() || strM44068g.charAt(iM43726i) != '\"') {
                            iM43725h2 = C7981e.m43725h(strM44068g, iM43726i, ",;");
                            strTrim2 = strM44068g.substring(iM43726i, iM43725h2).trim();
                        } else {
                            int i4 = iM43726i + 1;
                            int iM43725h3 = C7981e.m43725h(strM44068g, i4, "\"");
                            strTrim2 = strM44068g.substring(i4, iM43725h3);
                            iM43725h2 = iM43725h3 + 1;
                        }
                    }
                    if ("no-cache".equalsIgnoreCase(strTrim)) {
                        z2 = true;
                    } else if ("no-store".equalsIgnoreCase(strTrim)) {
                        z3 = true;
                    } else if ("max-age".equalsIgnoreCase(strTrim)) {
                        iM43723f = C7981e.m43723f(strTrim2, -1);
                    } else if ("s-maxage".equalsIgnoreCase(strTrim)) {
                        iM43723f2 = C7981e.m43723f(strTrim2, -1);
                    } else if ("private".equalsIgnoreCase(strTrim)) {
                        z4 = true;
                    } else if ("public".equalsIgnoreCase(strTrim)) {
                        z5 = true;
                    } else if ("must-revalidate".equalsIgnoreCase(strTrim)) {
                        z6 = true;
                    } else if ("max-stale".equalsIgnoreCase(strTrim)) {
                        iM43723f3 = C7981e.m43723f(strTrim2, Integer.MAX_VALUE);
                    } else if ("min-fresh".equalsIgnoreCase(strTrim)) {
                        iM43723f4 = C7981e.m43723f(strTrim2, -1);
                    } else if ("only-if-cached".equalsIgnoreCase(strTrim)) {
                        z7 = true;
                    } else if ("no-transform".equalsIgnoreCase(strTrim)) {
                        z8 = true;
                    } else if ("immutable".equalsIgnoreCase(strTrim)) {
                        z9 = true;
                    }
                }
            } else {
                if (strM44065c.equalsIgnoreCase("Pragma")) {
                }
            }
            z = false;
            while (i2 < strM44068g.length()) {
                iM43725h = C7981e.m43725h(strM44068g, i2, "=,;");
                strTrim = strM44068g.substring(i2, iM43725h).trim();
                if (iM43725h != strM44068g.length()) {
                    iM43725h2 = iM43725h + 1;
                    strTrim2 = null;
                } else {
                    iM43725h2 = iM43725h + 1;
                    strTrim2 = null;
                }
                if ("no-cache".equalsIgnoreCase(strTrim)) {
                    z2 = true;
                } else if ("no-store".equalsIgnoreCase(strTrim)) {
                    z3 = true;
                } else if ("max-age".equalsIgnoreCase(strTrim)) {
                    iM43723f = C7981e.m43723f(strTrim2, -1);
                } else if ("s-maxage".equalsIgnoreCase(strTrim)) {
                    iM43723f2 = C7981e.m43723f(strTrim2, -1);
                } else if ("private".equalsIgnoreCase(strTrim)) {
                    z4 = true;
                } else if ("public".equalsIgnoreCase(strTrim)) {
                    z5 = true;
                } else if ("must-revalidate".equalsIgnoreCase(strTrim)) {
                    z6 = true;
                } else if ("max-stale".equalsIgnoreCase(strTrim)) {
                    iM43723f3 = C7981e.m43723f(strTrim2, Integer.MAX_VALUE);
                } else if ("min-fresh".equalsIgnoreCase(strTrim)) {
                    iM43723f4 = C7981e.m43723f(strTrim2, -1);
                } else if ("only-if-cached".equalsIgnoreCase(strTrim)) {
                    z7 = true;
                } else if ("no-transform".equalsIgnoreCase(strTrim)) {
                    z8 = true;
                } else if ("immutable".equalsIgnoreCase(strTrim)) {
                    z9 = true;
                }
            }
        }
        return new C7955d(z2, z3, iM43723f, iM43723f2, z4, z5, z6, iM43723f3, iM43723f4, z7, z8, z9, !z ? null : str);
    }

    /* JADX INFO: renamed from: b */
    public boolean m43538b() {
        return this.f50599n;
    }

    /* JADX INFO: renamed from: c */
    public boolean m43539c() {
        return this.f50592g;
    }

    /* JADX INFO: renamed from: d */
    public boolean m43540d() {
        return this.f50593h;
    }

    /* JADX INFO: renamed from: e */
    public int m43541e() {
        return this.f50590e;
    }

    /* JADX INFO: renamed from: f */
    public int m43542f() {
        return this.f50595j;
    }

    /* JADX INFO: renamed from: g */
    public int m43543g() {
        return this.f50596k;
    }

    /* JADX INFO: renamed from: h */
    public boolean m43544h() {
        return this.f50594i;
    }

    /* JADX INFO: renamed from: i */
    public boolean m43545i() {
        return this.f50588c;
    }

    /* JADX INFO: renamed from: j */
    public boolean m43546j() {
        return this.f50589d;
    }

    /* JADX INFO: renamed from: k */
    public boolean m43547k() {
        return this.f50597l;
    }

    public String toString() {
        String str = this.f50600o;
        if (str != null) {
            return str;
        }
        String strM43536a = m43536a();
        this.f50600o = strM43536a;
        return strM43536a;
    }
}
