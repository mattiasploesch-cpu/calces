package p580l;

/* JADX INFO: renamed from: l.i */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC8017i {
}
