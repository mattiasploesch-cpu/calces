package p580l;

import java.io.Closeable;
import javax.annotation.Nullable;
import p580l.p581f0.C7962c;
import p590m.C8037c;
import p590m.InterfaceC8039e;

/* JADX INFO: renamed from: l.c0 */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC7954c0 implements Closeable {

    /* JADX INFO: renamed from: l.c0$a */
    /* JADX INFO: loaded from: classes2.dex */
    final class a extends AbstractC7954c0 {

        /* JADX INFO: renamed from: u2 */
        final /* synthetic */ C8029u f50583u2;

        /* JADX INFO: renamed from: v2 */
        final /* synthetic */ long f50584v2;

        /* JADX INFO: renamed from: w2 */
        final /* synthetic */ InterfaceC8039e f50585w2;

        a(C8029u c8029u, long j2, InterfaceC8039e interfaceC8039e) {
            this.f50583u2 = c8029u;
            this.f50584v2 = j2;
            this.f50585w2 = interfaceC8039e;
        }

        @Override // p580l.AbstractC7954c0
        /* JADX INFO: renamed from: c */
        public long mo43526c() {
            return this.f50584v2;
        }

        @Override // p580l.AbstractC7954c0
        /* JADX INFO: renamed from: f */
        public InterfaceC8039e mo43527f() {
            return this.f50585w2;
        }
    }

    /* JADX INFO: renamed from: d */
    public static AbstractC7954c0 m43534d(@Nullable C8029u c8029u, long j2, InterfaceC8039e interfaceC8039e) {
        if (interfaceC8039e != null) {
            return new a(c8029u, j2, interfaceC8039e);
        }
        throw new NullPointerException("source == null");
    }

    /* JADX INFO: renamed from: e */
    public static AbstractC7954c0 m43535e(@Nullable C8029u c8029u, byte[] bArr) {
        return m43534d(c8029u, bArr.length, new C8037c().mo44235Xa(bArr));
    }

    /* JADX INFO: renamed from: c */
    public abstract long mo43526c();

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        C7962c.m43582d(mo43527f());
    }

    /* JADX INFO: renamed from: f */
    public abstract InterfaceC8039e mo43527f();
}
