package p580l;

import java.util.Collections;
import java.util.List;

/* JADX INFO: renamed from: l.m */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC8021m {

    /* JADX INFO: renamed from: a */
    public static final InterfaceC8021m f51171a = new a();

    /* JADX INFO: renamed from: l.m$a */
    final class a implements InterfaceC8021m {
        a() {
        }

        @Override // p580l.InterfaceC8021m
        /* JADX INFO: renamed from: a */
        public void mo44023a(C8027s c8027s, List<C8020l> list) {
        }

        @Override // p580l.InterfaceC8021m
        /* JADX INFO: renamed from: b */
        public List<C8020l> mo44024b(C8027s c8027s) {
            return Collections.emptyList();
        }
    }

    /* JADX INFO: renamed from: a */
    void mo44023a(C8027s c8027s, List<C8020l> list);

    /* JADX INFO: renamed from: b */
    List<C8020l> mo44024b(C8027s c8027s);
}
