package p580l;

import java.io.IOException;

/* JADX INFO: renamed from: l.f */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC7959f {
    /* JADX INFO: renamed from: a */
    void m43562a(InterfaceC7957e interfaceC7957e, C7952b0 c7952b0);

    /* JADX INFO: renamed from: b */
    void m43563b(InterfaceC7957e interfaceC7957e, IOException iOException);
}
