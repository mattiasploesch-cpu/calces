package p580l;

import java.io.File;
import java.nio.charset.Charset;
import javax.annotation.Nullable;
import p580l.p581f0.C7962c;
import p590m.C8046l;
import p590m.InterfaceC8038d;
import p590m.InterfaceC8053s;

/* JADX INFO: renamed from: l.a0 */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC7950a0 {

    /* JADX INFO: renamed from: l.a0$a */
    final class a extends AbstractC7950a0 {

        /* JADX INFO: renamed from: a */
        final /* synthetic */ C8029u f50517a;

        /* JADX INFO: renamed from: b */
        final /* synthetic */ int f50518b;

        /* JADX INFO: renamed from: c */
        final /* synthetic */ byte[] f50519c;

        /* JADX INFO: renamed from: d */
        final /* synthetic */ int f50520d;

        a(C8029u c8029u, int i2, byte[] bArr, int i3) {
            this.f50517a = c8029u;
            this.f50518b = i2;
            this.f50519c = bArr;
            this.f50520d = i3;
        }

        @Override // p580l.AbstractC7950a0
        /* JADX INFO: renamed from: a */
        public long mo43472a() {
            return this.f50518b;
        }

        @Override // p580l.AbstractC7950a0
        @Nullable
        /* JADX INFO: renamed from: b */
        public C8029u mo43473b() {
            return this.f50517a;
        }

        @Override // p580l.AbstractC7950a0
        /* JADX INFO: renamed from: g */
        public void mo43474g(InterfaceC8038d interfaceC8038d) {
            interfaceC8038d.mo44231P7(this.f50519c, this.f50520d, this.f50518b);
        }
    }

    /* JADX INFO: renamed from: l.a0$b */
    final class b extends AbstractC7950a0 {

        /* JADX INFO: renamed from: a */
        final /* synthetic */ C8029u f50521a;

        /* JADX INFO: renamed from: b */
        final /* synthetic */ File f50522b;

        b(C8029u c8029u, File file) {
            this.f50521a = c8029u;
            this.f50522b = file;
        }

        @Override // p580l.AbstractC7950a0
        /* JADX INFO: renamed from: a */
        public long mo43472a() {
            return this.f50522b.length();
        }

        @Override // p580l.AbstractC7950a0
        @Nullable
        /* JADX INFO: renamed from: b */
        public C8029u mo43473b() {
            return this.f50521a;
        }

        @Override // p580l.AbstractC7950a0
        /* JADX INFO: renamed from: g */
        public void mo43474g(InterfaceC8038d interfaceC8038d) {
            InterfaceC8053s interfaceC8053sM44319j = null;
            try {
                interfaceC8053sM44319j = C8046l.m44319j(this.f50522b);
                interfaceC8038d.mo44259r8(interfaceC8053sM44319j);
            } finally {
                C7962c.m43582d(interfaceC8053sM44319j);
            }
        }
    }

    /* JADX INFO: renamed from: c */
    public static AbstractC7950a0 m43468c(@Nullable C8029u c8029u, File file) {
        if (file != null) {
            return new b(c8029u, file);
        }
        throw new NullPointerException("content == null");
    }

    /* JADX INFO: renamed from: d */
    public static AbstractC7950a0 m43469d(@Nullable C8029u c8029u, String str) {
        Charset charset = C7962c.f50630j;
        if (c8029u != null) {
            Charset charsetM44129a = c8029u.m44129a();
            if (charsetM44129a == null) {
                c8029u = C8029u.m44128c(c8029u + "; charset=utf-8");
            } else {
                charset = charsetM44129a;
            }
        }
        return m43470e(c8029u, str.getBytes(charset));
    }

    /* JADX INFO: renamed from: e */
    public static AbstractC7950a0 m43470e(@Nullable C8029u c8029u, byte[] bArr) {
        return m43471f(c8029u, bArr, 0, bArr.length);
    }

    /* JADX INFO: renamed from: f */
    public static AbstractC7950a0 m43471f(@Nullable C8029u c8029u, byte[] bArr, int i2, int i3) {
        if (bArr == null) {
            throw new NullPointerException("content == null");
        }
        C7962c.m43581c(bArr.length, i2, i3);
        return new a(c8029u, i3, bArr, i2);
    }

    /* JADX INFO: renamed from: a */
    public abstract long mo43472a();

    @Nullable
    /* JADX INFO: renamed from: b */
    public abstract C8029u mo43473b();

    /* JADX INFO: renamed from: g */
    public abstract void mo43474g(InterfaceC8038d interfaceC8038d);
}
