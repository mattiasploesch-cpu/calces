package p580l;

import java.net.Proxy;
import java.net.ProxySelector;
import java.util.List;
import javax.annotation.Nullable;
import javax.net.SocketFactory;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSocketFactory;
import p580l.p581f0.C7962c;

/* JADX INFO: renamed from: l.a */
/* JADX INFO: loaded from: classes.dex */
public final class C7949a {

    /* JADX INFO: renamed from: a */
    final C8027s f50506a;

    /* JADX INFO: renamed from: b */
    final InterfaceC8023o f50507b;

    /* JADX INFO: renamed from: c */
    final SocketFactory f50508c;

    /* JADX INFO: renamed from: d */
    final InterfaceC7951b f50509d;

    /* JADX INFO: renamed from: e */
    final List<EnumC8032x> f50510e;

    /* JADX INFO: renamed from: f */
    final List<C8019k> f50511f;

    /* JADX INFO: renamed from: g */
    final ProxySelector f50512g;

    /* JADX INFO: renamed from: h */
    @Nullable
    final Proxy f50513h;

    /* JADX INFO: renamed from: i */
    @Nullable
    final SSLSocketFactory f50514i;

    /* JADX INFO: renamed from: j */
    @Nullable
    final HostnameVerifier f50515j;

    /* JADX INFO: renamed from: k */
    @Nullable
    final C8015g f50516k;

    public C7949a(String str, int i2, InterfaceC8023o interfaceC8023o, SocketFactory socketFactory, @Nullable SSLSocketFactory sSLSocketFactory, @Nullable HostnameVerifier hostnameVerifier, @Nullable C8015g c8015g, InterfaceC7951b interfaceC7951b, @Nullable Proxy proxy, List<EnumC8032x> list, List<C8019k> list2, ProxySelector proxySelector) {
        this.f50506a = new C8027s.a().m44126q(sSLSocketFactory != null ? "https" : "http").m44121e(str).m44124l(i2).m44118a();
        if (interfaceC8023o == null) {
            throw new NullPointerException("dns == null");
        }
        this.f50507b = interfaceC8023o;
        if (socketFactory == null) {
            throw new NullPointerException("socketFactory == null");
        }
        this.f50508c = socketFactory;
        if (interfaceC7951b == null) {
            throw new NullPointerException("proxyAuthenticator == null");
        }
        this.f50509d = interfaceC7951b;
        if (list == null) {
            throw new NullPointerException("protocols == null");
        }
        this.f50510e = C7962c.m43595q(list);
        if (list2 == null) {
            throw new NullPointerException("connectionSpecs == null");
        }
        this.f50511f = C7962c.m43595q(list2);
        if (proxySelector == null) {
            throw new NullPointerException("proxySelector == null");
        }
        this.f50512g = proxySelector;
        this.f50513h = proxy;
        this.f50514i = sSLSocketFactory;
        this.f50515j = hostnameVerifier;
        this.f50516k = c8015g;
    }

    @Nullable
    /* JADX INFO: renamed from: a */
    public C8015g m43456a() {
        return this.f50516k;
    }

    /* JADX INFO: renamed from: b */
    public List<C8019k> m43457b() {
        return this.f50511f;
    }

    /* JADX INFO: renamed from: c */
    public InterfaceC8023o m43458c() {
        return this.f50507b;
    }

    /* JADX INFO: renamed from: d */
    boolean m43459d(C7949a c7949a) {
        return this.f50507b.equals(c7949a.f50507b) && this.f50509d.equals(c7949a.f50509d) && this.f50510e.equals(c7949a.f50510e) && this.f50511f.equals(c7949a.f50511f) && this.f50512g.equals(c7949a.f50512g) && C7962c.m43592n(this.f50513h, c7949a.f50513h) && C7962c.m43592n(this.f50514i, c7949a.f50514i) && C7962c.m43592n(this.f50515j, c7949a.f50515j) && C7962c.m43592n(this.f50516k, c7949a.f50516k) && m43467l().m44106x() == c7949a.m43467l().m44106x();
    }

    @Nullable
    /* JADX INFO: renamed from: e */
    public HostnameVerifier m43460e() {
        return this.f50515j;
    }

    public boolean equals(@Nullable Object obj) {
        if (obj instanceof C7949a) {
            C7949a c7949a = (C7949a) obj;
            if (this.f50506a.equals(c7949a.f50506a) && m43459d(c7949a)) {
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: renamed from: f */
    public List<EnumC8032x> m43461f() {
        return this.f50510e;
    }

    @Nullable
    /* JADX INFO: renamed from: g */
    public Proxy m43462g() {
        return this.f50513h;
    }

    /* JADX INFO: renamed from: h */
    public InterfaceC7951b m43463h() {
        return this.f50509d;
    }

    public int hashCode() {
        int iHashCode = (((((((((((527 + this.f50506a.hashCode()) * 31) + this.f50507b.hashCode()) * 31) + this.f50509d.hashCode()) * 31) + this.f50510e.hashCode()) * 31) + this.f50511f.hashCode()) * 31) + this.f50512g.hashCode()) * 31;
        Proxy proxy = this.f50513h;
        int iHashCode2 = (iHashCode + (proxy != null ? proxy.hashCode() : 0)) * 31;
        SSLSocketFactory sSLSocketFactory = this.f50514i;
        int iHashCode3 = (iHashCode2 + (sSLSocketFactory != null ? sSLSocketFactory.hashCode() : 0)) * 31;
        HostnameVerifier hostnameVerifier = this.f50515j;
        int iHashCode4 = (iHashCode3 + (hostnameVerifier != null ? hostnameVerifier.hashCode() : 0)) * 31;
        C8015g c8015g = this.f50516k;
        return iHashCode4 + (c8015g != null ? c8015g.hashCode() : 0);
    }

    /* JADX INFO: renamed from: i */
    public ProxySelector m43464i() {
        return this.f50512g;
    }

    /* JADX INFO: renamed from: j */
    public SocketFactory m43465j() {
        return this.f50508c;
    }

    @Nullable
    /* JADX INFO: renamed from: k */
    public SSLSocketFactory m43466k() {
        return this.f50514i;
    }

    /* JADX INFO: renamed from: l */
    public C8027s m43467l() {
        return this.f50506a;
    }

    public String toString() {
        Object obj;
        StringBuilder sb = new StringBuilder();
        sb.append("Address{");
        sb.append(this.f50506a.m44102l());
        sb.append(":");
        sb.append(this.f50506a.m44106x());
        if (this.f50513h != null) {
            sb.append(", proxy=");
            obj = this.f50513h;
        } else {
            sb.append(", proxySelector=");
            obj = this.f50512g;
        }
        sb.append(obj);
        sb.append("}");
        return sb.toString();
    }
}
