package p580l;

import java.io.Closeable;
import javax.annotation.Nullable;

/* JADX INFO: renamed from: l.b0 */
/* JADX INFO: loaded from: classes.dex */
public final class C7952b0 implements Closeable {

    /* JADX INFO: renamed from: A2 */
    @Nullable
    final AbstractC7954c0 f50524A2;

    /* JADX INFO: renamed from: B2 */
    @Nullable
    final C7952b0 f50525B2;

    /* JADX INFO: renamed from: C2 */
    @Nullable
    final C7952b0 f50526C2;

    /* JADX INFO: renamed from: D2 */
    @Nullable
    final C7952b0 f50527D2;

    /* JADX INFO: renamed from: E2 */
    final long f50528E2;

    /* JADX INFO: renamed from: F2 */
    final long f50529F2;

    /* JADX INFO: renamed from: G2 */
    private volatile C7955d f50530G2;

    /* JADX INFO: renamed from: u2 */
    final C8034z f50531u2;

    /* JADX INFO: renamed from: v2 */
    final EnumC8032x f50532v2;

    /* JADX INFO: renamed from: w2 */
    final int f50533w2;

    /* JADX INFO: renamed from: x2 */
    final String f50534x2;

    /* JADX INFO: renamed from: y2 */
    @Nullable
    final C8025q f50535y2;

    /* JADX INFO: renamed from: z2 */
    final C8026r f50536z2;

    /* JADX INFO: renamed from: l.b0$a */
    public static class a {

        /* JADX INFO: renamed from: a */
        C8034z f50537a;

        /* JADX INFO: renamed from: b */
        EnumC8032x f50538b;

        /* JADX INFO: renamed from: c */
        int f50539c;

        /* JADX INFO: renamed from: d */
        String f50540d;

        /* JADX INFO: renamed from: e */
        @Nullable
        C8025q f50541e;

        /* JADX INFO: renamed from: f */
        C8026r.a f50542f;

        /* JADX INFO: renamed from: g */
        AbstractC7954c0 f50543g;

        /* JADX INFO: renamed from: h */
        C7952b0 f50544h;

        /* JADX INFO: renamed from: i */
        C7952b0 f50545i;

        /* JADX INFO: renamed from: j */
        C7952b0 f50546j;

        /* JADX INFO: renamed from: k */
        long f50547k;

        /* JADX INFO: renamed from: l */
        long f50548l;

        public a() {
            this.f50539c = -1;
            this.f50542f = new C8026r.a();
        }

        a(C7952b0 c7952b0) {
            this.f50539c = -1;
            this.f50537a = c7952b0.f50531u2;
            this.f50538b = c7952b0.f50532v2;
            this.f50539c = c7952b0.f50533w2;
            this.f50540d = c7952b0.f50534x2;
            this.f50541e = c7952b0.f50535y2;
            this.f50542f = c7952b0.f50536z2.m44066d();
            this.f50543g = c7952b0.f50524A2;
            this.f50544h = c7952b0.f50525B2;
            this.f50545i = c7952b0.f50526C2;
            this.f50546j = c7952b0.f50527D2;
            this.f50547k = c7952b0.f50528E2;
            this.f50548l = c7952b0.f50529F2;
        }

        /* JADX INFO: renamed from: e */
        private void m43493e(C7952b0 c7952b0) {
            if (c7952b0.f50524A2 != null) {
                throw new IllegalArgumentException("priorResponse.body != null");
            }
        }

        /* JADX INFO: renamed from: f */
        private void m43494f(String str, C7952b0 c7952b0) {
            if (c7952b0.f50524A2 != null) {
                throw new IllegalArgumentException(str + ".body != null");
            }
            if (c7952b0.f50525B2 != null) {
                throw new IllegalArgumentException(str + ".networkResponse != null");
            }
            if (c7952b0.f50526C2 != null) {
                throw new IllegalArgumentException(str + ".cacheResponse != null");
            }
            if (c7952b0.f50527D2 == null) {
                return;
            }
            throw new IllegalArgumentException(str + ".priorResponse != null");
        }

        /* JADX INFO: renamed from: a */
        public a m43495a(String str, String str2) {
            this.f50542f.m44071a(str, str2);
            return this;
        }

        /* JADX INFO: renamed from: b */
        public a m43496b(@Nullable AbstractC7954c0 abstractC7954c0) {
            this.f50543g = abstractC7954c0;
            return this;
        }

        /* JADX INFO: renamed from: c */
        public C7952b0 m43497c() {
            if (this.f50537a == null) {
                throw new IllegalStateException("request == null");
            }
            if (this.f50538b == null) {
                throw new IllegalStateException("protocol == null");
            }
            if (this.f50539c >= 0) {
                if (this.f50540d != null) {
                    return new C7952b0(this);
                }
                throw new IllegalStateException("message == null");
            }
            throw new IllegalStateException("code < 0: " + this.f50539c);
        }

        /* JADX INFO: renamed from: d */
        public a m43498d(@Nullable C7952b0 c7952b0) {
            if (c7952b0 != null) {
                m43494f("cacheResponse", c7952b0);
            }
            this.f50545i = c7952b0;
            return this;
        }

        /* JADX INFO: renamed from: g */
        public a m43499g(int i2) {
            this.f50539c = i2;
            return this;
        }

        /* JADX INFO: renamed from: h */
        public a m43500h(@Nullable C8025q c8025q) {
            this.f50541e = c8025q;
            return this;
        }

        /* JADX INFO: renamed from: i */
        public a m43501i(C8026r c8026r) {
            this.f50542f = c8026r.m44066d();
            return this;
        }

        /* JADX INFO: renamed from: j */
        public a m43502j(String str) {
            this.f50540d = str;
            return this;
        }

        /* JADX INFO: renamed from: k */
        public a m43503k(@Nullable C7952b0 c7952b0) {
            if (c7952b0 != null) {
                m43494f("networkResponse", c7952b0);
            }
            this.f50544h = c7952b0;
            return this;
        }

        /* JADX INFO: renamed from: l */
        public a m43504l(@Nullable C7952b0 c7952b0) {
            if (c7952b0 != null) {
                m43493e(c7952b0);
            }
            this.f50546j = c7952b0;
            return this;
        }

        /* JADX INFO: renamed from: m */
        public a m43505m(EnumC8032x enumC8032x) {
            this.f50538b = enumC8032x;
            return this;
        }

        /* JADX INFO: renamed from: n */
        public a m43506n(long j2) {
            this.f50548l = j2;
            return this;
        }

        /* JADX INFO: renamed from: o */
        public a m43507o(C8034z c8034z) {
            this.f50537a = c8034z;
            return this;
        }

        /* JADX INFO: renamed from: p */
        public a m43508p(long j2) {
            this.f50547k = j2;
            return this;
        }
    }

    C7952b0(a aVar) {
        this.f50531u2 = aVar.f50537a;
        this.f50532v2 = aVar.f50538b;
        this.f50533w2 = aVar.f50539c;
        this.f50534x2 = aVar.f50540d;
        this.f50535y2 = aVar.f50541e;
        this.f50536z2 = aVar.f50542f.m44074d();
        this.f50524A2 = aVar.f50543g;
        this.f50525B2 = aVar.f50544h;
        this.f50526C2 = aVar.f50545i;
        this.f50527D2 = aVar.f50546j;
        this.f50528E2 = aVar.f50547k;
        this.f50529F2 = aVar.f50548l;
    }

    @Nullable
    /* JADX INFO: renamed from: c */
    public AbstractC7954c0 m43476c() {
        return this.f50524A2;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        AbstractC7954c0 abstractC7954c0 = this.f50524A2;
        if (abstractC7954c0 == null) {
            throw new IllegalStateException("response is not eligible for a body and must not be closed");
        }
        abstractC7954c0.close();
    }

    /* JADX INFO: renamed from: d */
    public C7955d m43477d() {
        C7955d c7955d = this.f50530G2;
        if (c7955d != null) {
            return c7955d;
        }
        C7955d c7955dM43537l = C7955d.m43537l(this.f50536z2);
        this.f50530G2 = c7955dM43537l;
        return c7955dM43537l;
    }

    @Nullable
    /* JADX INFO: renamed from: e */
    public C7952b0 m43478e() {
        return this.f50526C2;
    }

    /* JADX INFO: renamed from: f */
    public int m43479f() {
        return this.f50533w2;
    }

    /* JADX INFO: renamed from: g */
    public C8025q m43480g() {
        return this.f50535y2;
    }

    @Nullable
    /* JADX INFO: renamed from: h */
    public String m43481h(String str) {
        return m43482i(str, null);
    }

    @Nullable
    /* JADX INFO: renamed from: i */
    public String m43482i(String str, @Nullable String str2) {
        String strM44064a = this.f50536z2.m44064a(str);
        return strM44064a != null ? strM44064a : str2;
    }

    /* JADX INFO: renamed from: j */
    public C8026r m43483j() {
        return this.f50536z2;
    }

    /* JADX INFO: renamed from: k */
    public boolean m43484k() {
        int i2 = this.f50533w2;
        return i2 >= 200 && i2 < 300;
    }

    /* JADX INFO: renamed from: l */
    public String m43485l() {
        return this.f50534x2;
    }

    @Nullable
    /* JADX INFO: renamed from: o */
    public C7952b0 m43486o() {
        return this.f50525B2;
    }

    /* JADX INFO: renamed from: p */
    public a m43487p() {
        return new a(this);
    }

    @Nullable
    /* JADX INFO: renamed from: q */
    public C7952b0 m43488q() {
        return this.f50527D2;
    }

    /* JADX INFO: renamed from: s */
    public EnumC8032x m43489s() {
        return this.f50532v2;
    }

    /* JADX INFO: renamed from: t */
    public long m43490t() {
        return this.f50529F2;
    }

    public String toString() {
        return "Response{protocol=" + this.f50532v2 + ", code=" + this.f50533w2 + ", message=" + this.f50534x2 + ", url=" + this.f50531u2.m44191i() + '}';
    }

    /* JADX INFO: renamed from: u */
    public C8034z m43491u() {
        return this.f50531u2;
    }

    /* JADX INFO: renamed from: v */
    public long m43492v() {
        return this.f50528E2;
    }
}
