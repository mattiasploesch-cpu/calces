package p580l;

import java.security.cert.Certificate;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSession;
import p580l.p581f0.C7962c;

/* JADX INFO: renamed from: l.q */
/* JADX INFO: loaded from: classes.dex */
public final class C8025q {

    /* JADX INFO: renamed from: a */
    private final EnumC7958e0 f51182a;

    /* JADX INFO: renamed from: b */
    private final C8016h f51183b;

    /* JADX INFO: renamed from: c */
    private final List<Certificate> f51184c;

    /* JADX INFO: renamed from: d */
    private final List<Certificate> f51185d;

    private C8025q(EnumC7958e0 enumC7958e0, C8016h c8016h, List<Certificate> list, List<Certificate> list2) {
        this.f51182a = enumC7958e0;
        this.f51183b = c8016h;
        this.f51184c = list;
        this.f51185d = list2;
    }

    /* JADX INFO: renamed from: b */
    public static C8025q m44056b(SSLSession sSLSession) {
        Certificate[] peerCertificates;
        String cipherSuite = sSLSession.getCipherSuite();
        if (cipherSuite == null) {
            throw new IllegalStateException("cipherSuite == null");
        }
        C8016h c8016hM43988a = C8016h.m43988a(cipherSuite);
        String protocol = sSLSession.getProtocol();
        if (protocol == null) {
            throw new IllegalStateException("tlsVersion == null");
        }
        EnumC7958e0 enumC7958e0M43559c = EnumC7958e0.m43559c(protocol);
        try {
            peerCertificates = sSLSession.getPeerCertificates();
        } catch (SSLPeerUnverifiedException unused) {
            peerCertificates = null;
        }
        List listM43596r = peerCertificates != null ? C7962c.m43596r(peerCertificates) : Collections.emptyList();
        Certificate[] localCertificates = sSLSession.getLocalCertificates();
        return new C8025q(enumC7958e0M43559c, c8016hM43988a, listM43596r, localCertificates != null ? C7962c.m43596r(localCertificates) : Collections.emptyList());
    }

    /* JADX INFO: renamed from: c */
    public static C8025q m44057c(EnumC7958e0 enumC7958e0, C8016h c8016h, List<Certificate> list, List<Certificate> list2) {
        if (enumC7958e0 == null) {
            throw new NullPointerException("tlsVersion == null");
        }
        if (c8016h != null) {
            return new C8025q(enumC7958e0, c8016h, C7962c.m43595q(list), C7962c.m43595q(list2));
        }
        throw new NullPointerException("cipherSuite == null");
    }

    /* JADX INFO: renamed from: a */
    public C8016h m44058a() {
        return this.f51183b;
    }

    /* JADX INFO: renamed from: d */
    public List<Certificate> m44059d() {
        return this.f51185d;
    }

    /* JADX INFO: renamed from: e */
    public List<Certificate> m44060e() {
        return this.f51184c;
    }

    public boolean equals(@Nullable Object obj) {
        if (!(obj instanceof C8025q)) {
            return false;
        }
        C8025q c8025q = (C8025q) obj;
        return this.f51182a.equals(c8025q.f51182a) && this.f51183b.equals(c8025q.f51183b) && this.f51184c.equals(c8025q.f51184c) && this.f51185d.equals(c8025q.f51185d);
    }

    /* JADX INFO: renamed from: f */
    public EnumC7958e0 m44061f() {
        return this.f51182a;
    }

    public int hashCode() {
        return ((((((527 + this.f51182a.hashCode()) * 31) + this.f51183b.hashCode()) * 31) + this.f51184c.hashCode()) * 31) + this.f51185d.hashCode();
    }
}
