package p580l;

import java.net.Proxy;
import java.net.ProxySelector;
import java.net.Socket;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;
import javax.net.SocketFactory;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import p580l.p581f0.AbstractC7960a;
import p580l.p581f0.C7962c;
import p580l.p581f0.p582e.InterfaceC7969f;
import p580l.p581f0.p583f.C7972c;
import p580l.p581f0.p583f.C7973d;
import p580l.p581f0.p583f.C7976g;
import p580l.p581f0.p588k.C8009f;
import p580l.p581f0.p589l.AbstractC8012c;
import p580l.p581f0.p589l.C8013d;

/* JADX INFO: renamed from: l.w */
/* JADX INFO: loaded from: classes.dex */
public class C8031w implements Cloneable, InterfaceC7957e.a {

    /* JADX INFO: renamed from: u2 */
    static final List<EnumC8032x> f51236u2 = C7962c.m43596r(EnumC8032x.HTTP_2, EnumC8032x.HTTP_1_1);

    /* JADX INFO: renamed from: v2 */
    static final List<C8019k> f51237v2 = C7962c.m43596r(C8019k.f51147b, C8019k.f51149d);

    /* JADX INFO: renamed from: A2 */
    final List<InterfaceC8028t> f51238A2;

    /* JADX INFO: renamed from: B2 */
    final List<InterfaceC8028t> f51239B2;

    /* JADX INFO: renamed from: C2 */
    final AbstractC8024p.c f51240C2;

    /* JADX INFO: renamed from: D2 */
    final ProxySelector f51241D2;

    /* JADX INFO: renamed from: E2 */
    final InterfaceC8021m f51242E2;

    /* JADX INFO: renamed from: F2 */
    @Nullable
    final C7953c f51243F2;

    /* JADX INFO: renamed from: G2 */
    @Nullable
    final InterfaceC7969f f51244G2;

    /* JADX INFO: renamed from: H2 */
    final SocketFactory f51245H2;

    /* JADX INFO: renamed from: I2 */
    @Nullable
    final SSLSocketFactory f51246I2;

    /* JADX INFO: renamed from: J2 */
    @Nullable
    final AbstractC8012c f51247J2;

    /* JADX INFO: renamed from: K2 */
    final HostnameVerifier f51248K2;

    /* JADX INFO: renamed from: L2 */
    final C8015g f51249L2;

    /* JADX INFO: renamed from: M2 */
    final InterfaceC7951b f51250M2;

    /* JADX INFO: renamed from: N2 */
    final InterfaceC7951b f51251N2;

    /* JADX INFO: renamed from: O2 */
    final C8018j f51252O2;

    /* JADX INFO: renamed from: P2 */
    final InterfaceC8023o f51253P2;

    /* JADX INFO: renamed from: Q2 */
    final boolean f51254Q2;

    /* JADX INFO: renamed from: R2 */
    final boolean f51255R2;

    /* JADX INFO: renamed from: S2 */
    final boolean f51256S2;

    /* JADX INFO: renamed from: T2 */
    final int f51257T2;

    /* JADX INFO: renamed from: U2 */
    final int f51258U2;

    /* JADX INFO: renamed from: V2 */
    final int f51259V2;

    /* JADX INFO: renamed from: W2 */
    final int f51260W2;

    /* JADX INFO: renamed from: w2 */
    final C8022n f51261w2;

    /* JADX INFO: renamed from: x2 */
    @Nullable
    final Proxy f51262x2;

    /* JADX INFO: renamed from: y2 */
    final List<EnumC8032x> f51263y2;

    /* JADX INFO: renamed from: z2 */
    final List<C8019k> f51264z2;

    /* JADX INFO: renamed from: l.w$a */
    /* JADX INFO: loaded from: classes2.dex */
    final class a extends AbstractC7960a {
        a() {
        }

        @Override // p580l.p581f0.AbstractC7960a
        /* JADX INFO: renamed from: a */
        public void mo43564a(C8026r.a aVar, String str) {
            aVar.m44072b(str);
        }

        @Override // p580l.p581f0.AbstractC7960a
        /* JADX INFO: renamed from: b */
        public void mo43565b(C8026r.a aVar, String str, String str2) {
            aVar.m44073c(str, str2);
        }

        @Override // p580l.p581f0.AbstractC7960a
        /* JADX INFO: renamed from: c */
        public void mo43566c(C8019k c8019k, SSLSocket sSLSocket, boolean z) {
            c8019k.m44000a(sSLSocket, z);
        }

        @Override // p580l.p581f0.AbstractC7960a
        /* JADX INFO: renamed from: d */
        public int mo43567d(C7952b0.a aVar) {
            return aVar.f50539c;
        }

        @Override // p580l.p581f0.AbstractC7960a
        /* JADX INFO: renamed from: e */
        public boolean mo43568e(C8018j c8018j, C7972c c7972c) {
            return c8018j.m43995b(c7972c);
        }

        @Override // p580l.p581f0.AbstractC7960a
        /* JADX INFO: renamed from: f */
        public Socket mo43569f(C8018j c8018j, C7949a c7949a, C7976g c7976g) {
            return c8018j.m43996c(c7949a, c7976g);
        }

        @Override // p580l.p581f0.AbstractC7960a
        /* JADX INFO: renamed from: g */
        public boolean mo43570g(C7949a c7949a, C7949a c7949a2) {
            return c7949a.m43459d(c7949a2);
        }

        @Override // p580l.p581f0.AbstractC7960a
        /* JADX INFO: renamed from: h */
        public C7972c mo43571h(C8018j c8018j, C7949a c7949a, C7976g c7976g, C7956d0 c7956d0) {
            return c8018j.m43997d(c7949a, c7976g, c7956d0);
        }

        @Override // p580l.p581f0.AbstractC7960a
        /* JADX INFO: renamed from: i */
        public void mo43572i(C8018j c8018j, C7972c c7972c) {
            c8018j.m43998f(c7972c);
        }

        @Override // p580l.p581f0.AbstractC7960a
        /* JADX INFO: renamed from: j */
        public C7973d mo43573j(C8018j c8018j) {
            return c8018j.f51143f;
        }
    }

    /* JADX INFO: renamed from: l.w$b */
    public static final class b {

        /* JADX INFO: renamed from: A */
        int f51265A;

        /* JADX INFO: renamed from: b */
        @Nullable
        Proxy f51267b;

        /* JADX INFO: renamed from: j */
        @Nullable
        C7953c f51275j;

        /* JADX INFO: renamed from: k */
        @Nullable
        InterfaceC7969f f51276k;

        /* JADX INFO: renamed from: m */
        @Nullable
        SSLSocketFactory f51278m;

        /* JADX INFO: renamed from: n */
        @Nullable
        AbstractC8012c f51279n;

        /* JADX INFO: renamed from: q */
        InterfaceC7951b f51282q;

        /* JADX INFO: renamed from: r */
        InterfaceC7951b f51283r;

        /* JADX INFO: renamed from: s */
        C8018j f51284s;

        /* JADX INFO: renamed from: t */
        InterfaceC8023o f51285t;

        /* JADX INFO: renamed from: u */
        boolean f51286u;

        /* JADX INFO: renamed from: v */
        boolean f51287v;

        /* JADX INFO: renamed from: w */
        boolean f51288w;

        /* JADX INFO: renamed from: x */
        int f51289x;

        /* JADX INFO: renamed from: y */
        int f51290y;

        /* JADX INFO: renamed from: z */
        int f51291z;

        /* JADX INFO: renamed from: e */
        final List<InterfaceC8028t> f51270e = new ArrayList();

        /* JADX INFO: renamed from: f */
        final List<InterfaceC8028t> f51271f = new ArrayList();

        /* JADX INFO: renamed from: a */
        C8022n f51266a = new C8022n();

        /* JADX INFO: renamed from: c */
        List<EnumC8032x> f51268c = C8031w.f51236u2;

        /* JADX INFO: renamed from: d */
        List<C8019k> f51269d = C8031w.f51237v2;

        /* JADX INFO: renamed from: g */
        AbstractC8024p.c f51272g = AbstractC8024p.m44034k(AbstractC8024p.f51180a);

        /* JADX INFO: renamed from: h */
        ProxySelector f51273h = ProxySelector.getDefault();

        /* JADX INFO: renamed from: i */
        InterfaceC8021m f51274i = InterfaceC8021m.f51171a;

        /* JADX INFO: renamed from: l */
        SocketFactory f51277l = SocketFactory.getDefault();

        /* JADX INFO: renamed from: o */
        HostnameVerifier f51280o = C8013d.f51014a;

        /* JADX INFO: renamed from: p */
        C8015g f51281p = C8015g.f51015a;

        public b() {
            InterfaceC7951b interfaceC7951b = InterfaceC7951b.f50523a;
            this.f51282q = interfaceC7951b;
            this.f51283r = interfaceC7951b;
            this.f51284s = new C8018j();
            this.f51285t = InterfaceC8023o.f51179a;
            this.f51286u = true;
            this.f51287v = true;
            this.f51288w = true;
            this.f51289x = 10000;
            this.f51290y = 10000;
            this.f51291z = 10000;
            this.f51265A = 0;
        }

        /* JADX INFO: renamed from: a */
        public C8031w m44170a() {
            return new C8031w(this);
        }

        /* JADX INFO: renamed from: b */
        public b m44171b(@Nullable C7953c c7953c) {
            this.f51275j = c7953c;
            this.f51276k = null;
            return this;
        }
    }

    static {
        AbstractC7960a.f50619a = new a();
    }

    public C8031w() {
        this(new b());
    }

    C8031w(b bVar) {
        boolean z;
        AbstractC8012c abstractC8012cM43973b;
        this.f51261w2 = bVar.f51266a;
        this.f51262x2 = bVar.f51267b;
        this.f51263y2 = bVar.f51268c;
        List<C8019k> list = bVar.f51269d;
        this.f51264z2 = list;
        this.f51238A2 = C7962c.m43595q(bVar.f51270e);
        this.f51239B2 = C7962c.m43595q(bVar.f51271f);
        this.f51240C2 = bVar.f51272g;
        this.f51241D2 = bVar.f51273h;
        this.f51242E2 = bVar.f51274i;
        this.f51243F2 = bVar.f51275j;
        this.f51244G2 = bVar.f51276k;
        this.f51245H2 = bVar.f51277l;
        Iterator<C8019k> it = list.iterator();
        loop0: while (true) {
            while (true) {
                if (!it.hasNext()) {
                    break loop0;
                } else {
                    z = z || it.next().m44003d();
                }
            }
        }
        SSLSocketFactory sSLSocketFactory = bVar.f51278m;
        if (sSLSocketFactory == null && z) {
            X509TrustManager x509TrustManagerM44143C = m44143C();
            this.f51246I2 = m44142B(x509TrustManagerM44143C);
            abstractC8012cM43973b = AbstractC8012c.m43973b(x509TrustManagerM44143C);
        } else {
            this.f51246I2 = sSLSocketFactory;
            abstractC8012cM43973b = bVar.f51279n;
        }
        this.f51247J2 = abstractC8012cM43973b;
        this.f51248K2 = bVar.f51280o;
        this.f51249L2 = bVar.f51281p.m43985f(this.f51247J2);
        this.f51250M2 = bVar.f51282q;
        this.f51251N2 = bVar.f51283r;
        this.f51252O2 = bVar.f51284s;
        this.f51253P2 = bVar.f51285t;
        this.f51254Q2 = bVar.f51286u;
        this.f51255R2 = bVar.f51287v;
        this.f51256S2 = bVar.f51288w;
        this.f51257T2 = bVar.f51289x;
        this.f51258U2 = bVar.f51290y;
        this.f51259V2 = bVar.f51291z;
        this.f51260W2 = bVar.f51265A;
        if (this.f51238A2.contains(null)) {
            throw new IllegalStateException("Null interceptor: " + this.f51238A2);
        }
        if (this.f51239B2.contains(null)) {
            throw new IllegalStateException("Null network interceptor: " + this.f51239B2);
        }
    }

    /* JADX INFO: renamed from: B */
    private SSLSocketFactory m44142B(X509TrustManager x509TrustManager) {
        try {
            SSLContext sSLContextMo43955k = C8009f.m43969i().mo43955k();
            sSLContextMo43955k.init(null, new TrustManager[]{x509TrustManager}, null);
            return sSLContextMo43955k.getSocketFactory();
        } catch (GeneralSecurityException e2) {
            throw C7962c.m43579a("No System TLS", e2);
        }
    }

    /* JADX INFO: renamed from: C */
    private X509TrustManager m44143C() {
        try {
            TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            trustManagerFactory.init((KeyStore) null);
            TrustManager[] trustManagers = trustManagerFactory.getTrustManagers();
            if (trustManagers.length == 1 && (trustManagers[0] instanceof X509TrustManager)) {
                return (X509TrustManager) trustManagers[0];
            }
            throw new IllegalStateException("Unexpected default trust managers:" + Arrays.toString(trustManagers));
        } catch (GeneralSecurityException e2) {
            throw C7962c.m43579a("No System TLS", e2);
        }
    }

    /* JADX INFO: renamed from: A */
    public SSLSocketFactory m44144A() {
        return this.f51246I2;
    }

    /* JADX INFO: renamed from: D */
    public int m44145D() {
        return this.f51259V2;
    }

    @Override // p580l.InterfaceC7957e.a
    /* JADX INFO: renamed from: a */
    public InterfaceC7957e mo43558a(C8034z c8034z) {
        return C8033y.m44175f(this, c8034z, false);
    }

    /* JADX INFO: renamed from: b */
    public InterfaceC7951b m44146b() {
        return this.f51251N2;
    }

    /* JADX INFO: renamed from: c */
    public C7953c m44147c() {
        return this.f51243F2;
    }

    /* JADX INFO: renamed from: d */
    public C8015g m44148d() {
        return this.f51249L2;
    }

    /* JADX INFO: renamed from: e */
    public int m44149e() {
        return this.f51257T2;
    }

    /* JADX INFO: renamed from: f */
    public C8018j m44150f() {
        return this.f51252O2;
    }

    /* JADX INFO: renamed from: g */
    public List<C8019k> m44151g() {
        return this.f51264z2;
    }

    /* JADX INFO: renamed from: h */
    public InterfaceC8021m m44152h() {
        return this.f51242E2;
    }

    /* JADX INFO: renamed from: i */
    public C8022n m44153i() {
        return this.f51261w2;
    }

    /* JADX INFO: renamed from: j */
    public InterfaceC8023o m44154j() {
        return this.f51253P2;
    }

    /* JADX INFO: renamed from: k */
    public AbstractC8024p.c m44155k() {
        return this.f51240C2;
    }

    /* JADX INFO: renamed from: m */
    public boolean m44156m() {
        return this.f51255R2;
    }

    /* JADX INFO: renamed from: n */
    public boolean m44157n() {
        return this.f51254Q2;
    }

    /* JADX INFO: renamed from: o */
    public HostnameVerifier m44158o() {
        return this.f51248K2;
    }

    /* JADX INFO: renamed from: p */
    public List<InterfaceC8028t> m44159p() {
        return this.f51238A2;
    }

    /* JADX INFO: renamed from: q */
    InterfaceC7969f m44160q() {
        C7953c c7953c = this.f51243F2;
        return c7953c != null ? c7953c.f50550u2 : this.f51244G2;
    }

    /* JADX INFO: renamed from: r */
    public List<InterfaceC8028t> m44161r() {
        return this.f51239B2;
    }

    /* JADX INFO: renamed from: s */
    public int m44162s() {
        return this.f51260W2;
    }

    /* JADX INFO: renamed from: t */
    public List<EnumC8032x> m44163t() {
        return this.f51263y2;
    }

    /* JADX INFO: renamed from: u */
    public Proxy m44164u() {
        return this.f51262x2;
    }

    /* JADX INFO: renamed from: v */
    public InterfaceC7951b m44165v() {
        return this.f51250M2;
    }

    /* JADX INFO: renamed from: w */
    public ProxySelector m44166w() {
        return this.f51241D2;
    }

    /* JADX INFO: renamed from: x */
    public int m44167x() {
        return this.f51258U2;
    }

    /* JADX INFO: renamed from: y */
    public boolean m44168y() {
        return this.f51256S2;
    }

    /* JADX INFO: renamed from: z */
    public SocketFactory m44169z() {
        return this.f51245H2;
    }
}
