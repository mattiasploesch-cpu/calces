package p580l;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import p580l.p581f0.C7962c;

/* JADX INFO: renamed from: l.r */
/* JADX INFO: loaded from: classes.dex */
public final class C8026r {

    /* JADX INFO: renamed from: a */
    private final String[] f51186a;

    /* JADX INFO: renamed from: l.r$a */
    /* JADX INFO: loaded from: classes2.dex */
    public static final class a {

        /* JADX INFO: renamed from: a */
        final List<String> f51187a = new ArrayList(20);

        /* JADX INFO: renamed from: e */
        private void m44070e(String str, String str2) {
            if (str == null) {
                throw new NullPointerException("name == null");
            }
            if (str.isEmpty()) {
                throw new IllegalArgumentException("name is empty");
            }
            int length = str.length();
            for (int i2 = 0; i2 < length; i2++) {
                char cCharAt = str.charAt(i2);
                if (cCharAt <= ' ' || cCharAt >= 127) {
                    throw new IllegalArgumentException(C7962c.m43593o("Unexpected char %#04x at %d in header name: %s", Integer.valueOf(cCharAt), Integer.valueOf(i2), str));
                }
            }
            if (str2 == null) {
                throw new NullPointerException("value for name " + str + " == null");
            }
            int length2 = str2.length();
            for (int i3 = 0; i3 < length2; i3++) {
                char cCharAt2 = str2.charAt(i3);
                if ((cCharAt2 <= 31 && cCharAt2 != '\t') || cCharAt2 >= 127) {
                    throw new IllegalArgumentException(C7962c.m43593o("Unexpected char %#04x at %d in %s value: %s", Integer.valueOf(cCharAt2), Integer.valueOf(i3), str, str2));
                }
            }
        }

        /* JADX INFO: renamed from: a */
        public a m44071a(String str, String str2) {
            m44070e(str, str2);
            return m44073c(str, str2);
        }

        /* JADX INFO: renamed from: b */
        a m44072b(String str) {
            int iIndexOf = str.indexOf(":", 1);
            if (iIndexOf != -1) {
                return m44073c(str.substring(0, iIndexOf), str.substring(iIndexOf + 1));
            }
            return str.startsWith(":") ? m44073c("", str.substring(1)) : m44073c("", str);
        }

        /* JADX INFO: renamed from: c */
        a m44073c(String str, String str2) {
            this.f51187a.add(str);
            this.f51187a.add(str2.trim());
            return this;
        }

        /* JADX INFO: renamed from: d */
        public C8026r m44074d() {
            return new C8026r(this);
        }

        /* JADX INFO: renamed from: f */
        public String m44075f(String str) {
            for (int size = this.f51187a.size() - 2; size >= 0; size -= 2) {
                if (str.equalsIgnoreCase(this.f51187a.get(size))) {
                    return this.f51187a.get(size + 1);
                }
            }
            return null;
        }

        /* JADX INFO: renamed from: g */
        public a m44076g(String str) {
            int i2 = 0;
            while (i2 < this.f51187a.size()) {
                if (str.equalsIgnoreCase(this.f51187a.get(i2))) {
                    this.f51187a.remove(i2);
                    this.f51187a.remove(i2);
                    i2 -= 2;
                }
                i2 += 2;
            }
            return this;
        }

        /* JADX INFO: renamed from: h */
        public a m44077h(String str, String str2) {
            m44070e(str, str2);
            m44076g(str);
            m44073c(str, str2);
            return this;
        }
    }

    C8026r(a aVar) {
        List<String> list = aVar.f51187a;
        this.f51186a = (String[]) list.toArray(new String[list.size()]);
    }

    private C8026r(String[] strArr) {
        this.f51186a = strArr;
    }

    /* JADX INFO: renamed from: b */
    private static String m44062b(String[] strArr, String str) {
        for (int length = strArr.length - 2; length >= 0; length -= 2) {
            if (str.equalsIgnoreCase(strArr[length])) {
                return strArr[length + 1];
            }
        }
        return null;
    }

    /* JADX INFO: renamed from: e */
    public static C8026r m44063e(String... strArr) {
        if (strArr == null) {
            throw new NullPointerException("namesAndValues == null");
        }
        if (strArr.length % 2 != 0) {
            throw new IllegalArgumentException("Expected alternating header names and values");
        }
        String[] strArr2 = (String[]) strArr.clone();
        for (int i2 = 0; i2 < strArr2.length; i2++) {
            if (strArr2[i2] == null) {
                throw new IllegalArgumentException("Headers cannot be null");
            }
            strArr2[i2] = strArr2[i2].trim();
        }
        for (int i3 = 0; i3 < strArr2.length; i3 += 2) {
            String str = strArr2[i3];
            String str2 = strArr2[i3 + 1];
            if (str.length() == 0 || str.indexOf(0) != -1 || str2.indexOf(0) != -1) {
                throw new IllegalArgumentException("Unexpected header: " + str + ": " + str2);
            }
        }
        return new C8026r(strArr2);
    }

    @Nullable
    /* JADX INFO: renamed from: a */
    public String m44064a(String str) {
        return m44062b(this.f51186a, str);
    }

    /* JADX INFO: renamed from: c */
    public String m44065c(int i2) {
        return this.f51186a[i2 * 2];
    }

    /* JADX INFO: renamed from: d */
    public a m44066d() {
        a aVar = new a();
        Collections.addAll(aVar.f51187a, this.f51186a);
        return aVar;
    }

    public boolean equals(@Nullable Object obj) {
        return (obj instanceof C8026r) && Arrays.equals(((C8026r) obj).f51186a, this.f51186a);
    }

    /* JADX INFO: renamed from: f */
    public int m44067f() {
        return this.f51186a.length / 2;
    }

    /* JADX INFO: renamed from: g */
    public String m44068g(int i2) {
        return this.f51186a[(i2 * 2) + 1];
    }

    /* JADX INFO: renamed from: h */
    public List<String> m44069h(String str) {
        int iM44067f = m44067f();
        ArrayList arrayList = null;
        for (int i2 = 0; i2 < iM44067f; i2++) {
            if (str.equalsIgnoreCase(m44065c(i2))) {
                if (arrayList == null) {
                    arrayList = new ArrayList(2);
                }
                arrayList.add(m44068g(i2));
            }
        }
        return arrayList != null ? Collections.unmodifiableList(arrayList) : Collections.emptyList();
    }

    public int hashCode() {
        return Arrays.hashCode(this.f51186a);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        int iM44067f = m44067f();
        for (int i2 = 0; i2 < iM44067f; i2++) {
            sb.append(m44065c(i2));
            sb.append(": ");
            sb.append(m44068g(i2));
            sb.append("\n");
        }
        return sb.toString();
    }
}
