package p580l;

import java.lang.ref.Reference;
import java.net.Socket;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;
import p580l.p581f0.C7962c;
import p580l.p581f0.p583f.C7972c;
import p580l.p581f0.p583f.C7973d;
import p580l.p581f0.p583f.C7976g;
import p580l.p581f0.p588k.C8009f;

/* JADX INFO: renamed from: l.j */
/* JADX INFO: loaded from: classes.dex */
public final class C8018j {

    /* JADX INFO: renamed from: a */
    private static final Executor f51138a = new ThreadPoolExecutor(0, Integer.MAX_VALUE, 60, TimeUnit.SECONDS, new SynchronousQueue(), C7962c.m43576B("OkHttp ConnectionPool", true));

    /* JADX INFO: renamed from: b */
    private final int f51139b;

    /* JADX INFO: renamed from: c */
    private final long f51140c;

    /* JADX INFO: renamed from: d */
    private final Runnable f51141d;

    /* JADX INFO: renamed from: e */
    private final Deque<C7972c> f51142e;

    /* JADX INFO: renamed from: f */
    final C7973d f51143f;

    /* JADX INFO: renamed from: g */
    boolean f51144g;

    /* JADX INFO: renamed from: l.j$a */
    /* JADX INFO: loaded from: classes2.dex */
    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            while (true) {
                long jM43994a = C8018j.this.m43994a(System.nanoTime());
                if (jM43994a == -1) {
                    return;
                }
                if (jM43994a > 0) {
                    long j2 = jM43994a / 1000000;
                    long j3 = jM43994a - (1000000 * j2);
                    synchronized (C8018j.this) {
                        try {
                            C8018j.this.wait(j2, (int) j3);
                        } catch (InterruptedException unused) {
                        }
                    }
                }
            }
        }
    }

    public C8018j() {
        this(5, 5L, TimeUnit.MINUTES);
    }

    public C8018j(int i2, long j2, TimeUnit timeUnit) {
        this.f51141d = new a();
        this.f51142e = new ArrayDeque();
        this.f51143f = new C7973d();
        this.f51139b = i2;
        this.f51140c = timeUnit.toNanos(j2);
        if (j2 > 0) {
            return;
        }
        throw new IllegalArgumentException("keepAliveDuration <= 0: " + j2);
    }

    /* JADX INFO: renamed from: e */
    private int m43993e(C7972c c7972c, long j2) {
        List<Reference<C7976g>> list = c7972c.f50720n;
        int i2 = 0;
        while (i2 < list.size()) {
            Reference<C7976g> reference = list.get(i2);
            if (reference.get() != null) {
                i2++;
            } else {
                C8009f.m43969i().mo43947q("A connection to " + c7972c.m43671p().m43553a().m43467l() + " was leaked. Did you forget to close a response body?", ((C7976g.a) reference).f50749a);
                list.remove(i2);
                c7972c.f50717k = true;
                if (list.isEmpty()) {
                    c7972c.f50721o = j2 - this.f51140c;
                    return 0;
                }
            }
        }
        return list.size();
    }

    /* JADX INFO: renamed from: a */
    long m43994a(long j2) {
        synchronized (this) {
            C7972c c7972c = null;
            long j3 = Long.MIN_VALUE;
            int i2 = 0;
            int i3 = 0;
            for (C7972c c7972c2 : this.f51142e) {
                if (m43993e(c7972c2, j2) > 0) {
                    i3++;
                } else {
                    i2++;
                    long j4 = j2 - c7972c2.f50721o;
                    if (j4 > j3) {
                        c7972c = c7972c2;
                        j3 = j4;
                    }
                }
            }
            long j5 = this.f51140c;
            if (j3 < j5 && i2 <= this.f51139b) {
                if (i2 > 0) {
                    return j5 - j3;
                }
                if (i3 > 0) {
                    return j5;
                }
                this.f51144g = false;
                return -1L;
            }
            this.f51142e.remove(c7972c);
            C7962c.m43583e(c7972c.m43672q());
            return 0L;
        }
    }

    /* JADX INFO: renamed from: b */
    boolean m43995b(C7972c c7972c) {
        if (c7972c.f50717k || this.f51139b == 0) {
            this.f51142e.remove(c7972c);
            return true;
        }
        notifyAll();
        return false;
    }

    @Nullable
    /* JADX INFO: renamed from: c */
    Socket m43996c(C7949a c7949a, C7976g c7976g) {
        for (C7972c c7972c : this.f51142e) {
            if (c7972c.m43667k(c7949a, null) && c7972c.m43669m() && c7972c != c7976g.m43699c()) {
                return c7976g.m43704l(c7972c);
            }
        }
        return null;
    }

    @Nullable
    /* JADX INFO: renamed from: d */
    C7972c m43997d(C7949a c7949a, C7976g c7976g, C7956d0 c7956d0) {
        for (C7972c c7972c : this.f51142e) {
            if (c7972c.m43667k(c7949a, c7956d0)) {
                c7976g.m43697a(c7972c, true);
                return c7972c;
            }
        }
        return null;
    }

    /* JADX INFO: renamed from: f */
    void m43998f(C7972c c7972c) {
        if (!this.f51144g) {
            this.f51144g = true;
            f51138a.execute(this.f51141d);
        }
        this.f51142e.add(c7972c);
    }
}
