package p580l;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import p580l.p581f0.C7962c;
import p590m.C8037c;
import p590m.C8040f;
import p590m.InterfaceC8038d;

/* JADX INFO: renamed from: l.v */
/* JADX INFO: loaded from: classes.dex */
public final class C8030v extends AbstractC7950a0 {

    /* JADX INFO: renamed from: a */
    public static final C8029u f51218a = C8029u.m44128c("multipart/mixed");

    /* JADX INFO: renamed from: b */
    public static final C8029u f51219b = C8029u.m44128c("multipart/alternative");

    /* JADX INFO: renamed from: c */
    public static final C8029u f51220c = C8029u.m44128c("multipart/digest");

    /* JADX INFO: renamed from: d */
    public static final C8029u f51221d = C8029u.m44128c("multipart/parallel");

    /* JADX INFO: renamed from: e */
    public static final C8029u f51222e = C8029u.m44128c("multipart/form-data");

    /* JADX INFO: renamed from: f */
    private static final byte[] f51223f = {58, 32};

    /* JADX INFO: renamed from: g */
    private static final byte[] f51224g = {13, 10};

    /* JADX INFO: renamed from: h */
    private static final byte[] f51225h = {45, 45};

    /* JADX INFO: renamed from: i */
    private final C8040f f51226i;

    /* JADX INFO: renamed from: j */
    private final C8029u f51227j;

    /* JADX INFO: renamed from: k */
    private final C8029u f51228k;

    /* JADX INFO: renamed from: l */
    private final List<b> f51229l;

    /* JADX INFO: renamed from: m */
    private long f51230m = -1;

    /* JADX INFO: renamed from: l.v$a */
    public static final class a {

        /* JADX INFO: renamed from: a */
        private final C8040f f51231a;

        /* JADX INFO: renamed from: b */
        private C8029u f51232b;

        /* JADX INFO: renamed from: c */
        private final List<b> f51233c;

        public a() {
            this(UUID.randomUUID().toString());
        }

        public a(String str) {
            this.f51232b = C8030v.f51218a;
            this.f51233c = new ArrayList();
            this.f51231a = C8040f.m44278r(str);
        }

        /* JADX INFO: renamed from: a */
        public a m44134a(String str, String str2) {
            return m44136c(b.m44140b(str, str2));
        }

        /* JADX INFO: renamed from: b */
        public a m44135b(String str, @Nullable String str2, AbstractC7950a0 abstractC7950a0) {
            return m44136c(b.m44141c(str, str2, abstractC7950a0));
        }

        /* JADX INFO: renamed from: c */
        public a m44136c(b bVar) {
            if (bVar == null) {
                throw new NullPointerException("part == null");
            }
            this.f51233c.add(bVar);
            return this;
        }

        /* JADX INFO: renamed from: d */
        public C8030v m44137d() {
            if (this.f51233c.isEmpty()) {
                throw new IllegalStateException("Multipart body must have at least one part.");
            }
            return new C8030v(this.f51231a, this.f51232b, this.f51233c);
        }

        /* JADX INFO: renamed from: e */
        public a m44138e(C8029u c8029u) {
            if (c8029u == null) {
                throw new NullPointerException("type == null");
            }
            if (c8029u.m44131d().equals("multipart")) {
                this.f51232b = c8029u;
                return this;
            }
            throw new IllegalArgumentException("multipart != " + c8029u);
        }
    }

    /* JADX INFO: renamed from: l.v$b */
    public static final class b {

        /* JADX INFO: renamed from: a */
        @Nullable
        final C8026r f51234a;

        /* JADX INFO: renamed from: b */
        final AbstractC7950a0 f51235b;

        private b(@Nullable C8026r c8026r, AbstractC7950a0 abstractC7950a0) {
            this.f51234a = c8026r;
            this.f51235b = abstractC7950a0;
        }

        /* JADX INFO: renamed from: a */
        public static b m44139a(@Nullable C8026r c8026r, AbstractC7950a0 abstractC7950a0) {
            if (abstractC7950a0 == null) {
                throw new NullPointerException("body == null");
            }
            if (c8026r != null && c8026r.m44064a("Content-Type") != null) {
                throw new IllegalArgumentException("Unexpected header: Content-Type");
            }
            if (c8026r == null || c8026r.m44064a("Content-Length") == null) {
                return new b(c8026r, abstractC7950a0);
            }
            throw new IllegalArgumentException("Unexpected header: Content-Length");
        }

        /* JADX INFO: renamed from: b */
        public static b m44140b(String str, String str2) {
            return m44141c(str, null, AbstractC7950a0.m43469d(null, str2));
        }

        /* JADX INFO: renamed from: c */
        public static b m44141c(String str, @Nullable String str2, AbstractC7950a0 abstractC7950a0) {
            if (str == null) {
                throw new NullPointerException("name == null");
            }
            StringBuilder sb = new StringBuilder("form-data; name=");
            C8030v.m44132h(sb, str);
            if (str2 != null) {
                sb.append("; filename=");
                C8030v.m44132h(sb, str2);
            }
            return m44139a(C8026r.m44063e("Content-Disposition", sb.toString()), abstractC7950a0);
        }
    }

    C8030v(C8040f c8040f, C8029u c8029u, List<b> list) {
        this.f51226i = c8040f;
        this.f51227j = c8029u;
        this.f51228k = C8029u.m44128c(c8029u + "; boundary=" + c8040f.mo44281A1());
        this.f51229l = C7962c.m43595q(list);
    }

    /* JADX INFO: renamed from: h */
    static StringBuilder m44132h(StringBuilder sb, String str) {
        String str2;
        sb.append('\"');
        int length = str.length();
        for (int i2 = 0; i2 < length; i2++) {
            char cCharAt = str.charAt(i2);
            if (cCharAt == '\n') {
                str2 = "%0A";
            } else if (cCharAt != '\r') {
                if (cCharAt != '\"') {
                    sb.append(cCharAt);
                } else {
                    str2 = "%22";
                }
            } else {
                str2 = "%0D";
            }
            sb.append(str2);
        }
        sb.append('\"');
        return sb;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: i */
    private long m44133i(@Nullable InterfaceC8038d interfaceC8038d, boolean z) {
        C8037c c8037c;
        if (z) {
            interfaceC8038d = new C8037c();
            c8037c = interfaceC8038d;
        } else {
            c8037c = 0;
        }
        int size = this.f51229l.size();
        long j2 = 0;
        for (int i2 = 0; i2 < size; i2++) {
            b bVar = this.f51229l.get(i2);
            C8026r c8026r = bVar.f51234a;
            AbstractC7950a0 abstractC7950a0 = bVar.f51235b;
            interfaceC8038d.mo44235Xa(f51225h);
            interfaceC8038d.mo44253ob(this.f51226i);
            interfaceC8038d.mo44235Xa(f51224g);
            if (c8026r != null) {
                int iM44067f = c8026r.m44067f();
                for (int i3 = 0; i3 < iM44067f; i3++) {
                    interfaceC8038d.mo44234T6(c8026r.m44065c(i3)).mo44235Xa(f51223f).mo44234T6(c8026r.m44068g(i3)).mo44235Xa(f51224g);
                }
            }
            C8029u c8029uMo43473b = abstractC7950a0.mo43473b();
            if (c8029uMo43473b != null) {
                interfaceC8038d.mo44234T6("Content-Type: ").mo44234T6(c8029uMo43473b.toString()).mo44235Xa(f51224g);
            }
            long jMo43472a = abstractC7950a0.mo43472a();
            if (jMo43472a != -1) {
                interfaceC8038d.mo44234T6("Content-Length: ").mo44232Rd(jMo43472a).mo44235Xa(f51224g);
            } else if (z) {
                c8037c.m44238c();
                return -1L;
            }
            byte[] bArr = f51224g;
            interfaceC8038d.mo44235Xa(bArr);
            if (z) {
                j2 += jMo43472a;
            } else {
                abstractC7950a0.mo43474g(interfaceC8038d);
            }
            interfaceC8038d.mo44235Xa(bArr);
        }
        byte[] bArr2 = f51225h;
        interfaceC8038d.mo44235Xa(bArr2);
        interfaceC8038d.mo44253ob(this.f51226i);
        interfaceC8038d.mo44235Xa(bArr2);
        interfaceC8038d.mo44235Xa(f51224g);
        if (!z) {
            return j2;
        }
        long jM44265u = j2 + c8037c.m44265u();
        c8037c.m44238c();
        return jM44265u;
    }

    @Override // p580l.AbstractC7950a0
    /* JADX INFO: renamed from: a */
    public long mo43472a() {
        long j2 = this.f51230m;
        if (j2 != -1) {
            return j2;
        }
        long jM44133i = m44133i(null, true);
        this.f51230m = jM44133i;
        return jM44133i;
    }

    @Override // p580l.AbstractC7950a0
    /* JADX INFO: renamed from: b */
    public C8029u mo43473b() {
        return this.f51228k;
    }

    @Override // p580l.AbstractC7950a0
    /* JADX INFO: renamed from: g */
    public void mo43474g(InterfaceC8038d interfaceC8038d) {
        m44133i(interfaceC8038d, false);
    }
}
