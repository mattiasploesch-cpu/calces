package p580l;

import java.nio.charset.Charset;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.annotation.Nullable;

/* JADX INFO: renamed from: l.u */
/* JADX INFO: loaded from: classes.dex */
public final class C8029u {

    /* JADX INFO: renamed from: a */
    private static final Pattern f51212a = Pattern.compile("([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)/([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)");

    /* JADX INFO: renamed from: b */
    private static final Pattern f51213b = Pattern.compile(";\\s*(?:([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)=(?:([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)|\"([^\"]*)\"))?");

    /* JADX INFO: renamed from: c */
    private final String f51214c;

    /* JADX INFO: renamed from: d */
    private final String f51215d;

    /* JADX INFO: renamed from: e */
    private final String f51216e;

    /* JADX INFO: renamed from: f */
    @Nullable
    private final String f51217f;

    private C8029u(String str, String str2, String str3, @Nullable String str4) {
        this.f51214c = str;
        this.f51215d = str2;
        this.f51216e = str3;
        this.f51217f = str4;
    }

    @Nullable
    /* JADX INFO: renamed from: c */
    public static C8029u m44128c(String str) {
        Matcher matcher = f51212a.matcher(str);
        if (!matcher.lookingAt()) {
            return null;
        }
        String strGroup = matcher.group(1);
        Locale locale = Locale.US;
        String lowerCase = strGroup.toLowerCase(locale);
        String lowerCase2 = matcher.group(2).toLowerCase(locale);
        Matcher matcher2 = f51213b.matcher(str);
        String str2 = null;
        for (int iEnd = matcher.end(); iEnd < str.length(); iEnd = matcher2.end()) {
            matcher2.region(iEnd, str.length());
            if (!matcher2.lookingAt()) {
                return null;
            }
            String strGroup2 = matcher2.group(1);
            if (strGroup2 != null && strGroup2.equalsIgnoreCase("charset")) {
                String strGroup3 = matcher2.group(2);
                if (strGroup3 == null) {
                    strGroup3 = matcher2.group(3);
                } else if (strGroup3.startsWith("'") && strGroup3.endsWith("'") && strGroup3.length() > 2) {
                    strGroup3 = strGroup3.substring(1, strGroup3.length() - 1);
                }
                if (str2 != null && !strGroup3.equalsIgnoreCase(str2)) {
                    return null;
                }
                str2 = strGroup3;
            }
        }
        return new C8029u(str, lowerCase, lowerCase2, str2);
    }

    @Nullable
    /* JADX INFO: renamed from: a */
    public Charset m44129a() {
        return m44130b(null);
    }

    @Nullable
    /* JADX INFO: renamed from: b */
    public Charset m44130b(@Nullable Charset charset) {
        try {
            String str = this.f51217f;
            return str != null ? Charset.forName(str) : charset;
        } catch (IllegalArgumentException unused) {
            return charset;
        }
    }

    /* JADX INFO: renamed from: d */
    public String m44131d() {
        return this.f51215d;
    }

    public boolean equals(@Nullable Object obj) {
        return (obj instanceof C8029u) && ((C8029u) obj).f51214c.equals(this.f51214c);
    }

    public int hashCode() {
        return this.f51214c.hashCode();
    }

    public String toString() {
        return this.f51214c;
    }
}
