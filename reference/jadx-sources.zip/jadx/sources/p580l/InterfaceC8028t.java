package p580l;

/* JADX INFO: renamed from: l.t */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC8028t {

    /* JADX INFO: renamed from: l.t$a */
    public interface a {
        /* JADX INFO: renamed from: a */
        int mo43738a();

        /* JADX INFO: renamed from: b */
        int mo43739b();

        /* JADX INFO: renamed from: c */
        C7952b0 mo43740c(C8034z c8034z);

        /* JADX INFO: renamed from: d */
        int mo43741d();

        /* JADX INFO: renamed from: e */
        C8034z mo43742e();
    }

    /* JADX INFO: renamed from: a */
    C7952b0 mo43612a(a aVar);
}
