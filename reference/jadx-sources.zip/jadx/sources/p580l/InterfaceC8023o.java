package p580l;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: renamed from: l.o */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC8023o {

    /* JADX INFO: renamed from: a */
    public static final InterfaceC8023o f51179a = new a();

    /* JADX INFO: renamed from: l.o$a */
    final class a implements InterfaceC8023o {
        a() {
        }

        @Override // p580l.InterfaceC8023o
        /* JADX INFO: renamed from: a */
        public List<InetAddress> mo44033a(String str) throws UnknownHostException {
            if (str == null) {
                throw new UnknownHostException("hostname == null");
            }
            try {
                return Arrays.asList(InetAddress.getAllByName(str));
            } catch (NullPointerException e2) {
                UnknownHostException unknownHostException = new UnknownHostException("Broken system behaviour for dns lookup of " + str);
                unknownHostException.initCause(e2);
                throw unknownHostException;
            }
        }
    }

    /* JADX INFO: renamed from: a */
    List<InetAddress> mo44033a(String str);
}
