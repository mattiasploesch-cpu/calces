package p580l;

import javax.annotation.Nullable;

/* JADX INFO: renamed from: l.b */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7951b {

    /* JADX INFO: renamed from: a */
    public static final InterfaceC7951b f50523a = new a();

    /* JADX INFO: renamed from: l.b$a */
    /* JADX INFO: loaded from: classes2.dex */
    final class a implements InterfaceC7951b {
        a() {
        }

        @Override // p580l.InterfaceC7951b
        /* JADX INFO: renamed from: a */
        public C8034z mo43475a(C7956d0 c7956d0, C7952b0 c7952b0) {
            return null;
        }
    }

    @Nullable
    /* JADX INFO: renamed from: a */
    C8034z mo43475a(C7956d0 c7956d0, C7952b0 c7952b0);
}
