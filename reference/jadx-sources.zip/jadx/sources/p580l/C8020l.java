package p580l;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.annotation.Nullable;
import okhttp3.internal.publicsuffix.PublicSuffixDatabase;
import p580l.p581f0.C7962c;
import p580l.p581f0.p584g.C7980d;

/* JADX INFO: renamed from: l.l */
/* JADX INFO: loaded from: classes.dex */
public final class C8020l {

    /* JADX INFO: renamed from: a */
    private static final Pattern f51158a = Pattern.compile("(\\d{2,4})[^\\d]*");

    /* JADX INFO: renamed from: b */
    private static final Pattern f51159b = Pattern.compile("(?i)(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec).*");

    /* JADX INFO: renamed from: c */
    private static final Pattern f51160c = Pattern.compile("(\\d{1,2})[^\\d]*");

    /* JADX INFO: renamed from: d */
    private static final Pattern f51161d = Pattern.compile("(\\d{1,2}):(\\d{1,2}):(\\d{1,2})[^\\d]*");

    /* JADX INFO: renamed from: e */
    private final String f51162e;

    /* JADX INFO: renamed from: f */
    private final String f51163f;

    /* JADX INFO: renamed from: g */
    private final long f51164g;

    /* JADX INFO: renamed from: h */
    private final String f51165h;

    /* JADX INFO: renamed from: i */
    private final String f51166i;

    /* JADX INFO: renamed from: j */
    private final boolean f51167j;

    /* JADX INFO: renamed from: k */
    private final boolean f51168k;

    /* JADX INFO: renamed from: l */
    private final boolean f51169l;

    /* JADX INFO: renamed from: m */
    private final boolean f51170m;

    private C8020l(String str, String str2, long j2, String str3, String str4, boolean z, boolean z2, boolean z3, boolean z4) {
        this.f51162e = str;
        this.f51163f = str2;
        this.f51164g = j2;
        this.f51165h = str3;
        this.f51166i = str4;
        this.f51167j = z;
        this.f51168k = z2;
        this.f51170m = z3;
        this.f51169l = z4;
    }

    /* JADX INFO: renamed from: a */
    private static int m44012a(String str, int i2, int i3, boolean z) {
        while (i2 < i3) {
            char cCharAt = str.charAt(i2);
            if (((cCharAt < ' ' && cCharAt != '\t') || cCharAt >= 127 || (cCharAt >= '0' && cCharAt <= '9') || ((cCharAt >= 'a' && cCharAt <= 'z') || ((cCharAt >= 'A' && cCharAt <= 'Z') || cCharAt == ':'))) == (!z)) {
                return i2;
            }
            i2++;
        }
        return i3;
    }

    /* JADX INFO: renamed from: b */
    private static boolean m44013b(String str, String str2) {
        if (str.equals(str2)) {
            return true;
        }
        return str.endsWith(str2) && str.charAt((str.length() - str2.length()) - 1) == '.' && !C7962c.m43578D(str);
    }

    /* JADX WARN: Code duplicated, block: B:43:0x00c0 A[PHI: r0
      0x00c0: PHI (r0v15 long) = (r0v2 long), (r0v5 long) binds: [B:42:0x00be, B:53:0x00e1] A[DONT_GENERATE, DONT_INLINE]] */
    @Nullable
    /* JADX INFO: renamed from: d */
    static C8020l m44014d(long j2, C8027s c8027s, String str) {
        long j3;
        C8020l c8020l;
        String str2;
        String strSubstring;
        int length = str.length();
        char c2 = ';';
        int iM43589k = C7962c.m43589k(str, 0, length, ';');
        char c3 = '=';
        int iM43589k2 = C7962c.m43589k(str, 0, iM43589k, '=');
        if (iM43589k2 == iM43589k) {
            return null;
        }
        String strM43577C = C7962c.m43577C(str, 0, iM43589k2);
        if (strM43577C.isEmpty() || C7962c.m43598t(strM43577C) != -1) {
            return null;
        }
        String strM43577C2 = C7962c.m43577C(str, iM43589k2 + 1, iM43589k);
        if (C7962c.m43598t(strM43577C2) != -1) {
            return null;
        }
        int i2 = iM43589k + 1;
        String str3 = null;
        String strM44017g = null;
        long jM44019i = -1;
        long jM44018h = 253402300799999L;
        boolean z = false;
        boolean z2 = false;
        boolean z3 = true;
        boolean z4 = false;
        while (i2 < length) {
            int iM43589k3 = C7962c.m43589k(str, i2, length, c2);
            int iM43589k4 = C7962c.m43589k(str, i2, iM43589k3, c3);
            String strM43577C3 = C7962c.m43577C(str, i2, iM43589k4);
            String strM43577C4 = iM43589k4 < iM43589k3 ? C7962c.m43577C(str, iM43589k4 + 1, iM43589k3) : "";
            if (strM43577C3.equalsIgnoreCase("expires")) {
                try {
                    jM44018h = m44018h(strM43577C4, 0, strM43577C4.length());
                    z4 = true;
                } catch (NumberFormatException | IllegalArgumentException unused) {
                }
            } else if (strM43577C3.equalsIgnoreCase("max-age")) {
                jM44019i = m44019i(strM43577C4);
                z4 = true;
            } else if (strM43577C3.equalsIgnoreCase("domain")) {
                strM44017g = m44017g(strM43577C4);
                z3 = false;
            } else if (strM43577C3.equalsIgnoreCase("path")) {
                str3 = strM43577C4;
            } else if (strM43577C3.equalsIgnoreCase("secure")) {
                z = true;
            } else if (strM43577C3.equalsIgnoreCase("httponly")) {
                z2 = true;
            }
            i2 = iM43589k3 + 1;
            c2 = ';';
            c3 = '=';
        }
        long j4 = Long.MIN_VALUE;
        if (jM44019i == Long.MIN_VALUE) {
            j3 = j4;
        } else if (jM44019i != -1) {
            j4 = j2 + (jM44019i <= 9223372036854775L ? jM44019i * 1000 : Long.MAX_VALUE);
            if (j4 < j2 || j4 > 253402300799999L) {
                j3 = 253402300799999L;
            } else {
                j3 = j4;
            }
        } else {
            j3 = jM44018h;
        }
        String strM44102l = c8027s.m44102l();
        if (strM44017g == null) {
            str2 = strM44102l;
            c8020l = null;
        } else {
            if (!m44013b(strM44102l, strM44017g)) {
                return null;
            }
            c8020l = null;
            str2 = strM44017g;
        }
        if (strM44102l.length() != str2.length() && PublicSuffixDatabase.m56386c().m56389d(str2) == null) {
            return c8020l;
        }
        if (str3 == null || !str3.startsWith("/")) {
            String strM44098g = c8027s.m44098g();
            int iLastIndexOf = strM44098g.lastIndexOf(47);
            strSubstring = iLastIndexOf != 0 ? strM44098g.substring(0, iLastIndexOf) : "/";
        } else {
            strSubstring = str3;
        }
        return new C8020l(strM43577C, strM43577C2, j3, str2, strSubstring, z, z2, z3, z4);
    }

    @Nullable
    /* JADX INFO: renamed from: e */
    public static C8020l m44015e(C8027s c8027s, String str) {
        return m44014d(System.currentTimeMillis(), c8027s, str);
    }

    /* JADX INFO: renamed from: f */
    public static List<C8020l> m44016f(C8027s c8027s, C8026r c8026r) {
        List<String> listM44069h = c8026r.m44069h("Set-Cookie");
        int size = listM44069h.size();
        ArrayList arrayList = null;
        for (int i2 = 0; i2 < size; i2++) {
            C8020l c8020lM44015e = m44015e(c8027s, listM44069h.get(i2));
            if (c8020lM44015e != null) {
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                arrayList.add(c8020lM44015e);
            }
        }
        return arrayList != null ? Collections.unmodifiableList(arrayList) : Collections.emptyList();
    }

    /* JADX INFO: renamed from: g */
    private static String m44017g(String str) {
        if (str.endsWith(".")) {
            throw new IllegalArgumentException();
        }
        if (str.startsWith(".")) {
            str = str.substring(1);
        }
        String strM43580b = C7962c.m43580b(str);
        if (strM43580b != null) {
            return strM43580b;
        }
        throw new IllegalArgumentException();
    }

    /* JADX WARN: Code duplicated, block: B:18:0x0081  */
    /* JADX INFO: renamed from: h */
    private static long m44018h(String str, int i2, int i3) {
        int iM44012a = m44012a(str, i2, i3, false);
        Matcher matcher = f51161d.matcher(str);
        int i4 = -1;
        int i5 = -1;
        int i6 = -1;
        int iIndexOf = -1;
        int i7 = -1;
        int i8 = -1;
        while (iM44012a < i3) {
            int iM44012a2 = m44012a(str, iM44012a + 1, i3, true);
            matcher.region(iM44012a, iM44012a2);
            if (i5 == -1 && matcher.usePattern(f51161d).matches()) {
                i5 = Integer.parseInt(matcher.group(1));
                i7 = Integer.parseInt(matcher.group(2));
                i8 = Integer.parseInt(matcher.group(3));
            } else if (i6 == -1 && matcher.usePattern(f51160c).matches()) {
                i6 = Integer.parseInt(matcher.group(1));
            } else if (iIndexOf == -1) {
                Pattern pattern = f51159b;
                if (matcher.usePattern(pattern).matches()) {
                    iIndexOf = pattern.pattern().indexOf(matcher.group(1).toLowerCase(Locale.US)) / 4;
                } else if (i4 != -1 && matcher.usePattern(f51158a).matches()) {
                    i4 = Integer.parseInt(matcher.group(1));
                }
            } else if (i4 != -1) {
            }
            iM44012a = m44012a(str, iM44012a2 + 1, i3, false);
        }
        if (i4 >= 70 && i4 <= 99) {
            i4 += 1900;
        }
        if (i4 >= 0 && i4 <= 69) {
            i4 += 2000;
        }
        if (i4 < 1601) {
            throw new IllegalArgumentException();
        }
        if (iIndexOf == -1) {
            throw new IllegalArgumentException();
        }
        if (i6 < 1 || i6 > 31) {
            throw new IllegalArgumentException();
        }
        if (i5 < 0 || i5 > 23) {
            throw new IllegalArgumentException();
        }
        if (i7 < 0 || i7 > 59) {
            throw new IllegalArgumentException();
        }
        if (i8 < 0 || i8 > 59) {
            throw new IllegalArgumentException();
        }
        GregorianCalendar gregorianCalendar = new GregorianCalendar(C7962c.f50636p);
        gregorianCalendar.setLenient(false);
        gregorianCalendar.set(1, i4);
        gregorianCalendar.set(2, iIndexOf - 1);
        gregorianCalendar.set(5, i6);
        gregorianCalendar.set(11, i5);
        gregorianCalendar.set(12, i7);
        gregorianCalendar.set(13, i8);
        gregorianCalendar.set(14, 0);
        return gregorianCalendar.getTimeInMillis();
    }

    /* JADX INFO: renamed from: i */
    private static long m44019i(String str) {
        try {
            long j2 = Long.parseLong(str);
            if (j2 <= 0) {
                return Long.MIN_VALUE;
            }
            return j2;
        } catch (NumberFormatException e2) {
            if (str.matches("-?\\d+")) {
                return str.startsWith("-") ? Long.MIN_VALUE : Long.MAX_VALUE;
            }
            throw e2;
        }
    }

    /* JADX INFO: renamed from: c */
    public String m44020c() {
        return this.f51162e;
    }

    public boolean equals(@Nullable Object obj) {
        if (!(obj instanceof C8020l)) {
            return false;
        }
        C8020l c8020l = (C8020l) obj;
        return c8020l.f51162e.equals(this.f51162e) && c8020l.f51163f.equals(this.f51163f) && c8020l.f51165h.equals(this.f51165h) && c8020l.f51166i.equals(this.f51166i) && c8020l.f51164g == this.f51164g && c8020l.f51167j == this.f51167j && c8020l.f51168k == this.f51168k && c8020l.f51169l == this.f51169l && c8020l.f51170m == this.f51170m;
    }

    public int hashCode() {
        int iHashCode = (((((((527 + this.f51162e.hashCode()) * 31) + this.f51163f.hashCode()) * 31) + this.f51165h.hashCode()) * 31) + this.f51166i.hashCode()) * 31;
        long j2 = this.f51164g;
        return ((((((((iHashCode + ((int) (j2 ^ (j2 >>> 32)))) * 31) + (!this.f51167j ? 1 : 0)) * 31) + (!this.f51168k ? 1 : 0)) * 31) + (!this.f51169l ? 1 : 0)) * 31) + (!this.f51170m ? 1 : 0);
    }

    /* JADX INFO: renamed from: j */
    String m44021j(boolean z) {
        String strM43715a;
        StringBuilder sb = new StringBuilder();
        sb.append(this.f51162e);
        sb.append('=');
        sb.append(this.f51163f);
        if (this.f51169l) {
            if (this.f51164g == Long.MIN_VALUE) {
                strM43715a = "; max-age=0";
            } else {
                sb.append("; expires=");
                strM43715a = C7980d.m43715a(new Date(this.f51164g));
            }
            sb.append(strM43715a);
        }
        if (!this.f51170m) {
            sb.append("; domain=");
            if (z) {
                sb.append(".");
            }
            sb.append(this.f51165h);
        }
        sb.append("; path=");
        sb.append(this.f51166i);
        if (this.f51167j) {
            sb.append("; secure");
        }
        if (this.f51168k) {
            sb.append("; httponly");
        }
        return sb.toString();
    }

    /* JADX INFO: renamed from: k */
    public String m44022k() {
        return this.f51163f;
    }

    public String toString() {
        return m44021j(false);
    }
}
