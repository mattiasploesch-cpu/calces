package okhttp3.internal.publicsuffix;

import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.net.IDN;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;
import p580l.p581f0.C7962c;
import p580l.p581f0.p588k.C8009f;
import p590m.C8044j;
import p590m.C8046l;
import p590m.InterfaceC8039e;

/* JADX INFO: loaded from: classes2.dex */
public final class PublicSuffixDatabase {

    /* JADX INFO: renamed from: a */
    private static final byte[] f59887a = {42};

    /* JADX INFO: renamed from: b */
    private static final String[] f59888b = new String[0];

    /* JADX INFO: renamed from: c */
    private static final String[] f59889c = {"*"};

    /* JADX INFO: renamed from: d */
    private static final PublicSuffixDatabase f59890d = new PublicSuffixDatabase();

    /* JADX INFO: renamed from: e */
    private final AtomicBoolean f59891e = new AtomicBoolean(false);

    /* JADX INFO: renamed from: f */
    private final CountDownLatch f59892f = new CountDownLatch(1);

    /* JADX INFO: renamed from: g */
    private byte[] f59893g;

    /* JADX INFO: renamed from: h */
    private byte[] f59894h;

    /* JADX INFO: renamed from: a */
    private static String m56384a(byte[] bArr, byte[][] bArr2, int i2) {
        int i3;
        boolean z;
        int i4;
        int i5;
        int length = bArr.length;
        int i6 = 0;
        while (i6 < length) {
            int i7 = (i6 + length) / 2;
            while (i7 > -1 && bArr[i7] != 10) {
                i7--;
            }
            int i8 = i7 + 1;
            int i9 = 1;
            while (true) {
                i3 = i8 + i9;
                if (bArr[i3] == 10) {
                    break;
                }
                i9++;
            }
            int i10 = i3 - i8;
            int i11 = i2;
            boolean z2 = false;
            int i12 = 0;
            int i13 = 0;
            while (true) {
                if (z2) {
                    i4 = 46;
                    z = false;
                } else {
                    z = z2;
                    i4 = bArr2[i11][i12] & 255;
                }
                i5 = i4 - (bArr[i8 + i13] & 255);
                if (i5 == 0) {
                    i13++;
                    i12++;
                    if (i13 == i10) {
                        break;
                    }
                    if (bArr2[i11].length != i12) {
                        z2 = z;
                    } else {
                        if (i11 == bArr2.length - 1) {
                            break;
                        }
                        i11++;
                        z2 = true;
                        i12 = -1;
                    }
                } else {
                    break;
                }
            }
            if (i5 >= 0) {
                if (i5 <= 0) {
                    int i14 = i10 - i13;
                    int length2 = bArr2[i11].length - i12;
                    while (true) {
                        i11++;
                        if (i11 >= bArr2.length) {
                            break;
                        }
                        length2 += bArr2[i11].length;
                    }
                    if (length2 >= i14) {
                        if (length2 <= i14) {
                            return new String(bArr, i8, i10, C7962c.f50630j);
                        }
                    }
                }
                i6 = i3 + 1;
            }
            length = i8 - 1;
        }
        return null;
    }

    /* JADX INFO: renamed from: b */
    private String[] m56385b(String[] strArr) {
        String str;
        String strM56384a;
        String strM56384a2;
        if (this.f59891e.get() || !this.f59891e.compareAndSet(false, true)) {
            try {
                this.f59892f.await();
            } catch (InterruptedException unused) {
            }
        } else {
            m56388f();
        }
        synchronized (this) {
            if (this.f59893g == null) {
                throw new IllegalStateException("Unable to load publicsuffixes.gz resource from the classpath.");
            }
        }
        int length = strArr.length;
        byte[][] bArr = new byte[length][];
        for (int i2 = 0; i2 < strArr.length; i2++) {
            bArr[i2] = strArr[i2].getBytes(C7962c.f50630j);
        }
        int i3 = 0;
        while (true) {
            str = null;
            if (i3 >= length) {
                strM56384a = null;
                break;
            }
            strM56384a = m56384a(this.f59893g, bArr, i3);
            if (strM56384a != null) {
                break;
            }
            i3++;
        }
        if (length <= 1) {
            strM56384a2 = null;
            break;
        }
        byte[][] bArr2 = (byte[][]) bArr.clone();
        int i4 = 0;
        while (true) {
            if (i4 >= bArr2.length - 1) {
                strM56384a2 = null;
                break;
            }
            bArr2[i4] = f59887a;
            strM56384a2 = m56384a(this.f59893g, bArr2, i4);
            if (strM56384a2 != null) {
                break;
            }
            i4++;
        }
        if (strM56384a2 != null) {
            for (int i5 = 0; i5 < length - 1; i5++) {
                String strM56384a3 = m56384a(this.f59894h, bArr, i5);
                if (strM56384a3 != null) {
                    str = strM56384a3;
                    break;
                }
            }
        }
        if (str != null) {
            return ("!" + str).split("\\.");
        }
        if (strM56384a == null && strM56384a2 == null) {
            return f59889c;
        }
        String[] strArrSplit = strM56384a != null ? strM56384a.split("\\.") : f59888b;
        String[] strArrSplit2 = strM56384a2 != null ? strM56384a2.split("\\.") : f59888b;
        return strArrSplit.length > strArrSplit2.length ? strArrSplit : strArrSplit2;
    }

    /* JADX INFO: renamed from: c */
    public static PublicSuffixDatabase m56386c() {
        return f59890d;
    }

    /* JADX INFO: renamed from: e */
    private void m56387e() {
        InputStream resourceAsStream = PublicSuffixDatabase.class.getResourceAsStream("publicsuffixes.gz");
        if (resourceAsStream == null) {
            return;
        }
        InterfaceC8039e interfaceC8039eM44313d = C8046l.m44313d(new C8044j(C8046l.m44320k(resourceAsStream)));
        try {
            byte[] bArr = new byte[interfaceC8039eM44313d.readInt()];
            interfaceC8039eM44313d.readFully(bArr);
            byte[] bArr2 = new byte[interfaceC8039eM44313d.readInt()];
            interfaceC8039eM44313d.readFully(bArr2);
            C7962c.m43582d(interfaceC8039eM44313d);
            synchronized (this) {
                this.f59893g = bArr;
                this.f59894h = bArr2;
            }
            this.f59892f.countDown();
        } catch (Throwable th) {
            C7962c.m43582d(interfaceC8039eM44313d);
            throw th;
        }
    }

    /* JADX INFO: renamed from: f */
    private void m56388f() {
        boolean z = false;
        while (true) {
            try {
                try {
                    m56387e();
                    break;
                } catch (InterruptedIOException unused) {
                    z = true;
                } catch (IOException e2) {
                    C8009f.m43969i().mo43946p(5, "Failed to read public suffix list", e2);
                    if (z) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                    return;
                }
            } catch (Throwable th) {
                if (z) {
                    Thread.currentThread().interrupt();
                }
                throw th;
            }
        }
        if (z) {
            Thread.currentThread().interrupt();
        }
    }

    /* JADX INFO: renamed from: d */
    public String m56389d(String str) {
        if (str == null) {
            throw new NullPointerException("domain == null");
        }
        String[] strArrSplit = IDN.toUnicode(str).split("\\.");
        String[] strArrM56385b = m56385b(strArrSplit);
        if (strArrSplit.length == strArrM56385b.length && strArrM56385b[0].charAt(0) != '!') {
            return null;
        }
        char cCharAt = strArrM56385b[0].charAt(0);
        int length = strArrSplit.length;
        int length2 = strArrM56385b.length;
        if (cCharAt != '!') {
            length2++;
        }
        StringBuilder sb = new StringBuilder();
        String[] strArrSplit2 = str.split("\\.");
        for (int i2 = length - length2; i2 < strArrSplit2.length; i2++) {
            sb.append(strArrSplit2[i2]);
            sb.append('.');
        }
        sb.deleteCharAt(sb.length() - 1);
        return sb.toString();
    }
}
