package p575k.p576a.p577a.p578a.p579a;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: renamed from: k.a.a.a.a.m */
/* JADX INFO: loaded from: classes2.dex */
public class C7942m implements Cloneable {

    /* JADX INFO: renamed from: u2 */
    private C7948s f50470u2 = null;

    /* JADX INFO: renamed from: v2 */
    private List<C7948s> f50471v2 = new ArrayList();

    /* JADX INFO: renamed from: w2 */
    private List<AbstractC7932c> f50472w2 = new ArrayList();

    /* JADX INFO: renamed from: a */
    protected AbstractC7932c m43418a(AbstractC7932c abstractC7932c) {
        if (!this.f50472w2.contains(abstractC7932c)) {
            if (abstractC7932c.m43358d() >= 0) {
                throw new IllegalArgumentException();
            }
            abstractC7932c.m43361h(this.f50472w2.size());
            this.f50472w2.add(abstractC7932c);
        }
        return abstractC7932c;
    }

    /* JADX INFO: renamed from: b */
    protected C7948s m43419b(C7948s c7948s) {
        if (!this.f50471v2.contains(c7948s)) {
            if (c7948s.getIndex() >= 0) {
                throw new IllegalArgumentException();
            }
            c7948s.m43453g(this.f50471v2.size());
            this.f50471v2.add(c7948s);
        }
        return c7948s;
    }

    /* JADX INFO: renamed from: c */
    public List<AbstractC7932c> m43420c() {
        return this.f50472w2;
    }

    public Object clone() {
        C7942m c7942m = new C7942m();
        for (C7948s c7948s : this.f50471v2) {
            if (c7948s.getIndex() != c7948s.m43447a(c7942m).getIndex()) {
                throw new IllegalArgumentException();
            }
        }
        for (AbstractC7932c abstractC7932c : this.f50472w2) {
            if (abstractC7932c.m43358d() != abstractC7932c.mo43356a(c7942m).m43358d()) {
                throw new IllegalArgumentException();
            }
        }
        C7948s c7948s2 = this.f50470u2;
        if (c7948s2 != null) {
            c7942m.m43424g(c7942m.m43422e(c7948s2.getIndex()));
        }
        return c7942m;
    }

    /* JADX INFO: renamed from: d */
    public C7948s m43421d() {
        return this.f50470u2;
    }

    /* JADX INFO: renamed from: e */
    public C7948s m43422e(int i2) {
        return m43423f().get(i2);
    }

    /* JADX INFO: renamed from: f */
    public List<C7948s> m43423f() {
        return this.f50471v2;
    }

    /* JADX INFO: renamed from: g */
    public void m43424g(C7948s c7948s) {
        this.f50470u2 = c7948s;
        if (c7948s != null) {
            m43419b(c7948s);
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        if (this.f50470u2 != null) {
            sb.append("Objective: ");
            sb.append(this.f50470u2.m43449c());
            sb.append('=');
            sb.append(this.f50470u2.m43448b());
            sb.append('\n');
        }
        for (C7948s c7948s : this.f50471v2) {
            sb.append(c7948s.m43449c());
            sb.append('=');
            sb.append(c7948s.m43448b());
            sb.append('\n');
        }
        Iterator<AbstractC7932c> it = this.f50472w2.iterator();
        while (it.hasNext()) {
            sb.append(it.next().toString());
            sb.append('\n');
        }
        return sb.toString();
    }
}
