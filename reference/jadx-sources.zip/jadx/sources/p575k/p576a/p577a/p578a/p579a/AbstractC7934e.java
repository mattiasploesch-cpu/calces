package p575k.p576a.p577a.p578a.p579a;

import java.util.Iterator;

/* JADX INFO: renamed from: k.a.a.a.a.e */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC7934e implements Cloneable {

    /* JADX INFO: renamed from: u2 */
    int f50455u2 = 0;

    /* JADX INFO: renamed from: a */
    public abstract AbstractC7934e mo43369a(AbstractC7934e abstractC7934e);

    /* JADX INFO: renamed from: b */
    public abstract AbstractC7934e mo43370b(Object obj);

    /* JADX INFO: renamed from: c */
    public abstract Object mo43371c();

    /* JADX INFO: renamed from: d */
    public abstract Iterator<AbstractC7934e> mo43372d();

    /* JADX INFO: renamed from: e */
    public abstract boolean mo43373e(AbstractC7934e abstractC7934e);

    /* JADX INFO: renamed from: f */
    public boolean m43374f() {
        return m43375g() == 0;
    }

    /* JADX INFO: renamed from: g */
    public int m43375g() {
        return this.f50455u2;
    }
}
