package p575k.p576a.p577a.p578a.p579a;

/* JADX INFO: renamed from: k.a.a.a.a.g */
/* JADX INFO: loaded from: classes2.dex */
public class C7936g extends AbstractC7932c {

    /* JADX INFO: renamed from: c */
    private int f50457c;

    /* JADX INFO: renamed from: d */
    private C7948s[] f50458d;

    public C7936g(C7942m c7942m, int i2, C7948s c7948s, C7948s c7948s2, C7948s c7948s3) {
        this(c7942m, i2, new C7948s[]{c7948s, c7948s2, c7948s3});
    }

    private C7936g(C7942m c7942m, int i2, C7948s[] c7948sArr) {
        super(c7942m);
        this.f50457c = i2;
        this.f50458d = c7948sArr;
    }

    /* JADX INFO: renamed from: j */
    private C7938i m43376j(C7938i c7938i, C7938i c7938i2, C7938i c7938i3) {
        int iM43378l;
        int iM43377k;
        if (!c7938i2.m43394k(0)) {
            c7938i = c7938i.m43395m(0);
            if (c7938i.m43374f()) {
                return C7938i.f50461v2;
            }
        }
        if (c7938i3.m43394k(0)) {
            return c7938i;
        }
        if (c7938i3.m43397p() < 0 || c7938i3.m43398q() > 0) {
            int[] iArr = {c7938i2.m43398q() / c7938i3.m43398q(), c7938i2.m43397p() / c7938i3.m43398q(), c7938i2.m43398q() / c7938i3.m43397p(), c7938i2.m43397p() / c7938i3.m43397p()};
            iM43378l = m43378l(iArr);
            iM43377k = m43377k(iArr);
        } else {
            int[] iArr2 = {c7938i2.m43398q() / c7938i3.m43398q(), c7938i2.m43397p() / c7938i3.m43398q(), c7938i2.m43398q() / c7938i3.m43397p(), c7938i2.m43397p() / c7938i3.m43397p(), c7938i2.m43398q(), c7938i2.m43397p(), -c7938i2.m43398q(), -c7938i2.m43397p()};
            iM43378l = m43378l(iArr2);
            iM43377k = m43377k(iArr2);
        }
        return c7938i.m43393j(iM43378l, iM43377k);
    }

    /* JADX INFO: renamed from: k */
    private int m43377k(int[] iArr) {
        int iMax = iArr[0];
        for (int i2 = 1; i2 < iArr.length; i2++) {
            iMax = Math.max(iMax, iArr[i2]);
        }
        return iMax;
    }

    /* JADX INFO: renamed from: l */
    private int m43378l(int[] iArr) {
        int iMin = iArr[0];
        for (int i2 = 1; i2 < iArr.length; i2++) {
            iMin = Math.min(iMin, iArr[i2]);
        }
        return iMin;
    }

    /* JADX INFO: renamed from: m */
    private C7938i m43379m(C7938i c7938i, C7938i c7938i2, C7938i c7938i3) {
        if (!c7938i2.m43394k(0) && !c7938i3.m43394k(0)) {
            c7938i = c7938i.m43395m(0);
            if (c7938i.m43374f()) {
                return C7938i.f50461v2;
            }
        }
        int[] iArr = {m43384r(((long) c7938i2.m43398q()) * ((long) c7938i3.m43398q())), m43384r(((long) c7938i2.m43398q()) * ((long) c7938i3.m43397p())), m43384r(((long) c7938i2.m43397p()) * ((long) c7938i3.m43398q())), m43384r(((long) c7938i2.m43397p()) * ((long) c7938i3.m43397p()))};
        return c7938i.m43393j(m43378l(iArr), m43377k(iArr));
    }

    /* JADX INFO: renamed from: n */
    private boolean m43380n(C7948s c7948s, C7948s c7948s2, C7948s c7948s3, C7947r c7947r) {
        C7938i c7938i = (C7938i) c7948s.m43448b();
        C7938i c7938i2 = (C7938i) c7948s2.m43448b();
        C7938i c7938i3 = (C7938i) c7948s3.m43448b();
        if (c7938i2.m43375g() == 1 && c7938i3.m43375g() == 1) {
            int iM43401w = c7938i2.m43401w() + c7938i3.m43401w();
            if (!c7938i.m43394k(iM43401w)) {
                return false;
            }
            if (c7938i.m43375g() > 1) {
                c7948s.m43455i(new C7938i(iM43401w), c7947r);
            }
            return true;
        }
        if (c7938i.m43375g() == 1 && c7938i3.m43375g() == 1) {
            int iM43401w2 = c7938i.m43401w() - c7938i3.m43401w();
            if (!c7938i2.m43394k(iM43401w2)) {
                return false;
            }
            if (c7938i2.m43375g() > 1) {
                c7948s2.m43455i(new C7938i(iM43401w2), c7947r);
            }
            return true;
        }
        if (c7938i.m43375g() == 1 && c7938i2.m43375g() == 1) {
            int iM43401w3 = c7938i.m43401w() - c7938i2.m43401w();
            if (!c7938i3.m43394k(iM43401w3)) {
                return false;
            }
            if (c7938i3.m43375g() > 1) {
                c7948s3.m43455i(new C7938i(iM43401w3), c7947r);
            }
            return true;
        }
        C7938i c7938iM43393j = c7938i.m43393j(c7938i2.m43398q() + c7938i3.m43398q(), c7938i2.m43397p() + c7938i3.m43397p());
        if (c7938iM43393j.m43374f()) {
            return false;
        }
        c7948s.m43455i(c7938iM43393j, c7947r);
        C7938i c7938iM43393j2 = c7938i2.m43393j(c7938iM43393j.m43398q() - c7938i3.m43397p(), c7938iM43393j.m43397p() - c7938i3.m43398q());
        if (c7938iM43393j2.m43374f()) {
            return false;
        }
        c7948s2.m43455i(c7938iM43393j2, c7947r);
        C7938i c7938iM43393j3 = c7938i3.m43393j(c7938iM43393j.m43398q() - c7938iM43393j2.m43397p(), c7938iM43393j.m43397p() - c7938iM43393j2.m43398q());
        if (c7938iM43393j3.m43374f()) {
            return false;
        }
        c7948s3.m43455i(c7938iM43393j3, c7947r);
        return true;
    }

    /* JADX INFO: renamed from: o */
    private boolean m43381o(C7948s c7948s, C7948s c7948s2, C7948s c7948s3, C7947r c7947r) {
        C7938i c7938i = (C7938i) c7948s.m43448b();
        C7938i c7938iM43393j = (C7938i) c7948s2.m43448b();
        C7938i c7938iM43393j2 = (C7938i) c7948s3.m43448b();
        if (c7938iM43393j.m43375g() == 1 && c7938iM43393j2.m43375g() == 1) {
            int iMax = Math.max(c7938iM43393j.m43401w(), c7938iM43393j2.m43401w());
            if (!c7938i.m43394k(iMax)) {
                return false;
            }
            if (c7938i.m43375g() > 1) {
                c7948s.m43455i(new C7938i(iMax), c7947r);
            }
            return true;
        }
        if (c7938i.m43375g() == 1) {
            int iM43401w = c7938i.m43401w();
            if (!c7938iM43393j.m43394k(iM43401w) && !c7938iM43393j2.m43394k(iM43401w)) {
                return false;
            }
            if (c7938iM43393j.m43397p() > iM43401w) {
                c7938iM43393j.m43393j(-1073741823, iM43401w);
                if (c7938iM43393j.m43374f()) {
                    return false;
                }
                c7948s2.m43455i(c7938iM43393j, c7947r);
            }
            if (c7938iM43393j2.m43397p() > iM43401w) {
                c7938iM43393j2.m43393j(-1073741823, iM43401w);
                if (c7938iM43393j2.m43374f()) {
                    return false;
                }
                c7948s3.m43455i(c7938iM43393j2, c7947r);
            }
            return true;
        }
        C7938i c7938iM43393j3 = c7938i.m43393j(Math.max(c7938iM43393j.m43398q(), c7938iM43393j2.m43398q()), Math.max(c7938iM43393j.m43397p(), c7938iM43393j2.m43397p()));
        if (c7938iM43393j3.m43374f()) {
            return false;
        }
        c7948s.m43455i(c7938iM43393j3, c7947r);
        if (c7938iM43393j.m43397p() > c7938iM43393j3.m43397p()) {
            c7938iM43393j = c7938iM43393j.m43393j(-1073741823, c7938iM43393j3.m43397p());
        }
        if (c7938iM43393j2.m43397p() > c7938iM43393j3.m43397p()) {
            c7938iM43393j2 = c7938iM43393j2.m43393j(-1073741823, c7938iM43393j3.m43397p());
        }
        if (c7938iM43393j.m43397p() < c7938iM43393j3.m43398q()) {
            c7938iM43393j3 = (C7938i) c7938iM43393j3.mo43369a(c7938iM43393j2);
            c7938iM43393j2 = c7938iM43393j3;
        }
        if (c7938iM43393j2.m43397p() < c7938iM43393j3.m43398q()) {
            c7938iM43393j = (C7938i) c7938iM43393j3.mo43369a(c7938iM43393j);
            c7938iM43393j3 = c7938iM43393j;
        }
        if (c7938iM43393j3.m43374f() || c7938iM43393j.m43374f() || c7938iM43393j2.m43374f()) {
            return false;
        }
        c7948s.m43455i(c7938iM43393j3, c7947r);
        c7948s2.m43455i(c7938iM43393j, c7947r);
        c7948s3.m43455i(c7938iM43393j2, c7947r);
        return true;
    }

    /* JADX INFO: renamed from: p */
    private boolean m43382p(C7948s c7948s, C7948s c7948s2, C7948s c7948s3, C7947r c7947r) {
        C7938i c7938i = (C7938i) c7948s.m43448b();
        C7938i c7938iM43393j = (C7938i) c7948s2.m43448b();
        C7938i c7938iM43393j2 = (C7938i) c7948s3.m43448b();
        if (c7938iM43393j.m43375g() == 1 && c7938iM43393j2.m43375g() == 1) {
            int iMin = Math.min(c7938iM43393j.m43401w(), c7938iM43393j2.m43401w());
            if (!c7938i.m43394k(iMin)) {
                return false;
            }
            if (c7938i.m43375g() > 1) {
                c7948s.m43455i(new C7938i(iMin), c7947r);
            }
            return true;
        }
        if (c7938i.m43375g() == 1) {
            int iM43401w = c7938i.m43401w();
            if (!c7938iM43393j.m43394k(iM43401w) && !c7938iM43393j2.m43394k(iM43401w)) {
                return false;
            }
            if (c7938iM43393j.m43398q() < iM43401w) {
                c7938iM43393j.m43393j(iM43401w, 1073741823);
                if (c7938iM43393j.m43374f()) {
                    return false;
                }
                c7948s2.m43455i(c7938iM43393j, c7947r);
            }
            if (c7938iM43393j2.m43398q() < iM43401w) {
                c7938iM43393j2.m43393j(iM43401w, 1073741823);
                if (c7938iM43393j2.m43374f()) {
                    return false;
                }
                c7948s3.m43455i(c7938iM43393j2, c7947r);
            }
            return true;
        }
        C7938i c7938iM43393j3 = c7938i.m43393j(Math.min(c7938iM43393j.m43398q(), c7938iM43393j2.m43398q()), Math.min(c7938iM43393j.m43397p(), c7938iM43393j2.m43397p()));
        if (c7938iM43393j3.m43374f()) {
            return false;
        }
        c7948s.m43455i(c7938iM43393j3, c7947r);
        if (c7938iM43393j.m43398q() < c7938iM43393j3.m43398q()) {
            c7938iM43393j = c7938iM43393j.m43393j(c7938iM43393j3.m43398q(), 1073741823);
        }
        if (c7938iM43393j2.m43398q() < c7938iM43393j3.m43398q()) {
            c7938iM43393j2 = c7938iM43393j2.m43393j(c7938iM43393j3.m43398q(), 1073741823);
        }
        if (c7938iM43393j.m43398q() > c7938iM43393j3.m43397p()) {
            c7938iM43393j3 = (C7938i) c7938iM43393j3.mo43369a(c7938iM43393j2);
            c7938iM43393j2 = c7938iM43393j3;
        }
        if (c7938iM43393j2.m43398q() > c7938iM43393j3.m43397p()) {
            c7938iM43393j = (C7938i) c7938iM43393j3.mo43369a(c7938iM43393j);
            c7938iM43393j3 = c7938iM43393j;
        }
        if (c7938iM43393j3.m43374f() || c7938iM43393j.m43374f() || c7938iM43393j2.m43374f()) {
            return false;
        }
        c7948s.m43455i(c7938iM43393j3, c7947r);
        c7948s2.m43455i(c7938iM43393j, c7947r);
        c7948s3.m43455i(c7938iM43393j2, c7947r);
        return true;
    }

    /* JADX INFO: renamed from: q */
    private boolean m43383q(C7948s c7948s, C7948s c7948s2, C7948s c7948s3, C7947r c7947r) {
        C7938i c7938i = (C7938i) c7948s.m43448b();
        C7938i c7938i2 = (C7938i) c7948s2.m43448b();
        C7938i c7938i3 = (C7938i) c7948s3.m43448b();
        if (c7938i2.m43375g() == 1 && c7938i3.m43375g() == 1) {
            int iM43384r = m43384r(((long) c7938i2.m43401w()) * ((long) c7938i3.m43401w()));
            if (!c7938i.m43394k(iM43384r)) {
                return false;
            }
            if (c7938i.m43375g() > 1) {
                c7948s.m43455i(new C7938i(iM43384r), c7947r);
            }
            return true;
        }
        if (c7938i.m43375g() == 1 && c7938i3.m43375g() == 1) {
            int iM43401w = c7938i.m43401w();
            int iM43401w2 = c7938i3.m43401w();
            if (iM43401w2 == 0) {
                return iM43401w == 0;
            }
            if (iM43401w % iM43401w2 != 0) {
                return false;
            }
            int i2 = iM43401w / iM43401w2;
            if (!c7938i2.m43394k(i2)) {
                return false;
            }
            if (c7938i2.m43375g() > 1) {
                c7948s2.m43455i(new C7938i(i2), c7947r);
            }
            return true;
        }
        if (c7938i.m43375g() == 1 && c7938i2.m43375g() == 1) {
            int iM43401w3 = c7938i.m43401w();
            int iM43401w4 = c7938i2.m43401w();
            if (iM43401w4 == 0) {
                return iM43401w3 == 0;
            }
            if (iM43401w3 % iM43401w4 != 0) {
                return false;
            }
            int i3 = iM43401w3 / iM43401w4;
            if (!c7938i3.m43394k(i3)) {
                return false;
            }
            if (c7938i3.m43375g() > 1) {
                c7948s3.m43455i(new C7938i(i3), c7947r);
            }
            return true;
        }
        C7938i c7938iM43379m = m43379m(c7938i, c7938i2, c7938i3);
        if (c7938iM43379m.m43374f()) {
            return false;
        }
        C7938i c7938iM43376j = m43376j(c7938i2, c7938iM43379m, c7938i3);
        if (c7938iM43376j.m43374f()) {
            return false;
        }
        C7938i c7938iM43376j2 = m43376j(c7938i3, c7938iM43379m, c7938iM43376j);
        if (c7938iM43376j2.m43374f()) {
            return false;
        }
        if (c7938iM43379m != c7948s.m43448b()) {
            c7948s.m43455i(c7938iM43379m, c7947r);
        }
        if (c7938iM43376j != c7948s2.m43448b()) {
            c7948s2.m43455i(c7938iM43376j, c7947r);
        }
        if (c7938iM43376j2 != c7948s3.m43448b()) {
            c7948s3.m43455i(c7938iM43376j2, c7947r);
        }
        return true;
    }

    /* JADX INFO: renamed from: r */
    private int m43384r(long j2) {
        return (int) Math.max(-1073741823L, Math.min(1073741823L, j2));
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7932c
    /* JADX INFO: renamed from: a */
    public AbstractC7932c mo43356a(C7942m c7942m) {
        return new C7936g(c7942m, this.f50457c, AbstractC7932c.m43353b(this.f50458d, c7942m));
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7932c
    /* JADX INFO: renamed from: e */
    public boolean mo43359e() {
        return AbstractC7932c.m43354f(this.f50458d);
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7932c
    /* JADX INFO: renamed from: g */
    public boolean mo43360g(C7947r c7947r) {
        int i2 = this.f50457c;
        if (i2 == 0) {
            C7948s[] c7948sArr = this.f50458d;
            return m43380n(c7948sArr[0], c7948sArr[1], c7948sArr[2], c7947r);
        }
        if (i2 == 1) {
            C7948s[] c7948sArr2 = this.f50458d;
            return m43380n(c7948sArr2[1], c7948sArr2[0], c7948sArr2[2], c7947r);
        }
        if (i2 == 2) {
            C7948s[] c7948sArr3 = this.f50458d;
            return m43383q(c7948sArr3[0], c7948sArr3[1], c7948sArr3[2], c7947r);
        }
        if (i2 == 6) {
            C7948s[] c7948sArr4 = this.f50458d;
            return m43381o(c7948sArr4[0], c7948sArr4[1], c7948sArr4[2], c7947r);
        }
        if (i2 != 7) {
            return false;
        }
        C7948s[] c7948sArr5 = this.f50458d;
        return m43382p(c7948sArr5[0], c7948sArr5[1], c7948sArr5[2], c7947r);
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7932c
    public String toString() {
        String str;
        StringBuilder sb = new StringBuilder("IntArith(");
        int i2 = this.f50457c;
        if (i2 == 0) {
            str = "ADD";
        } else if (i2 == 1) {
            str = "SUBTRACT";
        } else if (i2 == 2) {
            str = "MULTIPLY";
        } else {
            if (i2 != 6) {
                if (i2 == 7) {
                    str = "MIN";
                }
                sb.append(',');
                sb.append(AbstractC7932c.m43355i(this.f50458d));
                sb.append(')');
                return sb.toString();
            }
            str = "MAX";
        }
        sb.append(str);
        sb.append(',');
        sb.append(AbstractC7932c.m43355i(this.f50458d));
        sb.append(')');
        return sb.toString();
    }
}
