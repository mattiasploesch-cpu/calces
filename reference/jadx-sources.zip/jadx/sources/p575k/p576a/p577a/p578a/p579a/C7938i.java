package p575k.p576a.p577a.p578a.p579a;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;

/* JADX INFO: renamed from: k.a.a.a.a.i */
/* JADX INFO: loaded from: classes2.dex */
public class C7938i extends AbstractC7934e {

    /* JADX INFO: renamed from: v2 */
    public static C7938i f50461v2 = new C7938i();

    /* JADX INFO: renamed from: w2 */
    public static C7938i f50462w2 = new C7938i(-1073741823, 1073741823);

    /* JADX INFO: renamed from: x2 */
    private ArrayList<int[]> f50463x2;

    /* JADX INFO: renamed from: y2 */
    private int f50464y2;

    /* JADX INFO: renamed from: z2 */
    private int f50465z2;

    /* JADX INFO: renamed from: k.a.a.a.a.i$a */
    class a implements Iterator<AbstractC7934e> {

        /* JADX INFO: renamed from: u2 */
        private int f50466u2;

        a() {
            this.f50466u2 = C7938i.this.f50464y2;
        }

        @Override // java.util.Iterator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public AbstractC7934e next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            C7938i c7938i = new C7938i(this.f50466u2);
            this.f50466u2++;
            return c7938i;
        }

        @Override // java.util.Iterator
        public boolean hasNext() {
            if (C7938i.this.f50455u2 == 0) {
                return false;
            }
            while (this.f50466u2 <= C7938i.this.f50465z2) {
                if (C7938i.this.m43394k(this.f50466u2)) {
                    return true;
                }
                this.f50466u2++;
            }
            return false;
        }

        @Override // java.util.Iterator
        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    public C7938i() {
        this.f50463x2 = new ArrayList<>();
    }

    public C7938i(int i2) {
        this(i2, i2);
    }

    public C7938i(int i2, int i3) {
        this.f50463x2 = new ArrayList<>();
        int iMax = Math.max(i2, -1073741823);
        int iMin = Math.min(i3, 1073741823);
        if (iMax <= iMin) {
            this.f50463x2.add(new int[]{iMax, iMin});
            this.f50455u2 = (iMin - iMax) + 1;
            this.f50464y2 = iMax;
            this.f50465z2 = iMin;
        }
    }

    /* JADX INFO: renamed from: o */
    private int m43389o(int i2) {
        if (i2 >= this.f50464y2 && this.f50465z2 >= i2) {
            for (int i3 = 0; i3 < this.f50463x2.size(); i3++) {
                try {
                    int[] iArr = this.f50463x2.get(i3);
                    if (i2 < iArr[0]) {
                        return -1;
                    }
                    if (i2 <= iArr[1]) {
                        return i3;
                    }
                } catch (IndexOutOfBoundsException unused) {
                }
            }
        }
        return -1;
    }

    /* JADX INFO: renamed from: t */
    private String m43390t(int i2) {
        if (i2 == -1073741823) {
            return "min";
        }
        return i2 == 1073741823 ? "max" : Integer.toString(i2);
    }

    /* JADX INFO: renamed from: u */
    private void m43391u() {
        if (this.f50455u2 > 0) {
            try {
                this.f50464y2 = this.f50463x2.get(0)[0];
                ArrayList<int[]> arrayList = this.f50463x2;
                this.f50465z2 = arrayList.get(arrayList.size() - 1)[1];
            } catch (IndexOutOfBoundsException unused) {
            }
        }
    }

    /* JADX INFO: renamed from: v */
    private void m43392v() {
        this.f50455u2 = 0;
        try {
            for (int[] iArr : this.f50463x2) {
                this.f50455u2 += (iArr[1] - iArr[0]) + 1;
            }
        } catch (IndexOutOfBoundsException unused) {
        }
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7934e
    /* JADX INFO: renamed from: a */
    public AbstractC7934e mo43369a(AbstractC7934e abstractC7934e) {
        if (!(abstractC7934e instanceof C7938i)) {
            return f50461v2;
        }
        C7938i c7938i = new C7938i();
        C7938i c7938i2 = (C7938i) abstractC7934e;
        int i2 = 0;
        int i3 = 0;
        while (i2 < this.f50463x2.size() && i3 < c7938i2.f50463x2.size()) {
            try {
                int[] iArr = this.f50463x2.get(i2);
                int i4 = iArr[0];
                int i5 = iArr[1];
                int[] iArr2 = c7938i2.f50463x2.get(i3);
                int i6 = iArr2[0];
                int i7 = iArr2[1];
                if (i5 < i6) {
                    i2++;
                } else {
                    if (i7 >= i4) {
                        c7938i.f50463x2.add(new int[]{Math.max(i4, i6), Math.min(i5, i7)});
                        if (i5 <= i7) {
                            i2++;
                        }
                        if (i7 <= i5) {
                        }
                    }
                    i3++;
                }
            } catch (IndexOutOfBoundsException unused) {
            }
        }
        c7938i.m43392v();
        c7938i.m43391u();
        return c7938i.m43374f() ? f50461v2 : c7938i;
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7934e
    /* JADX INFO: renamed from: b */
    public AbstractC7934e mo43370b(Object obj) {
        return !(obj instanceof Number) ? this : m43395m(((Number) obj).intValue());
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7934e
    /* JADX INFO: renamed from: c */
    public Object mo43371c() {
        return new Integer(m43401w());
    }

    public Object clone() {
        C7938i c7938i = new C7938i();
        try {
            Iterator<int[]> it = this.f50463x2.iterator();
            while (it.hasNext()) {
                c7938i.f50463x2.add((int[]) it.next().clone());
            }
        } catch (IndexOutOfBoundsException unused) {
        }
        c7938i.f50455u2 = this.f50455u2;
        c7938i.f50464y2 = this.f50464y2;
        c7938i.f50465z2 = this.f50465z2;
        return c7938i;
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7934e
    /* JADX INFO: renamed from: d */
    public Iterator<AbstractC7934e> mo43372d() {
        return new a();
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7934e
    /* JADX INFO: renamed from: e */
    public boolean mo43373e(AbstractC7934e abstractC7934e) {
        if (this == abstractC7934e) {
            return true;
        }
        if (!(abstractC7934e instanceof C7938i)) {
            return false;
        }
        C7938i c7938i = (C7938i) abstractC7934e;
        if (this.f50463x2.size() != c7938i.f50463x2.size()) {
            return false;
        }
        for (int i2 = 0; i2 < this.f50463x2.size(); i2++) {
            try {
                int[] iArr = this.f50463x2.get(i2);
                int[] iArr2 = c7938i.f50463x2.get(i2);
                if (iArr[0] != iArr2[0] || iArr[1] != iArr2[1]) {
                    return false;
                }
            } catch (IndexOutOfBoundsException unused) {
            }
        }
        return true;
    }

    /* JADX INFO: renamed from: j */
    public C7938i m43393j(int i2, int i3) {
        C7938i c7938iM43396n = -1073741823 < i2 ? m43396n(-1073741823, i2 - 1) : this;
        return i3 < 1073741823 ? c7938iM43396n.m43396n(i3 + 1, 1073741823) : c7938iM43396n;
    }

    /* JADX INFO: renamed from: k */
    public boolean m43394k(int i2) {
        return m43389o(i2) >= 0;
    }

    /* JADX INFO: renamed from: m */
    public C7938i m43395m(int i2) {
        if (!m43394k(i2)) {
            return this;
        }
        C7938i c7938i = (C7938i) clone();
        c7938i.m43400s(i2);
        return c7938i;
    }

    /* JADX INFO: renamed from: n */
    public C7938i m43396n(int i2, int i3) {
        if (this.f50455u2 == 0 || i2 > i3 || i3 < this.f50464y2 || this.f50465z2 < i2) {
            return this;
        }
        if (i2 == i3) {
            return m43395m(i2);
        }
        C7938i c7938i = new C7938i();
        for (int i4 = 0; i4 < this.f50463x2.size(); i4++) {
            try {
                int[] iArr = this.f50463x2.get(i4);
                int iMax = Math.max(i2, iArr[0]);
                int iMin = Math.min(i3, iArr[1]);
                if (iMax <= iMin) {
                    if (iArr[0] < iMax) {
                        c7938i.f50463x2.add(new int[]{iArr[0], iMax - 1});
                    }
                    if (iMin < iArr[1]) {
                        c7938i.f50463x2.add(new int[]{iMin + 1, iArr[1]});
                    }
                } else {
                    c7938i.f50463x2.add(new int[]{iArr[0], iArr[1]});
                }
            } catch (IndexOutOfBoundsException unused) {
            }
        }
        c7938i.m43392v();
        c7938i.m43391u();
        return c7938i;
    }

    /* JADX INFO: renamed from: p */
    public int m43397p() {
        if (this.f50455u2 != 0) {
            return this.f50465z2;
        }
        throw new NoSuchElementException();
    }

    /* JADX INFO: renamed from: q */
    public int m43398q() {
        if (this.f50455u2 != 0) {
            return this.f50464y2;
        }
        throw new NoSuchElementException();
    }

    /* JADX INFO: renamed from: r */
    public int m43399r() {
        double dRandom = Math.random();
        double d2 = this.f50455u2;
        Double.isNaN(d2);
        int i2 = (int) (dRandom * d2);
        for (int[] iArr : this.f50463x2) {
            int i3 = (iArr[1] - iArr[0]) + 1;
            if (i2 < i3) {
                return iArr[0] + i2;
            }
            i2 -= i3;
        }
        return m43398q();
    }

    /* JADX INFO: renamed from: s */
    public void m43400s(int i2) {
        int iM43389o = m43389o(i2);
        if (iM43389o < 0) {
            return;
        }
        try {
            int[] iArr = this.f50463x2.get(iM43389o);
            int i3 = iArr[0];
            int i4 = iArr[1];
            if (i2 == i3 && i2 == i4) {
                this.f50463x2.remove(iM43389o);
            } else if (i2 == i3) {
                iArr[0] = i3 + 1;
            } else if (i2 == i4) {
                iArr[1] = i4 - 1;
            } else {
                iArr[0] = i2 + 1;
                this.f50463x2.add(iM43389o, new int[]{i3, i2 - 1});
            }
            this.f50455u2--;
            m43391u();
        } catch (IndexOutOfBoundsException unused) {
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        try {
            String str = "";
            for (int[] iArr : this.f50463x2) {
                sb.append(str);
                sb.append(m43390t(iArr[0]));
                if (iArr[0] < iArr[1]) {
                    sb.append("..");
                    sb.append(m43390t(iArr[1]));
                }
                str = ",";
            }
        } catch (IndexOutOfBoundsException unused) {
        }
        if (m43375g() == 1) {
            return sb.toString();
        }
        sb.insert(0, '{').append('}');
        return sb.toString();
    }

    /* JADX INFO: renamed from: w */
    public int m43401w() {
        if (this.f50455u2 == 1) {
            return this.f50464y2;
        }
        throw new NoSuchElementException();
    }
}
