package p575k.p576a.p577a.p578a.p579a;

import java.util.Stack;

/* JADX INFO: renamed from: k.a.a.a.a.r */
/* JADX INFO: loaded from: classes2.dex */
public class C7947r {

    /* JADX INFO: renamed from: a */
    private Stack<Object[]> f50498a = new Stack<>();

    /* JADX INFO: renamed from: a */
    public void m43444a(C7948s c7948s) {
        this.f50498a.push(new Object[]{c7948s, c7948s.m43448b()});
    }

    /* JADX INFO: renamed from: b */
    public int m43445b() {
        return this.f50498a.size();
    }

    /* JADX INFO: renamed from: c */
    public void m43446c(int i2) {
        for (int size = this.f50498a.size(); size > i2; size--) {
            Object[] objArrPop = this.f50498a.pop();
            ((C7948s) objArrPop[0]).m43452f((AbstractC7934e) objArrPop[1]);
        }
    }
}
