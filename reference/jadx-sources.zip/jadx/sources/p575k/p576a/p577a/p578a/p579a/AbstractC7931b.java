package p575k.p576a.p577a.p578a.p579a;

/* JADX INFO: renamed from: k.a.a.a.a.b */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC7931b {

    /* JADX INFO: renamed from: a */
    protected int f50450a = -1;
}
