package p575k.p576a.p577a.p578a.p579a;

/* JADX INFO: renamed from: k.a.a.a.a.c */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC7932c {

    /* JADX INFO: renamed from: a */
    private C7942m f50451a;

    /* JADX INFO: renamed from: b */
    private int f50452b = -1;

    protected AbstractC7932c(C7942m c7942m) {
        this.f50451a = c7942m;
        c7942m.m43418a(this);
    }

    /* JADX INFO: renamed from: b */
    protected static C7948s[] m43353b(C7948s[] c7948sArr, C7942m c7942m) {
        C7948s[] c7948sArr2 = new C7948s[c7948sArr.length];
        for (int i2 = 0; i2 < c7948sArr.length; i2++) {
            c7948sArr2[i2] = c7942m.m43422e(c7948sArr[i2].getIndex());
        }
        return c7948sArr2;
    }

    /* JADX INFO: renamed from: f */
    protected static boolean m43354f(C7948s[] c7948sArr) {
        for (C7948s c7948s : c7948sArr) {
            if (c7948s.m43451e()) {
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: renamed from: i */
    protected static String m43355i(C7948s[] c7948sArr) {
        StringBuilder sb = new StringBuilder("{");
        if (c7948sArr != null) {
            int length = c7948sArr.length;
            int i2 = 0;
            String str = "";
            while (i2 < length) {
                C7948s c7948s = c7948sArr[i2];
                sb.append(str);
                sb.append(c7948s);
                i2++;
                str = ",";
            }
        }
        sb.append('}');
        return sb.toString();
    }

    /* JADX INFO: renamed from: a */
    public abstract AbstractC7932c mo43356a(C7942m c7942m);

    /* JADX INFO: renamed from: c */
    protected AbstractC7931b m43357c() {
        return null;
    }

    /* JADX INFO: renamed from: d */
    public int m43358d() {
        return this.f50452b;
    }

    /* JADX INFO: renamed from: e */
    public abstract boolean mo43359e();

    /* JADX INFO: renamed from: g */
    public abstract boolean mo43360g(C7947r c7947r);

    /* JADX INFO: renamed from: h */
    public void m43361h(int i2) {
        this.f50452b = i2;
    }

    public abstract String toString();
}
