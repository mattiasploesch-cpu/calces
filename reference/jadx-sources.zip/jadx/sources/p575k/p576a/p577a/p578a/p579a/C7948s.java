package p575k.p576a.p577a.p578a.p579a;

import p356f.p372c.p375g.p381e.p421f.p432l.C7068f;

/* JADX INFO: renamed from: k.a.a.a.a.s */
/* JADX INFO: loaded from: classes2.dex */
public class C7948s implements Cloneable {

    /* JADX INFO: renamed from: u2 */
    private static int f50499u2 = 1;

    /* JADX INFO: renamed from: v2 */
    private C7942m f50501v2;

    /* JADX INFO: renamed from: x2 */
    private AbstractC7934e f50503x2;

    /* JADX INFO: renamed from: y2 */
    private String f50504y2;

    /* JADX INFO: renamed from: w2 */
    private int f50502w2 = -1;

    /* JADX INFO: renamed from: z2 */
    private boolean f50505z2 = true;

    /* JADX INFO: renamed from: A2 */
    private boolean f50500A2 = false;

    public C7948s(C7942m c7942m, AbstractC7934e abstractC7934e, String str) {
        this.f50501v2 = c7942m;
        this.f50503x2 = abstractC7934e;
        if (str == null) {
            StringBuilder sb = new StringBuilder();
            sb.append(C7068f.f46032P2);
            int i2 = f50499u2;
            f50499u2 = i2 + 1;
            sb.append(i2);
            this.f50504y2 = sb.toString();
        } else {
            this.f50504y2 = str;
        }
        this.f50501v2.m43419b(this);
    }

    /* JADX INFO: renamed from: a */
    protected C7948s m43447a(C7942m c7942m) {
        return new C7948s(c7942m, this.f50503x2, this.f50504y2);
    }

    /* JADX INFO: renamed from: b */
    public AbstractC7934e m43448b() {
        return this.f50503x2;
    }

    /* JADX INFO: renamed from: c */
    public String m43449c() {
        return this.f50504y2;
    }

    /* JADX INFO: renamed from: d */
    public C7942m m43450d() {
        return this.f50501v2;
    }

    /* JADX INFO: renamed from: e */
    public boolean m43451e() {
        return this.f50505z2;
    }

    /* JADX INFO: renamed from: f */
    public void m43452f(AbstractC7934e abstractC7934e) {
        AbstractC7934e abstractC7934e2 = this.f50503x2;
        if (abstractC7934e2 == null || !abstractC7934e2.mo43373e(abstractC7934e)) {
            this.f50503x2 = abstractC7934e;
            this.f50505z2 = true;
        }
    }

    /* JADX INFO: renamed from: g */
    public void m43453g(int i2) {
        this.f50502w2 = i2;
    }

    public int getIndex() {
        return this.f50502w2;
    }

    /* JADX INFO: renamed from: h */
    public void m43454h(boolean z) {
        this.f50505z2 = z;
    }

    /* JADX INFO: renamed from: i */
    public void m43455i(AbstractC7934e abstractC7934e, C7947r c7947r) {
        AbstractC7934e abstractC7934e2 = this.f50503x2;
        if (abstractC7934e2 == null || !abstractC7934e2.mo43373e(abstractC7934e)) {
            c7947r.m43444a(this);
            this.f50503x2 = abstractC7934e;
            this.f50505z2 = true;
            if (this.f50500A2) {
                System.out.println(this + " = " + this.f50503x2);
            }
        }
    }

    public String toString() {
        return this.f50504y2;
    }
}
