package p575k.p576a.p577a.p578a.p579a;

/* JADX INFO: renamed from: k.a.a.a.a.j */
/* JADX INFO: loaded from: classes2.dex */
public class C7939j extends AbstractC7932c {

    /* JADX INFO: renamed from: c */
    private int f50468c;

    /* JADX INFO: renamed from: d */
    private C7948s[] f50469d;

    public C7939j(C7942m c7942m, int i2, C7948s c7948s, C7948s c7948s2) {
        this(c7942m, i2, new C7948s[]{c7948s, c7948s2});
    }

    private C7939j(C7942m c7942m, int i2, C7948s[] c7948sArr) {
        super(c7942m);
        this.f50468c = i2;
        this.f50469d = c7948sArr;
    }

    /* JADX INFO: renamed from: j */
    private boolean m43403j(C7948s c7948s, C7948s c7948s2, C7947r c7947r) {
        int iMax;
        int iM43398q;
        C7938i c7938i = (C7938i) c7948s.m43448b();
        C7938i c7938i2 = (C7938i) c7948s2.m43448b();
        if (c7938i2.m43375g() == 1) {
            int iAbs = Math.abs(c7938i2.m43401w());
            if (!c7938i.m43394k(iAbs)) {
                return false;
            }
            if (c7938i.m43375g() > 1) {
                c7948s.m43455i(new C7938i(iAbs), c7947r);
            }
            return true;
        }
        if (c7938i.m43375g() != 1) {
            if (c7938i2.m43398q() >= 0) {
                iM43398q = c7938i2.m43398q();
                iMax = c7938i2.m43397p();
            } else if (c7938i2.m43397p() <= 0) {
                iM43398q = -c7938i2.m43397p();
                iMax = -c7938i2.m43398q();
            } else {
                iMax = Math.max(-c7938i2.m43398q(), c7938i2.m43397p());
                iM43398q = 0;
            }
            C7938i c7938iM43393j = c7938i.m43393j(iM43398q, iMax);
            if (c7938iM43393j.m43374f()) {
                return false;
            }
            c7948s.m43455i(c7938iM43393j, c7947r);
            int iM43398q2 = c7938iM43393j.m43398q();
            int iM43397p = c7938iM43393j.m43397p();
            C7938i c7938iM43393j2 = c7938i2.m43393j(-iM43397p, iM43397p);
            if (c7938iM43393j2.m43374f()) {
                return false;
            }
            if (iM43398q2 > 0) {
                c7938iM43393j2 = c7938iM43393j2.m43396n((-iM43398q2) + 1, iM43398q2 - 1);
            }
            c7948s2.m43455i(c7938iM43393j2, c7947r);
            return true;
        }
        int iM43401w = c7938i.m43401w();
        if (iM43401w < 0) {
            return false;
        }
        boolean zM43394k = c7938i2.m43394k(iM43401w);
        if (iM43401w == 0) {
            if (!zM43394k) {
                return false;
            }
            if (c7938i2.m43375g() > 1) {
                c7948s2.m43455i(new C7938i(iM43401w), c7947r);
            }
            return true;
        }
        if (zM43394k && c7938i2.m43394k(-iM43401w)) {
            if (c7938i2.m43375g() > 2) {
                int iAbs2 = Math.abs(iM43401w);
                int i2 = -iAbs2;
                c7948s2.m43455i(new C7938i(i2, iAbs2).m43396n(i2 + 1, iAbs2 - 1), c7947r);
            }
            return true;
        }
        if (c7938i2.m43394k(iM43401w)) {
            if (c7938i2.m43375g() > 1) {
                c7948s2.m43455i(new C7938i(iM43401w), c7947r);
            }
            return true;
        }
        int i3 = -iM43401w;
        if (!c7938i2.m43394k(i3)) {
            return false;
        }
        if (c7938i2.m43375g() > 1) {
            c7948s2.m43455i(new C7938i(i3), c7947r);
        }
        return true;
    }

    /* JADX INFO: renamed from: k */
    private boolean m43404k(C7948s c7948s, C7948s c7948s2, C7947r c7947r) {
        C7938i c7938i = (C7938i) c7948s.m43448b();
        C7938i c7938i2 = (C7938i) c7948s2.m43448b();
        if (c7938i2.m43375g() == 1) {
            int i2 = -c7938i2.m43401w();
            if (!c7938i.m43394k(i2)) {
                return false;
            }
            if (c7938i.m43375g() > 1) {
                c7948s.m43455i(new C7938i(i2), c7947r);
            }
            return true;
        }
        if (c7938i.m43375g() == 1) {
            int i3 = -c7938i.m43401w();
            if (!c7938i2.m43394k(i3)) {
                return false;
            }
            if (c7938i2.m43375g() > 1) {
                c7948s2.m43455i(new C7938i(i3), c7947r);
            }
            return true;
        }
        C7938i c7938iM43393j = c7938i.m43393j(-c7938i2.m43397p(), -c7938i2.m43398q());
        if (c7938iM43393j.m43374f()) {
            return false;
        }
        c7948s.m43455i(c7938iM43393j, c7947r);
        C7938i c7938iM43393j2 = c7938i2.m43393j(-c7938iM43393j.m43397p(), -c7938iM43393j.m43398q());
        if (c7938iM43393j2.m43374f()) {
            return false;
        }
        c7948s2.m43455i(c7938iM43393j2, c7947r);
        return true;
    }

    /* JADX INFO: renamed from: l */
    private boolean m43405l(C7948s c7948s, C7948s c7948s2, C7947r c7947r) {
        C7938i c7938iM43393j = (C7938i) c7948s.m43448b();
        C7938i c7938iM43393j2 = (C7938i) c7948s2.m43448b();
        int i2 = -1;
        if (c7938iM43393j2.m43375g() == 1) {
            if (c7938iM43393j2.m43401w() >= 0) {
                i2 = c7938iM43393j2.m43401w() > 0 ? 1 : 0;
            }
            if (!c7938iM43393j.m43394k(i2)) {
                return false;
            }
            if (c7938iM43393j.m43375g() > 1) {
                c7948s.m43455i(new C7938i(i2), c7947r);
            }
            return true;
        }
        if (c7938iM43393j.m43375g() == 1) {
            int iM43401w = c7938iM43393j.m43401w();
            if (iM43401w < 0) {
                if (c7938iM43393j2.m43397p() >= 0) {
                    AbstractC7934e abstractC7934eM43393j = c7938iM43393j2.m43393j(-1073741823, -1);
                    if (abstractC7934eM43393j.m43374f()) {
                        return false;
                    }
                    c7948s2.m43455i(abstractC7934eM43393j, c7947r);
                }
                return true;
            }
            if (iM43401w == 0) {
                if (!c7938iM43393j2.m43394k(0)) {
                    return false;
                }
                if (c7938iM43393j2.m43375g() > 1) {
                    c7948s2.m43455i(new C7938i(0), c7947r);
                }
                return true;
            }
            if (c7938iM43393j2.m43398q() <= 0) {
                AbstractC7934e abstractC7934eM43393j2 = c7938iM43393j2.m43393j(1, 1073741823);
                if (abstractC7934eM43393j2.m43374f()) {
                    return false;
                }
                c7948s2.m43455i(abstractC7934eM43393j2, c7947r);
            }
            return true;
        }
        if (-1 > c7938iM43393j.m43398q() || c7938iM43393j.m43397p() > 1) {
            c7938iM43393j = c7938iM43393j.m43393j(-1, 1);
        }
        if (c7938iM43393j2.m43398q() >= 0) {
            c7938iM43393j = c7938iM43393j.m43395m(-1);
        }
        if (!c7938iM43393j2.m43394k(0)) {
            c7938iM43393j = c7938iM43393j.m43395m(0);
        }
        if (c7938iM43393j2.m43397p() <= 0) {
            c7938iM43393j = c7938iM43393j.m43395m(1);
        }
        if (!c7938iM43393j.m43394k(-1) && c7938iM43393j2.m43398q() < 0) {
            c7938iM43393j2 = c7938iM43393j2.m43393j(0, 1073741823);
        }
        if (!c7938iM43393j.m43394k(0)) {
            c7938iM43393j2 = c7938iM43393j2.m43395m(0);
        }
        if (!c7938iM43393j.m43394k(1) && c7938iM43393j2.m43397p() > 0) {
            c7938iM43393j2 = c7938iM43393j2.m43393j(-1073741823, 0);
        }
        if (c7938iM43393j.m43374f() || c7938iM43393j2.m43374f()) {
            return false;
        }
        c7948s.m43455i(c7938iM43393j, c7947r);
        c7948s2.m43455i(c7938iM43393j2, c7947r);
        return true;
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7932c
    /* JADX INFO: renamed from: a */
    public AbstractC7932c mo43356a(C7942m c7942m) {
        return new C7939j(c7942m, this.f50468c, AbstractC7932c.m43353b(this.f50469d, c7942m));
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7932c
    /* JADX INFO: renamed from: e */
    public boolean mo43359e() {
        return AbstractC7932c.m43354f(this.f50469d);
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7932c
    /* JADX INFO: renamed from: g */
    public boolean mo43360g(C7947r c7947r) {
        int i2 = this.f50468c;
        if (i2 == 0) {
            C7948s[] c7948sArr = this.f50469d;
            return m43404k(c7948sArr[0], c7948sArr[1], c7947r);
        }
        if (i2 == 1) {
            C7948s[] c7948sArr2 = this.f50469d;
            return m43403j(c7948sArr2[0], c7948sArr2[1], c7947r);
        }
        if (i2 != 2) {
            return false;
        }
        C7948s[] c7948sArr3 = this.f50469d;
        return m43405l(c7948sArr3[0], c7948sArr3[1], c7947r);
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7932c
    public String toString() {
        String str;
        int i2 = this.f50468c;
        if (i2 == 0) {
            str = "NEGATE";
        } else if (i2 != 1) {
            str = i2 != 2 ? "" : "SIGN";
        } else {
            str = "ABS";
        }
        return "IntFunc(" + str + "," + AbstractC7932c.m43355i(this.f50469d) + ")";
    }
}
