package p575k.p576a.p577a.p578a.p579a;

/* JADX INFO: renamed from: k.a.a.a.a.h */
/* JADX INFO: loaded from: classes2.dex */
public class C7937h extends AbstractC7932c {

    /* JADX INFO: renamed from: c */
    private int f50459c;

    /* JADX INFO: renamed from: d */
    private C7948s[] f50460d;

    public C7937h(C7942m c7942m, int i2, C7948s c7948s, C7948s c7948s2) {
        this(c7942m, i2, new C7948s[]{c7948s, c7948s2});
    }

    private C7937h(C7942m c7942m, int i2, C7948s[] c7948sArr) {
        super(c7942m);
        this.f50459c = i2;
        this.f50460d = c7948sArr;
    }

    /* JADX INFO: renamed from: j */
    private boolean m43385j(C7948s c7948s, C7948s c7948s2, C7947r c7947r) {
        C7938i c7938i = (C7938i) c7948s.m43448b();
        C7938i c7938i2 = (C7938i) c7948s2.m43448b();
        C7938i c7938iM43393j = c7938i.m43393j(-1073741823, c7938i2.m43397p());
        if (c7938iM43393j.m43374f()) {
            return false;
        }
        c7948s.m43455i(c7938iM43393j, c7947r);
        C7938i c7938iM43393j2 = c7938i2.m43393j(c7938iM43393j.m43398q(), 1073741823);
        if (c7938iM43393j2.m43374f()) {
            return false;
        }
        c7948s2.m43455i(c7938iM43393j2, c7947r);
        return true;
    }

    /* JADX INFO: renamed from: k */
    private boolean m43386k(C7948s c7948s, C7948s c7948s2, C7947r c7947r) {
        C7938i c7938i = (C7938i) c7948s.m43448b();
        C7938i c7938i2 = (C7938i) c7948s2.m43448b();
        C7938i c7938iM43393j = c7938i.m43393j(-1073741823, c7938i2.m43397p() - 1);
        if (c7938iM43393j.m43374f()) {
            return false;
        }
        c7948s.m43455i(c7938iM43393j, c7947r);
        C7938i c7938iM43393j2 = c7938i2.m43393j(c7938iM43393j.m43398q() + 1, 1073741823);
        if (c7938iM43393j2.m43374f()) {
            return false;
        }
        c7948s2.m43455i(c7938iM43393j2, c7947r);
        return true;
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7932c
    /* JADX INFO: renamed from: a */
    public AbstractC7932c mo43356a(C7942m c7942m) {
        return new C7937h(c7942m, this.f50459c, AbstractC7932c.m43353b(this.f50460d, c7942m));
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7932c
    /* JADX INFO: renamed from: e */
    public boolean mo43359e() {
        return AbstractC7932c.m43354f(this.f50460d);
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7932c
    /* JADX INFO: renamed from: g */
    public boolean mo43360g(C7947r c7947r) {
        int i2 = this.f50459c;
        if (i2 == 0) {
            C7948s[] c7948sArr = this.f50460d;
            return m43385j(c7948sArr[0], c7948sArr[1], c7947r);
        }
        if (i2 == 1) {
            C7948s[] c7948sArr2 = this.f50460d;
            return m43386k(c7948sArr2[0], c7948sArr2[1], c7947r);
        }
        if (i2 == 2) {
            C7948s[] c7948sArr3 = this.f50460d;
            return m43385j(c7948sArr3[1], c7948sArr3[0], c7947r);
        }
        if (i2 != 3) {
            return false;
        }
        C7948s[] c7948sArr4 = this.f50460d;
        return m43386k(c7948sArr4[1], c7948sArr4[0], c7947r);
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7932c
    public String toString() {
        String str;
        StringBuilder sb = new StringBuilder("IntComparison(");
        int i2 = this.f50459c;
        if (i2 == 0) {
            str = "LE";
        } else if (i2 == 1) {
            str = "LT";
        } else {
            if (i2 != 2) {
                if (i2 == 3) {
                    str = "GT";
                }
                sb.append(',');
                sb.append(AbstractC7932c.m43355i(this.f50460d));
                sb.append(')');
                return sb.toString();
            }
            str = "GE";
        }
        sb.append(str);
        sb.append(',');
        sb.append(AbstractC7932c.m43355i(this.f50460d));
        sb.append(')');
        return sb.toString();
    }
}
