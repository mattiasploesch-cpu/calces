package p575k.p576a.p577a.p578a.p579a;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: renamed from: k.a.a.a.a.d */
/* JADX INFO: loaded from: classes2.dex */
public class C7933d extends AbstractRunnableC7946q {

    /* JADX INFO: renamed from: L2 */
    private int f50453L2;

    /* JADX INFO: renamed from: M2 */
    private C7947r f50454M2;

    public C7933d(C7942m c7942m) {
        this(c7942m, -1, null);
    }

    public C7933d(C7942m c7942m, int i2, String str) {
        super(c7942m, i2, str);
        this.f50453L2 = 0;
        this.f50454M2 = new C7947r();
    }

    /* JADX INFO: renamed from: r */
    private List<AbstractC7932c> m43362r() {
        ArrayList arrayList = new ArrayList();
        for (AbstractC7932c abstractC7932c : this.f50491w2.m43420c()) {
            if (abstractC7932c.mo43359e()) {
                arrayList.add(abstractC7932c);
            }
        }
        Iterator<C7948s> it = this.f50491w2.m43423f().iterator();
        while (it.hasNext()) {
            it.next().m43454h(false);
        }
        return arrayList;
    }

    /* JADX INFO: renamed from: p */
    protected C7948s m43363p() {
        int iM43398q;
        C7948s c7948s = null;
        int i2 = Integer.MAX_VALUE;
        for (C7948s c7948s2 : this.f50491w2.m43423f()) {
            AbstractC7934e abstractC7934eM43448b = c7948s2.m43448b();
            if ((abstractC7934eM43448b instanceof C7938i) && abstractC7934eM43448b.m43375g() > 1 && (iM43398q = ((C7938i) abstractC7934eM43448b).m43398q()) < i2) {
                c7948s = c7948s2;
                i2 = iM43398q;
            }
        }
        return c7948s;
    }

    /* JADX INFO: renamed from: q */
    protected C7948s m43364q() {
        C7948s c7948s = null;
        int i2 = Integer.MAX_VALUE;
        for (C7948s c7948s2 : this.f50491w2.m43423f()) {
            int iM43375g = c7948s2.m43448b().m43375g();
            if (1 < iM43375g && iM43375g <= i2) {
                c7948s = c7948s2;
                i2 = iM43375g;
            }
        }
        return c7948s;
    }

    @Override // java.lang.Runnable
    public void run() {
        m43429a();
        this.f50454M2 = new C7947r();
        m43367u(0);
        this.f50454M2.m43446c(0);
        m43430b();
    }

    /* JADX INFO: renamed from: s */
    public boolean m43365s() {
        boolean zM43451e;
        for (boolean z = true; !m43432d() && z; z = zM43451e) {
            Iterator<AbstractC7932c> it = m43362r().iterator();
            do {
                zM43451e = false;
                if (!it.hasNext()) {
                    Iterator<C7948s> it2 = this.f50491w2.m43423f().iterator();
                    while (it2.hasNext() && !((zM43451e = zM43451e | it2.next().m43451e()))) {
                    }
                }
            } while (it.next().mo43360g(this.f50454M2));
            return false;
        }
        return true;
    }

    /* JADX INFO: renamed from: t */
    public C7948s m43366t() {
        C7948s c7948sM43368v;
        if (m43434f(1)) {
            c7948sM43368v = m43363p();
        } else {
            c7948sM43368v = m43434f(2) ? m43368v() : null;
        }
        return c7948sM43368v == null ? m43364q() : c7948sM43368v;
    }

    /* JADX INFO: renamed from: u */
    protected void m43367u(int i2) {
        C7938i c7938iM43396n;
        int iM43398q;
        C7948s c7948sM43421d = this.f50491w2.m43421d();
        while (!m43432d()) {
            if (m43434f(1)) {
                if (this.f50481C2 < 1073741823) {
                    c7938iM43396n = ((C7938i) c7948sM43421d.m43448b()).m43396n(this.f50481C2, 1073741823);
                    if (c7938iM43396n.m43374f()) {
                        return;
                    }
                    c7948sM43421d.m43455i(c7938iM43396n, this.f50454M2);
                }
            } else if (m43434f(2) && this.f50481C2 > -1073741823) {
                c7938iM43396n = ((C7938i) c7948sM43421d.m43448b()).m43396n(-1073741823, this.f50481C2);
                if (c7938iM43396n.m43374f()) {
                    return;
                }
                c7948sM43421d.m43455i(c7938iM43396n, this.f50454M2);
            }
            boolean zM43365s = m43365s();
            if (m43432d() || !zM43365s) {
                return;
            }
            C7948s c7948sM43366t = m43366t();
            if (c7948sM43366t == null) {
                this.f50479A2 = new C7944o(this.f50491w2);
                m43440l();
                return;
            }
            if (!(c7948sM43366t.m43448b() instanceof C7938i)) {
                Iterator<AbstractC7934e> itMo43372d = c7948sM43366t.m43448b().mo43372d();
                while (!m43432d() && itMo43372d.hasNext()) {
                    int iM43445b = this.f50454M2.m43445b();
                    c7948sM43366t.m43455i(itMo43372d.next(), this.f50454M2);
                    m43367u(i2 + 1);
                    this.f50454M2.m43446c(iM43445b);
                }
                return;
            }
            C7938i c7938i = (C7938i) c7948sM43366t.m43448b();
            int i3 = this.f50453L2;
            if (i3 == 0) {
                iM43398q = c7938i.m43398q();
                if (!m43432d()) {
                    int iM43445b2 = this.f50454M2.m43445b();
                    c7948sM43366t.m43455i(new C7938i(iM43398q), this.f50454M2);
                    m43367u(i2 + 1);
                    this.f50454M2.m43446c(iM43445b2);
                }
                if (m43432d()) {
                    return;
                }
            } else {
                if (i3 == 1) {
                    Iterator<AbstractC7934e> itMo43372d2 = c7948sM43366t.m43448b().mo43372d();
                    while (!m43432d() && itMo43372d2.hasNext()) {
                        int iM43445b3 = this.f50454M2.m43445b();
                        c7948sM43366t.m43455i(itMo43372d2.next(), this.f50454M2);
                        m43367u(i2 + 1);
                        this.f50454M2.m43446c(iM43445b3);
                    }
                    return;
                }
                if (i3 == 2) {
                    int iM43398q2 = c7938i.m43398q() + 1 == c7938i.m43397p() ? c7938i.m43398q() : (c7938i.m43398q() + c7938i.m43397p()) / 2;
                    if (!m43432d()) {
                        int iM43445b4 = this.f50454M2.m43445b();
                        c7948sM43366t.m43455i(c7938i.m43393j(c7938i.m43398q(), iM43398q2), this.f50454M2);
                        m43367u(i2 + 1);
                        this.f50454M2.m43446c(iM43445b4);
                    }
                    if (m43432d()) {
                        return;
                    }
                    int iM43445b5 = this.f50454M2.m43445b();
                    c7948sM43366t.m43455i(c7938i.m43393j(iM43398q2 + 1, c7938i.m43397p()), this.f50454M2);
                    m43367u(i2 + 1);
                    this.f50454M2.m43446c(iM43445b5);
                    return;
                }
                if (i3 != 3) {
                    return;
                }
                iM43398q = c7938i.m43399r();
                if (!m43432d()) {
                    int iM43445b6 = this.f50454M2.m43445b();
                    c7948sM43366t.m43455i(new C7938i(iM43398q), this.f50454M2);
                    m43367u(i2 + 1);
                    this.f50454M2.m43446c(iM43445b6);
                }
                if (m43432d()) {
                    return;
                }
            }
            c7948sM43366t.m43455i(c7938i.m43395m(iM43398q), this.f50454M2);
        }
    }

    /* JADX INFO: renamed from: v */
    protected C7948s m43368v() {
        int iM43397p;
        C7948s c7948s = null;
        int i2 = Integer.MIN_VALUE;
        for (C7948s c7948s2 : this.f50491w2.m43423f()) {
            AbstractC7934e abstractC7934eM43448b = c7948s2.m43448b();
            if ((abstractC7934eM43448b instanceof C7938i) && abstractC7934eM43448b.m43375g() > 1 && (iM43397p = ((C7938i) abstractC7934eM43448b).m43397p()) > i2) {
                c7948s = c7948s2;
                i2 = iM43397p;
            }
        }
        return c7948s;
    }
}
