package p575k.p576a.p577a.p578a.p579a;

/* JADX INFO: renamed from: k.a.a.a.a.p */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC7945p {
    /* JADX INFO: renamed from: a */
    void mo43428a(AbstractRunnableC7946q abstractRunnableC7946q, C7944o c7944o);
}
