package p575k.p576a.p577a.p578a.p579a;

/* JADX INFO: renamed from: k.a.a.a.a.k */
/* JADX INFO: loaded from: classes2.dex */
public class C7940k extends C7948s {
    public C7940k(C7942m c7942m) {
        this(c7942m, C7938i.f50462w2, null);
    }

    public C7940k(C7942m c7942m, int i2) {
        this(c7942m, new C7938i(i2), null);
    }

    public C7940k(C7942m c7942m, C7938i c7938i, String str) {
        super(c7942m, c7938i, str);
    }

    /* JADX INFO: renamed from: j */
    public C7940k m43406j() {
        C7942m c7942mM43450d = m43450d();
        C7940k c7940k = new C7940k(c7942mM43450d);
        new C7939j(c7942mM43450d, 1, c7940k, this);
        return c7940k;
    }

    /* JADX INFO: renamed from: k */
    public C7940k m43407k(C7940k c7940k) {
        C7942m c7942mM43450d = m43450d();
        C7940k c7940k2 = new C7940k(c7942mM43450d);
        new C7936g(c7942mM43450d, 0, c7940k2, this, c7940k);
        return c7940k2;
    }

    /* JADX INFO: renamed from: m */
    public void m43408m(C7940k c7940k) {
        new C7935f(m43450d(), this, c7940k);
    }

    /* JADX INFO: renamed from: n */
    public void m43409n(C7940k c7940k) {
        new C7937h(m43450d(), 2, this, c7940k);
    }

    /* JADX INFO: renamed from: o */
    public void m43410o(C7940k c7940k) {
        new C7937h(m43450d(), 3, this, c7940k);
    }

    /* JADX INFO: renamed from: p */
    public void m43411p(C7940k c7940k) {
        new C7937h(m43450d(), 0, this, c7940k);
    }

    /* JADX INFO: renamed from: q */
    public void m43412q(C7940k c7940k) {
        new C7937h(m43450d(), 1, this, c7940k);
    }

    /* JADX INFO: renamed from: r */
    public C7940k m43413r(C7940k c7940k) {
        C7942m c7942mM43450d = m43450d();
        C7940k c7940k2 = new C7940k(c7942mM43450d);
        new C7936g(c7942mM43450d, 6, c7940k2, this, c7940k);
        return c7940k2;
    }

    /* JADX INFO: renamed from: s */
    public C7940k m43414s(C7940k c7940k) {
        C7942m c7942mM43450d = m43450d();
        C7940k c7940k2 = new C7940k(c7942mM43450d);
        new C7936g(c7942mM43450d, 7, c7940k2, this, c7940k);
        return c7940k2;
    }

    /* JADX INFO: renamed from: t */
    public C7940k m43415t(C7940k c7940k) {
        C7942m c7942mM43450d = m43450d();
        C7940k c7940k2 = new C7940k(c7942mM43450d);
        new C7936g(c7942mM43450d, 2, c7940k2, this, c7940k);
        return c7940k2;
    }

    /* JADX INFO: renamed from: u */
    public void m43416u(C7940k c7940k) {
        new C7943n(m43450d(), this, c7940k);
    }

    /* JADX INFO: renamed from: v */
    public C7940k m43417v() {
        C7942m c7942mM43450d = m43450d();
        C7940k c7940k = new C7940k(c7942mM43450d);
        new C7939j(c7942mM43450d, 2, c7940k, this);
        return c7940k;
    }
}
