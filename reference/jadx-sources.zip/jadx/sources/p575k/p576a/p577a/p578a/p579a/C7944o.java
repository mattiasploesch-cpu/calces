package p575k.p576a.p577a.p578a.p579a;

import java.util.List;

/* JADX INFO: renamed from: k.a.a.a.a.o */
/* JADX INFO: loaded from: classes2.dex */
public class C7944o {

    /* JADX INFO: renamed from: a */
    private C7942m f50474a;

    /* JADX INFO: renamed from: b */
    private AbstractC7934e f50475b;

    /* JADX INFO: renamed from: c */
    private AbstractC7934e[] f50476c;

    /* JADX INFO: renamed from: d */
    private C7930a f50477d;

    public C7944o(C7942m c7942m) {
        this.f50474a = c7942m;
        this.f50475b = null;
        if (c7942m.m43421d() != null) {
            this.f50475b = c7942m.m43421d().m43448b();
        }
        List<C7948s> listM43423f = c7942m.m43423f();
        this.f50476c = new AbstractC7934e[listM43423f.size()];
        for (C7948s c7948s : listM43423f) {
            this.f50476c[c7948s.getIndex()] = c7948s.m43448b();
        }
        this.f50477d = new C7930a(c7942m);
    }

    /* JADX INFO: renamed from: a */
    public AbstractC7934e m43425a(C7948s c7948s) {
        return this.f50476c[c7948s.getIndex()];
    }

    /* JADX INFO: renamed from: b */
    public int m43426b(C7948s c7948s) {
        return ((C7938i) m43425a(c7948s)).m43401w();
    }

    /* JADX INFO: renamed from: c */
    public int m43427c() {
        return ((C7938i) this.f50475b).m43401w();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        String str = "";
        for (C7948s c7948s : this.f50474a.m43423f()) {
            sb.append(str);
            sb.append(c7948s.m43449c());
            sb.append('=');
            sb.append(m43425a(c7948s));
            str = ",";
        }
        return sb.toString();
    }
}
