package p575k.p576a.p577a.p578a.p579a;

/* JADX INFO: renamed from: k.a.a.a.a.n */
/* JADX INFO: loaded from: classes2.dex */
public class C7943n extends AbstractC7932c {

    /* JADX INFO: renamed from: c */
    private C7948s[] f50473c;

    public C7943n(C7942m c7942m, C7948s c7948s, C7948s c7948s2) {
        this(c7942m, new C7948s[]{c7948s, c7948s2});
    }

    public C7943n(C7942m c7942m, C7948s[] c7948sArr) {
        super(c7942m);
        this.f50473c = (C7948s[]) c7948sArr.clone();
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7932c
    /* JADX INFO: renamed from: a */
    public AbstractC7932c mo43356a(C7942m c7942m) {
        return new C7943n(c7942m, AbstractC7932c.m43353b(this.f50473c, c7942m));
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7932c
    /* JADX INFO: renamed from: e */
    public boolean mo43359e() {
        return AbstractC7932c.m43354f(this.f50473c);
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7932c
    /* JADX INFO: renamed from: g */
    public boolean mo43360g(C7947r c7947r) {
        int i2 = 0;
        while (true) {
            C7948s[] c7948sArr = this.f50473c;
            if (i2 >= c7948sArr.length) {
                return true;
            }
            AbstractC7934e abstractC7934eM43448b = c7948sArr[i2].m43448b();
            if (abstractC7934eM43448b.m43375g() == 1) {
                Object objMo43371c = abstractC7934eM43448b.mo43371c();
                int i3 = 0;
                while (true) {
                    C7948s[] c7948sArr2 = this.f50473c;
                    if (i3 >= c7948sArr2.length) {
                        break;
                    }
                    if (i2 != i3) {
                        AbstractC7934e abstractC7934eMo43370b = c7948sArr2[i3].m43448b().mo43370b(objMo43371c);
                        if (abstractC7934eMo43370b.m43374f()) {
                            return false;
                        }
                        this.f50473c[i3].m43455i(abstractC7934eMo43370b, c7947r);
                    }
                    i3++;
                }
            }
            i2++;
        }
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7932c
    public String toString() {
        return "NotEquals(" + AbstractC7932c.m43355i(this.f50473c) + ")";
    }
}
