package p575k.p576a.p577a.p578a.p579a;

import java.util.List;

/* JADX INFO: renamed from: k.a.a.a.a.a */
/* JADX INFO: loaded from: classes2.dex */
public class C7930a implements Cloneable {

    /* JADX INFO: renamed from: u2 */
    public AbstractC7931b[] f50449u2;

    private C7930a() {
    }

    public C7930a(C7942m c7942m) {
        List<AbstractC7932c> listM43420c = c7942m.m43420c();
        this.f50449u2 = new AbstractC7931b[listM43420c.size()];
        for (int i2 = 0; i2 < this.f50449u2.length; i2++) {
            this.f50449u2[i2] = listM43420c.get(i2).m43357c();
        }
    }

    public Object clone() {
        C7930a c7930a = new C7930a();
        c7930a.f50449u2 = (AbstractC7931b[]) this.f50449u2.clone();
        return c7930a;
    }
}
