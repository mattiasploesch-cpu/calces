package p575k.p576a.p577a.p578a.p579a;

/* JADX INFO: renamed from: k.a.a.a.a.q */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractRunnableC7946q implements Runnable {

    /* JADX INFO: renamed from: u2 */
    private static int f50478u2;

    /* JADX INFO: renamed from: C2 */
    protected int f50481C2;

    /* JADX INFO: renamed from: K2 */
    private C7941l f50489K2;

    /* JADX INFO: renamed from: v2 */
    private int f50490v2;

    /* JADX INFO: renamed from: w2 */
    protected C7942m f50491w2;

    /* JADX INFO: renamed from: x2 */
    protected int f50492x2;

    /* JADX INFO: renamed from: y2 */
    protected String f50493y2;

    /* JADX INFO: renamed from: z2 */
    protected boolean f50494z2 = false;

    /* JADX INFO: renamed from: A2 */
    protected C7944o f50479A2 = null;

    /* JADX INFO: renamed from: B2 */
    protected C7944o f50480B2 = null;

    /* JADX INFO: renamed from: D2 */
    private Thread f50482D2 = null;

    /* JADX INFO: renamed from: E2 */
    private boolean f50483E2 = false;

    /* JADX INFO: renamed from: F2 */
    private boolean f50484F2 = false;

    /* JADX INFO: renamed from: G2 */
    private boolean f50485G2 = false;

    /* JADX INFO: renamed from: H2 */
    protected long f50486H2 = 0;

    /* JADX INFO: renamed from: I2 */
    protected long f50487I2 = 0;

    /* JADX INFO: renamed from: J2 */
    protected long f50488J2 = 0;

    /* JADX INFO: renamed from: k.a.a.a.a.q$a */
    private class a implements Runnable {

        /* JADX INFO: renamed from: u2 */
        private InterfaceC7945p f50495u2;

        /* JADX INFO: renamed from: v2 */
        private long f50496v2;

        public a(InterfaceC7945p interfaceC7945p, long j2) {
            this.f50495u2 = interfaceC7945p;
            this.f50496v2 = j2;
        }

        @Override // java.lang.Runnable
        public void run() {
            AbstractRunnableC7946q.this.m43429a();
            AbstractRunnableC7946q.this.m43437i(this.f50496v2);
            while (AbstractRunnableC7946q.this.m43442n() && !AbstractRunnableC7946q.this.m43432d()) {
                InterfaceC7945p interfaceC7945p = this.f50495u2;
                AbstractRunnableC7946q abstractRunnableC7946q = AbstractRunnableC7946q.this;
                interfaceC7945p.mo43428a(abstractRunnableC7946q, abstractRunnableC7946q.f50479A2);
                AbstractRunnableC7946q.this.m43436h();
            }
            this.f50495u2.mo43428a(AbstractRunnableC7946q.this, null);
            AbstractRunnableC7946q.this.m43439k();
        }
    }

    public AbstractRunnableC7946q(C7942m c7942m, int i2, String str) {
        this.f50491w2 = c7942m;
        this.f50492x2 = i2 == -1 ? c7942m.m43421d() == null ? 0 : 1 : i2;
        int i3 = f50478u2;
        f50478u2 = i3 + 1;
        this.f50490v2 = i3;
        if (str == null) {
            this.f50493y2 = getClass().getName() + this.f50490v2;
        } else {
            this.f50493y2 = str;
        }
        m43429a();
    }

    /* JADX INFO: renamed from: a */
    public void m43429a() {
        this.f50480B2 = null;
        this.f50481C2 = m43434f(1) ? 1073741823 : -1073741823;
    }

    /* JADX INFO: renamed from: b */
    protected synchronized void m43430b() {
        if (this.f50494z2) {
            System.out.println(this.f50493y2 + " fail");
        }
        this.f50479A2 = null;
        this.f50484F2 = false;
        notifyAll();
    }

    /* JADX INFO: renamed from: c */
    public synchronized void m43431c(InterfaceC7945p interfaceC7945p, long j2) {
        m43429a();
        m43438j(interfaceC7945p, j2);
        m43435g();
    }

    /* JADX INFO: renamed from: d */
    public boolean m43432d() {
        return this.f50483E2;
    }

    /* JADX INFO: renamed from: e */
    protected boolean m43433e(int i2, int i3) {
        if (m43434f(1)) {
            if (i2 < i3) {
                return true;
            }
        } else if (i2 > i3) {
            return true;
        }
        return false;
    }

    /* JADX INFO: renamed from: f */
    protected boolean m43434f(int i2) {
        return (i2 & this.f50492x2) != 0;
    }

    /* JADX INFO: renamed from: g */
    public synchronized void m43435g() {
        if (this.f50494z2) {
            System.out.println(this.f50493y2 + " join");
        }
        while (this.f50482D2 == null) {
            try {
                wait();
            } catch (InterruptedException unused) {
            }
        }
        while (this.f50484F2) {
            try {
                wait();
            } catch (InterruptedException unused2) {
            }
        }
        this.f50482D2 = null;
    }

    /* JADX INFO: renamed from: h */
    public synchronized void m43436h() {
        if (this.f50494z2) {
            System.out.println(this.f50493y2 + " resume");
        }
        this.f50485G2 = false;
        notifyAll();
    }

    /* JADX INFO: renamed from: i */
    public synchronized void m43437i(long j2) {
        this.f50482D2 = null;
        if (this.f50494z2) {
            System.out.println(this.f50493y2 + " start");
        }
        this.f50487I2 = System.currentTimeMillis();
        this.f50488J2 = 0L;
        this.f50486H2 = j2;
        this.f50483E2 = false;
        this.f50484F2 = true;
        this.f50485G2 = false;
        this.f50479A2 = null;
        Thread thread = new Thread(this);
        this.f50482D2 = thread;
        thread.start();
        notifyAll();
    }

    /* JADX INFO: renamed from: j */
    public synchronized void m43438j(InterfaceC7945p interfaceC7945p, long j2) {
        new Thread(new a(interfaceC7945p, j2)).start();
    }

    /* JADX INFO: renamed from: k */
    public synchronized void m43439k() {
        if (this.f50494z2) {
            System.out.println(this.f50493y2 + " stop");
        }
        this.f50483E2 = true;
        while (this.f50484F2) {
            notifyAll();
            try {
                wait();
            } catch (InterruptedException unused) {
            }
        }
    }

    /* JADX INFO: renamed from: l */
    protected synchronized void m43440l() {
        if (this.f50494z2) {
            System.out.println(this.f50493y2 + " success");
        }
        if (this.f50483E2) {
            return;
        }
        this.f50488J2++;
        Thread.yield();
        boolean zM43441m = m43441m();
        if (m43434f(4)) {
            if (this.f50489K2 != null) {
                this.f50479A2.m43427c();
                throw null;
            }
            if (!zM43441m) {
                return;
            }
        } else if (this.f50489K2 != null) {
            this.f50479A2.m43427c();
            throw null;
        }
        this.f50485G2 = true;
        notifyAll();
        while (!this.f50483E2 && this.f50485G2) {
            try {
                wait();
            } catch (InterruptedException unused) {
            }
        }
    }

    /* JADX INFO: renamed from: m */
    protected boolean m43441m() {
        if (this.f50479A2 == null) {
            return false;
        }
        if (this.f50491w2.m43421d() == null) {
            this.f50480B2 = this.f50479A2;
            return true;
        }
        int iM43427c = this.f50479A2.m43427c();
        if (!m43433e(iM43427c, this.f50481C2)) {
            return false;
        }
        this.f50480B2 = this.f50479A2;
        this.f50481C2 = iM43427c;
        return true;
    }

    /* JADX INFO: renamed from: n */
    public synchronized boolean m43442n() {
        return m43443o(0L);
    }

    /* JADX INFO: renamed from: o */
    public synchronized boolean m43443o(long j2) {
        if (this.f50494z2) {
            System.out.println(this.f50493y2 + " waitNext");
        }
        long jCurrentTimeMillis = j2 > 0 ? System.currentTimeMillis() + j2 : Long.MAX_VALUE;
        long j3 = this.f50486H2;
        if (j3 > 0) {
            jCurrentTimeMillis = Math.min(jCurrentTimeMillis, this.f50487I2 + j3);
        }
        while (this.f50484F2 && !this.f50485G2) {
            if (jCurrentTimeMillis == Long.MAX_VALUE) {
                try {
                    wait();
                } catch (InterruptedException unused) {
                }
            } else {
                long jCurrentTimeMillis2 = jCurrentTimeMillis - System.currentTimeMillis();
                if (jCurrentTimeMillis2 <= 0) {
                    break;
                }
                wait(Math.max(10L, jCurrentTimeMillis2));
            }
        }
        if (this.f50484F2) {
            return this.f50485G2;
        }
        return false;
    }

    public String toString() {
        return this.f50493y2;
    }
}
