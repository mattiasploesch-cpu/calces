package p575k.p576a.p577a.p578a.p579a;

/* JADX INFO: renamed from: k.a.a.a.a.f */
/* JADX INFO: loaded from: classes2.dex */
public class C7935f extends AbstractC7932c {

    /* JADX INFO: renamed from: c */
    private C7948s[] f50456c;

    public C7935f(C7942m c7942m, C7948s c7948s, C7948s c7948s2) {
        this(c7942m, new C7948s[]{c7948s, c7948s2});
    }

    public C7935f(C7942m c7942m, C7948s[] c7948sArr) {
        super(c7942m);
        this.f50456c = (C7948s[]) c7948sArr.clone();
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7932c
    /* JADX INFO: renamed from: a */
    public AbstractC7932c mo43356a(C7942m c7942m) {
        return new C7935f(c7942m, AbstractC7932c.m43353b(this.f50456c, c7942m));
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7932c
    /* JADX INFO: renamed from: e */
    public boolean mo43359e() {
        return AbstractC7932c.m43354f(this.f50456c);
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7932c
    /* JADX INFO: renamed from: g */
    public boolean mo43360g(C7947r c7947r) {
        int i2 = 0;
        AbstractC7934e abstractC7934eM43448b = this.f50456c[0].m43448b();
        int i3 = 1;
        while (true) {
            C7948s[] c7948sArr = this.f50456c;
            if (i3 < c7948sArr.length) {
                abstractC7934eM43448b = abstractC7934eM43448b.mo43369a(c7948sArr[i3].m43448b());
                if (abstractC7934eM43448b.m43374f()) {
                    return false;
                }
                i3++;
            } else {
                while (true) {
                    C7948s[] c7948sArr2 = this.f50456c;
                    if (i2 >= c7948sArr2.length) {
                        return true;
                    }
                    c7948sArr2[i2].m43455i(abstractC7934eM43448b, c7947r);
                    i2++;
                }
            }
        }
    }

    @Override // p575k.p576a.p577a.p578a.p579a.AbstractC7932c
    public String toString() {
        return "Equals(" + AbstractC7932c.m43355i(this.f50456c) + ")";
    }
}
