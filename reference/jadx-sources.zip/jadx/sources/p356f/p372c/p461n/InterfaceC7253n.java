package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.n */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7253n {
    /* JADX INFO: renamed from: a */
    double m40425a(int i2);
}
