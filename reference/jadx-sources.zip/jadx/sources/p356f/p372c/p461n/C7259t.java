package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.t */
/* JADX INFO: loaded from: classes.dex */
public class C7259t {

    /* JADX INFO: Add missing generic type declarations: [T] */
    /* JADX INFO: renamed from: f.c.n.t$a */
    class a<T> implements InterfaceC7250k<T, T> {
        a() {
        }

        @Override // p356f.p372c.p461n.InterfaceC7250k
        /* JADX INFO: renamed from: a */
        public T mo32693a(T t) {
            return t;
        }
    }

    /* JADX INFO: renamed from: a */
    public static <T> InterfaceC7250k<T, T> m40432a() {
        return new a();
    }
}
