package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.p */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7255p<R> {
    /* JADX INFO: renamed from: a */
    R mo40427a(long j2);
}
