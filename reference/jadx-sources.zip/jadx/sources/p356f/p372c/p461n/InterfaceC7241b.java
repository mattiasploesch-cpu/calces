package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.b */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7241b<T, U, R> {
    /* JADX INFO: renamed from: a */
    R mo34656a(T t, U u);
}
