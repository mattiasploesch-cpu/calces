package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.l */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7251l {
    /* JADX INFO: renamed from: a */
    void m40423a(int i2);
}
