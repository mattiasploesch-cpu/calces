package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.s */
/* JADX INFO: loaded from: classes.dex */
public class C7258s<T> {

    /* JADX INFO: renamed from: a */
    private InterfaceC7257r<T> f47298a;

    /* JADX INFO: renamed from: f.c.n.s$a */
    class a implements InterfaceC7257r<T> {
        a() {
        }

        @Override // p356f.p372c.p461n.InterfaceC7257r
        /* JADX INFO: renamed from: a */
        public boolean mo145a(T t) {
            return !C7258s.this.m40430c(t);
        }
    }

    public C7258s(InterfaceC7257r<T> interfaceC7257r) {
        this.f47298a = interfaceC7257r;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: c */
    public boolean m40430c(T t) {
        return this.f47298a.mo145a(t);
    }

    /* JADX INFO: renamed from: b */
    public InterfaceC7257r<T> m40431b() {
        return new a();
    }
}
