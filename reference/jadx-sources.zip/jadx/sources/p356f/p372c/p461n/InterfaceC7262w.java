package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.w */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7262w<T> {
    /* JADX INFO: renamed from: a */
    int mo36926a(T t);
}
