package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.e */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7244e<T> {
    /* JADX INFO: renamed from: a */
    void mo171a(T t);
}
