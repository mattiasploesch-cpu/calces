package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.g */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7246g {
    /* JADX INFO: renamed from: c */
    void mo40419c(double d2);
}
