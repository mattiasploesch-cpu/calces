package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.r */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7257r<T> {
    /* JADX INFO: renamed from: a */
    boolean mo145a(T t);
}
