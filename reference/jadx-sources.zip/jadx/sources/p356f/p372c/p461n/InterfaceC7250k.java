package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.k */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7250k<T, R> {
    /* JADX INFO: renamed from: a */
    R mo32693a(T t);
}
