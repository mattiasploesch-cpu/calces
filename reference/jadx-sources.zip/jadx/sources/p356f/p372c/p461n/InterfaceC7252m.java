package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.m */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7252m<R> {
    /* JADX INFO: renamed from: a */
    R mo40424a(int i2);
}
