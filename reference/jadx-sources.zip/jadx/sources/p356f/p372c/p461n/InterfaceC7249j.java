package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.j */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7249j {
    /* JADX INFO: renamed from: e */
    double mo40422e(double d2);
}
