package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.q */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7256q<T> {
    /* JADX INFO: renamed from: a */
    void mo40428a(T t, int i2);
}
