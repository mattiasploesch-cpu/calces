package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.u */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7260u<T> {
    T get();
}
