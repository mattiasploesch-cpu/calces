package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.a */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7240a<T, U> {
    /* JADX INFO: renamed from: a */
    void mo40416a(T t, U u);
}
