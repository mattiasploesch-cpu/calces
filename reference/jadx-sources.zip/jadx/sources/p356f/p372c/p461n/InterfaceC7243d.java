package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.d */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7243d<T> extends InterfaceC7241b<T, T, T> {
}
