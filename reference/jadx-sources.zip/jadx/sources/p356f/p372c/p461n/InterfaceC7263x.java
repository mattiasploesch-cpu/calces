package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.x */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7263x<T> {
    /* JADX INFO: renamed from: a */
    long mo40434a(T t);
}
