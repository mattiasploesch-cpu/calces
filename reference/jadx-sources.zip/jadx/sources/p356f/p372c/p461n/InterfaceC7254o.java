package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.o */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7254o {
    /* JADX INFO: renamed from: a */
    void m40426a(long j2);
}
