package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.v */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7261v<T> {
    /* JADX INFO: renamed from: a */
    double m40433a(T t);
}
