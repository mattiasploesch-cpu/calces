package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.f */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7245f {
    /* JADX INFO: renamed from: a */
    double m40418a(double d2, double d3);
}
