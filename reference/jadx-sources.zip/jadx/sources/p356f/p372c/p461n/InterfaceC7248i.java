package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.i */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7248i {
    /* JADX INFO: renamed from: a */
    double m40421a();
}
