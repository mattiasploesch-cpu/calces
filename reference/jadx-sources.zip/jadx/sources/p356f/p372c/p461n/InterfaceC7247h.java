package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.h */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7247h<R> {
    /* JADX INFO: renamed from: a */
    R mo40420a(double d2);
}
