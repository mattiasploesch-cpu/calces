package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.y */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7264y<T> extends InterfaceC7250k<T, T> {
}
