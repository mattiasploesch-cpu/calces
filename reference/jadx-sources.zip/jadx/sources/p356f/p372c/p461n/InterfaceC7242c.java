package p356f.p372c.p461n;

/* JADX INFO: renamed from: f.c.n.c */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7242c<T, U> {
    /* JADX INFO: renamed from: E */
    boolean mo40417E(T t, U u);
}
