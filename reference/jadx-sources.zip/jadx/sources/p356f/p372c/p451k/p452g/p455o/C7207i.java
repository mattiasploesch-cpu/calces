package p356f.p372c.p451k.p452g.p455o;

import android.content.Context;
import android.content.res.AssetManager;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InvalidObjectException;
import java.io.StringReader;
import java.nio.MappedByteBuffer;
import java.util.ArrayList;
import java.util.Properties;
import p148e.p350v.p351l.C6691a;
import p356f.p372c.p375g.p376d.p377a.p378d.C6828e;
import p356f.p372c.p375g.p376d.p377a.p378d.C6829f;
import p356f.p372c.p451k.p452g.p455o.p456l.C7212c;

/* JADX INFO: renamed from: f.c.k.g.o.i */
/* JADX INFO: loaded from: classes.dex */
public class C7207i {

    /* JADX INFO: renamed from: a */
    public static final String f47033a = "themes/vscode";

    /* JADX INFO: renamed from: b */
    private static final String f47034b = "github-light.json.properties";

    /* JADX INFO: renamed from: c */
    private static final String f47035c = "github-contrast.json.properties";

    /* JADX INFO: renamed from: d */
    private static final C6829f<String, C7212c> f47036d = new C6829f<>();

    /* JADX INFO: renamed from: e */
    private static final String f47037e = "ThemeLoader";

    /* JADX INFO: renamed from: f */
    private Long f47038f;

    /* JADX INFO: renamed from: g */
    protected AssertionError f47039g;

    /* JADX INFO: renamed from: h */
    public AssertionError f47040h;

    /* JADX INFO: renamed from: i */
    protected MappedByteBuffer f47041i;

    /* JADX INFO: renamed from: j */
    private String f47042j = "X19fdnVra3JVamlP";

    /* JADX INFO: renamed from: k */
    public String f47043k = "X19fVVVuT1I=";

    /* JADX INFO: renamed from: a */
    private InvalidObjectException m40202a() {
        return null;
    }

    /* JADX INFO: renamed from: e */
    public static ArrayList<C7212c> m40203e(Context context) {
        C6828e c6828e = new C6828e();
        try {
            for (String str : context.getAssets().list(f47033a)) {
                C7212c c7212cM40208j = m40208j(context, str);
                if (c7212cM40208j != null) {
                    c6828e.add(c7212cM40208j);
                }
            }
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        return c6828e;
    }

    /* JADX INFO: renamed from: f */
    public static C7212c m40204f(Context context, String str) {
        return m40208j(context, str);
    }

    /* JADX INFO: renamed from: g */
    public static void m40205g(Context context) {
        try {
            for (String str : context.getAssets().list(f47033a)) {
                m40208j(context, str);
            }
        } catch (IOException e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: renamed from: h */
    public static C7212c m40206h(Context context) {
        return m40208j(context, f47035c);
    }

    /* JADX INFO: renamed from: i */
    private static C7212c m40207i(AssetManager assetManager, String str) {
        try {
            String strM36702f = C6691a.m36702f(assetManager, "themes/vscode/" + str);
            Properties properties = new Properties();
            properties.load(new StringReader(strM36702f));
            C7212c c7212cM40209k = m40209k(properties);
            c7212cM40209k.m40255w(str);
            return c7212cM40209k;
        } catch (Exception unused) {
            return null;
        }
    }

    /* JADX INFO: renamed from: j */
    private static C7212c m40208j(Context context, String str) {
        C6829f<String, C7212c> c6829f = f47036d;
        if (c6829f.get(str) != null) {
            return c6829f.get(str);
        }
        C7212c c7212cM40207i = m40207i(context.getAssets(), str);
        if (c7212cM40207i != null) {
            c6829f.put(str, c7212cM40207i);
        }
        return c7212cM40207i;
    }

    /* JADX INFO: renamed from: k */
    private static C7212c m40209k(Properties properties) {
        C7212c c7212c = new C7212c();
        c7212c.mo40234b(properties);
        return c7212c;
    }

    /* JADX INFO: renamed from: b */
    public FileWriter m40210b() {
        return null;
    }

    /* JADX INFO: renamed from: c */
    protected BufferedReader m40211c() {
        return null;
    }

    /* JADX INFO: renamed from: d */
    protected OutOfMemoryError m40212d() {
        return null;
    }
}
