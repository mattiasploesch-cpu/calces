package p356f.p372c.p451k.p452g.p454n;

import android.graphics.Paint;
import java.io.InvalidClassException;
import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import p356f.p527f.p528a.p529a.SharedPreferencesOnSharedPreferenceChangeListenerC7645a;

/* JADX INFO: renamed from: f.c.k.g.n.b */
/* JADX INFO: loaded from: classes.dex */
public class C7190b {

    /* JADX INFO: renamed from: a */
    public static final float f46857a = 0.8f;

    /* JADX INFO: renamed from: b */
    private Paint f46858b;

    /* JADX INFO: renamed from: c */
    private Paint f46859c;

    /* JADX INFO: renamed from: d */
    private Paint f46860d;

    /* JADX INFO: renamed from: e */
    public int f46861e;

    /* JADX INFO: renamed from: f */
    public SharedPreferencesOnSharedPreferenceChangeListenerC7645a f46862f;

    /* JADX INFO: renamed from: g */
    public boolean f46863g;

    /* JADX INFO: renamed from: h */
    public int f46864h;

    /* JADX INFO: renamed from: j */
    public int f46866j;

    /* JADX INFO: renamed from: l */
    private int f46868l;

    /* JADX INFO: renamed from: m */
    private int f46869m;

    /* JADX INFO: renamed from: o */
    private InstantiationException f46871o;

    /* JADX INFO: renamed from: p */
    private ByteBuffer f46872p;

    /* JADX INFO: renamed from: i */
    public int f46865i = -1;

    /* JADX INFO: renamed from: k */
    public C7193e f46867k = new C7193e();

    /* JADX INFO: renamed from: q */
    public String f46873q = "X19fR0x4RXhXdHBISQ==";

    /* JADX INFO: renamed from: n */
    private int f46870n = 920;

    /* JADX INFO: renamed from: a */
    private InvalidClassException m40069a() {
        return null;
    }

    /* JADX INFO: renamed from: c */
    private BufferUnderflowException m40070c() {
        return null;
    }

    /* JADX INFO: renamed from: A */
    public void m40071A(C7193e c7193e) {
        this.f46867k = c7193e;
    }

    /* JADX INFO: renamed from: B */
    public void m40072B(int i2) {
        this.f46864h = i2;
    }

    /* JADX INFO: renamed from: C */
    public void m40073C(int i2) {
        this.f46868l = i2;
    }

    /* JADX INFO: renamed from: b */
    public IllegalThreadStateException m40074b() {
        return null;
    }

    /* JADX INFO: renamed from: d */
    public Paint m40075d() {
        return this.f46860d;
    }

    /* JADX INFO: renamed from: e */
    public Paint m40076e() {
        return this.f46859c;
    }

    /* JADX INFO: renamed from: f */
    public Paint m40077f() {
        return this.f46858b;
    }

    /* JADX INFO: renamed from: g */
    public int m40078g() {
        return this.f46861e;
    }

    /* JADX INFO: renamed from: h */
    public int m40079h() {
        return this.f46869m;
    }

    /* JADX INFO: renamed from: i */
    public int m40080i() {
        return this.f46865i;
    }

    /* JADX INFO: renamed from: j */
    public int m40081j() {
        return this.f46866j;
    }

    /* JADX INFO: renamed from: k */
    public int m40082k() {
        return this.f46870n;
    }

    /* JADX INFO: renamed from: l */
    public SharedPreferencesOnSharedPreferenceChangeListenerC7645a m40083l() {
        return this.f46862f;
    }

    /* JADX INFO: renamed from: m */
    public C7193e m40084m() {
        return this.f46867k;
    }

    /* JADX INFO: renamed from: n */
    public int m40085n() {
        return this.f46864h;
    }

    /* JADX INFO: renamed from: o */
    public int m40086o() {
        return this.f46868l;
    }

    /* JADX INFO: renamed from: p */
    public boolean m40087p() {
        return this.f46863g;
    }

    /* JADX INFO: renamed from: q */
    public void m40088q(Paint paint) {
        this.f46860d = paint;
    }

    /* JADX INFO: renamed from: r */
    public void m40089r(Paint paint) {
        this.f46859c = paint;
    }

    /* JADX INFO: renamed from: s */
    public void m40090s(Paint paint) {
        this.f46858b = paint;
    }

    /* JADX INFO: renamed from: t */
    public void m40091t(int i2) {
        this.f46861e = i2;
    }

    /* JADX INFO: renamed from: u */
    public void m40092u(int i2) {
        this.f46869m = i2;
    }

    /* JADX INFO: renamed from: v */
    public void m40093v(int i2) {
        this.f46865i = i2;
    }

    /* JADX INFO: renamed from: w */
    public void m40094w(int i2) {
        this.f46866j = i2;
    }

    /* JADX INFO: renamed from: x */
    public void m40095x(int i2) {
        this.f46870n = i2;
    }

    /* JADX INFO: renamed from: y */
    public void m40096y(SharedPreferencesOnSharedPreferenceChangeListenerC7645a sharedPreferencesOnSharedPreferenceChangeListenerC7645a) {
        this.f46862f = sharedPreferencesOnSharedPreferenceChangeListenerC7645a;
    }

    /* JADX INFO: renamed from: z */
    public void m40097z(boolean z) {
        this.f46863g = z;
    }
}
