package p356f.p372c.p451k.p452g.p455o.p456l;

import android.graphics.Color;
import java.io.FileInputStream;
import java.nio.ReadOnlyBufferException;
import java.util.Properties;

/* JADX INFO: renamed from: f.c.k.g.o.l.i */
/* JADX INFO: loaded from: classes.dex */
public class C7218i extends AbstractC7210a {

    /* JADX INFO: renamed from: d */
    private static final String f47165d = "WhiteSpaceStyle";

    /* JADX INFO: renamed from: e */
    private StringBuilder f47166e;

    /* JADX INFO: renamed from: f */
    public ReadOnlyBufferException f47167f;

    /* JADX INFO: renamed from: f.c.k.g.o.l.i$a */
    public enum a {
        BLOCK_COLOR("white-space.block-color"),
        FOLD_COLOR("white-space.fold-color"),
        SPACE_COLOR("white-space.space-color"),
        TAB_COLOR("white-space.tab-color"),
        WHITESPACE_COLOR("white-space.whitespace-color");


        /* JADX INFO: renamed from: A2 */
        private String f47174A2;

        a(String str) {
            this.f47174A2 = str;
        }

        /* JADX INFO: renamed from: c */
        public String m40296c() {
            return this.f47174A2;
        }
    }

    /* JADX INFO: renamed from: e */
    private FileInputStream m40289e() {
        return null;
    }

    @Override // p356f.p372c.p451k.p452g.p455o.p456l.AbstractC7210a
    /* JADX INFO: renamed from: b */
    public void mo40234b(Properties properties) {
        for (a aVar : a.values()) {
            try {
                m40235c(aVar.m40296c(), Color.parseColor(properties.getProperty(aVar.m40296c())));
            } catch (Exception unused) {
            }
        }
    }

    /* JADX INFO: renamed from: d */
    protected AssertionError m40290d() {
        return null;
    }

    /* JADX INFO: renamed from: f */
    public int m40291f() {
        return m40233a(a.BLOCK_COLOR.m40296c());
    }

    /* JADX INFO: renamed from: g */
    public int m40292g() {
        return m40233a(a.FOLD_COLOR.m40296c());
    }

    /* JADX INFO: renamed from: h */
    public int m40293h() {
        return m40233a(a.SPACE_COLOR.m40296c());
    }

    /* JADX INFO: renamed from: i */
    public int m40294i() {
        return m40233a(a.TAB_COLOR.m40296c());
    }

    /* JADX INFO: renamed from: j */
    public int m40295j() {
        return m40233a(a.WHITESPACE_COLOR.m40296c());
    }
}
