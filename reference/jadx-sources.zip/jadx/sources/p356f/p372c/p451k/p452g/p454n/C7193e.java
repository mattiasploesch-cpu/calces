package p356f.p372c.p451k.p452g.p454n;

import java.io.CharArrayReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.CharBuffer;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: renamed from: f.c.k.g.n.e */
/* JADX INFO: loaded from: classes.dex */
public class C7193e {

    /* JADX INFO: renamed from: a */
    private List<a> f46896a = new ArrayList();

    /* JADX INFO: renamed from: b */
    public String f46897b = "X19fRWhKV1NXako=";

    /* JADX INFO: renamed from: f.c.k.g.n.e$a */
    public static class a {

        /* JADX INFO: renamed from: a */
        public final int f46898a;

        /* JADX INFO: renamed from: b */
        public String f46899b;

        /* JADX INFO: renamed from: c */
        private SecurityException f46900c;

        /* JADX INFO: renamed from: d */
        public IllegalStateException f46901d;

        /* JADX INFO: renamed from: e */
        protected Cloneable f46902e;

        /* JADX INFO: renamed from: f */
        public FileInputStream f46903f;

        /* JADX INFO: renamed from: g */
        protected String f46904g = "X19faWJ1RVBfUA==";

        /* JADX INFO: renamed from: h */
        private String f46905h = "X19famtWd1Vza2JoeV95TQ==";

        a(String str, int i2) {
            this.f46899b = str;
            this.f46898a = i2;
        }

        /* JADX INFO: renamed from: a */
        public VirtualMachineError m40117a() {
            return null;
        }

        /* JADX INFO: renamed from: b */
        public String m40118b() {
            return this.f46899b;
        }

        /* JADX INFO: renamed from: c */
        public int m40119c() {
            return this.f46898a;
        }
    }

    /* JADX INFO: renamed from: a */
    private CharSequence m40110a() {
        return null;
    }

    /* JADX INFO: renamed from: b */
    private CharBuffer m40111b() {
        return null;
    }

    /* JADX INFO: renamed from: c */
    public CharArrayReader m40112c() {
        return null;
    }

    /* JADX INFO: renamed from: d */
    public IOException m40113d() {
        return null;
    }

    /* JADX INFO: renamed from: e */
    public void m40114e(String str, int i2) {
        this.f46896a.add(new a(str, i2));
    }

    /* JADX INFO: renamed from: f */
    public void m40115f() {
        this.f46896a.clear();
    }

    /* JADX INFO: renamed from: g */
    public List<a> m40116g() {
        return this.f46896a;
    }
}
