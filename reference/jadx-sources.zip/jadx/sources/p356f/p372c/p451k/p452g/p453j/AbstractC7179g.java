package p356f.p372c.p451k.p452g.p453j;

import java.io.InvalidObjectException;
import java.io.NotSerializableException;
import java.io.StringWriter;
import java.nio.BufferOverflowException;
import java.nio.DoubleBuffer;
import java.security.CryptoPrimitive;
import java.security.NoSuchAlgorithmException;
import java.security.SecureClassLoader;
import java.security.SecureRandom;
import java.time.Month;
import java.time.Year;

/* JADX INFO: renamed from: f.c.k.g.j.g */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC7179g {

    /* JADX INFO: renamed from: a */
    static SecureClassLoader f46759a;

    /* JADX INFO: renamed from: b */
    public InvalidObjectException f46760b;

    /* JADX INFO: renamed from: c */
    volatile SecureRandom f46761c;

    /* JADX INFO: renamed from: d */
    transient CryptoPrimitive f46762d;

    /* JADX INFO: renamed from: e */
    transient Package f46763e;

    /* JADX INFO: renamed from: f */
    protected NoSuchAlgorithmException f46764f;

    /* JADX INFO: renamed from: g */
    protected Year f46765g;

    /* JADX INFO: renamed from: h */
    private StringWriter f46766h;

    /* JADX INFO: renamed from: i */
    public DoubleBuffer f46767i;

    /* JADX INFO: renamed from: j */
    private NotSerializableException f46768j;

    /* JADX INFO: renamed from: k */
    private IllegalThreadStateException f46769k;

    /* JADX INFO: renamed from: l */
    protected String f46770l = "X19fR0NoSWluRGVj";

    AbstractC7179g() {
    }

    /* JADX INFO: renamed from: a */
    synchronized BufferOverflowException m39978a(Month month) {
        return null;
    }
}
