package p356f.p372c.p451k.p452g.p453j;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import java.io.StringReader;

/* JADX INFO: renamed from: f.c.k.g.j.a */
/* JADX INFO: loaded from: classes.dex */
public class C7173a {

    /* JADX INFO: renamed from: a */
    private Context f46721a;

    /* JADX INFO: renamed from: b */
    private ClipboardManager f46722b;

    /* JADX INFO: renamed from: c */
    public StringReader f46723c;

    /* JADX INFO: renamed from: d */
    protected String f46724d = "X19fZFROYnZxVGppdmRDU2g=";

    @SuppressLint({"WrongConstant"})
    public C7173a(Context context) {
        this.f46721a = context;
        this.f46722b = (ClipboardManager) context.getSystemService("clipboard");
    }

    /* JADX INFO: renamed from: a */
    public Exception m39939a() {
        return null;
    }

    /* JADX INFO: renamed from: b */
    public CharSequence m39940b() {
        ClipboardManager clipboardManager = this.f46722b;
        if (clipboardManager == null) {
            return null;
        }
        return clipboardManager.getPrimaryClip().getItemAt(0).getText();
    }

    /* JADX INFO: renamed from: c */
    public void m39941c(CharSequence charSequence) {
        ClipData clipDataNewPlainText = ClipData.newPlainText("", charSequence);
        ClipboardManager clipboardManager = this.f46722b;
        if (clipboardManager != null) {
            clipboardManager.setPrimaryClip(clipDataNewPlainText);
        }
    }
}
