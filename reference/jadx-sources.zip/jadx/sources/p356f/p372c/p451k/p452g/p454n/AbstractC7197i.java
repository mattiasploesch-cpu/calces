package p356f.p372c.p451k.p452g.p454n;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.NotSerializableException;
import java.io.StringWriter;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.ShortBuffer;
import java.security.AlgorithmParameters;
import java.security.AllPermission;
import java.security.CodeSource;
import java.security.DigestOutputStream;
import java.security.Key;
import java.security.KeyStoreSpi;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.Timestamp;
import java.text.DecimalFormatSymbols;
import java.time.Clock;
import java.time.DateTimeException;
import java.time.Duration;
import java.time.Instant;
import java.time.YearMonth;
import java.util.AbstractQueue;
import p148e.p150d.p154l.ViewOnClickListenerC5073g;

/* JADX INFO: renamed from: f.c.k.g.n.i */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC7197i {

    /* JADX INFO: renamed from: a */
    static Character f46934a;

    /* JADX INFO: renamed from: b */
    static ClassCircularityError f46935b;

    /* JADX INFO: renamed from: c */
    private IOException f46936c;

    /* JADX INFO: renamed from: d */
    protected NullPointerException f46937d;

    /* JADX INFO: renamed from: e */
    volatile Math f46938e;

    /* JADX INFO: renamed from: f */
    public StackOverflowError f46939f;

    /* JADX INFO: renamed from: g */
    public Cloneable f46940g;

    /* JADX INFO: renamed from: h */
    private String f46941h = "X19fVWtxeEdsSmY=";

    /* JADX INFO: renamed from: i */
    private String f46942i = "X19fUENZS3ZTaG1SRElN";

    AbstractC7197i() {
    }

    /* JADX INFO: renamed from: a */
    static NotSerializableException m40144a(ShortBuffer shortBuffer, AllPermission allPermission, FilterInputStream filterInputStream, Key key, UnsupportedOperationException unsupportedOperationException, YearMonth yearMonth) {
        return null;
    }

    /* JADX INFO: renamed from: i */
    private AbstractQueue m40145i(NoSuchFieldError noSuchFieldError) {
        return null;
    }

    /* JADX INFO: renamed from: j */
    static FileOutputStream m40146j(IOException iOException) {
        return null;
    }

    /* JADX INFO: renamed from: b */
    DateTimeException m40147b(Math math, BigInteger bigInteger, PrivateKey privateKey, ByteBuffer byteBuffer) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    protected StringWriter m40148c() {
        return null;
    }

    /* JADX INFO: renamed from: d */
    protected StringBuffer m40149d() {
        return null;
    }

    /* JADX INFO: renamed from: e */
    protected StringBuffer m40150e() {
        return null;
    }

    /* JADX INFO: renamed from: f */
    CodeSource m40151f(Clock clock, MessageDigest messageDigest) {
        return null;
    }

    /* JADX INFO: renamed from: g */
    DecimalFormatSymbols m40152g(AlgorithmParameters algorithmParameters, Instant instant) {
        return null;
    }

    /* JADX INFO: renamed from: h */
    IllegalAccessException m40153h(Timestamp timestamp, DecimalFormatSymbols decimalFormatSymbols, NullPointerException nullPointerException, FileInputStream fileInputStream, ViewOnClickListenerC5073g viewOnClickListenerC5073g) {
        return null;
    }

    /* JADX INFO: renamed from: k */
    public DigestOutputStream m40154k(NotSerializableException notSerializableException, DecimalFormatSymbols decimalFormatSymbols, Duration duration, KeyStoreSpi keyStoreSpi) {
        return null;
    }
}
