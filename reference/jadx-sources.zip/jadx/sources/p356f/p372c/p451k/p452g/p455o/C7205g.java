package p356f.p372c.p451k.p452g.p455o;

import android.graphics.Color;
import java.util.Locale;
import java.util.Properties;
import java.util.StringTokenizer;
import p356f.p372c.p451k.p452g.p455o.p456l.C7216g;
import p591n.p608d.p609a.p610a.p611e.C8197a;
import p591n.p608d.p609a.p610a.p612f.C8206i;

/* JADX INFO: renamed from: f.c.k.g.o.g */
/* JADX INFO: loaded from: classes.dex */
public class C7205g {

    /* JADX INFO: renamed from: a */
    private static final String f46998a = "SyntaxUtilities";

    /* JADX INFO: renamed from: b */
    protected String f46999b = "X19fX0NGWVVVQQ==";

    /* JADX INFO: renamed from: c */
    private String f47000c = "X19fRmFYTF9QRldV";

    /* JADX INFO: renamed from: d */
    public String f47001d = "X19fcUljaktVdVlUTWlobW4=";

    private C7205g() {
    }

    /* JADX INFO: renamed from: a */
    private TypeNotPresentException m40196a() {
        return null;
    }

    /* JADX INFO: renamed from: b */
    public static C7216g[] m40197b(Properties properties) {
        C7216g[] c7216gArr = new C7216g[19];
        C7216g c7216g = null;
        for (int i2 = 1; i2 < 19; i2++) {
            try {
                c7216gArr[i2] = m40199d(properties.getProperty("view.style." + C8206i.m45160b((byte) i2).toLowerCase(Locale.ENGLISH)));
                c7216g = c7216gArr[i2];
            } catch (Exception unused) {
                c7216gArr[i2] = c7216g;
            }
        }
        return c7216gArr;
    }

    /* JADX INFO: renamed from: c */
    public static int m40198c(String str, int i2) {
        try {
            return Color.parseColor(str);
        } catch (Exception unused) {
            return i2;
        }
    }

    /* JADX INFO: renamed from: d */
    public static C7216g m40199d(String str) {
        return m40200e(str, -16777216);
    }

    /* JADX INFO: renamed from: e */
    public static C7216g m40200e(String str, int i2) {
        StringTokenizer stringTokenizer = new StringTokenizer(str);
        int iM40198c = i2;
        int iM40198c2 = 0;
        boolean z = false;
        int i3 = 0;
        while (stringTokenizer.hasMoreTokens()) {
            String strNextToken = stringTokenizer.nextToken();
            if (strNextToken.startsWith("color:")) {
                iM40198c = m40198c(strNextToken.substring(6), -16777216);
            } else if (strNextToken.startsWith("bgColor:")) {
                iM40198c2 = m40198c(strNextToken.substring(8), iM40198c2);
            } else if (strNextToken.startsWith("style:")) {
                for (int i4 = 6; i4 < strNextToken.length(); i4++) {
                    if (strNextToken.charAt(i4) == 'i') {
                        z = true;
                    } else {
                        if (strNextToken.charAt(i4) != 'b') {
                            throw new IllegalArgumentException("Invalid style: " + strNextToken);
                        }
                        i3 = 1;
                    }
                }
            } else {
                if (!strNextToken.startsWith("#")) {
                    throw new IllegalArgumentException("Invalid directive: " + strNextToken);
                }
                iM40198c = m40198c(strNextToken, i2);
            }
        }
        return new C7216g(iM40198c, iM40198c2, new C8197a((z ? 2 : 0) | i3));
    }
}
