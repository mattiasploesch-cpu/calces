package p356f.p372c.p451k.p452g.p455o.p456l;

import java.io.Closeable;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.FilterOutputStream;
import java.io.PrintStream;
import java.io.PushbackReader;
import java.io.RandomAccessFile;
import java.io.SequenceInputStream;
import java.nio.CharBuffer;
import java.security.MessageDigest;
import java.text.BreakIterator;
import java.time.Instant;
import java.util.ArrayList;

/* JADX INFO: renamed from: f.c.k.g.o.l.h */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC7217h {

    /* JADX INFO: renamed from: a */
    static Enum f47155a;

    /* JADX INFO: renamed from: b */
    protected RandomAccessFile f47156b;

    /* JADX INFO: renamed from: c */
    transient StackTraceElement f47157c;

    /* JADX INFO: renamed from: d */
    transient Instant f47158d;

    /* JADX INFO: renamed from: e */
    transient InterruptedException f47159e;

    /* JADX INFO: renamed from: f */
    public PushbackReader f47160f;

    /* JADX INFO: renamed from: g */
    private BreakIterator f47161g;

    /* JADX INFO: renamed from: h */
    private CharBuffer f47162h;

    /* JADX INFO: renamed from: i */
    private ArrayList f47163i;

    /* JADX INFO: renamed from: j */
    public SequenceInputStream f47164j;

    AbstractC7217h() {
    }

    /* JADX INFO: renamed from: a */
    private PrintStream m40285a(Runnable runnable, FileFilter fileFilter, Comparable comparable, MessageDigest messageDigest, Closeable closeable) {
        return null;
    }

    /* JADX INFO: renamed from: b */
    protected Cloneable m40286b() {
        return null;
    }

    /* JADX INFO: renamed from: c */
    public FilterOutputStream m40287c() {
        return null;
    }

    /* JADX INFO: renamed from: d */
    public FileNotFoundException m40288d() {
        return null;
    }
}
