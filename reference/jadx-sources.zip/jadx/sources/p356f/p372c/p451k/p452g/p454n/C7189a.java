package p356f.p372c.p451k.p452g.p454n;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

/* JADX INFO: renamed from: f.c.k.g.n.a */
/* JADX INFO: loaded from: classes.dex */
public class C7189a {

    /* JADX INFO: renamed from: a */
    protected NoSuchFieldError f46853a;

    /* JADX INFO: renamed from: b */
    private UnsupportedOperationException f46854b;

    /* JADX INFO: renamed from: c */
    protected String f46855c = "X19fR2h5R2JEUlQ=";

    /* JADX INFO: renamed from: d */
    public String f46856d = "X19fS1VralZEbg==";

    /* JADX INFO: renamed from: a */
    public static void m40066a(View view) {
        InputMethodManager inputMethodManagerM40067b = m40067b(view.getContext());
        if (inputMethodManagerM40067b != null) {
            inputMethodManagerM40067b.hideSoftInputFromWindow(view.getWindowToken(), 2);
        }
    }

    @SuppressLint({"WrongConstant"})
    /* JADX INFO: renamed from: b */
    public static InputMethodManager m40067b(Context context) {
        return (InputMethodManager) context.getSystemService("input_method");
    }

    /* JADX INFO: renamed from: c */
    public static void m40068c(View view) {
        InputMethodManager inputMethodManagerM40067b = m40067b(view.getContext());
        if (inputMethodManagerM40067b != null) {
            inputMethodManagerM40067b.showSoftInput(view, 2);
        }
    }
}
