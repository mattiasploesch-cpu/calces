package p356f.p372c.p451k.p452g;

import java.io.DataInput;
import java.io.InvalidObjectException;
import java.io.OutputStream;
import java.nio.Buffer;
import java.security.AllPermission;
import java.security.CodeSigner;

/* JADX INFO: renamed from: f.c.k.g.k */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC7186k {

    /* JADX INFO: renamed from: a */
    static Comparable f46831a;

    /* JADX INFO: renamed from: b */
    static ExceptionInInitializerError f46832b;

    /* JADX INFO: renamed from: c */
    private OutputStream f46833c;

    /* JADX INFO: renamed from: d */
    volatile Number f46834d;

    /* JADX INFO: renamed from: e */
    transient AllPermission f46835e;

    /* JADX INFO: renamed from: f */
    public CodeSigner f46836f;

    /* JADX INFO: renamed from: g */
    private Short f46837g;

    /* JADX INFO: renamed from: h */
    protected DataInput f46838h;

    /* JADX INFO: renamed from: i */
    public ClassLoader f46839i;

    /* JADX INFO: renamed from: j */
    private Comparable f46840j;

    /* JADX INFO: renamed from: k */
    public InvalidObjectException f46841k;

    /* JADX INFO: renamed from: l */
    protected StackTraceElement f46842l;

    AbstractC7186k() {
    }

    /* JADX INFO: renamed from: a */
    public ClassLoader m40049a() {
        return null;
    }

    /* JADX INFO: renamed from: b */
    public Buffer m40050b() {
        return null;
    }
}
