package p356f.p372c.p451k.p452g.p454n;

import java.io.FileInputStream;
import java.io.ObjectStreamException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.security.AlgorithmParameterGeneratorSpi;
import java.security.GeneralSecurityException;
import java.security.Key;
import java.security.KeyStoreException;
import java.security.Permission;
import java.security.UnrecoverableKeyException;
import java.time.Clock;
import java.time.LocalDate;
import java.time.Period;

/* JADX INFO: renamed from: f.c.k.g.n.h */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC7196h {

    /* JADX INFO: renamed from: a */
    private InterruptedException f46927a;

    /* JADX INFO: renamed from: b */
    volatile GeneralSecurityException f46928b;

    /* JADX INFO: renamed from: c */
    protected TypeNotPresentException f46929c;

    /* JADX INFO: renamed from: d */
    protected RuntimeException f46930d;

    /* JADX INFO: renamed from: e */
    private String f46931e = "X19fTVhlVVl4";

    /* JADX INFO: renamed from: f */
    private String f46932f = "X19fdllZdllrYkU=";

    /* JADX INFO: renamed from: g */
    protected String f46933g = "X19fQW9EY1JCRVFFdUY=";

    AbstractC7196h() {
    }

    /* JADX INFO: renamed from: b */
    private KeyStoreException m40137b(Number number, UnsatisfiedLinkError unsatisfiedLinkError, InternalError internalError, AlgorithmParameterGeneratorSpi algorithmParameterGeneratorSpi, ObjectStreamException objectStreamException) {
        return null;
    }

    /* JADX INFO: renamed from: g */
    static Period m40138g(LocalDate localDate, Long l2, Permission permission, Key key) {
        return null;
    }

    /* JADX INFO: renamed from: a */
    final IllegalAccessException m40139a(Clock clock) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    protected FileInputStream m40140c() {
        return null;
    }

    /* JADX INFO: renamed from: d */
    public UnrecoverableKeyException m40141d(ByteBuffer byteBuffer) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    public RandomAccessFile m40142e() {
        return null;
    }

    /* JADX INFO: renamed from: f */
    protected FileInputStream m40143f() {
        return null;
    }
}
