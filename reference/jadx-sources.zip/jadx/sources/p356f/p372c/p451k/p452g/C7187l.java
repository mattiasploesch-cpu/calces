package p356f.p372c.p451k.p452g;

import java.io.NotActiveException;
import java.io.OptionalDataException;
import java.nio.InvalidMarkException;
import java.security.AccessControlContext;
import java.security.PrivateKey;
import p356f.p372c.p375g.p376d.p377a.C6821a;

/* JADX INFO: renamed from: f.c.k.g.l */
/* JADX INFO: loaded from: classes.dex */
final class C7187l {

    /* JADX INFO: renamed from: a */
    public Void f46843a;

    /* JADX INFO: renamed from: b */
    public ClassCastException f46844b;

    /* JADX INFO: renamed from: c */
    protected String f46845c = "X19fTkNBUkFnS1FYSWVY";

    /* JADX INFO: renamed from: d */
    protected String f46846d = "X19fRWd4Vm9qT2hieQ==";

    C7187l() {
    }

    /* JADX INFO: renamed from: d */
    private ClassNotFoundException m40051d() {
        return null;
    }

    /* JADX INFO: renamed from: a */
    public InvalidMarkException m40052a() {
        return null;
    }

    /* JADX INFO: renamed from: b */
    protected CloneNotSupportedException m40053b() {
        return null;
    }

    /* JADX INFO: renamed from: c */
    protected ClassCastException m40054c() {
        return null;
    }

    /* JADX INFO: renamed from: e */
    final NotActiveException m40055e(Byte b2, OutOfMemoryError outOfMemoryError, Readable readable, PrivateKey privateKey, IncompatibleClassChangeError incompatibleClassChangeError, C6821a c6821a) {
        return null;
    }

    /* JADX INFO: renamed from: f */
    synchronized AccessControlContext m40056f(OptionalDataException optionalDataException) {
        return null;
    }
}
