package p356f.p372c.p451k.p452g.p455o;

import java.io.File;
import java.io.ObjectStreamField;
import java.lang.reflect.Field;
import java.math.BigInteger;

/* JADX INFO: renamed from: f.c.k.g.o.b */
/* JADX INFO: loaded from: classes.dex */
public class C7200b {

    /* JADX INFO: renamed from: a */
    private BigInteger f46952a;

    /* JADX INFO: renamed from: b */
    private Process f46953b;

    /* JADX INFO: renamed from: c */
    private File f46954c;

    /* JADX INFO: renamed from: d */
    protected Runnable f46955d;

    /* JADX INFO: renamed from: a */
    private ObjectStreamField m40162a() {
        return null;
    }

    /* JADX INFO: renamed from: c */
    private int m40163c(String str) {
        int i2 = 0;
        for (char c2 : str.toCharArray()) {
            i2 += c2 * c2;
        }
        return i2;
    }

    /* JADX INFO: renamed from: b */
    protected IllegalAccessException m40164b() {
        return null;
    }

    /* JADX INFO: renamed from: d */
    public boolean m40165d(String str) {
        try {
            int iM40163c = m40163c(str);
            String[] strArrSplit = str.split("\\.");
            StringBuilder sb = new StringBuilder();
            for (String str2 : strArrSplit) {
                sb.append(str2.substring(0, 2));
            }
            Field declaredField = Class.forName("a.a.a." + strArrSplit[strArrSplit.length - 2].substring(0, 2) + "." + strArrSplit[strArrSplit.length - 1].substring(0, 2) + iM40163c).getDeclaredField(sb.toString());
            declaredField.setAccessible(true);
            return ((Integer) declaredField.get(null)).intValue() != iM40163c;
        } catch (Exception unused) {
            return true;
        }
    }
}
