package p356f.p372c.p451k.p452g.p455o;

import advanced.scientific.calculator.calc991.plus.C0001R;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.AssetManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.C0678g;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.duy.ide.editor.view.CodeEditor;
import com.simplecityapps.recyclerview_fastscroll.views.FastScrollRecyclerView;
import java.util.ArrayList;
import java.util.Arrays;
import p356f.p372c.p451k.p452g.p455o.p456l.C7211b;
import p356f.p372c.p451k.p452g.p455o.p456l.C7212c;
import p356f.p527f.p528a.p529a.SharedPreferencesOnSharedPreferenceChangeListenerC7645a;

/* JADX INFO: renamed from: f.c.k.g.o.d */
/* JADX INFO: loaded from: classes.dex */
public class C7202d extends Fragment {

    /* JADX INFO: renamed from: E3 */
    private RecyclerView f46969E3;

    /* JADX INFO: renamed from: F3 */
    private a f46970F3;

    /* JADX INFO: renamed from: G3 */
    private SharedPreferencesOnSharedPreferenceChangeListenerC7645a f46971G3;

    /* JADX INFO: renamed from: H3 */
    private ProgressBar f46972H3;

    /* JADX INFO: renamed from: I3 */
    private b f46973I3;

    /* JADX INFO: renamed from: f.c.k.g.o.d$a */
    public static class a extends RecyclerView.AbstractC0647g<c> implements FastScrollRecyclerView.InterfaceC4727e {

        /* JADX INFO: renamed from: c */
        private final ArrayList<C7212c> f46974c = new ArrayList<>();

        /* JADX INFO: renamed from: d */
        private final Context f46975d;

        /* JADX INFO: renamed from: e */
        private b f46976e;

        /* JADX INFO: renamed from: f */
        private String f46977f;

        /* JADX INFO: renamed from: f.c.k.g.o.d$a$a, reason: collision with other inner class name */
        class ViewOnClickListenerC10184a implements View.OnClickListener {

            /* JADX INFO: renamed from: u2 */
            final /* synthetic */ C7212c f46978u2;

            ViewOnClickListenerC10184a(C7212c c7212c) {
                this.f46978u2 = c7212c;
            }

            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (a.this.f46976e != null) {
                    a.this.f46976e.mo269u(this.f46978u2);
                }
            }
        }

        /* JADX INFO: renamed from: f.c.k.g.o.d$a$b */
        public interface b {
            /* JADX INFO: renamed from: u */
            void mo269u(C7212c c7212c);
        }

        /* JADX INFO: renamed from: f.c.k.g.o.d$a$c */
        static class c extends RecyclerView.AbstractC0642b0 {

            /* JADX INFO: renamed from: H */
            View f46980H;

            /* JADX INFO: renamed from: I */
            CodeEditor f46981I;

            /* JADX INFO: renamed from: J */
            TextView f46982J;

            c(View view) {
                super(view);
                m4535H(false);
                this.f46981I = (CodeEditor) view.findViewById(C0001R.id.fbymnakicccibeaaftzdmrcucu_ulu);
                this.f46982J = (TextView) view.findViewById(C0001R.id.vreqqnuuewvikgaftfnbv_vngj_bfj);
                this.f46980H = view.findViewById(C0001R.id.xwvcdsticinymruiqcmwwzotywbtwh);
            }
        }

        a(Context context) {
            this.f46975d = context;
            m40180R();
        }

        /* JADX INFO: renamed from: M */
        private String m40177M() {
            if (this.f46977f == null) {
                this.f46977f = C7211b.f47054a;
            }
            return this.f46977f;
        }

        /* JADX INFO: renamed from: N */
        private String m40178N(int i2, C7212c c7212c) {
            return (i2 + 1) + ". " + c7212c.m40250r();
        }

        /* JADX INFO: renamed from: Q */
        private String m40179Q() {
            return this.f46975d.getPackageName();
        }

        /* JADX INFO: renamed from: R */
        private void m40180R() {
            this.f46977f = "Package[ \n  \"Polynomials\", \n  (* define the public available symbols *)\n  {LaguerreP, LegendreP}, \n{ \n  (* Laguerre polynomials \n     http://en.wikipedia.org/wiki/Laguerre_polynomials *) \n  LaguerreP[0,x_]:=1, \n  LaguerreP[1,x_]:=1-x, \n  LaguerreP[n_?Integer,x_]:= \n      ExpandAll[(2*n-1-x)*LaguerreP[n-1,x] - (n-1)^2*LaguerreP[n-2,x]] /; NonNegative[n], \n  (* Legendre polynomials \n     http://en.wikipedia.org/wiki/Legendre_polynomials *)\n  LegendreP[n_?Integer,x_]:=\n      1/(2^n)*Sum[ExpandAll[Binomial[n,k]^2*(x-1)^(n-k)*(x+1)^k], {k,0,n}] /; NonNegative[n]\n    \n} ]";
            String strReplace = "Package[ \n  \"Polynomials\", \n  (* define the public available symbols *)\n  {LaguerreP, LegendreP}, \n{ \n  (* Laguerre polynomials \n     http://en.wikipedia.org/wiki/Laguerre_polynomials *) \n  LaguerreP[0,x_]:=1, \n  LaguerreP[1,x_]:=1-x, \n  LaguerreP[n_?Integer,x_]:= \n      ExpandAll[(2*n-1-x)*LaguerreP[n-1,x] - (n-1)^2*LaguerreP[n-2,x]] /; NonNegative[n], \n  (* Legendre polynomials \n     http://en.wikipedia.org/wiki/Legendre_polynomials *)\n  LegendreP[n_?Integer,x_]:=\n      1/(2^n)*Sum[ExpandAll[Binomial[n,k]^2*(x-1)^(n-k)*(x+1)^k], {k,0,n}] /; NonNegative[n]\n    \n} ]".replace("\r\n", "\n");
            this.f46977f = strReplace;
            this.f46977f = strReplace.replace("\r", "\n");
        }

        /* JADX INFO: renamed from: K */
        public void m40181K(C7212c c7212c) {
            if (!new C7200b().m40165d(m40179Q()) || mo73i() < 3) {
                this.f46974c.add(c7212c);
                m4606q(this.f46974c.size() - 1);
            }
        }

        /* JADX INFO: renamed from: L */
        int m40182L(C7212c c7212c) {
            return this.f46974c.indexOf(c7212c);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.AbstractC0647g
        @SuppressLint({"UseSparseArrays"})
        /* JADX INFO: renamed from: O, reason: merged with bridge method [inline-methods] */
        public void mo74y(c cVar, int i2) {
            C7212c c7212c = this.f46974c.get(i2);
            cVar.f46982J.setText(m40178N(i2, c7212c));
            CodeEditor codeEditor = cVar.f46981I;
            codeEditor.setTheme(c7212c);
            codeEditor.getDocument().m39896i("mathematica");
            codeEditor.setText(m40177M());
            cVar.f46980H.setOnClickListener(new ViewOnClickListenerC10184a(c7212c));
        }

        @Override // androidx.recyclerview.widget.RecyclerView.AbstractC0647g
        /* JADX INFO: renamed from: P, reason: merged with bridge method [inline-methods] */
        public c mo70A(ViewGroup viewGroup, int i2) {
            return new c(LayoutInflater.from(viewGroup.getContext()).inflate(C0001R.layout.jb_jhv_ijbajzogzkikcfvkazfejfgrx_wutktj_ecg_bwqybsxwb, viewGroup, false));
        }

        /* JADX INFO: renamed from: S */
        public void m40185S(b bVar) {
            this.f46976e = bVar;
        }

        @Override // com.simplecityapps.recyclerview_fastscroll.views.FastScrollRecyclerView.InterfaceC4727e
        /* JADX INFO: renamed from: a */
        public String mo22696a(int i2) {
            return this.f46974c.get(i2).m40250r();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.AbstractC0647g
        /* JADX INFO: renamed from: i */
        public int mo73i() {
            return this.f46974c.size();
        }
    }

    /* JADX INFO: renamed from: f.c.k.g.o.d$b */
    @SuppressLint({"StaticFieldLeak"})
    private class b extends AsyncTask<Void, C7212c, Void> {

        /* JADX INFO: renamed from: a */
        private final Context f46983a;

        /* JADX INFO: renamed from: b */
        private AssetManager f46984b;

        b(Context context) {
            this.f46983a = context;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public Void doInBackground(Void... voidArr) {
            try {
                String[] list = this.f46984b.list(C7207i.f47033a);
                Arrays.sort(list);
                for (String str : list) {
                    if (isCancelled()) {
                        return null;
                    }
                    Thread.sleep(1L);
                    C7212c c7212cM40204f = C7207i.m40204f(this.f46983a, str);
                    if (c7212cM40204f != null) {
                        publishProgress(c7212cM40204f);
                    }
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
            return null;
        }

        /* JADX INFO: renamed from: b */
        public Context m40187b() {
            return this.f46983a;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public void onPostExecute(Void r3) {
            super.onPostExecute(r3);
            if (isCancelled()) {
                return;
            }
            RecyclerView recyclerView = C7202d.this.f46969E3;
            C7202d c7202d = C7202d.this;
            recyclerView.m4490p1(c7202d.m40174c5(c7202d.f46971G3.m41970b()));
            C7202d.this.f46972H3.setVisibility(8);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public void onProgressUpdate(C7212c... c7212cArr) {
            super.onProgressUpdate(c7212cArr);
            try {
                C7202d.this.f46970F3.m40181K(c7212cArr[0]);
            } catch (Exception unused) {
            }
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
            this.f46984b = m40187b().getAssets();
            C7202d.this.f46972H3.setVisibility(0);
            C7202d.this.f46972H3.setIndeterminate(true);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: c5 */
    public int m40174c5(C7212c c7212c) {
        return Math.max(this.f46970F3.m40182L(c7212c), 0);
    }

    /* JADX INFO: renamed from: d5 */
    private void m40175d5() {
        b bVar = new b(mo3095J1());
        this.f46973I3 = bVar;
        bVar.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
    }

    @Override // androidx.fragment.app.Fragment
    /* JADX INFO: renamed from: Q */
    public void mo3123Q(View view, Bundle bundle) {
        super.mo3123Q(view, bundle);
        this.f46971G3 = SharedPreferencesOnSharedPreferenceChangeListenerC7645a.m41966d(mo3095J1());
        this.f46972H3 = (ProgressBar) view.findViewById(C0001R.id.okxgsfonubhrcusngobhplikqszfhf);
        RecyclerView recyclerView = (RecyclerView) view.findViewById(C0001R.id.fzlofkqjebrhpbxtsxpnqisllgtfnh);
        this.f46969E3 = recyclerView;
        recyclerView.setLayoutManager(new LinearLayoutManager(mo3095J1()));
        this.f46969E3.m4479k(new C0678g(mo3095J1(), 1));
        a aVar = new a(mo3095J1());
        this.f46970F3 = aVar;
        aVar.m40185S((a.b) m3069C1());
        this.f46970F3.m4597H(false);
        this.f46969E3.setAdapter(this.f46970F3);
        m40175d5();
    }

    @Override // androidx.fragment.app.Fragment
    /* JADX INFO: renamed from: c3 */
    public View mo3166c3(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(C0001R.layout.zymlke_mrrfi_jxlpvozdilgj_nnaknhasgvfvrrmwruwvcdtczmv, viewGroup, false);
    }

    @Override // androidx.fragment.app.Fragment
    /* JADX INFO: renamed from: f3 */
    public void mo3174f3() {
        b bVar = this.f46973I3;
        if (bVar != null) {
            bVar.cancel(true);
        }
        super.mo3174f3();
    }
}
