package p356f.p372c.p451k.p452g;

import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOError;
import java.io.NotSerializableException;
import java.io.PipedWriter;
import java.io.Serializable;
import java.io.StreamTokenizer;
import java.io.StringWriter;
import java.io.WriteAbortedException;
import java.math.BigDecimal;
import java.nio.BufferOverflowException;
import java.nio.MappedByteBuffer;
import java.security.AccessController;
import java.security.UnrecoverableEntryException;
import java.security.cert.Certificate;
import java.text.CollationKey;
import java.text.DateFormatSymbols;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.time.Year;
import java.util.AbstractMap;
import java.util.Comparator;
import p356f.p372c.p375g.p376d.p377a.C6822b;

/* JADX INFO: renamed from: f.c.k.g.e */
/* JADX INFO: loaded from: classes.dex */
public class C7168e {

    /* JADX INFO: renamed from: a */
    private PipedWriter f46692a;

    /* JADX INFO: renamed from: b */
    private Serializable f46693b;

    /* JADX INFO: renamed from: c */
    public DataOutputStream f46694c;

    /* JADX INFO: renamed from: d */
    public SecurityManager f46695d;

    /* JADX INFO: renamed from: g */
    private DateFormatSymbols m39906g(AbstractMap abstractMap, UnsupportedOperationException unsupportedOperationException, StringIndexOutOfBoundsException stringIndexOutOfBoundsException, MappedByteBuffer mappedByteBuffer) {
        return null;
    }

    /* JADX INFO: renamed from: h */
    static CollationKey m39907h(StringIndexOutOfBoundsException stringIndexOutOfBoundsException, StackTraceElement stackTraceElement) {
        return null;
    }

    /* JADX INFO: renamed from: a */
    UnrecoverableEntryException m39908a(NotSerializableException notSerializableException, LocalTime localTime) {
        return null;
    }

    /* JADX INFO: renamed from: b */
    final AutoCloseable m39909b(Year year, StreamTokenizer streamTokenizer, StringBuilder sb) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    synchronized SimpleDateFormat m39910c(ClassFormatError classFormatError, Comparable comparable, Package r3) {
        return null;
    }

    /* JADX INFO: renamed from: d */
    synchronized AccessController m39911d(NumberFormatException numberFormatException, C6822b c6822b) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    synchronized BufferOverflowException m39912e(IOError iOError, NoSuchMethodError noSuchMethodError, WriteAbortedException writeAbortedException, BigDecimal bigDecimal, StreamTokenizer streamTokenizer) {
        return null;
    }

    /* JADX INFO: renamed from: f */
    DecimalFormatSymbols m39913f(Certificate certificate, Comparator comparator, FileInputStream fileInputStream, StringWriter stringWriter) {
        return null;
    }
}
