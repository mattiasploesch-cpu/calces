package p356f.p372c.p451k.p452g;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.CharacterStyle;
import android.text.style.ForegroundColorSpan;
import com.duy.ide.editor.view.InterfaceC1060e;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import p356f.p527f.p528a.p529a.p530c.C7648b;
import p591n.p608d.p609a.p610a.C8194b;
import p591n.p608d.p609a.p610a.p612f.C8201d;

/* JADX INFO: renamed from: f.c.k.g.b */
/* JADX INFO: loaded from: classes.dex */
public class C7165b implements TextWatcher {

    /* JADX INFO: renamed from: A2 */
    private String f46674A2;

    /* JADX INFO: renamed from: B2 */
    protected NoClassDefFoundError f46675B2;

    /* JADX INFO: renamed from: u2 */
    private final Context f46676u2;

    /* JADX INFO: renamed from: y2 */
    private final InterfaceC1060e f46680y2;

    /* JADX INFO: renamed from: w2 */
    private final HashMap<Integer, ArrayList<? extends CharacterStyle>> f46678w2 = new HashMap<>();

    /* JADX INFO: renamed from: x2 */
    private final C7167d f46679x2 = new C7167d();

    /* JADX INFO: renamed from: v2 */
    private final C7648b f46677v2 = new C7648b();

    /* JADX INFO: renamed from: z2 */
    private int f46681z2 = 1;

    public C7165b(Context context, InterfaceC1060e interfaceC1060e) {
        this.f46676u2 = context;
        this.f46680y2 = interfaceC1060e;
        interfaceC1060e.addTextChangedListener(this);
        interfaceC1060e.setInitLineNumber(1);
    }

    /* JADX INFO: renamed from: b */
    private NegativeArraySizeException m39888b() {
        return null;
    }

    /* JADX INFO: renamed from: g */
    private void m39889g(InterfaceC1060e interfaceC1060e) {
        try {
            this.f46679x2.m39903d(this.f46677v2, this.f46680y2.getEditorTheme(), this.f46678w2, interfaceC1060e.getEditableText(), 0, this.f46681z2 - 1);
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: renamed from: a */
    public BigDecimal m39890a() {
        return null;
    }

    @Override // android.text.TextWatcher
    public void afterTextChanged(Editable editable) {
    }

    @Override // android.text.TextWatcher
    public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
    }

    /* JADX INFO: renamed from: c */
    public C7648b m39891c() {
        return this.f46677v2;
    }

    /* JADX INFO: renamed from: d */
    public int m39892d() {
        return this.f46681z2;
    }

    /* JADX INFO: renamed from: e */
    public String m39893e() {
        return this.f46674A2;
    }

    /* JADX INFO: renamed from: f */
    public void m39894f(int i2, int i3) {
        try {
            this.f46679x2.m39904e(this.f46677v2, this.f46680y2.getEditorTheme(), this.f46678w2, this.f46680y2.getEditableText(), i2 - 1, i3 - 1, false);
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: renamed from: h */
    public void m39895h(int i2, int i3) {
        try {
            this.f46679x2.m39905f(this.f46677v2, this.f46680y2.getEditorTheme(), this.f46678w2, this.f46680y2.getEditableText(), i2, i3, false);
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: renamed from: i */
    public void m39896i(String str) {
        this.f46674A2 = str;
        this.f46677v2.m41997m(C8201d.m45115a().m45116b(str), this.f46676u2);
        m39889g(this.f46680y2);
    }

    @Override // android.text.TextWatcher
    public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        try {
            Editable editableText = this.f46680y2.getEditableText();
            this.f46677v2.m41996l(editableText);
            if (i3 > 0) {
                this.f46677v2.m41995k(i2, i3);
            }
            if (i4 > 0) {
                this.f46677v2.m41991g(i2, charSequence.subSequence(i2, i2 + i4));
            }
            this.f46681z2 = this.f46677v2.m41987b().m45089e();
            C8194b c8194bM41987b = this.f46677v2.m41987b();
            int iM45091g = c8194bM41987b.m45091g(i2);
            int iM45091g2 = c8194bM41987b.m45091g(i2 + i4);
            int iM45092h = c8194bM41987b.m45092h(iM45091g);
            int iM45090f = c8194bM41987b.m45090f(iM45091g2);
            if (this.f46677v2.m41992h()) {
                for (ForegroundColorSpan foregroundColorSpan : (ForegroundColorSpan[]) editableText.getSpans(iM45092h, iM45090f, ForegroundColorSpan.class)) {
                    editableText.removeSpan(foregroundColorSpan);
                }
                this.f46679x2.m39903d(this.f46677v2, this.f46680y2.getEditorTheme(), this.f46678w2, editableText, iM45091g, iM45091g2);
            }
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }
}
