package p356f.p372c.p451k.p452g.p455o;

import java.io.FileWriter;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectStreamClass;
import java.io.OutputStreamWriter;
import java.io.PipedInputStream;
import java.io.StreamTokenizer;
import java.io.StringBufferInputStream;
import java.io.StringReader;
import java.io.UTFDataFormatException;
import java.security.DigestException;
import java.security.Identity;
import java.security.KeyStoreSpi;
import java.text.DateFormatSymbols;
import java.time.LocalDate;
import java.util.AbstractMap;
import p148e.p150d.p154l.C5069c;

/* JADX INFO: renamed from: f.c.k.g.o.k */
/* JADX INFO: loaded from: classes.dex */
public class C7209k {

    /* JADX INFO: renamed from: a */
    public String f47049a = "X19fVVVqTGlyWFZobVVReA==";

    /* JADX INFO: renamed from: b */
    public String f47050b = "X19fd1JuWVdHTFJLQ1lXbA==";

    /* JADX INFO: renamed from: a */
    static Number m40222a(Identity identity, ArithmeticException arithmeticException, PipedInputStream pipedInputStream, StringReader stringReader) {
        return null;
    }

    /* JADX INFO: renamed from: b */
    static KeyStoreSpi m40223b(UTFDataFormatException uTFDataFormatException) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    private StackOverflowError m40224e() {
        return null;
    }

    /* JADX INFO: renamed from: j */
    private C5069c m40225j(DigestException digestException, LocalDate localDate, StringBufferInputStream stringBufferInputStream, Runnable runnable) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    public DigestException m40226c(IOException iOException, FileWriter fileWriter) {
        return null;
    }

    /* JADX INFO: renamed from: d */
    public FilterInputStream m40227d() {
        return null;
    }

    /* JADX INFO: renamed from: f */
    public NoSuchMethodError m40228f() {
        return null;
    }

    /* JADX INFO: renamed from: g */
    public NoSuchFieldError m40229g() {
        return null;
    }

    /* JADX INFO: renamed from: h */
    FilterInputStream m40230h(C5069c c5069c, OutputStreamWriter outputStreamWriter) {
        return null;
    }

    /* JADX INFO: renamed from: i */
    public LinkageError m40231i(Runnable runnable, StreamTokenizer streamTokenizer, ThreadGroup threadGroup, ObjectStreamClass objectStreamClass, Exception exc) {
        return null;
    }

    /* JADX INFO: renamed from: k */
    synchronized DateFormatSymbols m40232k(AbstractMap abstractMap, Byte b2, StreamTokenizer streamTokenizer, ClassCircularityError classCircularityError, ObjectInputStream objectInputStream, EnumConstantNotPresentException enumConstantNotPresentException) {
        return null;
    }
}
