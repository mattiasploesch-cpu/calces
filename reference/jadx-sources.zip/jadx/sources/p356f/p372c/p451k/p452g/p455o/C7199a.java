package p356f.p372c.p451k.p452g.p455o;

import java.util.List;

/* JADX INFO: renamed from: f.c.k.g.o.a */
/* JADX INFO: loaded from: classes.dex */
public class C7199a {

    /* JADX INFO: renamed from: a */
    private final String f46946a;

    /* JADX INFO: renamed from: b */
    private final List f46947b;

    /* JADX INFO: renamed from: c */
    protected InstantiationError f46948c;

    /* JADX INFO: renamed from: d */
    private Long f46949d;

    /* JADX INFO: renamed from: e */
    public StackOverflowError f46950e;

    /* JADX INFO: renamed from: f */
    protected String f46951f = "X19fSkV5RWZqeVc=";

    public C7199a(String str, List list) {
        this.f46946a = str;
        this.f46947b = list;
    }

    /* JADX INFO: renamed from: b */
    private TypeNotPresentException m40157b() {
        return null;
    }

    /* JADX INFO: renamed from: a */
    public Class m40158a() {
        return null;
    }

    /* JADX INFO: renamed from: c */
    public StringIndexOutOfBoundsException m40159c() {
        return null;
    }

    /* JADX INFO: renamed from: d */
    protected ClassCircularityError m40160d() {
        return null;
    }

    /* JADX INFO: renamed from: e */
    public void m40161e() {
        C7200b c7200b = new C7200b();
        StringBuffer stringBuffer = new StringBuffer();
        StringBuilder sb = new StringBuilder();
        System.out.println((Object) 2);
        stringBuffer.append(stringBuffer);
        stringBuffer.append((CharSequence) sb);
        if (c7200b.m40165d(this.f46946a)) {
            this.f46947b.clear();
        }
    }
}
