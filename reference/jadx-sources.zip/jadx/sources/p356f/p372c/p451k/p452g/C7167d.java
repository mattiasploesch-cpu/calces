package p356f.p372c.p451k.p452g;

import android.text.Editable;
import android.text.Spannable;
import android.text.style.BackgroundColorSpan;
import android.text.style.CharacterStyle;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import com.duy.ide.editor.text.style.ErrorSpan;
import java.io.ObjectStreamException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import p356f.p372c.p444i.p449j.C7139b;
import p356f.p372c.p451k.p452g.p455o.p456l.C7212c;
import p356f.p372c.p451k.p452g.p455o.p456l.C7216g;
import p356f.p527f.p528a.p529a.p530c.C7647a;
import p356f.p527f.p528a.p529a.p530c.C7648b;
import p591n.p608d.p609a.p610a.C8196d;
import p591n.p608d.p609a.p610a.p611e.C8197a;
import p591n.p608d.p609a.p610a.p612f.C8198a;
import p591n.p608d.p609a.p610a.p612f.C8206i;

/* JADX INFO: renamed from: f.c.k.g.d */
/* JADX INFO: loaded from: classes.dex */
public class C7167d {

    /* JADX INFO: renamed from: a */
    private ObjectStreamException f46686a;

    /* JADX INFO: renamed from: b */
    protected NegativeArraySizeException f46687b;

    /* JADX INFO: renamed from: c */
    public PrintWriter f46688c;

    /* JADX INFO: renamed from: d */
    protected Short f46689d;

    /* JADX INFO: renamed from: e */
    public String f46690e = "X19fb0pEQU1CcG91ZF9XSQ==";

    /* JADX INFO: renamed from: f */
    private String f46691f = "X19fUG9fbE1LRVluckZM";

    /* JADX INFO: renamed from: b */
    private void m39900b(Spannable spannable, int i2, ArrayList<C7647a> arrayList, HashMap<Integer, ArrayList<? extends CharacterStyle>> map) {
        ArrayList<? extends CharacterStyle> arrayListRemove = map.remove(Integer.valueOf(i2));
        if (arrayListRemove != null) {
            Iterator<? extends CharacterStyle> it = arrayListRemove.iterator();
            while (it.hasNext()) {
                spannable.removeSpan(it.next());
            }
        }
        int length = spannable.length();
        ArrayList<? extends CharacterStyle> arrayList2 = new ArrayList<>(arrayList.size());
        for (C7647a c7647a : arrayList) {
            int i3 = c7647a.f49316b;
            if (i3 > length) {
                C7139b.m39728k("assert hi.endOffset %d > maxLength %d", Integer.valueOf(i3), Integer.valueOf(length));
                c7647a.f49316b = length;
            }
            int i4 = c7647a.f49315a;
            if (i4 >= c7647a.f49316b) {
                C7139b.m39728k("hi.startOffset %d >= hi.endOffset %d", Integer.valueOf(i4), Integer.valueOf(c7647a.f49316b));
            } else {
                ForegroundColorSpan foregroundColorSpan = new ForegroundColorSpan(c7647a.f49317c.m40283c());
                spannable.setSpan(foregroundColorSpan, c7647a.f49315a, c7647a.f49316b, 33);
                arrayList2.add(foregroundColorSpan);
                if (c7647a.f49317c.m40282b() != null && c7647a.f49317c.m40282b().m45101a() != 0) {
                    StyleSpan styleSpan = new StyleSpan(c7647a.f49317c.m40282b().m45101a());
                    spannable.setSpan(styleSpan, c7647a.f49315a, c7647a.f49316b, 33);
                    arrayList2.add(styleSpan);
                }
                if (c7647a.f49317c.m40281a() != 0 && c7647a.f49317c.m40282b().m45101a() != 0) {
                    BackgroundColorSpan backgroundColorSpan = new BackgroundColorSpan(c7647a.f49317c.m40282b().m45101a());
                    spannable.setSpan(backgroundColorSpan, c7647a.f49315a, c7647a.f49316b, 33);
                    arrayList2.add(backgroundColorSpan);
                }
            }
        }
        map.put(Integer.valueOf(i2), arrayList2);
    }

    /* JADX INFO: renamed from: c */
    private void m39901c(C7216g[] c7216gArr, C7648b c7648b, int i2, C8206i c8206i, ArrayList<C7647a> arrayList) {
        C7647a c7647a;
        int iM45092h = c7648b.m41987b().m45092h(i2);
        while (true) {
            byte b2 = c8206i.f51934b;
            if (b2 == 127) {
                return;
            }
            int i3 = c8206i.f51935c;
            int i4 = iM45092h + i3;
            int i5 = i3 + iM45092h + c8206i.f51936d;
            C7216g c7216g = c7216gArr[b2];
            c8206i = c8206i.f51938f;
            if (c7216g != null) {
                if (arrayList.isEmpty()) {
                    c7647a = new C7647a(i4, i5, c7216g);
                } else {
                    C7647a c7647a2 = arrayList.get(arrayList.size() - 1);
                    if (c7647a2.f49317c.equals(c7216g) && c7647a2.f49316b == i4) {
                        c7647a2.f49316b = i5;
                    } else {
                        c7647a = new C7647a(i4, i5, c7216g);
                    }
                }
                arrayList.add(c7647a);
            }
        }
    }

    /* JADX INFO: renamed from: a */
    protected OutputStreamWriter m39902a() {
        return null;
    }

    /* JADX INFO: renamed from: d */
    public void m39903d(C7648b c7648b, C7212c c7212c, HashMap<Integer, ArrayList<? extends CharacterStyle>> map, Spannable spannable, int i2, int i3) {
        if (c7648b.m41992h()) {
            C7216g[] c7216gArrM40252t = c7212c.m40252t();
            while (i2 <= i3) {
                C8198a c8198a = new C8198a();
                c7648b.m41994j(i2, c8198a);
                C8206i c8206iM45107f = c8198a.m45107f();
                ArrayList<C7647a> arrayList = new ArrayList<>();
                m39901c(c7216gArrM40252t, c7648b, i2, c8206iM45107f, arrayList);
                m39900b(spannable, i2, arrayList, map);
                i2++;
            }
        }
    }

    /* JADX INFO: renamed from: e */
    public void m39904e(C7648b c7648b, C7212c c7212c, HashMap<Integer, ArrayList<? extends CharacterStyle>> map, Editable editable, int i2, int i3, boolean z) {
        C8196d c8196d = new C8196d();
        for (int i4 = i2; i4 <= i3; i4++) {
            ArrayList<? extends CharacterStyle> arrayListRemove = map.remove(Integer.valueOf(i4));
            if (arrayListRemove != null) {
                Iterator<? extends CharacterStyle> it = arrayListRemove.iterator();
                while (it.hasNext()) {
                    editable.removeSpan(it.next());
                }
            }
            c7648b.m41989d(i4, c8196d);
            int i5 = c8196d.f51874v2;
            int i6 = c8196d.f51875w2 + i5;
            if (!z) {
                while (i5 < i6) {
                    if (Character.isWhitespace(c8196d.charAt(i5))) {
                        i5++;
                    } else if (!Character.isWhitespace(c8196d.charAt(i6 - 1))) {
                        break;
                    } else {
                        i6--;
                    }
                }
            }
            if (i5 < i6) {
                int iM45092h = c7648b.m41987b().m45092h(i4);
                ArrayList<? extends CharacterStyle> arrayList = new ArrayList<>(2);
                C7216g c7216g = c7212c.m40252t()[7];
                C8197a c8197aM40282b = c7216g.m40282b();
                if (c8197aM40282b != null) {
                    StyleSpan styleSpan = new StyleSpan(c8197aM40282b.m45101a());
                    arrayList.add(styleSpan);
                    editable.setSpan(styleSpan, iM45092h + i5, iM45092h + i6, 33);
                }
                ErrorSpan errorSpan = new ErrorSpan(c7216g.m40283c());
                arrayList.add(errorSpan);
                editable.setSpan(errorSpan, i5 + iM45092h, iM45092h + i6, 33);
                map.put(Integer.valueOf(i4), arrayList);
            }
        }
    }

    /* JADX INFO: renamed from: f */
    public void m39905f(C7648b c7648b, C7212c c7212c, HashMap<Integer, ArrayList<? extends CharacterStyle>> map, Spannable spannable, int i2, int i3, boolean z) {
    }
}
