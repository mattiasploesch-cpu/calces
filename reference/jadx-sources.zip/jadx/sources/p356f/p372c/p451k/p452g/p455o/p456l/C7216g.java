package p356f.p372c.p451k.p452g.p455o.p456l;

import p591n.p608d.p609a.p610a.p611e.C8197a;

/* JADX INFO: renamed from: f.c.k.g.o.l.g */
/* JADX INFO: loaded from: classes.dex */
public class C7216g {

    /* JADX INFO: renamed from: a */
    private int f47127a;

    /* JADX INFO: renamed from: b */
    private int f47128b;

    /* JADX INFO: renamed from: c */
    private C8197a f47129c;

    /* JADX INFO: renamed from: d */
    public String f47130d = "X19fakFEbVFwX0g=";

    /* JADX INFO: renamed from: f.c.k.g.o.l.g$a */
    public enum a {
        view_style_comment1("view.style.comment1"),
        view_style_comment2("view.style.comment2"),
        view_style_comment3("view.style.comment3"),
        view_style_comment4("view.style.comment4"),
        view_style_digit("view.style.digit"),
        view_style_foldLine_0("view.style.foldLine.0"),
        view_style_foldLine_1("view.style.foldLine.1"),
        view_style_foldLine_2("view.style.foldLine.2"),
        view_style_foldLine_3("view.style.foldLine.3"),
        view_style_function("view.style.function"),
        view_style_invalid("view.style.invalid"),
        view_style_keyword1("view.style.keyword1"),
        view_style_keyword2("view.style.keyword2"),
        view_style_keyword3("view.style.keyword3"),
        view_style_keyword4("view.style.keyword4"),
        view_style_label("view.style.label"),
        view_style_literal1("view.style.literal1"),
        view_style_literal2("view.style.literal2"),
        view_style_literal3("view.style.literal3"),
        view_style_literal4("view.style.literal4"),
        view_style_markup("view.style.markup"),
        view_style_operator("view.style.operator");


        /* JADX INFO: renamed from: R2 */
        private String f47154R2;

        a(String str) {
            this.f47154R2 = str;
        }

        /* JADX INFO: renamed from: c */
        public String m40284c() {
            return this.f47154R2;
        }
    }

    public C7216g(int i2, int i3, C8197a c8197a) {
        this.f47127a = i2;
        this.f47128b = i3;
        this.f47129c = c8197a;
    }

    /* JADX INFO: renamed from: a */
    public int m40281a() {
        return this.f47128b;
    }

    /* JADX INFO: renamed from: b */
    public C8197a m40282b() {
        return this.f47129c;
    }

    /* JADX INFO: renamed from: c */
    public int m40283c() {
        return this.f47127a;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C7216g)) {
            return false;
        }
        C7216g c7216g = (C7216g) obj;
        if (this.f47127a != c7216g.f47127a || this.f47128b != c7216g.f47128b) {
            return false;
        }
        if (m40282b() != null) {
            return m40282b().equals(c7216g.m40282b());
        }
        return c7216g.m40282b() == null;
    }

    public int hashCode() {
        return (((this.f47127a * 31) + this.f47128b) * 31) + (m40282b() != null ? m40282b().hashCode() : 0);
    }
}
