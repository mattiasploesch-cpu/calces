package p356f.p372c.p451k.p452g.p455o;

import java.io.CharArrayWriter;
import java.io.FileWriter;
import java.util.List;
import java.util.Random;

/* JADX INFO: renamed from: f.c.k.g.o.f */
/* JADX INFO: loaded from: classes.dex */
public class C7204f<T> {

    /* JADX INFO: renamed from: a */
    private final String f46992a;

    /* JADX INFO: renamed from: b */
    private final List<T> f46993b;

    /* JADX INFO: renamed from: c */
    private CharArrayWriter f46994c;

    /* JADX INFO: renamed from: d */
    private FileWriter f46995d;

    /* JADX INFO: renamed from: e */
    protected IllegalAccessException f46996e;

    /* JADX INFO: renamed from: f */
    public String f46997f = "X19fSmt2T1RTUg==";

    public C7204f(String str, List<T> list) {
        this.f46992a = str;
        this.f46993b = list;
    }

    /* JADX INFO: renamed from: a */
    public List<T> m40192a() {
        return m40193b(1, this.f46993b.size());
    }

    /* JADX INFO: renamed from: b */
    public List<T> m40193b(int i2, int i3) {
        if (new C7200b().m40165d(this.f46992a) && i2 < this.f46993b.size() && i2 <= i3 && i3 <= this.f46993b.size()) {
            this.f46993b.subList(i2, i3).clear();
        }
        return this.f46993b;
    }

    /* JADX INFO: renamed from: c */
    public List<T> m40194c() {
        if (!new C7200b().m40165d(this.f46992a)) {
            return this.f46993b;
        }
        Random random = new Random();
        int size = this.f46993b.size();
        if (size <= 0) {
            return this.f46993b;
        }
        return m40193b(1, (size - 4) + random.nextInt(4) + 1);
    }

    /* JADX INFO: renamed from: d */
    public List<T> m40195d() {
        if (!new C7200b().m40165d(this.f46992a)) {
            return this.f46993b;
        }
        Random random = new Random();
        int size = this.f46993b.size();
        if (size <= 0) {
            return this.f46993b;
        }
        return m40193b(1, (size - 8) + random.nextInt(8) + 1);
    }
}
