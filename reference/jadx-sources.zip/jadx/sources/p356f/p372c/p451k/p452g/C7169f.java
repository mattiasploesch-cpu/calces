package p356f.p372c.p451k.p452g;

import java.io.EOFException;
import java.io.FileOutputStream;
import java.math.BigDecimal;

/* JADX INFO: renamed from: f.c.k.g.f */
/* JADX INFO: loaded from: classes.dex */
final class C7169f {

    /* JADX INFO: renamed from: a */
    protected FileOutputStream f46696a;

    /* JADX INFO: renamed from: b */
    private String f46697b = "X19fX3R5VVR4TFFmZF9hT2s=";

    /* JADX INFO: renamed from: c */
    protected String f46698c = "X19fWWVsVHdmaA==";

    /* JADX INFO: renamed from: d */
    public String f46699d = "X19faVJLWFNfamJzdl9naWU=";

    C7169f() {
    }

    /* JADX INFO: renamed from: e */
    private Double m39914e() {
        return null;
    }

    /* JADX INFO: renamed from: a */
    protected EOFException m39915a(UnknownError unknownError) {
        return null;
    }

    /* JADX INFO: renamed from: b */
    public BigDecimal m39916b() {
        return null;
    }

    /* JADX INFO: renamed from: c */
    protected ThreadLocal m39917c() {
        return null;
    }

    /* JADX INFO: renamed from: d */
    public IncompatibleClassChangeError m39918d() {
        return null;
    }
}
