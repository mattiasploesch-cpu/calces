package p356f.p372c.p451k.p452g.p454n;

import java.io.BufferedOutputStream;
import java.nio.ShortBuffer;
import java.security.BasicPermission;

/* JADX INFO: renamed from: f.c.k.g.n.j */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC7198j {

    /* JADX INFO: renamed from: a */
    public BufferedOutputStream f46943a;

    /* JADX INFO: renamed from: b */
    protected NoSuchFieldException f46944b;

    /* JADX INFO: renamed from: c */
    protected String f46945c = "X19fV2lxUWxKdQ==";

    AbstractC7198j() {
    }

    /* JADX INFO: renamed from: a */
    final BasicPermission m40155a(Object obj) {
        return null;
    }

    /* JADX INFO: renamed from: b */
    public ShortBuffer m40156b() {
        return null;
    }
}
