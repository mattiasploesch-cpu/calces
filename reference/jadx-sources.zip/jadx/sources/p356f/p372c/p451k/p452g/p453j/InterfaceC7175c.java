package p356f.p372c.p451k.p452g.p453j;

import android.content.SharedPreferences;

/* JADX INFO: renamed from: f.c.k.g.j.c */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7175c {
    /* JADX INFO: renamed from: a */
    void mo39950a();

    /* JADX INFO: renamed from: b */
    void mo39951b();

    /* JADX INFO: renamed from: c */
    boolean mo39952c();

    /* JADX INFO: renamed from: d */
    void mo39953d(SharedPreferences sharedPreferences);

    /* JADX INFO: renamed from: e */
    boolean mo39954e();

    /* JADX INFO: renamed from: f */
    void mo39955f();

    /* JADX INFO: renamed from: g */
    void mo39956g();

    /* JADX INFO: renamed from: h */
    void mo39957h(SharedPreferences sharedPreferences);
}
