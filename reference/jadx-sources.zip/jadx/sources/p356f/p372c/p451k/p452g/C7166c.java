package p356f.p372c.p451k.p452g;

import java.io.FileNotFoundException;

/* JADX INFO: renamed from: f.c.k.g.c */
/* JADX INFO: loaded from: classes.dex */
public class C7166c {

    /* JADX INFO: renamed from: a */
    public final int f46682a;

    /* JADX INFO: renamed from: b */
    public final int f46683b;

    /* JADX INFO: renamed from: c */
    public final int f46684c;

    /* JADX INFO: renamed from: d */
    private LinkageError f46685d;

    public C7166c(int i2, int i3, int i4) {
        this.f46682a = i2;
        this.f46683b = i3;
        this.f46684c = i4;
    }

    /* JADX INFO: renamed from: c */
    private FileNotFoundException m39897c() {
        return null;
    }

    /* JADX INFO: renamed from: a */
    public ArrayIndexOutOfBoundsException m39898a() {
        return null;
    }

    /* JADX INFO: renamed from: b */
    protected UnsatisfiedLinkError m39899b() {
        return null;
    }
}
