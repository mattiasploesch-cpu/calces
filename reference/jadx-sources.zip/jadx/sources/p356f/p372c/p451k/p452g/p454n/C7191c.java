package p356f.p372c.p451k.p452g.p454n;

import android.graphics.Rect;
import android.text.Editable;
import android.text.Layout;
import android.text.TextUtils;
import android.widget.EditText;
import java.io.ObjectStreamException;
import java.math.BigInteger;
import java.nio.CharBuffer;

/* JADX INFO: renamed from: f.c.k.g.n.c */
/* JADX INFO: loaded from: classes.dex */
public class C7191c {

    /* JADX INFO: renamed from: a */
    private static final Rect f46874a = new Rect();

    /* JADX INFO: renamed from: b */
    private static final String f46875b = "LineManager";

    /* JADX INFO: renamed from: d */
    private boolean[] f46877d;

    /* JADX INFO: renamed from: e */
    private int f46878e;

    /* JADX INFO: renamed from: f */
    private int[] f46879f;

    /* JADX INFO: renamed from: g */
    private EditText f46880g;

    /* JADX INFO: renamed from: h */
    protected ObjectStreamException f46881h;

    /* JADX INFO: renamed from: i */
    public NullPointerException f46882i;

    /* JADX INFO: renamed from: j */
    protected LinkageError f46883j;

    /* JADX INFO: renamed from: k */
    protected CharBuffer f46884k;

    /* JADX INFO: renamed from: c */
    private final C7193e f46876c = new C7193e();

    /* JADX INFO: renamed from: l */
    public String f46885l = "X19fX05MeUdWYw==";

    /* JADX INFO: renamed from: m */
    public String f46886m = "X19fU0dRSkptX2hrTF9QWA==";

    /* JADX INFO: renamed from: n */
    public String f46887n = "X19fS3lVb3duSVl5dQ==";

    public C7191c(EditText editText) {
        this.f46880g = editText;
    }

    /* JADX INFO: renamed from: a */
    protected BigInteger m40098a() {
        return null;
    }

    /* JADX INFO: renamed from: b */
    public void m40099b() {
        this.f46876c.m40115f();
        Layout layout = this.f46880g.getLayout();
        if (layout == null) {
            return;
        }
        if (this.f46877d == null || this.f46879f == null) {
            m40106i(0);
        }
        int iMin = Math.min(this.f46877d.length - 1, m40101d());
        for (int iM40100c = m40100c(); iM40100c <= iMin; iM40100c++) {
            if (this.f46877d[iM40100c]) {
                this.f46876c.m40114e(String.valueOf(this.f46879f[iM40100c]), layout.getLineBaseline(iM40100c));
            }
        }
    }

    /* JADX INFO: renamed from: c */
    public int m40100c() {
        try {
            Layout layout = this.f46880g.getLayout();
            if (layout == null || !this.f46880g.isVerticalScrollBarEnabled()) {
                return 0;
            }
            int lineCount = layout.getLineCount();
            return Math.max(0, Math.min((int) ((this.f46880g.getScrollY() / layout.getHeight()) * lineCount), lineCount - 1));
        } catch (Exception unused) {
            return 0;
        }
    }

    /* JADX INFO: renamed from: d */
    public int m40101d() {
        try {
            Layout layout = this.f46880g.getLayout();
            if (layout == null) {
                return 0;
            }
            int lineCount = this.f46880g.getLineCount();
            if (!this.f46880g.isVerticalScrollBarEnabled()) {
                return lineCount - 1;
            }
            EditText editText = this.f46880g;
            Rect rect = f46874a;
            editText.getGlobalVisibleRect(rect);
            return Math.max(0, Math.min((int) (((this.f46880g.getScrollY() + rect.height()) / layout.getHeight()) * lineCount), lineCount - 1));
        } catch (Exception unused) {
            return 0;
        }
    }

    /* JADX INFO: renamed from: e */
    public int m40102e() {
        return this.f46878e;
    }

    /* JADX INFO: renamed from: f */
    public C7193e m40103f() {
        return this.f46876c;
    }

    /* JADX INFO: renamed from: g */
    public int m40104g(int i2) {
        if (this.f46880g.getLayout() == null) {
            return 0;
        }
        return this.f46880g.getLayout().getLineTop(i2);
    }

    /* JADX INFO: renamed from: h */
    public int m40105h(int i2) {
        if (i2 >= this.f46879f.length) {
            return 0;
        }
        int i3 = 0;
        while (true) {
            int[] iArr = this.f46879f;
            if (i3 >= iArr.length) {
                return 0;
            }
            if (i2 == iArr[i3]) {
                return i3;
            }
            i3++;
        }
    }

    /* JADX INFO: renamed from: i */
    public void m40106i(int i2) {
        int lineCount = this.f46880g.getLayout().getLineCount();
        if (i2 >= lineCount) {
            return;
        }
        int iMax = Math.max(lineCount, 1);
        boolean[] zArr = this.f46877d;
        if (zArr != null) {
            boolean[] zArr2 = new boolean[iMax];
            System.arraycopy(zArr, 0, zArr2, 0, Math.max(0, Math.min(zArr.length, i2)));
            this.f46877d = zArr2;
            int[] iArr = new int[iMax];
            int[] iArr2 = this.f46879f;
            System.arraycopy(iArr2, 0, iArr, 0, Math.max(0, Math.min(iArr2.length, i2)));
            this.f46879f = iArr;
        } else {
            this.f46877d = new boolean[iMax];
            this.f46879f = new int[iMax];
        }
        Layout layout = this.f46880g.getLayout();
        Editable text = this.f46880g.getText();
        if (TextUtils.isEmpty(text) || layout == null) {
            this.f46877d[0] = false;
            this.f46879f[0] = 1;
            this.f46878e = 0;
            return;
        }
        for (int i3 = i2; i3 < iMax; i3++) {
            int lineEnd = layout.getLineEnd(i3) - 1;
            if (text.charAt(lineEnd) == '\n') {
                int i4 = lineEnd - 1;
                while (i4 >= 0 && text.charAt(i4) != '\n') {
                    i4--;
                }
                this.f46877d[layout.getLineForOffset(i4 + 1)] = true;
            }
        }
        this.f46877d[iMax - 1] = true;
        int i5 = this.f46879f[i2];
        int i6 = i5;
        while (i5 < iMax) {
            if (this.f46877d[i5]) {
                i6++;
            }
            this.f46879f[i5] = i6;
            i5++;
        }
        this.f46878e = i6;
    }

    /* JADX INFO: renamed from: j */
    public int m40107j(int i2) {
        int i3 = 0;
        while (true) {
            int[] iArr = this.f46879f;
            if (i3 >= iArr.length) {
                return 0;
            }
            if (i2 == iArr[i3]) {
                return i3;
            }
            i3++;
        }
    }
}
