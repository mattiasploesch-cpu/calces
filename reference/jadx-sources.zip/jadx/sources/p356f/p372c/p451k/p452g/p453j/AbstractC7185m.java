package p356f.p372c.p451k.p452g.p453j;

import java.io.ByteArrayInputStream;
import java.io.DataInput;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.math.BigInteger;
import java.nio.Buffer;
import java.nio.ReadOnlyBufferException;
import java.security.AccessControlException;
import java.security.DigestOutputStream;
import java.security.MessageDigest;
import java.security.Signature;
import java.security.SignatureException;
import java.text.Bidi;
import java.text.CollationKey;

/* JADX INFO: renamed from: f.c.k.g.j.m */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC7185m {

    /* JADX INFO: renamed from: a */
    static IndexOutOfBoundsException f46826a;

    /* JADX INFO: renamed from: b */
    volatile Signature f46827b;

    /* JADX INFO: renamed from: c */
    public PrintStream f46828c;

    /* JADX INFO: renamed from: d */
    volatile Bidi f46829d;

    /* JADX INFO: renamed from: e */
    private String f46830e = "X19fSm5yeUV3QUg=";

    AbstractC7185m() {
    }

    /* JADX INFO: renamed from: d */
    static File m40042d(Buffer buffer, MessageDigest messageDigest, DigestOutputStream digestOutputStream) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    private FileInputStream m40043e() {
        return null;
    }

    /* JADX INFO: renamed from: a */
    synchronized InputStream m40044a(ReadOnlyBufferException readOnlyBufferException) {
        return null;
    }

    /* JADX INFO: renamed from: b */
    final AccessControlException m40045b(DataInput dataInput, IllegalAccessException illegalAccessException, FileOutputStream fileOutputStream, CollationKey collationKey) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    protected SignatureException m40046c(InheritableThreadLocal inheritableThreadLocal, InternalError internalError, File file) {
        return null;
    }

    /* JADX INFO: renamed from: f */
    protected BigInteger m40047f() {
        return null;
    }

    /* JADX INFO: renamed from: g */
    protected ByteArrayInputStream m40048g() {
        return null;
    }
}
