package p356f.p372c.p451k.p452g.p455o;

import java.io.DataInput;
import java.io.DataOutputStream;
import java.io.FilenameFilter;
import java.io.FilterReader;
import java.io.NotSerializableException;
import java.io.RandomAccessFile;
import java.io.Serializable;
import java.io.StringBufferInputStream;
import java.math.BigDecimal;
import java.nio.BufferUnderflowException;
import java.nio.LongBuffer;
import java.security.AuthProvider;
import java.security.BasicPermission;
import java.security.DigestInputStream;
import java.security.DomainCombiner;
import java.security.InvalidParameterException;
import java.security.KeyFactorySpi;
import java.security.KeyPairGeneratorSpi;
import java.security.PolicySpi;
import java.security.SignatureSpi;
import java.security.SignedObject;
import java.text.Bidi;
import java.time.Month;
import java.time.MonthDay;
import java.util.AbstractMap;
import java.util.Stack;
import java.util.regex.Pattern;

/* JADX INFO: renamed from: f.c.k.g.o.j */
/* JADX INFO: loaded from: classes.dex */
final class C7208j {

    /* JADX INFO: renamed from: a */
    volatile MonthDay f47044a;

    /* JADX INFO: renamed from: b */
    volatile LongBuffer f47045b;

    /* JADX INFO: renamed from: c */
    transient DataOutputStream f47046c;

    /* JADX INFO: renamed from: d */
    private DigestInputStream f47047d;

    /* JADX INFO: renamed from: e */
    volatile KeyFactorySpi f47048e;

    C7208j() {
    }

    /* JADX INFO: renamed from: a */
    private BufferUnderflowException m40213a(SignedObject signedObject, Runnable runnable, Serializable serializable, OutOfMemoryError outOfMemoryError, PolicySpi policySpi, PolicySpi policySpi2) {
        return null;
    }

    /* JADX INFO: renamed from: d */
    private Bidi m40214d(UnknownError unknownError, ClassNotFoundException classNotFoundException, AuthProvider authProvider, SignatureSpi signatureSpi, Long l2, InvalidParameterException invalidParameterException) {
        return null;
    }

    /* JADX INFO: renamed from: g */
    static BigDecimal m40215g(Pattern pattern, Double d2) {
        return null;
    }

    /* JADX INFO: renamed from: b */
    final IllegalArgumentException m40216b(Appendable appendable, RandomAccessFile randomAccessFile, IllegalStateException illegalStateException, Iterable iterable) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    public InternalError m40217c(DomainCombiner domainCombiner, AbstractMap abstractMap) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    NotSerializableException m40218e(DataInput dataInput, Byte b2, ClassNotFoundException classNotFoundException, Month month, KeyPairGeneratorSpi keyPairGeneratorSpi, Error error) {
        return null;
    }

    /* JADX INFO: renamed from: f */
    FilenameFilter m40219f(StringBufferInputStream stringBufferInputStream, FilterReader filterReader, Readable readable, BigDecimal bigDecimal) {
        return null;
    }

    /* JADX INFO: renamed from: h */
    public ReflectiveOperationException m40220h(BasicPermission basicPermission) {
        return null;
    }

    /* JADX INFO: renamed from: i */
    public PolicySpi m40221i(Stack stack) {
        return null;
    }
}
