package p356f.p372c.p451k.p452g.p455o.p456l;

import android.graphics.Color;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Properties;

/* JADX INFO: renamed from: f.c.k.g.o.l.a */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC7210a {

    /* JADX INFO: renamed from: b */
    protected FileReader f47052b;

    /* JADX INFO: renamed from: a */
    private HashMap<String, Integer> f47051a = new HashMap<>();

    /* JADX INFO: renamed from: c */
    public String f47053c = "X19feHVpSGNqR1c=";

    /* JADX INFO: renamed from: a */
    protected int m40233a(String str) {
        Integer num = this.f47051a.get(str);
        if (num == null) {
            return -16777216;
        }
        return (Color.alpha(num.intValue()) != 0 || num.intValue() == 0) ? num.intValue() : Color.rgb(Color.red(num.intValue()), Color.green(num.intValue()), Color.blue(num.intValue()));
    }

    /* JADX INFO: renamed from: b */
    public abstract void mo40234b(Properties properties);

    /* JADX INFO: renamed from: c */
    protected void m40235c(String str, int i2) {
        this.f47051a.put(str, Integer.valueOf(i2));
    }
}
