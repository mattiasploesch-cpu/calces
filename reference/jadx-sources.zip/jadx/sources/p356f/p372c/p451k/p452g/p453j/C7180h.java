package p356f.p372c.p451k.p452g.p453j;

import android.content.SharedPreferences;
import android.widget.EditText;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;

/* JADX INFO: renamed from: f.c.k.g.j.h */
/* JADX INFO: loaded from: classes.dex */
public class C7180h implements InterfaceC7175c {

    /* JADX INFO: renamed from: a */
    private static final int f46771a = 100;

    /* JADX INFO: renamed from: b */
    private C7181i f46772b;

    /* JADX INFO: renamed from: c */
    public BufferedWriter f46773c;

    /* JADX INFO: renamed from: d */
    private BufferedOutputStream f46774d;

    /* JADX INFO: renamed from: e */
    protected StringBuilder f46775e;

    /* JADX INFO: renamed from: f */
    public String f46776f = "X19fZ0JFY3FBeUt5UWk=";

    public C7180h(EditText editText) {
        C7181i c7181i = new C7181i(editText);
        this.f46772b = c7181i;
        c7181i.m39986c();
        this.f46772b.m39993k(100);
    }

    @Override // p356f.p372c.p451k.p452g.p453j.InterfaceC7175c
    /* JADX INFO: renamed from: a */
    public void mo39950a() {
        if (mo39952c()) {
            this.f46772b.m39991i();
        }
    }

    @Override // p356f.p372c.p451k.p452g.p453j.InterfaceC7175c
    /* JADX INFO: renamed from: b */
    public void mo39951b() {
        if (mo39954e()) {
            this.f46772b.m39995m();
        }
    }

    @Override // p356f.p372c.p451k.p452g.p453j.InterfaceC7175c
    /* JADX INFO: renamed from: c */
    public boolean mo39952c() {
        return this.f46772b.m39989g();
    }

    @Override // p356f.p372c.p451k.p452g.p453j.InterfaceC7175c
    /* JADX INFO: renamed from: d */
    public void mo39953d(SharedPreferences sharedPreferences) {
        this.f46772b.m39992j(sharedPreferences, "");
    }

    @Override // p356f.p372c.p451k.p452g.p453j.InterfaceC7175c
    /* JADX INFO: renamed from: e */
    public boolean mo39954e() {
        return this.f46772b.m39990h();
    }

    @Override // p356f.p372c.p451k.p452g.p453j.InterfaceC7175c
    /* JADX INFO: renamed from: f */
    public void mo39955f() {
        this.f46772b.m39986c();
    }

    @Override // p356f.p372c.p451k.p452g.p453j.InterfaceC7175c
    /* JADX INFO: renamed from: g */
    public void mo39956g() {
        this.f46772b.m39988e();
    }

    @Override // p356f.p372c.p451k.p452g.p453j.InterfaceC7175c
    /* JADX INFO: renamed from: h */
    public void mo39957h(SharedPreferences sharedPreferences) {
        SharedPreferences.Editor editorEdit = sharedPreferences.edit();
        this.f46772b.m39994l(editorEdit, "");
        editorEdit.apply();
    }

    /* JADX INFO: renamed from: i */
    public ClassCircularityError m39979i() {
        return null;
    }

    /* JADX INFO: renamed from: j */
    public InternalError m39980j() {
        return null;
    }

    /* JADX INFO: renamed from: k */
    protected RuntimeException m39981k() {
        return null;
    }

    /* JADX INFO: renamed from: l */
    public StrictMath m39982l() {
        return null;
    }
}
