package p356f.p372c.p451k.p452g.p453j;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectStreamConstants;
import java.io.Serializable;
import java.math.BigDecimal;
import java.security.CryptoPrimitive;
import java.security.KeyPair;
import java.security.SignatureException;
import java.text.DateFormatSymbols;
import java.time.LocalDateTime;
import java.time.Month;
import p148e.p150d.p154l.ViewOnClickListenerC5067a;

/* JADX INFO: renamed from: f.c.k.g.j.f */
/* JADX INFO: loaded from: classes.dex */
final class C7178f {

    /* JADX INFO: renamed from: a */
    public Month f46752a;

    /* JADX INFO: renamed from: b */
    public IOException f46753b;

    /* JADX INFO: renamed from: c */
    volatile ViewOnClickListenerC5067a f46754c;

    /* JADX INFO: renamed from: d */
    private BufferedInputStream f46755d;

    /* JADX INFO: renamed from: e */
    protected TypeNotPresentException f46756e;

    /* JADX INFO: renamed from: f */
    protected CloneNotSupportedException f46757f;

    /* JADX INFO: renamed from: g */
    protected String f46758g = "X19fZlVNWERUc0g=";

    C7178f() {
    }

    /* JADX INFO: renamed from: b */
    private FileInputStream m39974b() {
        return null;
    }

    /* JADX INFO: renamed from: c */
    private BigDecimal m39975c() {
        return null;
    }

    /* JADX INFO: renamed from: d */
    private IOException m39976d(SignatureException signatureException) {
        return null;
    }

    /* JADX INFO: renamed from: a */
    final ObjectStreamConstants m39977a(DateFormatSymbols dateFormatSymbols, KeyPair keyPair, NumberFormatException numberFormatException, Serializable serializable, CryptoPrimitive cryptoPrimitive, LocalDateTime localDateTime) {
        return null;
    }
}
