package p356f.p372c.p451k.p452g.p455o.p456l;

import android.graphics.Color;
import java.io.CharArrayWriter;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Properties;
import p356f.p372c.p451k.p452g.p455o.C7205g;

/* JADX INFO: renamed from: f.c.k.g.o.l.c */
/* JADX INFO: loaded from: classes.dex */
public class C7212c extends AbstractC7210a {

    /* JADX INFO: renamed from: d */
    private static final String f47060d = "EditorTheme";

    /* JADX INFO: renamed from: e */
    private C7213d f47061e = new C7213d();

    /* JADX INFO: renamed from: f */
    private C7218i f47062f = new C7218i();

    /* JADX INFO: renamed from: g */
    private C7216g[] f47063g;

    /* JADX INFO: renamed from: h */
    private String f47064h;

    /* JADX INFO: renamed from: i */
    private String f47065i;

    /* JADX INFO: renamed from: j */
    public InterruptedException f47066j;

    /* JADX INFO: renamed from: k */
    private CharArrayWriter f47067k;

    /* JADX INFO: renamed from: f.c.k.g.o.l.c$a */
    public enum a {
        BG_COLOR("view.bgColor"),
        CARENT_COLOR("view.caretColor"),
        EOL_MARKER_COLOR("view.eolMarkerColor"),
        FG_COLOR("view.fgColor"),
        LINE_HIGHLIGHT_COLOR("view.lineHighlightColor"),
        SELECTION_COLOR("view.selectionColor"),
        STRUCTURE_HIGHLIGHT_COLOR("view.structureHighlightColor"),
        WRAP_GUIDE_COLOR("view.wrapGuideColor"),
        DROPDOWN_BACKGROUND("dropdown.background"),
        DROPDOWN_FOREGROUND("dropdown.foreground"),
        DROPDOWN_BORDER("dropdown.border");


        /* JADX INFO: renamed from: G2 */
        private String f47080G2;

        a(String str) {
            this.f47080G2 = str;
        }

        /* JADX INFO: renamed from: c */
        public String m40257c() {
            return this.f47080G2;
        }
    }

    /* JADX INFO: renamed from: f.c.k.g.o.l.c$b */
    public enum b {
        SCHEME_NAME("theme.name"),
        TYPE("theme.type"),
        STATUS_BAR_BACKGROUND("theme.statusbar.background"),
        STATUS_BAR_FOREGROUND("theme.statusbar.foreground");


        /* JADX INFO: renamed from: z2 */
        private String f47086z2;

        b(String str) {
            this.f47086z2 = str;
        }

        /* JADX INFO: renamed from: c */
        public String m40258c() {
            return this.f47086z2;
        }
    }

    /* JADX INFO: renamed from: f */
    private InputStream m40236f() {
        return null;
    }

    /* JADX INFO: renamed from: i */
    private int m40237i(a aVar) {
        return super.m40233a(aVar.m40257c());
    }

    @Override // p356f.p372c.p451k.p452g.p455o.p456l.AbstractC7210a
    /* JADX INFO: renamed from: b */
    public void mo40234b(Properties properties) {
        m40256x(properties.getProperty(b.SCHEME_NAME.m40258c()));
        for (a aVar : a.values()) {
            try {
                m40235c(aVar.m40257c(), Color.parseColor(properties.getProperty(aVar.m40257c())));
            } catch (Exception unused) {
            }
        }
        this.f47061e.mo40234b(properties);
        this.f47062f.mo40234b(properties);
        this.f47063g = C7205g.m40197b(properties);
    }

    /* JADX INFO: renamed from: d */
    protected StackOverflowError m40238d() {
        return null;
    }

    /* JADX INFO: renamed from: e */
    protected InstantiationError m40239e() {
        return null;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C7212c)) {
            return false;
        }
        C7212c c7212c = (C7212c) obj;
        if (m40248p() == null ? c7212c.m40248p() != null : !m40248p().equals(c7212c.m40248p())) {
            return false;
        }
        if (m40253u() == null ? c7212c.m40253u() != null : !m40253u().equals(c7212c.m40253u())) {
            return false;
        }
        if (!Arrays.equals(m40252t(), c7212c.m40252t())) {
            return false;
        }
        if (m40247o() == null ? c7212c.m40247o() != null : !m40247o().equals(c7212c.m40247o())) {
            return false;
        }
        if (m40250r() != null) {
            return m40250r().equals(c7212c.m40250r());
        }
        return c7212c.m40250r() == null;
    }

    /* JADX INFO: renamed from: g */
    public int m40240g() {
        return m40237i(a.BG_COLOR);
    }

    /* JADX INFO: renamed from: h */
    public int m40241h() {
        return m40237i(a.CARENT_COLOR);
    }

    public int hashCode() {
        return ((((((((m40248p() != null ? m40248p().hashCode() : 0) * 31) + (m40253u() != null ? m40253u().hashCode() : 0)) * 31) + Arrays.hashCode(m40252t())) * 31) + (m40247o() != null ? m40247o().hashCode() : 0)) * 31) + (m40250r() != null ? m40250r().hashCode() : 0);
    }

    /* JADX INFO: renamed from: j */
    public int m40242j() {
        return m40237i(a.DROPDOWN_BACKGROUND);
    }

    /* JADX INFO: renamed from: k */
    public int m40243k() {
        return m40237i(a.DROPDOWN_BORDER);
    }

    /* JADX INFO: renamed from: l */
    public int m40244l() {
        return m40237i(a.DROPDOWN_FOREGROUND);
    }

    /* JADX INFO: renamed from: m */
    public int m40245m() {
        return m40237i(a.EOL_MARKER_COLOR);
    }

    /* JADX INFO: renamed from: n */
    public int m40246n() {
        return m40237i(a.FG_COLOR);
    }

    /* JADX INFO: renamed from: o */
    public String m40247o() {
        return this.f47064h;
    }

    /* JADX INFO: renamed from: p */
    public C7213d m40248p() {
        return this.f47061e;
    }

    /* JADX INFO: renamed from: q */
    public int m40249q() {
        return m40237i(a.LINE_HIGHLIGHT_COLOR);
    }

    /* JADX INFO: renamed from: r */
    public String m40250r() {
        return this.f47065i;
    }

    /* JADX INFO: renamed from: s */
    public int m40251s() {
        return m40237i(a.SELECTION_COLOR);
    }

    /* JADX INFO: renamed from: t */
    public C7216g[] m40252t() {
        return this.f47063g;
    }

    /* JADX INFO: renamed from: u */
    public C7218i m40253u() {
        return this.f47062f;
    }

    /* JADX INFO: renamed from: v */
    public int m40254v() {
        return m40237i(a.WRAP_GUIDE_COLOR);
    }

    /* JADX INFO: renamed from: w */
    public void m40255w(String str) {
        this.f47064h = str;
    }

    /* JADX INFO: renamed from: x */
    public void m40256x(String str) {
        int i2;
        if (str.isEmpty()) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(str.replace("-", " "));
        sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
        for (int i3 = 0; i3 < sb.length(); i3++) {
            if (sb.charAt(i3) == ' ' && (i2 = i3 + 1) < sb.length()) {
                sb.setCharAt(i2, Character.toUpperCase(sb.charAt(i2)));
            }
        }
        this.f47065i = sb.toString();
    }
}
