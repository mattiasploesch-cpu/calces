package p356f.p372c.p451k.p452g.p453j;

import android.content.SharedPreferences;
import android.text.Editable;
import android.text.Selection;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.UnderlineSpan;
import android.widget.EditText;
import java.util.LinkedList;

/* JADX INFO: renamed from: f.c.k.g.j.i */
/* JADX INFO: loaded from: classes.dex */
public class C7181i {

    /* JADX INFO: renamed from: a */
    private static final String f46777a = "f.c.k.g.j.i";

    /* JADX INFO: renamed from: b */
    private boolean f46778b = false;

    /* JADX INFO: renamed from: c */
    private c f46779c;

    /* JADX INFO: renamed from: d */
    private e f46780d;

    /* JADX INFO: renamed from: e */
    private EditText f46781e;

    /* JADX INFO: renamed from: f.c.k.g.j.i$b */
    enum b {
        INSERT,
        DELETE,
        PASTE,
        NOT_DEF
    }

    /* JADX INFO: renamed from: f.c.k.g.j.i$c */
    private final class c {

        /* JADX INFO: renamed from: a */
        private final LinkedList<d> f46787a;

        /* JADX INFO: renamed from: b */
        private int f46788b;

        /* JADX INFO: renamed from: c */
        private int f46789c;

        private c() {
            this.f46787a = new LinkedList<>();
            this.f46788b = 0;
            this.f46789c = -1;
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* JADX INFO: renamed from: l */
        public void m40007l(d dVar) {
            while (this.f46787a.size() > this.f46788b) {
                this.f46787a.removeLast();
            }
            this.f46787a.add(dVar);
            this.f46788b++;
            if (this.f46789c >= 0) {
                m40013r();
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* JADX INFO: renamed from: m */
        public void m40008m() {
            this.f46788b = 0;
            this.f46787a.clear();
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* JADX INFO: renamed from: n */
        public d m40009n() {
            int i2 = this.f46788b;
            if (i2 == 0) {
                return null;
            }
            return this.f46787a.get(i2 - 1);
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* JADX INFO: renamed from: o */
        public d m40010o() {
            if (this.f46788b >= this.f46787a.size()) {
                return null;
            }
            d dVar = this.f46787a.get(this.f46788b);
            this.f46788b++;
            return dVar;
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* JADX INFO: renamed from: p */
        public d m40011p() {
            int i2 = this.f46788b;
            if (i2 == 0) {
                return null;
            }
            int i3 = i2 - 1;
            this.f46788b = i3;
            return this.f46787a.get(i3);
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* JADX INFO: renamed from: q */
        public void m40012q(int i2) {
            this.f46789c = i2;
            if (i2 >= 0) {
                m40013r();
            }
        }

        /* JADX INFO: renamed from: r */
        private void m40013r() {
            while (this.f46787a.size() > this.f46789c) {
                this.f46787a.removeFirst();
                this.f46788b--;
            }
            if (this.f46788b < 0) {
                this.f46788b = 0;
            }
        }
    }

    /* JADX INFO: renamed from: f.c.k.g.j.i$d */
    private static final class d {

        /* JADX INFO: renamed from: a */
        private int f46791a;

        /* JADX INFO: renamed from: b */
        private CharSequence f46792b;

        /* JADX INFO: renamed from: c */
        private CharSequence f46793c;

        public d(int i2, CharSequence charSequence, CharSequence charSequence2) {
            this.f46791a = i2;
            this.f46792b = charSequence;
            this.f46793c = charSequence2;
        }

        public String toString() {
            return "EditItem{mmStart=" + this.f46791a + ", mmBefore=" + ((Object) this.f46792b) + ", mmAfter=" + ((Object) this.f46793c) + '}';
        }
    }

    /* JADX INFO: renamed from: f.c.k.g.j.i$e */
    private final class e implements TextWatcher {

        /* JADX INFO: renamed from: u2 */
        private CharSequence f46794u2;

        /* JADX INFO: renamed from: v2 */
        private CharSequence f46795v2;

        /* JADX INFO: renamed from: w2 */
        private b f46796w2;

        /* JADX INFO: renamed from: x2 */
        private long f46797x2;

        private e() {
            this.f46796w2 = b.NOT_DEF;
            this.f46797x2 = 0L;
        }

        /* JADX INFO: renamed from: a */
        private b m40020a() {
            if (TextUtils.isEmpty(this.f46794u2) || !TextUtils.isEmpty(this.f46795v2)) {
                return (!TextUtils.isEmpty(this.f46794u2) || TextUtils.isEmpty(this.f46795v2)) ? b.PASTE : b.INSERT;
            }
            return b.DELETE;
        }

        /* JADX INFO: renamed from: b */
        private void m40021b(int i2) {
            b bVarM40020a = m40020a();
            d dVarM40009n = C7181i.this.f46779c.m40009n();
            if (this.f46796w2 != bVarM40020a || b.PASTE == bVarM40020a || System.currentTimeMillis() - this.f46797x2 > 1000 || dVarM40009n == null) {
                C7181i.this.f46779c.m40007l(new d(i2, this.f46794u2, this.f46795v2));
            } else if (bVarM40020a == b.DELETE) {
                dVarM40009n.f46791a = i2;
                dVarM40009n.f46792b = TextUtils.concat(this.f46794u2, dVarM40009n.f46792b);
            } else {
                dVarM40009n.f46793c = TextUtils.concat(dVarM40009n.f46793c, this.f46795v2);
            }
            this.f46796w2 = bVarM40020a;
            this.f46797x2 = System.currentTimeMillis();
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
            if (C7181i.this.f46778b) {
                return;
            }
            this.f46794u2 = charSequence.subSequence(i2, i3 + i2);
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
            if (C7181i.this.f46778b) {
                return;
            }
            this.f46795v2 = charSequence.subSequence(i2, i4 + i2);
            m40021b(i2);
        }
    }

    public C7181i(EditText editText) {
        this.f46781e = editText;
        this.f46779c = new c();
        this.f46780d = new e();
    }

    /* JADX INFO: renamed from: f */
    private boolean m39985f(SharedPreferences sharedPreferences, String str) {
        String string = sharedPreferences.getString(str + ".hash", null);
        if (string == null) {
            return true;
        }
        if (Integer.valueOf(string).intValue() != this.f46781e.getText().toString().hashCode()) {
            return false;
        }
        this.f46779c.m40008m();
        this.f46779c.f46789c = sharedPreferences.getInt(str + ".maxSize", -1);
        int i2 = sharedPreferences.getInt(str + ".size", -1);
        if (i2 == -1) {
            return false;
        }
        for (int i3 = 0; i3 < i2; i3++) {
            String str2 = str + "." + i3;
            int i4 = sharedPreferences.getInt(str2 + ".start", -1);
            String string2 = sharedPreferences.getString(str2 + ".before", null);
            String string3 = sharedPreferences.getString(str2 + ".after", null);
            if (i4 == -1 || string2 == null || string3 == null) {
                return false;
            }
            this.f46779c.m40007l(new d(i4, string2, string3));
        }
        this.f46779c.f46788b = sharedPreferences.getInt(str + ".position", -1);
        return this.f46779c.f46788b != -1;
    }

    /* JADX INFO: renamed from: c */
    public void m39986c() {
        this.f46781e.addTextChangedListener(this.f46780d);
    }

    /* JADX INFO: renamed from: d */
    public void m39987d() {
        this.f46779c.m40008m();
    }

    /* JADX INFO: renamed from: e */
    public void m39988e() {
        this.f46781e.removeTextChangedListener(this.f46780d);
    }

    /* JADX INFO: renamed from: g */
    public boolean m39989g() {
        return this.f46779c.f46788b < this.f46779c.f46787a.size();
    }

    /* JADX INFO: renamed from: h */
    public boolean m39990h() {
        return this.f46779c.f46788b > 0;
    }

    /* JADX INFO: renamed from: i */
    public void m39991i() {
        d dVarM40010o = this.f46779c.m40010o();
        if (dVarM40010o == null) {
            return;
        }
        Editable editableText = this.f46781e.getEditableText();
        int length = dVarM40010o.f46791a;
        int length2 = dVarM40010o.f46792b != null ? dVarM40010o.f46792b.length() : 0;
        this.f46778b = true;
        editableText.replace(length, length2 + length, dVarM40010o.f46793c);
        this.f46778b = false;
        for (UnderlineSpan underlineSpan : (UnderlineSpan[]) editableText.getSpans(0, editableText.length(), UnderlineSpan.class)) {
            editableText.removeSpan(underlineSpan);
        }
        if (dVarM40010o.f46793c != null) {
            length += dVarM40010o.f46793c.length();
        }
        Selection.setSelection(editableText, length);
    }

    /* JADX INFO: renamed from: j */
    public boolean m39992j(SharedPreferences sharedPreferences, String str) {
        boolean zM39985f = m39985f(sharedPreferences, str);
        if (!zM39985f) {
            this.f46779c.m40008m();
        }
        return zM39985f;
    }

    /* JADX INFO: renamed from: k */
    public void m39993k(int i2) {
        this.f46779c.m40012q(i2);
    }

    /* JADX INFO: renamed from: l */
    public void m39994l(SharedPreferences.Editor editor, String str) {
        editor.putString(str + ".hash", String.valueOf(this.f46781e.getText().toString().hashCode()));
        editor.putInt(str + ".maxSize", this.f46779c.f46789c);
        editor.putInt(str + ".position", this.f46779c.f46788b);
        editor.putInt(str + ".size", this.f46779c.f46787a.size());
        int i2 = 0;
        for (d dVar : this.f46779c.f46787a) {
            String str2 = str + "." + i2;
            editor.putInt(str2 + ".start", dVar.f46791a);
            editor.putString(str2 + ".before", dVar.f46792b.toString());
            editor.putString(str2 + ".after", dVar.f46793c.toString());
            i2++;
        }
    }

    /* JADX INFO: renamed from: m */
    public void m39995m() {
        d dVarM40011p = this.f46779c.m40011p();
        if (dVarM40011p == null) {
            return;
        }
        Editable editableText = this.f46781e.getEditableText();
        int length = dVarM40011p.f46791a;
        int length2 = dVarM40011p.f46793c != null ? dVarM40011p.f46793c.length() : 0;
        this.f46778b = true;
        editableText.replace(length, length2 + length, dVarM40011p.f46792b);
        this.f46778b = false;
        for (UnderlineSpan underlineSpan : (UnderlineSpan[]) editableText.getSpans(0, editableText.length(), UnderlineSpan.class)) {
            editableText.removeSpan(underlineSpan);
        }
        if (dVarM40011p.f46792b != null) {
            length += dVarM40011p.f46792b.length();
        }
        Selection.setSelection(editableText, length);
    }
}
