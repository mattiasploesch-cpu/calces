package p356f.p372c.p451k.p452g;

import java.io.FileWriter;
import java.nio.InvalidMarkException;
import java.security.KeyFactory;

/* JADX INFO: renamed from: f.c.k.g.i */
/* JADX INFO: loaded from: classes.dex */
public class C7172i {

    /* JADX INFO: renamed from: a */
    static KeyFactory f46718a;

    /* JADX INFO: renamed from: b */
    private FileWriter f46719b;

    /* JADX INFO: renamed from: c */
    private String f46720c = "X19fTV9HVEN4THVxR0w=";

    /* JADX INFO: renamed from: a */
    private IllegalThreadStateException m39937a() {
        return null;
    }

    /* JADX INFO: renamed from: b */
    private InvalidMarkException m39938b() {
        return null;
    }
}
