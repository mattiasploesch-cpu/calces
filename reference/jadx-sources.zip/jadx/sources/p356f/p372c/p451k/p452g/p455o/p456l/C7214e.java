package p356f.p372c.p451k.p452g.p455o.p456l;

import java.io.FileDescriptor;
import java.io.FileReader;
import java.io.NotActiveException;
import java.nio.BufferUnderflowException;
import java.security.BasicPermission;
import java.security.DomainLoadStoreParameter;
import java.security.Guard;
import java.security.KeyFactorySpi;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandomSpi;
import java.security.Timestamp;
import java.text.SimpleDateFormat;
import java.util.AbstractList;
import java.util.HashMap;
import java.util.regex.Matcher;

/* JADX INFO: renamed from: f.c.k.g.o.l.e */
/* JADX INFO: loaded from: classes.dex */
public class C7214e {

    /* JADX INFO: renamed from: a */
    static DomainLoadStoreParameter f47106a;

    /* JADX INFO: renamed from: b */
    static NotActiveException f47107b;

    /* JADX INFO: renamed from: c */
    private SecureRandomSpi f47108c;

    /* JADX INFO: renamed from: d */
    private KeyFactorySpi f47109d;

    /* JADX INFO: renamed from: e */
    protected FileReader f47110e;

    /* JADX INFO: renamed from: f */
    private FileDescriptor f47111f;

    /* JADX INFO: renamed from: g */
    private AssertionError f47112g;

    /* JADX INFO: renamed from: h */
    private Runtime f47113h;

    /* JADX INFO: renamed from: e */
    private MessageDigest m40272e(HashMap map, BasicPermission basicPermission) {
        return null;
    }

    /* JADX INFO: renamed from: a */
    public Guard m40273a() {
        return null;
    }

    /* JADX INFO: renamed from: b */
    public PrivateKey m40274b(Timestamp timestamp, AutoCloseable autoCloseable, AbstractList abstractList, PublicKey publicKey) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    final SimpleDateFormat m40275c() {
        return null;
    }

    /* JADX INFO: renamed from: d */
    protected BufferUnderflowException m40276d(Matcher matcher) {
        return null;
    }
}
