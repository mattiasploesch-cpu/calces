package p356f.p372c.p451k.p452g.p455o.p456l;

import android.graphics.Color;
import java.io.FilterWriter;
import java.io.LineNumberReader;
import java.math.BigInteger;
import java.util.Properties;

/* JADX INFO: renamed from: f.c.k.g.o.l.d */
/* JADX INFO: loaded from: classes.dex */
public class C7213d extends AbstractC7210a {

    /* JADX INFO: renamed from: d */
    private static final String f47087d = "GutterStyle";

    /* JADX INFO: renamed from: e */
    public IllegalThreadStateException f47088e;

    /* JADX INFO: renamed from: f */
    protected FilterWriter f47089f;

    /* JADX INFO: renamed from: g */
    private BigInteger f47090g;

    /* JADX INFO: renamed from: h */
    protected String f47091h = "X19fWEZLTWJCaGhNZUE=";

    /* JADX INFO: renamed from: i */
    public String f47092i = "X19fV1llQmtrSW5f";

    /* JADX INFO: renamed from: j */
    protected String f47093j = "X19fSnVJX1hfbXg=";

    /* JADX INFO: renamed from: f.c.k.g.o.l.d$a */
    public enum a {
        VIEW_GUTTER_BG_COLOR("view.gutter.bgColor"),
        VIEW_GUTTER_CURRENT_LINE_COLOR("view.gutter.currentLineColor"),
        VIEW_GUTTER_FG_COLOR("view.gutter.fgColor"),
        VIEW_GUTTER_FOCUS_BORDER_COLOR("view.gutter.focusBorderColor"),
        VIEW_GUTTER_FOLD_COLOR("view.gutter.foldColor"),
        VIEW_GUTTER_HIGHLIGHT_COLOR("view.gutter.highlightColor"),
        VIEW_GUTTER_MARKER_COLOR("view.gutter.markerColor"),
        VIEW_GUTTER_NO_FOCUS_BORDER_COLOR("view.gutter.noFocusBorderColor"),
        VIEW_GUTTER_REGISTER_COLOR("view.gutter.registerColor"),
        VIEW_GUTTER_STRUCTURE_HIGHLIGHT_COLOR("view.gutter.structureHighlightColor");


        /* JADX INFO: renamed from: F2 */
        private String f47105F2;

        a(String str) {
            this.f47105F2 = str;
        }

        /* JADX INFO: renamed from: c */
        public String m40271c() {
            return this.f47105F2;
        }
    }

    /* JADX INFO: renamed from: g */
    private int m40259g(a aVar) {
        return super.m40233a(aVar.m40271c());
    }

    @Override // p356f.p372c.p451k.p452g.p455o.p456l.AbstractC7210a
    /* JADX INFO: renamed from: b */
    public void mo40234b(Properties properties) {
        for (a aVar : a.values()) {
            try {
                m40235c(aVar.m40271c(), Color.parseColor(properties.getProperty(aVar.m40271c())));
            } catch (Exception unused) {
            }
        }
    }

    /* JADX INFO: renamed from: d */
    public LineNumberReader m40260d() {
        return null;
    }

    /* JADX INFO: renamed from: e */
    public UnsupportedOperationException m40261e() {
        return null;
    }

    /* JADX INFO: renamed from: f */
    public int m40262f() {
        return m40259g(a.VIEW_GUTTER_BG_COLOR);
    }

    /* JADX INFO: renamed from: h */
    public int m40263h() {
        return m40259g(a.VIEW_GUTTER_CURRENT_LINE_COLOR);
    }

    /* JADX INFO: renamed from: i */
    public int m40264i() {
        return m40259g(a.VIEW_GUTTER_FG_COLOR);
    }

    /* JADX INFO: renamed from: j */
    public int m40265j() {
        return m40259g(a.VIEW_GUTTER_FOCUS_BORDER_COLOR);
    }

    /* JADX INFO: renamed from: k */
    public int m40266k() {
        return m40259g(a.VIEW_GUTTER_FOLD_COLOR);
    }

    /* JADX INFO: renamed from: l */
    public int m40267l() {
        return m40259g(a.VIEW_GUTTER_HIGHLIGHT_COLOR);
    }

    /* JADX INFO: renamed from: m */
    public int m40268m() {
        return m40259g(a.VIEW_GUTTER_MARKER_COLOR);
    }

    /* JADX INFO: renamed from: n */
    public int m40269n() {
        return m40259g(a.VIEW_GUTTER_NO_FOCUS_BORDER_COLOR);
    }

    /* JADX INFO: renamed from: o */
    public int m40270o() {
        return m40259g(a.VIEW_GUTTER_REGISTER_COLOR);
    }
}
