package p356f.p372c.p451k.p452g.p453j;

import java.io.PipedReader;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.security.DigestException;
import java.security.Guard;
import java.security.IdentityScope;
import java.security.MessageDigestSpi;
import java.security.PermissionCollection;
import java.security.SecureRandom;
import java.text.DecimalFormatSymbols;
import java.text.ParsePosition;
import java.time.DateTimeException;
import java.time.MonthDay;
import java.time.ZonedDateTime;
import java.util.Stack;

/* JADX INFO: renamed from: f.c.k.g.j.d */
/* JADX INFO: loaded from: classes.dex */
public class C7176d {

    /* JADX INFO: renamed from: a */
    public IdentityScope f46735a;

    /* JADX INFO: renamed from: b */
    protected ByteBuffer f46736b;

    /* JADX INFO: renamed from: c */
    public Long f46737c;

    /* JADX INFO: renamed from: d */
    public Exception f46738d;

    /* JADX INFO: renamed from: e */
    protected IllegalAccessException f46739e;

    /* JADX INFO: renamed from: f */
    private String f46740f = "X19fU05mTmVLQ25URlJE";

    /* JADX INFO: renamed from: g */
    private String f46741g = "X19fWFJhR3ZoWWRQcmJhcmg=";

    /* JADX INFO: renamed from: h */
    public String f46742h = "X19fbnZZcEhwTWtJYmhHSA==";

    /* JADX INFO: renamed from: c */
    private EnumConstantNotPresentException m39958c(UnsupportedOperationException unsupportedOperationException) {
        return null;
    }

    /* JADX INFO: renamed from: a */
    Boolean m39959a() {
        return null;
    }

    /* JADX INFO: renamed from: b */
    protected InheritableThreadLocal m39960b(DateTimeException dateTimeException, MonthDay monthDay, DecimalFormatSymbols decimalFormatSymbols, Byte b2, IllegalThreadStateException illegalThreadStateException) {
        return null;
    }

    /* JADX INFO: renamed from: d */
    final SecureRandom m39961d(NoSuchFieldException noSuchFieldException, DecimalFormatSymbols decimalFormatSymbols, ZonedDateTime zonedDateTime, ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException, IllegalAccessError illegalAccessError) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    public UnsatisfiedLinkError m39962e() {
        return null;
    }

    /* JADX INFO: renamed from: f */
    public PipedReader m39963f(Integer num, ArithmeticException arithmeticException, MappedByteBuffer mappedByteBuffer) {
        return null;
    }

    /* JADX INFO: renamed from: g */
    final ParsePosition m39964g(Package r1) {
        return null;
    }

    /* JADX INFO: renamed from: h */
    public Stack m39965h(Guard guard, PermissionCollection permissionCollection, MessageDigestSpi messageDigestSpi, DigestException digestException) {
        return null;
    }
}
