package p356f.p372c.p451k.p452g;

import java.io.CharArrayReader;
import java.io.CharConversionException;
import java.io.DataInputStream;
import java.io.File;
import java.io.FilePermission;
import java.io.InputStream;
import java.io.InvalidObjectException;
import java.io.ObjectOutputStream;
import java.io.SyncFailedException;
import java.nio.Buffer;
import java.nio.FloatBuffer;
import java.security.DigestException;
import java.security.DigestOutputStream;
import java.security.Guard;
import java.security.KeyManagementException;
import java.security.KeyPairGenerator;
import java.security.KeyPairGeneratorSpi;
import java.security.Principal;
import java.security.PrivilegedExceptionAction;
import java.security.Provider;
import java.security.Signature;
import java.security.SignatureSpi;
import java.security.UnrecoverableKeyException;
import java.text.Bidi;
import java.text.ChoiceFormat;
import java.util.AbstractList;
import java.util.ArrayDeque;

/* JADX INFO: renamed from: f.c.k.g.g */
/* JADX INFO: loaded from: classes.dex */
public class C7170g {

    /* JADX INFO: renamed from: a */
    protected CharArrayReader f46700a;

    /* JADX INFO: renamed from: b */
    protected Math f46701b;

    /* JADX INFO: renamed from: c */
    private Signature f46702c;

    /* JADX INFO: renamed from: d */
    protected ChoiceFormat f46703d;

    /* JADX INFO: renamed from: e */
    private IllegalAccessError f46704e;

    /* JADX INFO: renamed from: f */
    transient Double f46705f;

    /* JADX INFO: renamed from: g */
    public InstantiationException f46706g;

    /* JADX INFO: renamed from: h */
    volatile Buffer f46707h;

    /* JADX INFO: renamed from: i */
    transient Double f46708i;

    /* JADX INFO: renamed from: g */
    private KeyPairGeneratorSpi m39919g(InputStream inputStream, UnrecoverableKeyException unrecoverableKeyException, SyncFailedException syncFailedException, Buffer buffer, Principal principal) {
        return null;
    }

    /* JADX INFO: renamed from: i */
    static DigestException m39920i(System system, File file, Signature signature) {
        return null;
    }

    /* JADX INFO: renamed from: a */
    protected KeyManagementException m39921a(ProcessBuilder processBuilder) {
        return null;
    }

    /* JADX INFO: renamed from: b */
    Provider m39922b(DataInputStream dataInputStream, FilePermission filePermission) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    public AbstractList m39923c() {
        return null;
    }

    /* JADX INFO: renamed from: d */
    public Guard m39924d(CharConversionException charConversionException) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    synchronized Bidi m39925e(SignatureSpi signatureSpi, NegativeArraySizeException negativeArraySizeException, InvalidObjectException invalidObjectException, ArrayDeque arrayDeque, ObjectOutputStream objectOutputStream) {
        return null;
    }

    /* JADX INFO: renamed from: f */
    synchronized KeyPairGenerator m39926f(ClassCastException classCastException) {
        return null;
    }

    /* JADX INFO: renamed from: h */
    synchronized Exception m39927h(FloatBuffer floatBuffer, PrivilegedExceptionAction privilegedExceptionAction, DigestOutputStream digestOutputStream) {
        return null;
    }
}
