package p356f.p372c.p451k.p452g.p455o.p456l;

import java.io.CharArrayWriter;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.MappedByteBuffer;
import java.security.AccessController;
import java.security.MessageDigest;
import java.security.PrivilegedActionException;
import java.util.AbstractCollection;
import p148e.p150d.p154l.ViewOnClickListenerC5073g;
import p356f.p372c.p375g.p376d.p377a.C6822b;

/* JADX INFO: renamed from: f.c.k.g.o.l.f */
/* JADX INFO: loaded from: classes.dex */
public class C7215f {

    /* JADX INFO: renamed from: a */
    volatile Number f47114a;

    /* JADX INFO: renamed from: b */
    private ViewOnClickListenerC5073g f47115b;

    /* JADX INFO: renamed from: c */
    public OutputStream f47116c;

    /* JADX INFO: renamed from: d */
    transient UnsupportedOperationException f47117d;

    /* JADX INFO: renamed from: e */
    protected Throwable f47118e;

    /* JADX INFO: renamed from: f */
    protected PrivilegedActionException f47119f;

    /* JADX INFO: renamed from: g */
    transient InstantiationException f47120g;

    /* JADX INFO: renamed from: h */
    protected StringBuilder f47121h;

    /* JADX INFO: renamed from: i */
    protected NoClassDefFoundError f47122i;

    /* JADX INFO: renamed from: j */
    protected IOException f47123j;

    /* JADX INFO: renamed from: k */
    protected CharArrayWriter f47124k;

    /* JADX INFO: renamed from: l */
    private String f47125l = "X19fSk1BeGdva1NnZg==";

    /* JADX INFO: renamed from: m */
    protected String f47126m = "X19fcGNSRmlHY1hsZA==";

    /* JADX INFO: renamed from: a */
    static Error m40277a(MappedByteBuffer mappedByteBuffer, C6822b c6822b) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    static MessageDigest m40278c() {
        return null;
    }

    /* JADX INFO: renamed from: b */
    synchronized Enum m40279b(AbstractCollection abstractCollection, DataOutputStream dataOutputStream) {
        return null;
    }

    /* JADX INFO: renamed from: d */
    protected AccessController m40280d(MappedByteBuffer mappedByteBuffer, LinkageError linkageError) {
        return null;
    }
}
