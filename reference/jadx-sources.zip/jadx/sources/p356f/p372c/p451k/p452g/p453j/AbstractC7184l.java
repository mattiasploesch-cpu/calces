package p356f.p372c.p451k.p452g.p453j;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilePermission;
import java.io.LineNumberReader;
import java.io.OutputStreamWriter;
import java.io.SequenceInputStream;
import java.io.UnsupportedEncodingException;
import java.nio.Buffer;
import java.security.CodeSigner;
import java.security.InvalidParameterException;
import java.security.KeyStoreException;
import java.security.UnrecoverableKeyException;
import java.text.ChoiceFormat;
import java.time.Instant;
import java.time.LocalDate;

/* JADX INFO: renamed from: f.c.k.g.j.l */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC7184l {

    /* JADX INFO: renamed from: a */
    volatile Short f46819a;

    /* JADX INFO: renamed from: b */
    volatile InvalidParameterException f46820b;

    /* JADX INFO: renamed from: c */
    private StackTraceElement f46821c;

    /* JADX INFO: renamed from: d */
    public Short f46822d;

    /* JADX INFO: renamed from: e */
    public String f46823e;

    /* JADX INFO: renamed from: f */
    protected UnsupportedEncodingException f46824f;

    /* JADX INFO: renamed from: g */
    public String f46825g = "X19fZ2VwZ0JY";

    AbstractC7184l() {
    }

    /* JADX INFO: renamed from: a */
    static LocalDate m40034a(DataOutputStream dataOutputStream) {
        return null;
    }

    /* JADX INFO: renamed from: b */
    public KeyStoreException m40035b(FilePermission filePermission, Short sh, DataOutputStream dataOutputStream, Readable readable, Short sh2) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    Instant m40036c(BufferedReader bufferedReader, OutputStreamWriter outputStreamWriter) {
        return null;
    }

    /* JADX INFO: renamed from: d */
    public Number m40037d() {
        return null;
    }

    /* JADX INFO: renamed from: e */
    public LineNumberReader m40038e() {
        return null;
    }

    /* JADX INFO: renamed from: f */
    public SequenceInputStream m40039f() {
        return null;
    }

    /* JADX INFO: renamed from: g */
    final NoSuchMethodException m40040g(Buffer buffer, InheritableThreadLocal inheritableThreadLocal, FileNotFoundException fileNotFoundException, FileOutputStream fileOutputStream, CodeSigner codeSigner, UnrecoverableKeyException unrecoverableKeyException) {
        return null;
    }

    /* JADX INFO: renamed from: h */
    public ChoiceFormat m40041h(Throwable th) {
        return null;
    }
}
