package p356f.p372c.p451k.p452g;

import java.io.BufferedInputStream;
import java.io.DataInput;
import java.io.IOException;
import java.io.OptionalDataException;
import java.io.PipedWriter;
import java.io.PrintWriter;
import java.io.PushbackInputStream;
import java.io.StringBufferInputStream;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.security.AccessController;
import java.security.AlgorithmParameterGenerator;
import java.security.IdentityScope;
import java.security.InvalidAlgorithmParameterException;
import java.security.MessageDigestSpi;
import java.security.PermissionCollection;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.security.SecureRandomSpi;
import java.security.Security;
import java.text.Collator;
import java.text.ParsePosition;
import java.time.MonthDay;
import java.time.Year;
import java.util.AbstractCollection;
import java.util.AbstractQueue;
import java.util.Collections;

/* JADX INFO: renamed from: f.c.k.g.h */
/* JADX INFO: loaded from: classes.dex */
final class C7171h {

    /* JADX INFO: renamed from: a */
    transient ThreadLocal f46709a;

    /* JADX INFO: renamed from: b */
    volatile AbstractMethodError f46710b;

    /* JADX INFO: renamed from: c */
    private PipedWriter f46711c;

    /* JADX INFO: renamed from: d */
    volatile String f46712d;

    /* JADX INFO: renamed from: e */
    volatile RuntimeException f46713e;

    /* JADX INFO: renamed from: f */
    protected Iterable f46714f;

    /* JADX INFO: renamed from: g */
    private ThreadGroup f46715g;

    /* JADX INFO: renamed from: h */
    public SecurityManager f46716h;

    /* JADX INFO: renamed from: i */
    transient Number f46717i;

    C7171h() {
    }

    /* JADX INFO: renamed from: b */
    private ShortBuffer m39928b(ClassFormatError classFormatError, IdentityScope identityScope) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    static Integer m39929e(PrivilegedExceptionAction privilegedExceptionAction, Appendable appendable, Collections collections, AbstractQueue abstractQueue, SecurityManager securityManager) {
        return null;
    }

    /* JADX INFO: renamed from: f */
    static Enum m39930f(FloatBuffer floatBuffer, PrivilegedActionException privilegedActionException, OptionalDataException optionalDataException, PermissionCollection permissionCollection, IOException iOException) {
        return null;
    }

    /* JADX INFO: renamed from: h */
    private PushbackInputStream m39931h(MonthDay monthDay, DataInput dataInput, Class cls, Void r4) {
        return null;
    }

    /* JADX INFO: renamed from: a */
    AbstractCollection m39932a(Void r1, Year year, ParsePosition parsePosition, MessageDigestSpi messageDigestSpi) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    protected Security m39933c(StringBufferInputStream stringBufferInputStream, Exception exc) {
        return null;
    }

    /* JADX INFO: renamed from: d */
    synchronized BufferedInputStream m39934d(MessageDigestSpi messageDigestSpi, PrintWriter printWriter, PrivilegedExceptionAction privilegedExceptionAction, StringBuffer stringBuffer, InheritableThreadLocal inheritableThreadLocal, StackTraceElement stackTraceElement) {
        return null;
    }

    /* JADX INFO: renamed from: g */
    PrivilegedExceptionAction m39935g(Collator collator, VirtualMachineError virtualMachineError) {
        return null;
    }

    /* JADX INFO: renamed from: i */
    SecureRandomSpi m39936i(InvalidAlgorithmParameterException invalidAlgorithmParameterException, AccessController accessController, AlgorithmParameterGenerator algorithmParameterGenerator, StringBuilder sb, Security security) {
        return null;
    }
}
