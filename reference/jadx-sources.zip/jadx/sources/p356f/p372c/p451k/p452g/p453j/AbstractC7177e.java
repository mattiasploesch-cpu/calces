package p356f.p372c.p451k.p452g.p453j;

import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.FileWriter;
import java.io.FilterReader;
import java.io.FilterWriter;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.ObjectInputValidation;
import java.io.ObjectOutput;
import java.io.OptionalDataException;
import java.io.SerializablePermission;
import java.nio.MappedByteBuffer;
import java.security.AccessController;
import java.security.CodeSource;
import java.security.DomainLoadStoreParameter;
import java.security.InvalidParameterException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PKCS12Attribute;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.text.AttributedCharacterIterator;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.time.Clock;
import java.time.Month;
import java.time.MonthDay;
import java.time.OffsetTime;
import java.time.Period;
import java.util.Comparator;
import p148e.p150d.p154l.C5069c;

/* JADX INFO: renamed from: f.c.k.g.j.e */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC7177e {

    /* JADX INFO: renamed from: a */
    static InternalError f46743a;

    /* JADX INFO: renamed from: b */
    static NoSuchAlgorithmException f46744b;

    /* JADX INFO: renamed from: c */
    static C5069c f46745c;

    /* JADX INFO: renamed from: d */
    static ObjectInputValidation f46746d;

    /* JADX INFO: renamed from: e */
    protected SerializablePermission f46747e;

    /* JADX INFO: renamed from: f */
    volatile CodeSource f46748f;

    /* JADX INFO: renamed from: g */
    protected RuntimePermission f46749g;

    /* JADX INFO: renamed from: h */
    volatile StringBuffer f46750h;

    /* JADX INFO: renamed from: i */
    private FileWriter f46751i;

    AbstractC7177e() {
    }

    /* JADX INFO: renamed from: c */
    static KeyStoreException m39966c(Long l2, FilterWriter filterWriter, Period period, ArrayStoreException arrayStoreException, ClassLoader classLoader, ObjectOutput objectOutput) {
        return null;
    }

    /* JADX INFO: renamed from: f */
    static FilterReader m39967f(InvalidParameterException invalidParameterException, Comparator comparator, SimpleDateFormat simpleDateFormat, PublicKey publicKey, MappedByteBuffer mappedByteBuffer) {
        return null;
    }

    /* JADX INFO: renamed from: h */
    static InheritableThreadLocal m39968h(OptionalDataException optionalDataException) {
        return null;
    }

    /* JADX INFO: renamed from: a */
    synchronized AttributedCharacterIterator m39969a(ObjectInputStream objectInputStream) {
        return null;
    }

    /* JADX INFO: renamed from: b */
    public DomainLoadStoreParameter m39970b(AccessController accessController, InheritableThreadLocal inheritableThreadLocal, Number number, OffsetTime offsetTime, ClassLoader classLoader, Certificate certificate) {
        return null;
    }

    /* JADX INFO: renamed from: d */
    public ByteArrayInputStream m39971d(InvalidParameterException invalidParameterException, Closeable closeable, ParsePosition parsePosition) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    public ClassCastException m39972e(PKCS12Attribute pKCS12Attribute, MonthDay monthDay, InvalidObjectException invalidObjectException, Short sh, StringIndexOutOfBoundsException stringIndexOutOfBoundsException, Clock clock) {
        return null;
    }

    /* JADX INFO: renamed from: g */
    UnsatisfiedLinkError m39973g(Double d2, Month month) {
        return null;
    }
}
