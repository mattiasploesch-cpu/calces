package p356f.p372c.p451k.p452g;

import java.io.Console;
import java.io.FileNotFoundException;
import java.io.InterruptedIOException;
import java.io.InvalidClassException;
import java.io.ObjectOutput;
import java.io.ObjectStreamField;
import java.io.SerializablePermission;
import java.io.StreamTokenizer;
import java.security.AlgorithmParameterGenerator;
import java.security.AlgorithmParameters;
import java.security.KeyFactory;
import java.security.Permission;
import java.security.PermissionCollection;
import java.security.PrivilegedAction;
import java.security.SecureRandomSpi;
import java.time.DayOfWeek;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import p148e.p150d.p153k.C5062a;
import p148e.p150d.p153k.C5065d;
import p148e.p150d.p154l.ViewOnClickListenerC5067a;

/* JADX INFO: renamed from: f.c.k.g.m */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC7188m {

    /* JADX INFO: renamed from: a */
    static StringBuilder f46847a;

    /* JADX INFO: renamed from: b */
    public PermissionCollection f46848b;

    /* JADX INFO: renamed from: c */
    protected AlgorithmParameterGenerator f46849c;

    /* JADX INFO: renamed from: d */
    volatile SerializablePermission f46850d;

    /* JADX INFO: renamed from: e */
    transient IllegalAccessError f46851e;

    /* JADX INFO: renamed from: f */
    public C5065d f46852f;

    AbstractC7188m() {
    }

    /* JADX INFO: renamed from: c */
    static IllegalArgumentException m40057c() {
        return null;
    }

    /* JADX INFO: renamed from: h */
    static ObjectOutput m40058h(Comparable comparable, Boolean bool, Permission permission, ZonedDateTime zonedDateTime, ThreadGroup threadGroup, C5062a c5062a) {
        return null;
    }

    /* JADX INFO: renamed from: a */
    ZoneOffset m40059a() {
        return null;
    }

    /* JADX INFO: renamed from: b */
    protected StreamTokenizer m40060b(Cloneable cloneable, InterruptedIOException interruptedIOException, C5065d c5065d, StringBuilder sb) {
        return null;
    }

    /* JADX INFO: renamed from: d */
    ViewOnClickListenerC5067a m40061d(AlgorithmParameters algorithmParameters, SecureRandomSpi secureRandomSpi, Number number, InterruptedIOException interruptedIOException) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    public PrivilegedAction m40062e() {
        return null;
    }

    /* JADX INFO: renamed from: f */
    synchronized Enum m40063f() {
        return null;
    }

    /* JADX INFO: renamed from: g */
    DayOfWeek m40064g(StringBuilder sb, Void r2, Console console, FileNotFoundException fileNotFoundException, KeyFactory keyFactory, ObjectStreamField objectStreamField) {
        return null;
    }

    /* JADX INFO: renamed from: i */
    public ArrayList m40065i(InvalidClassException invalidClassException, ReflectiveOperationException reflectiveOperationException, IllegalThreadStateException illegalThreadStateException, Thread thread) {
        return null;
    }
}
