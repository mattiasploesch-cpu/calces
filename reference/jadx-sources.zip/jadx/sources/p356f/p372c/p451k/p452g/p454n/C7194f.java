package p356f.p372c.p451k.p452g.p454n;

import java.io.CharArrayReader;
import java.io.FilePermission;
import java.io.FilterInputStream;
import java.io.Flushable;
import java.io.InvalidObjectException;
import java.io.ObjectStreamField;
import java.io.PipedOutputStream;
import java.io.PrintWriter;
import java.io.PushbackReader;
import java.io.SerializablePermission;
import java.io.StringReader;
import java.io.UncheckedIOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.DoubleBuffer;
import java.nio.InvalidMarkException;
import java.nio.ReadOnlyBufferException;
import java.security.AlgorithmParametersSpi;
import java.security.IdentityScope;
import java.security.ProviderException;
import java.text.CollationElementIterator;
import java.text.FieldPosition;
import java.time.Clock;
import java.time.DateTimeException;
import java.util.ArrayList;

/* JADX INFO: renamed from: f.c.k.g.n.f */
/* JADX INFO: loaded from: classes.dex */
public class C7194f {

    /* JADX INFO: renamed from: a */
    static SerializablePermission f46906a;

    /* JADX INFO: renamed from: b */
    private DateTimeException f46907b;

    /* JADX INFO: renamed from: c */
    public AlgorithmParametersSpi f46908c;

    /* JADX INFO: renamed from: d */
    public ReadOnlyBufferException f46909d;

    /* JADX INFO: renamed from: e */
    transient UncheckedIOException f46910e;

    /* JADX INFO: renamed from: f */
    public CharArrayReader f46911f;

    /* JADX INFO: renamed from: g */
    public StringReader f46912g;

    /* JADX INFO: renamed from: h */
    protected InvalidObjectException f46913h;

    /* JADX INFO: renamed from: i */
    protected Byte f46914i;

    /* JADX INFO: renamed from: j */
    public String f46915j = "X19fZWRydVNERGdzb19RbEQ=";

    /* JADX INFO: renamed from: k */
    public String f46916k = "X19fSEJGSWVLSG1GYmJP";

    /* JADX INFO: renamed from: l */
    private String f46917l = "X19fT0xrUURSTV9JWQ==";

    /* JADX INFO: renamed from: h */
    private ProviderException m40120h(String str, Runnable runnable, ThreadLocal threadLocal, FieldPosition fieldPosition) {
        return null;
    }

    /* JADX INFO: renamed from: a */
    ObjectStreamField m40121a(BigInteger bigInteger) {
        return null;
    }

    /* JADX INFO: renamed from: b */
    synchronized CollationElementIterator m40122b(Package r1, NegativeArraySizeException negativeArraySizeException, ArrayList arrayList, UncheckedIOException uncheckedIOException, FilterInputStream filterInputStream, AutoCloseable autoCloseable) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    public StackTraceElement m40123c(InvalidMarkException invalidMarkException, DoubleBuffer doubleBuffer, Flushable flushable, NoSuchFieldError noSuchFieldError, PushbackReader pushbackReader, PipedOutputStream pipedOutputStream) {
        return null;
    }

    /* JADX INFO: renamed from: d */
    protected NoClassDefFoundError m40124d() {
        return null;
    }

    /* JADX INFO: renamed from: e */
    public CloneNotSupportedException m40125e() {
        return null;
    }

    /* JADX INFO: renamed from: f */
    public ByteBuffer m40126f() {
        return null;
    }

    /* JADX INFO: renamed from: g */
    final Compiler m40127g() {
        return null;
    }

    /* JADX INFO: renamed from: i */
    protected IdentityScope m40128i(StringBuffer stringBuffer, FilePermission filePermission, Clock clock, PrintWriter printWriter) {
        return null;
    }
}
