package p356f.p372c.p451k.p452g.p454n;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Console;
import java.io.DataOutputStream;
import java.io.Flushable;
import java.io.ObjectStreamConstants;
import java.io.OutputStream;
import java.io.PipedReader;
import java.io.PrintStream;
import java.io.RandomAccessFile;
import java.io.Reader;
import java.io.SerializablePermission;
import java.nio.Buffer;
import java.nio.BufferUnderflowException;
import java.security.AlgorithmParametersSpi;
import java.security.AllPermission;
import java.security.AuthProvider;
import java.security.BasicPermission;
import java.security.DigestException;
import java.security.DigestInputStream;
import java.security.DomainLoadStoreParameter;
import java.security.GuardedObject;
import java.security.KeyPair;
import java.security.NoSuchProviderException;
import java.security.PermissionCollection;
import java.security.SecureClassLoader;
import java.security.Security;
import java.security.SecurityPermission;
import java.security.UnrecoverableKeyException;
import java.time.Duration;
import java.time.Instant;
import java.time.OffsetTime;
import java.time.YearMonth;
import java.time.ZonedDateTime;
import java.util.HashMap;
import p356f.p372c.p375g.p376d.p377a.C6821a;

/* JADX INFO: renamed from: f.c.k.g.n.g */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC7195g {

    /* JADX INFO: renamed from: a */
    static DataOutputStream f46918a;

    /* JADX INFO: renamed from: b */
    public BufferUnderflowException f46919b;

    /* JADX INFO: renamed from: c */
    transient KeyPair f46920c;

    /* JADX INFO: renamed from: d */
    private Reader f46921d;

    /* JADX INFO: renamed from: e */
    private DigestException f46922e;

    /* JADX INFO: renamed from: f */
    protected Console f46923f;

    /* JADX INFO: renamed from: g */
    protected OutputStream f46924g;

    /* JADX INFO: renamed from: h */
    protected Duration f46925h;

    /* JADX INFO: renamed from: i */
    volatile PipedReader f46926i;

    AbstractC7195g() {
    }

    /* JADX INFO: renamed from: b */
    private AuthProvider m40129b(NumberFormatException numberFormatException) {
        return null;
    }

    /* JADX INFO: renamed from: a */
    public DigestInputStream m40130a(UnrecoverableKeyException unrecoverableKeyException, Instant instant, C6821a c6821a, RandomAccessFile randomAccessFile, NumberFormatException numberFormatException, ClassLoader classLoader) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    public PermissionCollection m40131c(Buffer buffer, ByteArrayOutputStream byteArrayOutputStream, GuardedObject guardedObject) {
        return null;
    }

    /* JADX INFO: renamed from: d */
    protected PrintStream m40132d(AssertionError assertionError, SerializablePermission serializablePermission) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    synchronized StrictMath m40133e(HashMap map, SecureClassLoader secureClassLoader, Security security, Reader reader, ByteArrayInputStream byteArrayInputStream, Cloneable cloneable) {
        return null;
    }

    /* JADX INFO: renamed from: f */
    synchronized DigestInputStream m40134f(AllPermission allPermission, BasicPermission basicPermission, Flushable flushable, SecurityException securityException, OffsetTime offsetTime, Long l2) {
        return null;
    }

    /* JADX INFO: renamed from: g */
    public ZonedDateTime m40135g(YearMonth yearMonth) {
        return null;
    }

    /* JADX INFO: renamed from: h */
    synchronized AlgorithmParametersSpi m40136h(SecurityPermission securityPermission, DomainLoadStoreParameter domainLoadStoreParameter, ArithmeticException arithmeticException, ObjectStreamConstants objectStreamConstants, NoSuchProviderException noSuchProviderException) {
        return null;
    }
}
