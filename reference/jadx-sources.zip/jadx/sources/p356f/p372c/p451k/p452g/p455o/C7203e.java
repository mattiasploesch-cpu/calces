package p356f.p372c.p451k.p452g.p455o;

import java.io.ByteArrayOutputStream;
import java.io.PipedInputStream;
import java.nio.ReadOnlyBufferException;

/* JADX INFO: renamed from: f.c.k.g.o.e */
/* JADX INFO: loaded from: classes.dex */
final class C7203e {

    /* JADX INFO: renamed from: a */
    static Thread f46986a;

    /* JADX INFO: renamed from: b */
    transient ReadOnlyBufferException f46987b;

    /* JADX INFO: renamed from: c */
    public PipedInputStream f46988c;

    /* JADX INFO: renamed from: d */
    private InternalError f46989d;

    /* JADX INFO: renamed from: e */
    public CharSequence f46990e;

    /* JADX INFO: renamed from: f */
    private String f46991f = "X19faUdRbk1uQ2VEZ3JQ";

    C7203e() {
    }

    /* JADX INFO: renamed from: a */
    public InternalError m40190a() {
        return null;
    }

    /* JADX INFO: renamed from: b */
    public ByteArrayOutputStream m40191b() {
        return null;
    }
}
