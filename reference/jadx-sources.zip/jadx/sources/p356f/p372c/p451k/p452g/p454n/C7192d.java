package p356f.p372c.p451k.p452g.p454n;

import java.text.CharacterIterator;

/* JADX INFO: renamed from: f.c.k.g.n.d */
/* JADX INFO: loaded from: classes.dex */
public class C7192d implements Cloneable, CharacterIterator, CharSequence {

    /* JADX INFO: renamed from: A2 */
    public String f46888A2;

    /* JADX INFO: renamed from: B2 */
    public String f46889B2;

    /* JADX INFO: renamed from: u2 */
    public char[] f46890u2;

    /* JADX INFO: renamed from: v2 */
    public int f46891v2;

    /* JADX INFO: renamed from: w2 */
    public int f46892w2;

    /* JADX INFO: renamed from: x2 */
    private boolean f46893x2;

    /* JADX INFO: renamed from: y2 */
    private int f46894y2;

    /* JADX INFO: renamed from: z2 */
    public IncompatibleClassChangeError f46895z2;

    public C7192d() {
        this(null, 0, 0);
    }

    public C7192d(char[] cArr, int i2, int i3) {
        this.f46888A2 = "X19fVGlQR19N";
        this.f46889B2 = "X19feHlDaEE=";
        this.f46890u2 = cArr;
        this.f46891v2 = i2;
        this.f46892w2 = i3;
        this.f46893x2 = false;
    }

    /* JADX INFO: renamed from: a */
    public boolean m40108a() {
        return this.f46893x2;
    }

    /* JADX INFO: renamed from: b */
    public void m40109b(boolean z) {
        this.f46893x2 = z;
    }

    @Override // java.lang.CharSequence
    public char charAt(int i2) {
        if (i2 < 0 || i2 >= this.f46892w2) {
            throw new StringIndexOutOfBoundsException(i2);
        }
        return this.f46890u2[this.f46891v2 + i2];
    }

    @Override // java.text.CharacterIterator
    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException unused) {
            return null;
        }
    }

    @Override // java.text.CharacterIterator
    public char current() {
        int i2;
        int i3 = this.f46892w2;
        if (i3 == 0 || (i2 = this.f46894y2) >= this.f46891v2 + i3) {
            return (char) 65535;
        }
        return this.f46890u2[i2];
    }

    @Override // java.text.CharacterIterator
    public char first() {
        int i2 = this.f46891v2;
        this.f46894y2 = i2;
        if (this.f46892w2 != 0) {
            return this.f46890u2[i2];
        }
        return (char) 65535;
    }

    @Override // java.text.CharacterIterator
    public int getBeginIndex() {
        return this.f46891v2;
    }

    @Override // java.text.CharacterIterator
    public int getEndIndex() {
        return this.f46891v2 + this.f46892w2;
    }

    @Override // java.text.CharacterIterator
    public int getIndex() {
        return this.f46894y2;
    }

    @Override // java.text.CharacterIterator
    public char last() {
        int i2 = this.f46891v2;
        int i3 = this.f46892w2;
        int i4 = i2 + i3;
        this.f46894y2 = i4;
        if (i3 == 0) {
            return (char) 65535;
        }
        int i5 = i4 - 1;
        this.f46894y2 = i5;
        return this.f46890u2[i5];
    }

    @Override // java.lang.CharSequence
    public int length() {
        return this.f46892w2;
    }

    @Override // java.text.CharacterIterator
    public char next() {
        int i2 = this.f46894y2 + 1;
        this.f46894y2 = i2;
        int i3 = this.f46891v2 + this.f46892w2;
        if (i2 < i3) {
            return current();
        }
        this.f46894y2 = i3;
        return (char) 65535;
    }

    @Override // java.text.CharacterIterator
    public char previous() {
        int i2 = this.f46894y2;
        if (i2 == this.f46891v2) {
            return (char) 65535;
        }
        this.f46894y2 = i2 - 1;
        return current();
    }

    @Override // java.text.CharacterIterator
    public char setIndex(int i2) {
        int i3 = this.f46891v2;
        int i4 = this.f46892w2;
        int i5 = i3 + i4;
        if (i2 < i3 || i2 > i5) {
            throw new IllegalArgumentException("bad position: " + i2);
        }
        this.f46894y2 = i2;
        if (i2 == i5 || i4 == 0) {
            return (char) 65535;
        }
        return this.f46890u2[i2];
    }

    @Override // java.lang.CharSequence
    public CharSequence subSequence(int i2, int i3) {
        if (i2 < 0) {
            throw new StringIndexOutOfBoundsException(i2);
        }
        if (i3 > this.f46892w2) {
            throw new StringIndexOutOfBoundsException(i3);
        }
        if (i2 > i3) {
            throw new StringIndexOutOfBoundsException(i3 - i2);
        }
        C7192d c7192d = new C7192d();
        c7192d.f46890u2 = this.f46890u2;
        c7192d.f46891v2 = this.f46891v2 + i2;
        c7192d.f46892w2 = i3 - i2;
        return c7192d;
    }

    @Override // java.lang.CharSequence
    public String toString() {
        return this.f46890u2 != null ? new String(this.f46890u2, this.f46891v2, this.f46892w2) : "";
    }
}
