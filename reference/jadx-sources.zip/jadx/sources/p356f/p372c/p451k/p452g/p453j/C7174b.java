package p356f.p372c.p451k.p452g.p453j;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOError;
import java.io.RandomAccessFile;
import java.io.SequenceInputStream;
import java.io.WriteAbortedException;
import java.io.Writer;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.security.AlgorithmConstraints;
import java.security.Identity;
import java.security.PKCS12Attribute;
import java.security.PermissionCollection;
import java.security.Signature;
import java.security.SignedObject;
import java.security.Signer;
import java.text.AttributedCharacterIterator;
import java.text.BreakIterator;
import java.text.Collator;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.OffsetDateTime;
import p148e.p150d.p154l.C5069c;

/* JADX INFO: renamed from: f.c.k.g.j.b */
/* JADX INFO: loaded from: classes.dex */
public class C7174b {

    /* JADX INFO: renamed from: a */
    static FileOutputStream f46725a;

    /* JADX INFO: renamed from: b */
    static NoClassDefFoundError f46726b;

    /* JADX INFO: renamed from: c */
    private InstantiationError f46727c;

    /* JADX INFO: renamed from: d */
    protected C5069c f46728d;

    /* JADX INFO: renamed from: e */
    private Writer f46729e;

    /* JADX INFO: renamed from: f */
    volatile Package f46730f;

    /* JADX INFO: renamed from: g */
    public WriteAbortedException f46731g;

    /* JADX INFO: renamed from: h */
    public PermissionCollection f46732h;

    /* JADX INFO: renamed from: i */
    public Double f46733i;

    /* JADX INFO: renamed from: j */
    protected String f46734j = "X19fanlhVGhH";

    /* JADX INFO: renamed from: c */
    static Duration m39942c() {
        return null;
    }

    /* JADX INFO: renamed from: d */
    private AlgorithmConstraints m39943d(SimpleDateFormat simpleDateFormat, DateFormatSymbols dateFormatSymbols, BreakIterator breakIterator, IncompatibleClassChangeError incompatibleClassChangeError, Short sh) {
        return null;
    }

    /* JADX INFO: renamed from: h */
    static SequenceInputStream m39944h() {
        return null;
    }

    /* JADX INFO: renamed from: a */
    public RandomAccessFile m39945a(ByteArrayInputStream byteArrayInputStream, Signer signer) {
        return null;
    }

    /* JADX INFO: renamed from: b */
    protected InheritableThreadLocal m39946b(Identity identity, SignedObject signedObject) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    public Buffer m39947e(FileNotFoundException fileNotFoundException, Signature signature, IOError iOError, OffsetDateTime offsetDateTime, Integer num, Collator collator) {
        return null;
    }

    /* JADX INFO: renamed from: f */
    public IllegalArgumentException m39948f() {
        return null;
    }

    /* JADX INFO: renamed from: g */
    protected DateFormatSymbols m39949g(AttributedCharacterIterator attributedCharacterIterator, PKCS12Attribute pKCS12Attribute, ByteBuffer byteBuffer, Compiler compiler) {
        return null;
    }
}
