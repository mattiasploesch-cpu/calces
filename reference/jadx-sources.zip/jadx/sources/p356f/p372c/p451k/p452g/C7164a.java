package p356f.p372c.p451k.p452g;

import java.security.AuthProvider;
import java.security.PolicySpi;
import java.text.Bidi;

/* JADX INFO: renamed from: f.c.k.g.a */
/* JADX INFO: loaded from: classes.dex */
public class C7164a {

    /* JADX INFO: renamed from: a */
    public AuthProvider f46664a;

    /* JADX INFO: renamed from: b */
    private ThreadDeath f46665b;

    /* JADX INFO: renamed from: c */
    transient IndexOutOfBoundsException f46666c;

    /* JADX INFO: renamed from: d */
    public Bidi f46667d;

    /* JADX INFO: renamed from: e */
    volatile ProcessBuilder f46668e;

    /* JADX INFO: renamed from: f */
    volatile PolicySpi f46669f;

    /* JADX INFO: renamed from: g */
    protected Integer f46670g;

    /* JADX INFO: renamed from: h */
    protected Boolean f46671h;

    /* JADX INFO: renamed from: i */
    public OutOfMemoryError f46672i;

    /* JADX INFO: renamed from: j */
    private ClassCircularityError f46673j;
}
