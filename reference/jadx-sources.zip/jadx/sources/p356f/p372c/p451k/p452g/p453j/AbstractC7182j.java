package p356f.p372c.p451k.p452g.p453j;

import java.io.CharConversionException;
import java.io.DataInput;
import java.io.DataOutputStream;
import java.io.PipedWriter;
import java.math.BigDecimal;
import java.security.AlgorithmParameterGeneratorSpi;
import java.security.AlgorithmParameters;
import java.security.AllPermission;
import java.security.CodeSigner;
import java.security.DigestException;
import java.security.Key;
import java.security.PrivilegedActionException;
import java.security.UnrecoverableEntryException;

/* JADX INFO: renamed from: f.c.k.g.j.j */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC7182j {

    /* JADX INFO: renamed from: a */
    protected UnrecoverableEntryException f46799a;

    /* JADX INFO: renamed from: b */
    private DataOutputStream f46800b;

    /* JADX INFO: renamed from: c */
    private DataInput f46801c;

    /* JADX INFO: renamed from: d */
    transient AlgorithmParameters f46802d;

    /* JADX INFO: renamed from: e */
    transient DigestException f46803e;

    /* JADX INFO: renamed from: f */
    public Float f46804f;

    AbstractC7182j() {
    }

    /* JADX INFO: renamed from: a */
    public BigDecimal m40022a() {
        return null;
    }

    /* JADX INFO: renamed from: b */
    protected String m40023b() {
        return null;
    }

    /* JADX INFO: renamed from: c */
    protected PrivilegedActionException m40024c(NegativeArraySizeException negativeArraySizeException, CodeSigner codeSigner, InstantiationException instantiationException, Key key) {
        return null;
    }

    /* JADX INFO: renamed from: d */
    protected ThreadGroup m40025d(CharConversionException charConversionException, PipedWriter pipedWriter, AlgorithmParameterGeneratorSpi algorithmParameterGeneratorSpi, AllPermission allPermission) {
        return null;
    }
}
