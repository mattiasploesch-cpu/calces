package p356f.p372c.p451k.p452g.p455o.p456l;

import java.io.BufferedOutputStream;
import java.nio.InvalidMarkException;
import java.nio.LongBuffer;
import java.security.PermissionCollection;
import java.security.PrivateKey;
import java.security.SignatureException;
import java.security.UnrecoverableEntryException;
import java.text.DateFormat;
import p148e.p150d.p154l.C5069c;

/* JADX INFO: renamed from: f.c.k.g.o.l.k */
/* JADX INFO: loaded from: classes.dex */
final class C7220k {

    /* JADX INFO: renamed from: a */
    protected UnknownError f47182a;

    /* JADX INFO: renamed from: b */
    volatile UnrecoverableEntryException f47183b;

    /* JADX INFO: renamed from: c */
    protected Appendable f47184c;

    /* JADX INFO: renamed from: d */
    protected BootstrapMethodError f47185d;

    /* JADX INFO: renamed from: e */
    protected Integer f47186e;

    /* JADX INFO: renamed from: f */
    private CharSequence f47187f;

    /* JADX INFO: renamed from: g */
    transient PrivateKey f47188g;

    /* JADX INFO: renamed from: h */
    public Byte f47189h;

    /* JADX INFO: renamed from: i */
    protected Boolean f47190i;

    /* JADX INFO: renamed from: j */
    protected InvalidMarkException f47191j;

    /* JADX INFO: renamed from: k */
    protected Void f47192k;

    C7220k() {
    }

    /* JADX INFO: renamed from: a */
    static BufferedOutputStream m40304a(C5069c c5069c, Cloneable cloneable, SignatureException signatureException, PermissionCollection permissionCollection, LongBuffer longBuffer, DateFormat dateFormat) {
        return null;
    }
}
