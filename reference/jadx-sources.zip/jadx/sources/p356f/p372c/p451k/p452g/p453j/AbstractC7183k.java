package p356f.p372c.p451k.p452g.p453j;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.FilterWriter;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.BufferOverflowException;
import java.nio.ByteBuffer;
import java.security.AlgorithmConstraints;
import java.security.DigestException;
import java.security.KeyStore;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignedObject;
import java.security.Timestamp;
import java.text.AttributedString;
import java.util.ArrayList;

/* JADX INFO: renamed from: f.c.k.g.j.k */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC7183k {

    /* JADX INFO: renamed from: a */
    protected Writer f46805a;

    /* JADX INFO: renamed from: b */
    protected String f46806b;

    /* JADX INFO: renamed from: c */
    volatile AssertionError f46807c;

    /* JADX INFO: renamed from: d */
    private IllegalStateException f46808d;

    /* JADX INFO: renamed from: e */
    public FilterWriter f46809e;

    /* JADX INFO: renamed from: f */
    protected Runtime f46810f;

    /* JADX INFO: renamed from: g */
    public Reader f46811g;

    /* JADX INFO: renamed from: h */
    private KeyStore f46812h;

    /* JADX INFO: renamed from: i */
    transient ByteBuffer f46813i;

    /* JADX INFO: renamed from: j */
    public Byte f46814j;

    /* JADX INFO: renamed from: k */
    private NoSuchMethodError f46815k;

    /* JADX INFO: renamed from: l */
    private InstantiationError f46816l;

    /* JADX INFO: renamed from: m */
    protected Comparable f46817m;

    /* JADX INFO: renamed from: n */
    protected String f46818n = "X19fRVJDVnBuWUdiT0U=";

    AbstractC7183k() {
    }

    /* JADX INFO: renamed from: b */
    private NegativeArraySizeException m40026b() {
        return null;
    }

    /* JADX INFO: renamed from: f */
    private BufferedInputStream m40027f(IllegalMonitorStateException illegalMonitorStateException, Void r2, Thread thread, Long l2, Thread thread2, AttributedString attributedString) {
        return null;
    }

    /* JADX INFO: renamed from: a */
    Short m40028a(PublicKey publicKey) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    protected Iterable m40029c() {
        return null;
    }

    /* JADX INFO: renamed from: d */
    synchronized DigestException m40030d(FilterOutputStream filterOutputStream, IllegalArgumentException illegalArgumentException, InstantiationError instantiationError) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    StrictMath m40031e(BufferOverflowException bufferOverflowException, Signature signature, Runtime runtime, BufferedWriter bufferedWriter, Byte b2, Comparable comparable) {
        return null;
    }

    /* JADX INFO: renamed from: g */
    public ExceptionInInitializerError m40032g(ArrayList arrayList, NumberFormatException numberFormatException, AlgorithmConstraints algorithmConstraints, ClassLoader classLoader, StringWriter stringWriter) {
        return null;
    }

    /* JADX INFO: renamed from: h */
    Timestamp m40033h(File file, SignedObject signedObject, FileOutputStream fileOutputStream, RuntimeException runtimeException) {
        return null;
    }
}
