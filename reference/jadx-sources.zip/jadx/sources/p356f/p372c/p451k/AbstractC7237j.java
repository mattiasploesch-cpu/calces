package p356f.p372c.p451k;

import java.io.BufferedWriter;
import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.Flushable;
import java.io.LineNumberReader;
import java.io.OptionalDataException;
import java.io.OutputStream;
import java.io.PipedOutputStream;
import java.io.PushbackInputStream;
import java.io.SerializablePermission;
import java.io.Writer;
import java.math.BigDecimal;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.security.AccessController;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.text.AttributedString;
import java.text.Collator;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.AbstractList;
import java.util.AbstractMap;
import java.util.regex.Matcher;

/* JADX INFO: renamed from: f.c.k.j */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC7237j {

    /* JADX INFO: renamed from: a */
    static Collator f47286a;

    /* JADX INFO: renamed from: b */
    private FileNotFoundException f47287b;

    /* JADX INFO: renamed from: c */
    private FileDescriptor f47288c;

    /* JADX INFO: renamed from: d */
    volatile IllegalAccessError f47289d;

    /* JADX INFO: renamed from: e */
    protected Float f47290e;

    /* JADX INFO: renamed from: f */
    volatile AttributedString f47291f;

    /* JADX INFO: renamed from: g */
    private AutoCloseable f47292g;

    /* JADX INFO: renamed from: h */
    protected DecimalFormat f47293h;

    /* JADX INFO: renamed from: i */
    public Matcher f47294i;

    /* JADX INFO: renamed from: j */
    protected BigDecimal f47295j;

    /* JADX INFO: renamed from: k */
    public Writer f47296k;

    /* JADX INFO: renamed from: l */
    public String f47297l = "X19fdGd1d2ZoVVZwaWph";

    AbstractC7237j() {
    }

    /* JADX INFO: renamed from: d */
    private DigestInputStream m40410d(SimpleDateFormat simpleDateFormat, PushbackInputStream pushbackInputStream, Cloneable cloneable) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    private BufferedWriter m40411e() {
        return null;
    }

    /* JADX INFO: renamed from: f */
    private AbstractMap m40412f(SerializablePermission serializablePermission, Integer num, OutputStream outputStream, PipedOutputStream pipedOutputStream) {
        return null;
    }

    /* JADX INFO: renamed from: a */
    final AccessController m40413a(AbstractList abstractList, Float f2, PrivateKey privateKey, NumberFormat numberFormat) {
        return null;
    }

    /* JADX INFO: renamed from: b */
    LineNumberReader m40414b(ByteBuffer byteBuffer, Buffer buffer, Flushable flushable, OptionalDataException optionalDataException) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    synchronized MessageDigest m40415c() {
        return null;
    }
}
