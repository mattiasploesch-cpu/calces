package p356f.p372c.p451k.p457h;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.io.Serializable;
import java.io.StringWriter;
import java.nio.IntBuffer;
import java.security.AlgorithmParameterGeneratorSpi;
import java.security.AlgorithmParameters;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.PKCS12Attribute;
import java.security.Permissions;
import java.security.ProtectionDomain;
import java.security.SecurityPermission;
import java.security.UnrecoverableEntryException;
import java.security.UnrecoverableKeyException;
import java.time.LocalDate;

/* JADX INFO: renamed from: f.c.k.h.c */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC7224c {

    /* JADX INFO: renamed from: a */
    protected FileReader f47212a;

    /* JADX INFO: renamed from: b */
    protected ClassCircularityError f47213b;

    /* JADX INFO: renamed from: c */
    transient String f47214c;

    /* JADX INFO: renamed from: d */
    transient UnrecoverableKeyException f47215d;

    /* JADX INFO: renamed from: e */
    protected DataOutputStream f47216e;

    /* JADX INFO: renamed from: f */
    public Double f47217f;

    /* JADX INFO: renamed from: g */
    private Double f47218g;

    /* JADX INFO: renamed from: h */
    public String f47219h = "X19fWWRzZU12QXI=";

    AbstractC7224c() {
    }

    /* JADX INFO: renamed from: a */
    private StringWriter m40328a() {
        return null;
    }

    /* JADX INFO: renamed from: c */
    private Object m40329c(LocalDate localDate, PKCS12Attribute pKCS12Attribute, IllegalAccessException illegalAccessException, UnrecoverableEntryException unrecoverableEntryException, IntBuffer intBuffer) {
        return null;
    }

    /* JADX INFO: renamed from: b */
    protected String m40330b() {
        return null;
    }

    /* JADX INFO: renamed from: d */
    ProtectionDomain m40331d(SecurityPermission securityPermission, FileNotFoundException fileNotFoundException, LineNumberReader lineNumberReader, Math math, KeyStore keyStore) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    File m40332e(AlgorithmParameterGeneratorSpi algorithmParameterGeneratorSpi, AlgorithmParameters algorithmParameters, Serializable serializable, ThreadGroup threadGroup, DataOutputStream dataOutputStream) {
        return null;
    }

    /* JADX INFO: renamed from: f */
    public GeneralSecurityException m40333f(AutoCloseable autoCloseable, Runtime runtime, DataOutputStream dataOutputStream, IllegalAccessException illegalAccessException, Permissions permissions, NoSuchFieldException noSuchFieldException) {
        return null;
    }
}
