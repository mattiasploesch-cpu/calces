package p356f.p372c.p451k.p457h.p458d;

import java.io.CharArrayWriter;
import java.io.CharConversionException;
import java.io.FilePermission;
import java.io.FilterInputStream;
import java.io.LineNumberReader;
import java.io.ObjectStreamField;
import java.io.OptionalDataException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.nio.IntBuffer;
import java.security.AlgorithmConstraints;
import java.security.AlgorithmParameterGenerator;
import java.security.Guard;
import java.security.KeyPairGeneratorSpi;
import java.security.PrivilegedActionException;
import java.security.Signer;
import java.time.LocalDateTime;
import java.util.Comparator;

/* JADX INFO: renamed from: f.c.k.h.d.i */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC7233i {

    /* JADX INFO: renamed from: a */
    transient OptionalDataException f47257a;

    /* JADX INFO: renamed from: b */
    protected ArrayIndexOutOfBoundsException f47258b;

    /* JADX INFO: renamed from: c */
    public BigDecimal f47259c;

    /* JADX INFO: renamed from: d */
    public TypeNotPresentException f47260d;

    /* JADX INFO: renamed from: e */
    protected String f47261e = "X19fZUNBa1dLSUs=";

    /* JADX INFO: renamed from: f */
    private String f47262f = "X19fZ29uRmtE";

    /* JADX INFO: renamed from: g */
    private String f47263g = "X19fR2xkVml4b0Zhb1Bt";

    AbstractC7233i() {
    }

    /* JADX INFO: renamed from: d */
    private PrivilegedActionException m40390d(NoSuchFieldException noSuchFieldException, FilterInputStream filterInputStream, OutputStream outputStream) {
        return null;
    }

    /* JADX INFO: renamed from: a */
    LocalDateTime m40391a() {
        return null;
    }

    /* JADX INFO: renamed from: b */
    protected AlgorithmConstraints m40392b(Guard guard, CharSequence charSequence, Signer signer, Guard guard2, RuntimePermission runtimePermission, AlgorithmParameterGenerator algorithmParameterGenerator) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    protected CharConversionException m40393c(NoSuchMethodError noSuchMethodError, KeyPairGeneratorSpi keyPairGeneratorSpi, Character ch, RuntimeException runtimeException) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    protected ClassCastException m40394e() {
        return null;
    }

    /* JADX INFO: renamed from: f */
    protected LineNumberReader m40395f() {
        return null;
    }

    /* JADX INFO: renamed from: g */
    FilePermission m40396g(ObjectStreamField objectStreamField) {
        return null;
    }

    /* JADX INFO: renamed from: h */
    final CharArrayWriter m40397h(IntBuffer intBuffer) {
        return null;
    }

    /* JADX INFO: renamed from: i */
    final Comparator m40398i() {
        return null;
    }
}
