package p356f.p372c.p451k.p457h;

import java.io.BufferedOutputStream;
import java.io.CharArrayReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InvalidObjectException;
import java.io.NotSerializableException;
import java.io.ObjectStreamField;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.security.DomainCombiner;
import java.text.BreakIterator;
import java.text.NumberFormat;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.AbstractCollection;
import p148e.p150d.p153k.C5065d;

/* JADX INFO: renamed from: f.c.k.h.b */
/* JADX INFO: loaded from: classes.dex */
final class C7223b {

    /* JADX INFO: renamed from: a */
    public AbstractMethodError f47208a;

    /* JADX INFO: renamed from: b */
    volatile BootstrapMethodError f47209b;

    /* JADX INFO: renamed from: c */
    private Readable f47210c;

    /* JADX INFO: renamed from: d */
    public Runtime f47211d;

    C7223b() {
    }

    /* JADX INFO: renamed from: a */
    static Thread m40318a() {
        return null;
    }

    /* JADX INFO: renamed from: g */
    private NoSuchFieldError m40319g() {
        return null;
    }

    /* JADX INFO: renamed from: j */
    static ObjectStreamField m40320j(BufferedOutputStream bufferedOutputStream, NoClassDefFoundError noClassDefFoundError, Float f2, Readable readable) {
        return null;
    }

    /* JADX INFO: renamed from: b */
    final DataOutputStream m40321b(AbstractCollection abstractCollection, Thread thread, Byte b2, UnsatisfiedLinkError unsatisfiedLinkError, ZoneOffset zoneOffset) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    ByteOrder m40322c(AbstractMethodError abstractMethodError, DomainCombiner domainCombiner, C5065d c5065d, MappedByteBuffer mappedByteBuffer) {
        return null;
    }

    /* JADX INFO: renamed from: d */
    public IncompatibleClassChangeError m40323d(FileOutputStream fileOutputStream, CharArrayReader charArrayReader, ZonedDateTime zonedDateTime, Number number, StringWriter stringWriter) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    final Double m40324e(File file, NumberFormat numberFormat, StringReader stringReader, ThreadGroup threadGroup, InvalidObjectException invalidObjectException, BreakIterator breakIterator) {
        return null;
    }

    /* JADX INFO: renamed from: f */
    public ClassNotFoundException m40325f() {
        return null;
    }

    /* JADX INFO: renamed from: h */
    protected Comparable m40326h() {
        return null;
    }

    /* JADX INFO: renamed from: i */
    public NotSerializableException m40327i() {
        return null;
    }
}
