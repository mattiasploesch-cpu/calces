package p356f.p372c.p451k.p457h.p458d;

import java.io.BufferedWriter;
import java.io.FileDescriptor;
import java.io.FilterReader;
import java.io.ObjectInput;
import java.io.ObjectStreamConstants;
import java.io.PipedInputStream;
import java.io.PrintWriter;
import java.io.Writer;
import java.math.RoundingMode;
import java.nio.BufferOverflowException;
import java.nio.LongBuffer;
import java.security.Key;
import java.security.KeyPairGeneratorSpi;
import java.security.KeyStoreSpi;
import java.security.NoSuchAlgorithmException;
import java.security.PKCS12Attribute;
import java.security.Policy;
import java.security.Principal;
import java.security.Provider;
import java.security.PublicKey;
import java.security.SecureClassLoader;
import java.security.SecureRandom;
import java.text.AttributedCharacterIterator;
import java.time.YearMonth;
import java.time.ZoneOffset;
import p148e.p150d.p153k.C5062a;
import p148e.p150d.p154l.ViewOnClickListenerC5073g;
import p148e.p150d.p182u.ViewOnClickListenerC5322k;

/* JADX INFO: renamed from: f.c.k.h.d.b */
/* JADX INFO: loaded from: classes.dex */
final class C7226b {

    /* JADX INFO: renamed from: a */
    static ZoneOffset f47228a;

    /* JADX INFO: renamed from: b */
    transient KeyStoreSpi f47229b;

    /* JADX INFO: renamed from: c */
    public KeyPairGeneratorSpi f47230c;

    C7226b() {
    }

    /* JADX INFO: renamed from: b */
    private NoSuchAlgorithmException m40343b(C5062a c5062a, LongBuffer longBuffer, ObjectInput objectInput, PipedInputStream pipedInputStream, SecurityException securityException) {
        return null;
    }

    /* JADX INFO: renamed from: h */
    private ViewOnClickListenerC5322k m40344h(Writer writer) {
        return null;
    }

    /* JADX INFO: renamed from: a */
    synchronized YearMonth m40345a(IndexOutOfBoundsException indexOutOfBoundsException, SecureRandom secureRandom, Short sh, Principal principal) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    Policy m40346c(RoundingMode roundingMode, PublicKey publicKey, BufferedWriter bufferedWriter, Key key, Byte b2) {
        return null;
    }

    /* JADX INFO: renamed from: d */
    protected ViewOnClickListenerC5073g m40347d(SecureClassLoader secureClassLoader, PKCS12Attribute pKCS12Attribute, Key key) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    public SecureRandom m40348e(ObjectStreamConstants objectStreamConstants) {
        return null;
    }

    /* JADX INFO: renamed from: f */
    protected IllegalThreadStateException m40349f(FilterReader filterReader, Thread thread, Provider provider, AttributedCharacterIterator attributedCharacterIterator, C5062a c5062a, PrintWriter printWriter) {
        return null;
    }

    /* JADX INFO: renamed from: g */
    synchronized BufferOverflowException m40350g(FileDescriptor fileDescriptor, CharSequence charSequence) {
        return null;
    }
}
