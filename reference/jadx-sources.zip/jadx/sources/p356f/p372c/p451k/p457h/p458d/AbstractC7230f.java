package p356f.p372c.p451k.p457h.p458d;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FilterInputStream;
import java.io.FilterReader;
import java.io.ObjectInputStream;
import java.math.RoundingMode;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.PermissionCollection;
import java.security.PolicySpi;
import java.security.ProviderException;
import java.text.AttributedString;
import java.time.LocalDateTime;
import java.util.Stack;
import java.util.regex.Matcher;

/* JADX INFO: renamed from: f.c.k.h.d.f */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC7230f {

    /* JADX INFO: renamed from: a */
    static LinkageError f47238a;

    /* JADX INFO: renamed from: b */
    volatile Key f47239b;

    /* JADX INFO: renamed from: c */
    private RoundingMode f47240c;

    /* JADX INFO: renamed from: d */
    protected NoSuchMethodException f47241d;

    /* JADX INFO: renamed from: e */
    public DataInputStream f47242e;

    AbstractC7230f() {
    }

    /* JADX INFO: renamed from: a */
    static FilterInputStream m40368a(LocalDateTime localDateTime, NoSuchAlgorithmException noSuchAlgorithmException, RuntimeException runtimeException, InterruptedException interruptedException) {
        return null;
    }

    /* JADX INFO: renamed from: d */
    private ProviderException m40369d(Matcher matcher, String str, Package r3, StringBuffer stringBuffer) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    private FilterReader m40370e() {
        return null;
    }

    /* JADX INFO: renamed from: g */
    private PermissionCollection m40371g(Compiler compiler) {
        return null;
    }

    /* JADX INFO: renamed from: b */
    protected ObjectInputStream m40372b(Void r1, AttributedString attributedString) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    PolicySpi m40373c(Stack stack) {
        return null;
    }

    /* JADX INFO: renamed from: f */
    protected DataOutputStream m40374f() {
        return null;
    }
}
