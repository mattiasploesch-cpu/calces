package p356f.p372c.p451k.p457h.p458d;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInput;
import java.io.FileFilter;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.nio.Buffer;
import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.nio.DoubleBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import java.security.AlgorithmParameterGeneratorSpi;
import java.security.CryptoPrimitive;
import java.security.DomainCombiner;
import java.security.InvalidParameterException;
import java.security.KeyManagementException;
import java.security.Principal;
import java.security.PrivilegedExceptionAction;
import java.security.Security;
import java.text.AttributedString;
import java.text.DateFormat;
import java.time.OffsetTime;
import java.time.ZoneOffset;
import java.util.Stack;

/* JADX INFO: renamed from: f.c.k.h.d.d */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC7228d {

    /* JADX INFO: renamed from: a */
    static IntBuffer f47231a;

    /* JADX INFO: renamed from: b */
    public ReflectiveOperationException f47232b;

    /* JADX INFO: renamed from: c */
    public DomainCombiner f47233c;

    /* JADX INFO: renamed from: d */
    protected AbstractMethodError f47234d;

    AbstractC7228d() {
    }

    /* JADX INFO: renamed from: a */
    static ArrayIndexOutOfBoundsException m40351a(BufferUnderflowException bufferUnderflowException, DomainCombiner domainCombiner) {
        return null;
    }

    /* JADX INFO: renamed from: d */
    static ByteArrayOutputStream m40352d() {
        return null;
    }

    /* JADX INFO: renamed from: i */
    static ZoneOffset m40353i(IllegalArgumentException illegalArgumentException, IllegalStateException illegalStateException) {
        return null;
    }

    /* JADX INFO: renamed from: b */
    AlgorithmParameterGeneratorSpi m40354b(ByteBuffer byteBuffer, OffsetTime offsetTime) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    Number m40355c(ShortBuffer shortBuffer, Stack stack, ObjectInputStream objectInputStream) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    public InvalidParameterException m40356e(Security security, Buffer buffer, DoubleBuffer doubleBuffer, DataInput dataInput, FileFilter fileFilter) {
        return null;
    }

    /* JADX INFO: renamed from: f */
    synchronized ObjectInput m40357f(Readable readable, PrivilegedExceptionAction privilegedExceptionAction, IncompatibleClassChangeError incompatibleClassChangeError, KeyManagementException keyManagementException, OutOfMemoryError outOfMemoryError) {
        return null;
    }

    /* JADX INFO: renamed from: g */
    synchronized Iterable m40358g(DateFormat dateFormat) {
        return null;
    }

    /* JADX INFO: renamed from: h */
    protected KeyManagementException m40359h(CryptoPrimitive cryptoPrimitive, ReflectiveOperationException reflectiveOperationException, Principal principal, ByteArrayInputStream byteArrayInputStream, ObjectInput objectInput, AttributedString attributedString) {
        return null;
    }
}
