package p356f.p372c.p451k.p457h.p458d;

import java.io.ObjectInputValidation;
import java.io.OptionalDataException;
import java.io.OutputStream;
import java.io.StreamTokenizer;
import java.io.StringWriter;
import java.io.UTFDataFormatException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.nio.ByteOrder;
import java.security.AccessController;
import java.security.AlgorithmParameters;
import java.security.DigestInputStream;
import java.security.DomainCombiner;
import java.security.KeyException;
import java.security.KeyFactory;
import java.security.Principal;
import java.security.PublicKey;
import java.text.ChoiceFormat;
import java.text.DecimalFormatSymbols;
import java.text.FieldPosition;
import java.time.OffsetDateTime;
import java.util.AbstractCollection;
import java.util.Collections;
import java.util.Comparator;
import p148e.p150d.p153k.C5062a;
import p148e.p150d.p154l.C5069c;

/* JADX INFO: renamed from: f.c.k.h.d.e */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC7229e {

    /* JADX INFO: renamed from: a */
    volatile ThreadDeath f47235a;

    /* JADX INFO: renamed from: b */
    public AlgorithmParameters f47236b;

    /* JADX INFO: renamed from: c */
    transient ChoiceFormat f47237c;

    AbstractC7229e() {
    }

    /* JADX INFO: renamed from: d */
    private DecimalFormatSymbols m40360d() {
        return null;
    }

    /* JADX INFO: renamed from: e */
    static Long m40361e(BigDecimal bigDecimal, ArithmeticException arithmeticException, UTFDataFormatException uTFDataFormatException, Principal principal, IllegalAccessException illegalAccessException) {
        return null;
    }

    /* JADX INFO: renamed from: f */
    static KeyException m40362f(Integer num, KeyFactory keyFactory, Process process, DomainCombiner domainCombiner, OffsetDateTime offsetDateTime, AbstractCollection abstractCollection) {
        return null;
    }

    /* JADX INFO: renamed from: a */
    public StreamTokenizer m40363a(OutputStream outputStream, StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {
        return null;
    }

    /* JADX INFO: renamed from: b */
    protected C5062a m40364b(UnsupportedEncodingException unsupportedEncodingException, OptionalDataException optionalDataException, Collections collections, NoSuchFieldError noSuchFieldError) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    public Collections m40365c(Void r1, Comparator comparator, DigestInputStream digestInputStream, ObjectInputValidation objectInputValidation) {
        return null;
    }

    /* JADX INFO: renamed from: g */
    AbstractCollection m40366g(PublicKey publicKey, AssertionError assertionError, BigDecimal bigDecimal, ByteOrder byteOrder, StringWriter stringWriter) {
        return null;
    }

    /* JADX INFO: renamed from: h */
    CloneNotSupportedException m40367h(Iterable iterable, AccessController accessController, FieldPosition fieldPosition, C5069c c5069c) {
        return null;
    }
}
