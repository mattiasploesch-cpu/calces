package p356f.p372c.p451k.p457h.p458d;

import java.io.Console;
import java.io.OutputStream;
import java.nio.BufferOverflowException;
import java.time.LocalDate;
import p148e.p150d.p154l.ViewOnClickListenerC5067a;
import p148e.p150d.p154l.ViewOnClickListenerC5073g;

/* JADX INFO: renamed from: f.c.k.h.d.g */
/* JADX INFO: loaded from: classes.dex */
final class C7231g {

    /* JADX INFO: renamed from: a */
    static Math f47243a;

    /* JADX INFO: renamed from: b */
    static Readable f47244b;

    /* JADX INFO: renamed from: c */
    public LocalDate f47245c;

    /* JADX INFO: renamed from: d */
    protected Console f47246d;

    /* JADX INFO: renamed from: e */
    transient ViewOnClickListenerC5073g f47247e;

    /* JADX INFO: renamed from: f */
    transient ViewOnClickListenerC5067a f47248f;

    /* JADX INFO: renamed from: g */
    transient Runnable f47249g;

    C7231g() {
    }

    /* JADX INFO: renamed from: a */
    public BufferOverflowException m40375a() {
        return null;
    }

    /* JADX INFO: renamed from: b */
    public Process m40376b() {
        return null;
    }

    /* JADX INFO: renamed from: c */
    public OutputStream m40377c() {
        return null;
    }
}
