package p356f.p372c.p451k.p457h.p458d;

import android.net.Uri;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;

/* JADX INFO: renamed from: f.c.k.h.d.c */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC7227c {
    /* JADX INFO: renamed from: a */
    Uri mo40335a();

    /* JADX INFO: renamed from: b */
    InputStream mo40336b();

    /* JADX INFO: renamed from: c */
    Reader mo40337c();

    /* JADX INFO: renamed from: d */
    OutputStream mo40338d();

    /* JADX INFO: renamed from: e */
    Writer mo40339e();
}
