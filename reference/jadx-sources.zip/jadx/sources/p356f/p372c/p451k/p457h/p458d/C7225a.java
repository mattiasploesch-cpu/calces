package p356f.p372c.p451k.p457h.p458d;

import android.content.res.AssetManager;
import android.net.Uri;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.nio.ReadOnlyBufferException;
import p148e.p350v.p351l.C6691a;

/* JADX INFO: renamed from: f.c.k.h.d.a */
/* JADX INFO: loaded from: classes.dex */
public class C7225a implements InterfaceC7227c {

    /* JADX INFO: renamed from: a */
    private final AssetManager f47220a;

    /* JADX INFO: renamed from: b */
    private final String f47221b;

    /* JADX INFO: renamed from: c */
    protected Double f47222c;

    /* JADX INFO: renamed from: d */
    private AssertionError f47223d;

    /* JADX INFO: renamed from: e */
    public CloneNotSupportedException f47224e;

    /* JADX INFO: renamed from: f */
    protected String f47225f = "X19fbm5vd0NYUXJTVkJT";

    /* JADX INFO: renamed from: g */
    private String f47226g = "X19fZlB5T2NqTWdTbExs";

    /* JADX INFO: renamed from: h */
    protected String f47227h = "X19fd2JKeEt5Q2hVbmlWbUI=";

    public C7225a(AssetManager assetManager, String str) {
        this.f47220a = assetManager;
        this.f47221b = str;
    }

    /* JADX INFO: renamed from: i */
    private ReadOnlyBufferException m40334i() {
        return null;
    }

    @Override // p356f.p372c.p451k.p457h.p458d.InterfaceC7227c
    /* JADX INFO: renamed from: a */
    public Uri mo40335a() {
        return null;
    }

    @Override // p356f.p372c.p451k.p457h.p458d.InterfaceC7227c
    /* JADX INFO: renamed from: b */
    public InputStream mo40336b() throws IOException {
        try {
            return new ByteArrayInputStream(C6691a.m36702f(this.f47220a, this.f47221b).getBytes());
        } catch (Exception e2) {
            e2.printStackTrace();
            throw new IOException();
        }
    }

    @Override // p356f.p372c.p451k.p457h.p458d.InterfaceC7227c
    /* JADX INFO: renamed from: c */
    public Reader mo40337c() {
        return new InputStreamReader(mo40336b());
    }

    @Override // p356f.p372c.p451k.p457h.p458d.InterfaceC7227c
    /* JADX INFO: renamed from: d */
    public OutputStream mo40338d() {
        throw new UnsupportedOperationException();
    }

    @Override // p356f.p372c.p451k.p457h.p458d.InterfaceC7227c
    /* JADX INFO: renamed from: e */
    public Writer mo40339e() {
        throw new UnsupportedOperationException();
    }

    /* JADX INFO: renamed from: f */
    protected Exception m40340f() {
        return null;
    }

    /* JADX INFO: renamed from: g */
    public Byte m40341g() {
        return null;
    }

    /* JADX INFO: renamed from: h */
    protected StringBuilder m40342h() {
        return null;
    }
}
