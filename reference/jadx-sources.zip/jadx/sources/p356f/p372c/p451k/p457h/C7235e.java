package p356f.p372c.p451k.p457h;

import java.io.EOFException;
import java.nio.BufferUnderflowException;
import java.text.Bidi;
import java.time.LocalDateTime;
import java.util.ArrayDeque;

/* JADX INFO: renamed from: f.c.k.h.e */
/* JADX INFO: loaded from: classes.dex */
final class C7235e {

    /* JADX INFO: renamed from: a */
    static EOFException f47272a;

    /* JADX INFO: renamed from: b */
    static ArrayDeque f47273b;

    /* JADX INFO: renamed from: c */
    public LocalDateTime f47274c;

    /* JADX INFO: renamed from: d */
    public AbstractMethodError f47275d;

    /* JADX INFO: renamed from: e */
    public BufferUnderflowException f47276e;

    /* JADX INFO: renamed from: f */
    private String f47277f = "X19fcmR5YmJNZk9J";

    /* JADX INFO: renamed from: g */
    private String f47278g = "X19fc0FfcUtjb3B4Sg==";

    /* JADX INFO: renamed from: h */
    protected String f47279h = "X19fdkxCQU1XeXNo";

    C7235e() {
    }

    /* JADX INFO: renamed from: a */
    private Bidi m40405a() {
        return null;
    }
}
