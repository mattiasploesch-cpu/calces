package p356f.p372c.p451k.p457h;

import java.io.CharArrayReader;
import java.io.DataInputStream;
import java.io.InputStreamReader;
import java.io.ObjectStreamConstants;
import java.io.PipedInputStream;
import java.io.UnsupportedEncodingException;
import java.nio.InvalidMarkException;
import java.security.AccessControlContext;
import java.security.AccessController;
import java.security.Key;
import java.security.PermissionCollection;
import java.security.UnrecoverableKeyException;
import java.time.MonthDay;

/* JADX INFO: renamed from: f.c.k.h.a */
/* JADX INFO: loaded from: classes.dex */
final class C7222a {

    /* JADX INFO: renamed from: a */
    transient MonthDay f47198a;

    /* JADX INFO: renamed from: b */
    volatile AccessControlContext f47199b;

    /* JADX INFO: renamed from: c */
    protected ObjectStreamConstants f47200c;

    /* JADX INFO: renamed from: d */
    public Key f47201d;

    /* JADX INFO: renamed from: e */
    public Error f47202e;

    /* JADX INFO: renamed from: f */
    protected CharArrayReader f47203f;

    /* JADX INFO: renamed from: g */
    public DataInputStream f47204g;

    /* JADX INFO: renamed from: h */
    public InvalidMarkException f47205h;

    /* JADX INFO: renamed from: i */
    private String f47206i = "X19fUWZZcnF0S1hsal9Y";

    /* JADX INFO: renamed from: j */
    private String f47207j = "X19fdFZBZ0pnaE9vY3FBdg==";

    C7222a() {
    }

    /* JADX INFO: renamed from: a */
    private String m40314a() {
        return null;
    }

    /* JADX INFO: renamed from: b */
    private IllegalStateException m40315b() {
        return null;
    }

    /* JADX INFO: renamed from: c */
    protected InvalidMarkException m40316c() {
        return null;
    }

    /* JADX INFO: renamed from: d */
    synchronized InputStreamReader m40317d(AccessController accessController, PermissionCollection permissionCollection, PipedInputStream pipedInputStream, UnsupportedEncodingException unsupportedEncodingException, PipedInputStream pipedInputStream2, UnrecoverableKeyException unrecoverableKeyException) {
        return null;
    }
}
