package p356f.p372c.p451k;

import java.nio.BufferOverflowException;
import java.security.SecureRandomSpi;
import java.text.MessageFormat;
import java.time.ZoneId;

/* JADX INFO: renamed from: f.c.k.c */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC7160c {

    /* JADX INFO: renamed from: a */
    public ZoneId f46644a;

    /* JADX INFO: renamed from: b */
    private NoSuchFieldException f46645b;

    /* JADX INFO: renamed from: c */
    transient MessageFormat f46646c;

    /* JADX INFO: renamed from: d */
    transient BufferOverflowException f46647d;

    /* JADX INFO: renamed from: e */
    public BufferOverflowException f46648e;

    /* JADX INFO: renamed from: f */
    private StringIndexOutOfBoundsException f46649f;

    /* JADX INFO: renamed from: g */
    private String f46650g = "X19fdWZ4cmdr";

    AbstractC7160c() {
    }

    /* JADX INFO: renamed from: a */
    final SecureRandomSpi m39859a() {
        return null;
    }

    /* JADX INFO: renamed from: b */
    public ClassNotFoundException m39860b() {
        return null;
    }
}
