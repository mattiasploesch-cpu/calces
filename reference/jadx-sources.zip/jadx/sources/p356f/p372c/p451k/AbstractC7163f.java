package p356f.p372c.p451k;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.Console;
import java.io.DataOutput;
import java.io.FileDescriptor;
import java.io.LineNumberReader;
import java.io.ObjectOutput;
import java.io.OutputStreamWriter;
import java.io.PushbackReader;
import java.io.SerializablePermission;
import java.security.AccessControlException;
import java.security.CodeSigner;
import java.security.KeyManagementException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.UnrecoverableKeyException;
import java.text.AttributedCharacterIterator;
import java.util.ArrayDeque;
import p148e.p150d.p154l.ViewOnClickListenerC5073g;

/* JADX INFO: renamed from: f.c.k.f */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC7163f {

    /* JADX INFO: renamed from: a */
    public IllegalAccessException f46656a;

    /* JADX INFO: renamed from: b */
    transient OutputStreamWriter f46657b;

    /* JADX INFO: renamed from: c */
    protected AttributedCharacterIterator f46658c;

    /* JADX INFO: renamed from: d */
    private ViewOnClickListenerC5073g f46659d;

    /* JADX INFO: renamed from: e */
    private NumberFormatException f46660e;

    /* JADX INFO: renamed from: f */
    protected FileDescriptor f46661f;

    /* JADX INFO: renamed from: g */
    private System f46662g;

    /* JADX INFO: renamed from: h */
    public BufferedReader f46663h;

    AbstractC7163f() {
    }

    /* JADX INFO: renamed from: f */
    private System m39878f() {
        return null;
    }

    /* JADX INFO: renamed from: a */
    synchronized Character m39879a() {
        return null;
    }

    /* JADX INFO: renamed from: b */
    final ObjectOutput m39880b() {
        return null;
    }

    /* JADX INFO: renamed from: c */
    protected StringIndexOutOfBoundsException m39881c(Compiler compiler, Console console, KeyManagementException keyManagementException) {
        return null;
    }

    /* JADX INFO: renamed from: d */
    public IllegalMonitorStateException m39882d(PrivateKey privateKey) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    public UnsatisfiedLinkError m39883e() {
        return null;
    }

    /* JADX INFO: renamed from: g */
    public Void m39884g() {
        return null;
    }

    /* JADX INFO: renamed from: h */
    protected LineNumberReader m39885h() {
        return null;
    }

    /* JADX INFO: renamed from: i */
    ByteArrayOutputStream m39886i(UnknownError unknownError, ArrayDeque arrayDeque) {
        return null;
    }

    /* JADX INFO: renamed from: j */
    public PushbackReader m39887j(SerializablePermission serializablePermission, CodeSigner codeSigner, Provider provider, AccessControlException accessControlException, DataOutput dataOutput, UnrecoverableKeyException unrecoverableKeyException) {
        return null;
    }
}
