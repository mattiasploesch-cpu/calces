package p356f.p372c.p451k;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.InvalidObjectException;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.StringWriter;
import java.io.UncheckedIOException;
import java.nio.ByteBuffer;
import java.security.CryptoPrimitive;
import java.security.GuardedObject;
import java.security.KeyException;
import java.security.KeyRep;
import java.security.PrivilegedActionException;
import java.security.SignatureSpi;
import java.security.UnrecoverableKeyException;
import java.text.BreakIterator;
import java.text.Collator;
import java.time.MonthDay;
import java.time.YearMonth;
import java.util.AbstractCollection;
import java.util.AbstractList;
import java.util.Stack;
import p148e.p150d.p154l.ViewOnClickListenerC5073g;

/* JADX INFO: renamed from: f.c.k.e */
/* JADX INFO: loaded from: classes.dex */
public class C7162e {

    /* JADX INFO: renamed from: a */
    transient StringBuilder f46655a;

    /* JADX INFO: renamed from: c */
    static CryptoPrimitive m39869c(IllegalAccessError illegalAccessError, Stack stack, ViewOnClickListenerC5073g viewOnClickListenerC5073g, StringWriter stringWriter, ByteBuffer byteBuffer) {
        return null;
    }

    /* JADX INFO: renamed from: h */
    static TypeNotPresentException m39870h(Exception exc, KeyRep keyRep) {
        return null;
    }

    /* JADX INFO: renamed from: a */
    KeyException m39871a(PrintStream printStream) {
        return null;
    }

    /* JADX INFO: renamed from: b */
    final ViewOnClickListenerC5073g m39872b(BreakIterator breakIterator) {
        return null;
    }

    /* JADX INFO: renamed from: d */
    Short m39873d(UncheckedIOException uncheckedIOException, Number number, FilterOutputStream filterOutputStream) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    synchronized YearMonth m39874e(IllegalArgumentException illegalArgumentException, Iterable iterable) {
        return null;
    }

    /* JADX INFO: renamed from: f */
    final SignatureSpi m39875f(AutoCloseable autoCloseable, MonthDay monthDay, IllegalAccessException illegalAccessException, BufferedOutputStream bufferedOutputStream, OutputStreamWriter outputStreamWriter, EnumConstantNotPresentException enumConstantNotPresentException) {
        return null;
    }

    /* JADX INFO: renamed from: g */
    EnumConstantNotPresentException m39876g(UnrecoverableKeyException unrecoverableKeyException, ProcessBuilder processBuilder, PrivilegedActionException privilegedActionException, Number number, StringBuilder sb, FileOutputStream fileOutputStream) {
        return null;
    }

    /* JADX INFO: renamed from: i */
    synchronized Character m39877i(GuardedObject guardedObject, AbstractCollection abstractCollection, Collator collator, AbstractList abstractList, InvalidObjectException invalidObjectException, Runnable runnable) {
        return null;
    }
}
