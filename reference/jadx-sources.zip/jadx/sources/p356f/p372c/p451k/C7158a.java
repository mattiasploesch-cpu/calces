package p356f.p372c.p451k;

import java.io.CharConversionException;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.PushbackReader;
import java.io.StringBufferInputStream;
import java.io.StringWriter;
import java.io.Writer;
import java.math.BigInteger;
import java.nio.DoubleBuffer;
import java.security.AccessControlContext;
import java.security.DigestInputStream;
import java.security.IdentityScope;
import java.security.InvalidKeyException;
import java.security.InvalidParameterException;
import java.security.KeyPairGenerator;
import java.security.ProviderException;
import java.security.Security;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.time.OffsetTime;
import java.util.regex.Pattern;
import p356f.p372c.p375g.p376d.p377a.C6822b;

/* JADX INFO: renamed from: f.c.k.a */
/* JADX INFO: loaded from: classes.dex */
final class C7158a {

    /* JADX INFO: renamed from: a */
    protected CharConversionException f46629a;

    /* JADX INFO: renamed from: b */
    protected InvalidParameterException f46630b;

    /* JADX INFO: renamed from: c */
    transient IOException f46631c;

    /* JADX INFO: renamed from: d */
    private UnsupportedClassVersionError f46632d;

    /* JADX INFO: renamed from: e */
    public StringWriter f46633e;

    /* JADX INFO: renamed from: f */
    volatile Pattern f46634f;

    /* JADX INFO: renamed from: g */
    volatile PushbackReader f46635g;

    /* JADX INFO: renamed from: h */
    protected AccessControlContext f46636h;

    /* JADX INFO: renamed from: i */
    protected DoubleBuffer f46637i;

    C7158a() {
    }

    /* JADX INFO: renamed from: b */
    private NumberFormatException m39842b(Certificate certificate, Security security, StringBufferInputStream stringBufferInputStream) {
        return null;
    }

    /* JADX INFO: renamed from: a */
    final NoSuchMethodException m39843a() {
        return null;
    }

    /* JADX INFO: renamed from: c */
    KeyPairGenerator m39844c(Enum r1, InterruptedException interruptedException, IdentityScope identityScope, Short sh, OffsetTime offsetTime, Exception exc) {
        return null;
    }

    /* JADX INFO: renamed from: d */
    protected IncompatibleClassChangeError m39845d() {
        return null;
    }

    /* JADX INFO: renamed from: e */
    protected NoSuchFieldError m39846e() {
        return null;
    }

    /* JADX INFO: renamed from: f */
    protected BigInteger m39847f() {
        return null;
    }

    /* JADX INFO: renamed from: g */
    protected ProviderException m39848g(ClassCircularityError classCircularityError, InvalidKeyException invalidKeyException, DigestInputStream digestInputStream, C6822b c6822b, DoubleBuffer doubleBuffer) {
        return null;
    }

    /* JADX INFO: renamed from: h */
    Appendable m39849h(Writer writer, ProcessBuilder processBuilder, UnrecoverableKeyException unrecoverableKeyException, ReflectiveOperationException reflectiveOperationException, ObjectOutput objectOutput) {
        return null;
    }
}
