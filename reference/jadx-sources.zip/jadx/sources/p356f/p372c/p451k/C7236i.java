package p356f.p372c.p451k;

import java.io.Console;
import java.io.EOFException;
import java.io.Externalizable;
import java.io.ObjectStreamConstants;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.text.ParsePosition;

/* JADX INFO: renamed from: f.c.k.i */
/* JADX INFO: loaded from: classes.dex */
public class C7236i {

    /* JADX INFO: renamed from: a */
    transient Externalizable f47280a;

    /* JADX INFO: renamed from: b */
    transient ParsePosition f47281b;

    /* JADX INFO: renamed from: c */
    public IllegalAccessException f47282c;

    /* JADX INFO: renamed from: d */
    private String f47283d = "X19fQ1h3RmRX";

    /* JADX INFO: renamed from: e */
    protected String f47284e = "X19fRnN4d0tVTGZH";

    /* JADX INFO: renamed from: f */
    protected String f47285f = "X19fT3h3cVN4d1Z0d2RfY28=";

    /* JADX INFO: renamed from: b */
    private IntBuffer m40406b() {
        return null;
    }

    /* JADX INFO: renamed from: a */
    protected PublicKey m40407a(OutputStream outputStream, ByteBuffer byteBuffer, VirtualMachineError virtualMachineError, EOFException eOFException, NoSuchAlgorithmException noSuchAlgorithmException) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    public Class m40408c() {
        return null;
    }

    /* JADX INFO: renamed from: d */
    protected StackTraceElement m40409d(ExceptionInInitializerError exceptionInInitializerError, Console console, ObjectStreamConstants objectStreamConstants) {
        return null;
    }
}
