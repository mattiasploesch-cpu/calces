package p356f.p372c.p451k;

import java.io.DataOutputStream;
import java.io.FilterOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamClass;
import java.io.ObjectStreamField;
import java.io.OutputStream;
import java.io.PushbackReader;
import java.nio.ShortBuffer;
import java.security.AccessControlException;
import java.security.Guard;
import java.security.KeyFactorySpi;
import java.security.SecureRandomSpi;
import java.text.ChoiceFormat;
import java.text.Collator;
import java.text.ParsePosition;
import java.time.Period;
import java.util.ArrayList;
import p148e.p150d.p154l.ViewOnClickListenerC5067a;

/* JADX INFO: renamed from: f.c.k.d */
/* JADX INFO: loaded from: classes.dex */
final class C7161d {

    /* JADX INFO: renamed from: a */
    protected String f46651a;

    /* JADX INFO: renamed from: b */
    protected ObjectStreamField f46652b;

    /* JADX INFO: renamed from: c */
    public AssertionError f46653c;

    /* JADX INFO: renamed from: d */
    public String f46654d = "X19fS2R3cXZFVEo=";

    C7161d() {
    }

    /* JADX INFO: renamed from: c */
    static DataOutputStream m39861c(ViewOnClickListenerC5067a viewOnClickListenerC5067a, NullPointerException nullPointerException, ChoiceFormat choiceFormat) {
        return null;
    }

    /* JADX INFO: renamed from: a */
    final ObjectOutputStream m39862a() {
        return null;
    }

    /* JADX INFO: renamed from: b */
    Period m39863b(OutputStream outputStream, Short sh, Exception exc, ThreadDeath threadDeath, Collator collator) {
        return null;
    }

    /* JADX INFO: renamed from: d */
    synchronized PushbackReader m39864d(IllegalAccessException illegalAccessException, ShortBuffer shortBuffer, SecureRandomSpi secureRandomSpi, Long l2) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    final KeyFactorySpi m39865e(ArrayList arrayList, Byte b2, ObjectOutputStream objectOutputStream) {
        return null;
    }

    /* JADX INFO: renamed from: f */
    protected ObjectStreamClass m39866f(ParsePosition parsePosition) {
        return null;
    }

    /* JADX INFO: renamed from: g */
    protected FilterOutputStream m39867g(Guard guard, NoSuchMethodError noSuchMethodError, SecureRandomSpi secureRandomSpi, ExceptionInInitializerError exceptionInInitializerError, IndexOutOfBoundsException indexOutOfBoundsException) {
        return null;
    }

    /* JADX INFO: renamed from: h */
    public ClassCastException m39868h(AccessControlException accessControlException) {
        return null;
    }
}
