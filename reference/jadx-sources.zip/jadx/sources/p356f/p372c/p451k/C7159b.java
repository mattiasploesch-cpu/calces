package p356f.p372c.p451k;

import java.io.CharConversionException;
import java.io.FileDescriptor;
import java.io.FileReader;
import java.io.InvalidClassException;
import java.io.Reader;
import java.io.UTFDataFormatException;
import java.nio.MappedByteBuffer;
import java.nio.ReadOnlyBufferException;
import java.security.AccessControlException;
import java.security.AlgorithmParameters;
import java.security.AuthProvider;
import java.security.CryptoPrimitive;
import java.security.Identity;
import java.security.Key;
import java.security.KeyPairGeneratorSpi;
import java.security.ProtectionDomain;
import java.security.SignedObject;
import java.security.UnrecoverableEntryException;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import p148e.p150d.p153k.C5065d;
import p356f.p372c.p375g.p376d.p377a.C6821a;

/* JADX INFO: renamed from: f.c.k.b */
/* JADX INFO: loaded from: classes.dex */
final class C7159b {

    /* JADX INFO: renamed from: a */
    static Key f46638a;

    /* JADX INFO: renamed from: b */
    transient FileReader f46639b;

    /* JADX INFO: renamed from: c */
    volatile Reader f46640c;

    /* JADX INFO: renamed from: d */
    protected LocalDateTime f46641d;

    /* JADX INFO: renamed from: e */
    public AccessControlException f46642e;

    /* JADX INFO: renamed from: f */
    volatile SignedObject f46643f;

    C7159b() {
    }

    /* JADX INFO: renamed from: a */
    private AuthProvider m39850a(ProtectionDomain protectionDomain, Identity identity) {
        return null;
    }

    /* JADX INFO: renamed from: b */
    private ZonedDateTime m39851b(Runtime runtime, FileDescriptor fileDescriptor, LocalTime localTime, Class cls) {
        return null;
    }

    /* JADX INFO: renamed from: c */
    public MappedByteBuffer m39852c(C5065d c5065d, IllegalAccessException illegalAccessException, KeyPairGeneratorSpi keyPairGeneratorSpi, Appendable appendable) {
        return null;
    }

    /* JADX INFO: renamed from: d */
    public CryptoPrimitive m39853d(UnrecoverableEntryException unrecoverableEntryException, Double d2, Process process, C5065d c5065d, AssertionError assertionError) {
        return null;
    }

    /* JADX INFO: renamed from: e */
    InheritableThreadLocal m39854e(UTFDataFormatException uTFDataFormatException, InstantiationError instantiationError, AlgorithmParameters algorithmParameters) {
        return null;
    }

    /* JADX INFO: renamed from: f */
    final Class m39855f(ReadOnlyBufferException readOnlyBufferException) {
        return null;
    }

    /* JADX INFO: renamed from: g */
    public AbstractMethodError m39856g(C6821a c6821a, InvalidClassException invalidClassException) {
        return null;
    }

    /* JADX INFO: renamed from: h */
    public UnsupportedClassVersionError m39857h(BootstrapMethodError bootstrapMethodError) {
        return null;
    }

    /* JADX INFO: renamed from: i */
    synchronized CharConversionException m39858i() {
        return null;
    }
}
