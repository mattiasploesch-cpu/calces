package p356f.p372c.p462o;

/* JADX INFO: renamed from: f.c.o.a */
/* JADX INFO: loaded from: classes.dex */
public class C7265a {
    /* JADX INFO: renamed from: a */
    public static int m40435a(byte b2, byte b3) {
        return b2 - b3;
    }

    /* JADX INFO: renamed from: b */
    public static int m40436b(byte b2) {
        return b2 & 255;
    }
}
