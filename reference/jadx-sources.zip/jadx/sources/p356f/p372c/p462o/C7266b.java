package p356f.p372c.p462o;

/* JADX INFO: renamed from: f.c.o.b */
/* JADX INFO: loaded from: classes.dex */
public class C7266b {
    /* JADX INFO: renamed from: a */
    public static int m40437a(char c2, char c3) {
        return c2 - c3;
    }
}
