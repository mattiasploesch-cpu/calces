package p356f.p372c.p462o;

/* JADX INFO: renamed from: f.c.o.i */
/* JADX INFO: loaded from: classes.dex */
public class C7273i {
    /* JADX INFO: renamed from: a */
    public static int m40467a(short s, short s2) {
        return s - s2;
    }

    /* JADX INFO: renamed from: b */
    public static int m40468b(short s) {
        return s & 65535;
    }
}
