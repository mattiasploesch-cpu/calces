package p356f.p372c.p462o;

/* JADX INFO: renamed from: f.c.o.h */
/* JADX INFO: loaded from: classes.dex */
public class C7272h {
    /* JADX INFO: renamed from: a */
    public static int m40448a(int i2, int i3) {
        int i4 = i2 + i3;
        if (((i2 ^ i4) & (i3 ^ i4)) >= 0) {
            return i4;
        }
        throw new ArithmeticException("integer overflow");
    }

    /* JADX INFO: renamed from: b */
    public static long m40449b(long j2, long j3) {
        long j4 = j2 + j3;
        if (((j2 ^ j4) & (j3 ^ j4)) >= 0) {
            return j4;
        }
        throw new ArithmeticException("long overflow");
    }

    /* JADX INFO: renamed from: c */
    public static int m40450c(int i2) {
        if (i2 != Integer.MIN_VALUE) {
            return i2 - 1;
        }
        throw new ArithmeticException("integer overflow");
    }

    /* JADX INFO: renamed from: d */
    public static long m40451d(long j2) {
        if (j2 != Long.MIN_VALUE) {
            return j2 - 1;
        }
        throw new ArithmeticException("long overflow");
    }

    /* JADX INFO: renamed from: e */
    public static int m40452e(int i2, int i3) {
        int i4 = i2 / i3;
        return ((i2 ^ i3) >= 0 || i3 * i4 == i2) ? i4 : i4 - 1;
    }

    /* JADX INFO: renamed from: f */
    public static long m40453f(long j2, long j3) {
        long j4 = j2 / j3;
        return ((j2 ^ j3) >= 0 || j3 * j4 == j2) ? j4 : j4 - 1;
    }

    /* JADX INFO: renamed from: g */
    public static int m40454g(int i2, int i3) {
        return i2 - (m40452e(i2, i3) * i3);
    }

    /* JADX INFO: renamed from: h */
    public static long m40455h(long j2, long j3) {
        return j2 - (m40453f(j2, j3) * j3);
    }

    /* JADX INFO: renamed from: i */
    public static int m40456i(int i2) {
        if (i2 != Integer.MAX_VALUE) {
            return i2 + 1;
        }
        throw new ArithmeticException("integer overflow");
    }

    /* JADX INFO: renamed from: j */
    public static long m40457j(long j2) {
        if (j2 != Long.MAX_VALUE) {
            return j2 + 1;
        }
        throw new ArithmeticException("long overflow");
    }

    /* JADX INFO: renamed from: k */
    public static int m40458k(int i2, int i3) {
        long j2 = ((long) i2) * ((long) i3);
        int i4 = (int) j2;
        if (i4 == j2) {
            return i4;
        }
        throw new ArithmeticException("integer overflow");
    }

    /* JADX INFO: renamed from: l */
    public static long m40459l(long j2, long j3) {
        long j4 = j2 * j3;
        if (((Math.abs(j2) | Math.abs(j3)) >>> 31) == 0 || ((j3 == 0 || j4 / j3 == j2) && !(j2 == Long.MIN_VALUE && j3 == -1))) {
            return j4;
        }
        throw new ArithmeticException("long overflow");
    }

    /* JADX INFO: renamed from: m */
    public static int m40460m(int i2) {
        if (i2 != Integer.MIN_VALUE) {
            return -i2;
        }
        throw new ArithmeticException("integer overflow");
    }

    /* JADX INFO: renamed from: n */
    public static long m40461n(long j2) {
        if (j2 != Long.MIN_VALUE) {
            return -j2;
        }
        throw new ArithmeticException("long overflow");
    }

    /* JADX INFO: renamed from: o */
    public static double m40462o(double d2) {
        if (Double.isNaN(d2) || d2 == Double.NEGATIVE_INFINITY) {
            return d2;
        }
        if (d2 == 0.0d) {
            return -4.9E-324d;
        }
        return Double.longBitsToDouble(Double.doubleToRawLongBits(d2) + (d2 > 0.0d ? -1L : 1L));
    }

    /* JADX INFO: renamed from: p */
    public static double m40463p(double d2) {
        if (Double.isNaN(d2) || d2 == Double.POSITIVE_INFINITY) {
            return d2;
        }
        double d3 = d2 + 0.0d;
        return Double.longBitsToDouble(Double.doubleToRawLongBits(d3) + (d3 >= 0.0d ? 1L : -1L));
    }

    /* JADX INFO: renamed from: q */
    public static int m40464q(int i2, int i3) {
        int i4 = i2 - i3;
        if (((i2 ^ i4) & (i3 ^ i2)) >= 0) {
            return i4;
        }
        throw new ArithmeticException("integer overflow");
    }

    /* JADX INFO: renamed from: r */
    public static long m40465r(long j2, long j3) {
        long j4 = j2 - j3;
        if (((j2 ^ j4) & (j3 ^ j2)) >= 0) {
            return j4;
        }
        throw new ArithmeticException("long overflow");
    }

    /* JADX INFO: renamed from: s */
    public static int m40466s(long j2) {
        int i2 = (int) j2;
        if (i2 == j2) {
            return i2;
        }
        throw new ArithmeticException("integer overflow");
    }
}
