package p356f.p372c.p462o;

import p356f.p372c.p461n.InterfaceC7244e;

/* JADX INFO: renamed from: f.c.o.f */
/* JADX INFO: loaded from: classes.dex */
public class C7270f {
    /* JADX INFO: renamed from: a */
    public static void m40446a(Iterable iterable, InterfaceC7244e interfaceC7244e) {
    }
}
