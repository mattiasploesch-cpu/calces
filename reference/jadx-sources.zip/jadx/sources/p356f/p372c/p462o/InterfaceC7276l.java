package p356f.p372c.p462o;

/* JADX INFO: renamed from: f.c.o.l */
/* JADX INFO: loaded from: classes.dex */
public @interface InterfaceC7276l {
}
