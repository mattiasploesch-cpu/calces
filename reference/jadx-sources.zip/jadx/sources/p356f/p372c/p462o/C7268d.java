package p356f.p372c.p462o;

/* JADX INFO: renamed from: f.c.o.d */
/* JADX INFO: loaded from: classes.dex */
public class C7268d {
    /* JADX INFO: renamed from: a */
    public static boolean m40440a(float f2) {
        return Math.abs(f2) <= Float.MAX_VALUE;
    }
}
