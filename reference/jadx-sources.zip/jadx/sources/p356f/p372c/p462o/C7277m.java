package p356f.p372c.p462o;

/* JADX INFO: renamed from: f.c.o.m */
/* JADX INFO: loaded from: classes.dex */
public class C7277m {
    /* JADX INFO: renamed from: a */
    public static int m40475a(int i2, int i3) {
        if (i2 < i3) {
            return -1;
        }
        return i2 == i3 ? 0 : 1;
    }

    /* JADX INFO: renamed from: b */
    public static int m40476b(int i2) {
        return i2;
    }
}
