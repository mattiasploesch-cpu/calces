package p356f.p372c.p462o;

/* JADX INFO: renamed from: f.c.o.g */
/* JADX INFO: loaded from: classes.dex */
public class C7271g {
    /* JADX INFO: renamed from: a */
    public static int m40447a(long j2, long j3) {
        if (j2 < j3) {
            return -1;
        }
        return j2 == j3 ? 0 : 1;
    }
}
