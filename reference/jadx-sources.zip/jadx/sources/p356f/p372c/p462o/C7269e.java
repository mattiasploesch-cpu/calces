package p356f.p372c.p462o;

/* JADX INFO: renamed from: f.c.o.e */
/* JADX INFO: loaded from: classes.dex */
public class C7269e {
    /* JADX INFO: renamed from: a */
    public static int m40441a(int i2, int i3) {
        if (i2 < i3) {
            return -1;
        }
        return i2 == i3 ? 0 : 1;
    }

    /* JADX INFO: renamed from: b */
    public static int m40442b(int i2, int i3) {
        return Math.max(i2, i3);
    }

    /* JADX INFO: renamed from: c */
    public static int m40443c(int i2, int i3) {
        return i2 + i3;
    }

    /* JADX INFO: renamed from: d */
    public static long m40444d(int i2) {
        return ((long) i2) & 4294967295L;
    }

    /* JADX INFO: renamed from: e */
    public static String m40445e(int i2) {
        return Long.toString(m40444d(i2));
    }
}
