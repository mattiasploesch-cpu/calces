package p356f.p372c.p462o;

/* JADX INFO: renamed from: f.c.o.c */
/* JADX INFO: loaded from: classes.dex */
public class C7267c {
    /* JADX INFO: renamed from: a */
    public static int m40438a(double d2) {
        long jDoubleToLongBits = Double.doubleToLongBits(d2);
        return (int) (jDoubleToLongBits ^ (jDoubleToLongBits >>> 32));
    }

    /* JADX INFO: renamed from: b */
    public static boolean m40439b(double d2) {
        return Math.abs(d2) <= Double.MAX_VALUE;
    }
}
