package p356f.p372c.p462o;

/* JADX INFO: renamed from: f.c.o.k */
/* JADX INFO: loaded from: classes.dex */
public class C7275k<T> {

    /* JADX INFO: renamed from: a */
    private T f47300a;

    /* JADX INFO: renamed from: e */
    private synchronized T m40470e() {
        T tMo40472b;
        tMo40472b = mo40472b();
        this.f47300a = tMo40472b;
        return tMo40472b;
    }

    /* JADX INFO: renamed from: a */
    public synchronized T m40471a() {
        T t = this.f47300a;
        if (t != null) {
            return t;
        }
        return m40470e();
    }

    /* JADX INFO: renamed from: b */
    protected T mo40472b() {
        return null;
    }

    /* JADX INFO: renamed from: c */
    public synchronized void m40473c() {
        this.f47300a = null;
    }

    /* JADX INFO: renamed from: d */
    public synchronized void m40474d(T t) {
        this.f47300a = t;
    }
}
