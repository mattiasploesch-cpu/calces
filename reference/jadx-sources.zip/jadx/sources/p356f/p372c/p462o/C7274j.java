package p356f.p372c.p462o;

/* JADX INFO: renamed from: f.c.o.j */
/* JADX INFO: loaded from: classes.dex */
public class C7274j {
    /* JADX INFO: renamed from: a */
    public static String m40469a() {
        return "\n";
    }
}
