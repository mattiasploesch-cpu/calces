package p356f.p372c.p466r;

/* JADX INFO: renamed from: f.c.r.a */
/* JADX INFO: loaded from: classes.dex */
public class C7280a<T> {

    /* JADX INFO: renamed from: a */
    private T f47302a;

    public C7280a() {
    }

    public C7280a(T t) {
        this.f47302a = t;
    }

    /* JADX INFO: renamed from: a */
    public T m40478a() {
        return this.f47302a;
    }

    /* JADX INFO: renamed from: b */
    public void m40479b(T t) {
        this.f47302a = t;
    }
}
