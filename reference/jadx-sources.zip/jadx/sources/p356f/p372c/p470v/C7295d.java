package p356f.p372c.p470v;

/* JADX INFO: renamed from: f.c.v.d */
/* JADX INFO: loaded from: classes.dex */
public class C7295d extends RuntimeException {

    /* JADX INFO: renamed from: u2 */
    private static final long f47408u2 = -3666751008965953603L;

    public C7295d() {
    }

    public C7295d(String str) {
        super(str);
    }

    public C7295d(String str, Throwable th) {
        super(str, th);
    }

    public C7295d(Throwable th) {
        super(th);
    }
}
