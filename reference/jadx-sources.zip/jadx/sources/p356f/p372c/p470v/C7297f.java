package p356f.p372c.p470v;

import java.util.Arrays;
import java.util.Comparator;
import p356f.p372c.p461n.InterfaceC7260u;

/* JADX INFO: renamed from: f.c.v.f */
/* JADX INFO: loaded from: classes.dex */
public final class C7297f {
    private C7297f() {
        throw new AssertionError("No java.util.Objects instances for you!");
    }

    /* JADX INFO: renamed from: a */
    public static <T> int m40629a(T t, T t2, Comparator<? super T> comparator) {
        if (t == t2) {
            return 0;
        }
        return comparator.compare(t, t2);
    }

    /* JADX INFO: renamed from: b */
    public static boolean m40630b(Object obj, Object obj2) {
        return obj == obj2 || (obj != null && obj.equals(obj2));
    }

    /* JADX INFO: renamed from: c */
    public static int m40631c(Object... objArr) {
        return Arrays.hashCode(objArr);
    }

    /* JADX INFO: renamed from: d */
    public static int m40632d(Object obj) {
        if (obj != null) {
            return obj.hashCode();
        }
        return 0;
    }

    /* JADX INFO: renamed from: e */
    public static int m40633e(Object... objArr) {
        return Arrays.hashCode(objArr);
    }

    /* JADX INFO: renamed from: f */
    public static boolean m40634f(Object obj) {
        return obj == null;
    }

    /* JADX INFO: renamed from: g */
    public static boolean m40635g(Object obj) {
        return obj != null;
    }

    /* JADX INFO: renamed from: h */
    public static <T> T m40636h(T t) {
        t.getClass();
        return t;
    }

    /* JADX INFO: renamed from: i */
    public static <T> T m40637i(T t, InterfaceC7260u<String> interfaceC7260u) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException(interfaceC7260u.get());
    }

    /* JADX INFO: renamed from: j */
    public static <T> T m40638j(T t, String str) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException(str);
    }

    /* JADX INFO: renamed from: k */
    public static String m40639k(Object obj) {
        return String.valueOf(obj);
    }

    /* JADX INFO: renamed from: l */
    public static String m40640l(Object obj, String str) {
        return obj != null ? obj.toString() : str;
    }
}
