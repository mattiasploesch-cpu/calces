package p356f.p372c.p470v;

import java.util.Iterator;
import p356f.p372c.p461n.InterfaceC7244e;

/* JADX INFO: renamed from: f.c.v.l */
/* JADX INFO: loaded from: classes.dex */
public class C7303l<T> {

    /* JADX INFO: renamed from: a */
    private Iterator<T> f47443a;

    public C7303l(Iterator<T> it) {
        this.f47443a = it;
    }

    /* JADX INFO: renamed from: b */
    private boolean m40721b() {
        return this.f47443a.hasNext();
    }

    /* JADX INFO: renamed from: c */
    private T m40722c() {
        return this.f47443a.next();
    }

    /* JADX INFO: renamed from: a */
    public void m40723a(InterfaceC7244e<T> interfaceC7244e) {
        C7297f.m40636h(interfaceC7244e);
        while (m40721b()) {
            interfaceC7244e.mo171a(m40722c());
        }
    }
}
