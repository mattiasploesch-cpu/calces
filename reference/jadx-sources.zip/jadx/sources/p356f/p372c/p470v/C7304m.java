package p356f.p372c.p470v;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/* JADX INFO: renamed from: f.c.v.m */
/* JADX INFO: loaded from: classes.dex */
public class C7304m<E> extends C7293b<E> {

    /* JADX INFO: renamed from: c */
    private final List<E> f47444c;

    public C7304m(List<E> list) {
        super(list);
        this.f47444c = list;
    }

    /* JADX INFO: renamed from: d */
    public void m40724d(Comparator<? super E> comparator) {
        Collections.sort(this.f47444c, comparator);
    }
}
