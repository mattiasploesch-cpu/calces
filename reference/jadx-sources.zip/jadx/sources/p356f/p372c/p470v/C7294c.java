package p356f.p372c.p470v;

import java.util.Comparator;
import p356f.p372c.p461n.InterfaceC7262w;
import p356f.p372c.p462o.C7269e;

/* JADX INFO: renamed from: f.c.v.c */
/* JADX INFO: loaded from: classes.dex */
public class C7294c {

    /* JADX INFO: Add missing generic type declarations: [T] */
    /* JADX INFO: renamed from: f.c.v.c$a */
    class a<T> implements Comparator<T> {

        /* JADX INFO: renamed from: u2 */
        final /* synthetic */ InterfaceC7262w f47405u2;

        a(InterfaceC7262w interfaceC7262w) {
            this.f47405u2 = interfaceC7262w;
        }

        @Override // java.util.Comparator
        public int compare(T t, T t2) {
            return C7269e.m40441a(this.f47405u2.mo36926a(t), this.f47405u2.mo36926a(t2));
        }
    }

    /* JADX INFO: Add missing generic type declarations: [T] */
    /* JADX INFO: renamed from: f.c.v.c$b */
    class b<T> implements Comparator<T> {

        /* JADX INFO: renamed from: u2 */
        final /* synthetic */ InterfaceC7262w f47406u2;

        b(InterfaceC7262w interfaceC7262w) {
            this.f47406u2 = interfaceC7262w;
        }

        @Override // java.util.Comparator
        public int compare(T t, T t2) {
            return C7269e.m40441a(this.f47406u2.mo36926a(t), this.f47406u2.mo36926a(t2));
        }
    }

    /* JADX INFO: Add missing generic type declarations: [T] */
    /* JADX INFO: renamed from: f.c.v.c$c */
    class c<T> implements Comparator<T> {

        /* JADX INFO: renamed from: u2 */
        final /* synthetic */ InterfaceC7262w f47407u2;

        c(InterfaceC7262w interfaceC7262w) {
            this.f47407u2 = interfaceC7262w;
        }

        @Override // java.util.Comparator
        public int compare(T t, T t2) {
            return -C7269e.m40441a(this.f47407u2.mo36926a(t), this.f47407u2.mo36926a(t2));
        }
    }

    /* JADX INFO: renamed from: a */
    public static <T> Comparator<T> m40623a(InterfaceC7262w<? super T> interfaceC7262w) {
        C7297f.m40636h(interfaceC7262w);
        return new b(interfaceC7262w);
    }

    /* JADX INFO: renamed from: b */
    public static <T> Comparator<T> m40624b(InterfaceC7262w<? super T> interfaceC7262w) {
        C7297f.m40636h(interfaceC7262w);
        return new a(interfaceC7262w);
    }

    /* JADX INFO: renamed from: c */
    public static <T> Comparator<T> m40625c(InterfaceC7262w<? super T> interfaceC7262w) {
        C7297f.m40636h(interfaceC7262w);
        return new c(interfaceC7262w);
    }
}
