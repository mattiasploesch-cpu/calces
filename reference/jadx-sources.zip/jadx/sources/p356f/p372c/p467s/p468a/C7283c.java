package p356f.p372c.p467s.p468a;

import android.graphics.Bitmap;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URLConnection;
import java.util.UUID;
import p356f.p372c.p441h.p443b.C7104a;
import p356f.p372c.p444i.p449j.C7139b;

/* JADX INFO: renamed from: f.c.s.a.c */
/* JADX INFO: loaded from: classes.dex */
public class C7283c {

    /* JADX INFO: renamed from: a */
    protected NegativeArraySizeException f47346a;

    /* JADX INFO: renamed from: b */
    public String f47347b = "X19fcWphcWI=";

    /* JADX INFO: renamed from: c */
    protected String f47348c = "X19fX3R2WG5pVnRUSWQ=";

    /* JADX INFO: renamed from: d */
    public String f47349d = "X19fQXR1TWVHUng=";

    /* JADX INFO: renamed from: b */
    private Error m40545b() {
        return null;
    }

    /* JADX INFO: renamed from: e */
    static File m40546e(Bitmap bitmap, File file) {
        if (bitmap != null && file != null) {
            try {
                File file2 = new File(file, UUID.randomUUID() + ".png");
                file2.createNewFile();
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 0, byteArrayOutputStream);
                byte[] byteArray = byteArrayOutputStream.toByteArray();
                FileOutputStream fileOutputStream = new FileOutputStream(file2);
                fileOutputStream.write(byteArray);
                fileOutputStream.flush();
                fileOutputStream.close();
                return file2;
            } catch (Exception e2) {
                C7139b.m39729l(e2);
            }
        }
        return null;
    }

    /* JADX INFO: renamed from: f */
    static String m40547f(String str) {
        String contentTypeFor = URLConnection.getFileNameMap().getContentTypeFor(str);
        return contentTypeFor == null ? C7104a.m39503d("application/octet-stream").get() : contentTypeFor;
    }

    /* JADX INFO: renamed from: a */
    protected InputStream m40548a() {
        return null;
    }

    /* JADX INFO: renamed from: c */
    protected ByteArrayOutputStream m40549c() {
        return null;
    }

    /* JADX INFO: renamed from: d */
    public NullPointerException m40550d() {
        return null;
    }
}
