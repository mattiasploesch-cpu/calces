package p356f.p372c.p467s.p468a;

import android.annotation.SuppressLint;
import java.io.LineNumberReader;
import p356f.p372c.p375g.p376d.p377a.C6822b;

/* JADX INFO: renamed from: f.c.s.a.b */
/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"UnknownNullness"})
public class C7282b {

    /* JADX INFO: renamed from: a */
    private String f47326a;

    /* JADX INFO: renamed from: b */
    private String f47327b;

    /* JADX INFO: renamed from: c */
    private String f47328c;

    /* JADX INFO: renamed from: d */
    private String f47329d;

    /* JADX INFO: renamed from: e */
    private String f47330e;

    /* JADX INFO: renamed from: f */
    private String f47331f;

    /* JADX INFO: renamed from: g */
    private String f47332g;

    /* JADX INFO: renamed from: h */
    private String f47333h;

    /* JADX INFO: renamed from: i */
    private Object f47334i;

    /* JADX INFO: renamed from: j */
    private Object f47335j;

    /* JADX INFO: renamed from: k */
    private Object f47336k;

    /* JADX INFO: renamed from: l */
    private Object f47337l;

    /* JADX INFO: renamed from: m */
    private Object f47338m;

    /* JADX INFO: renamed from: n */
    private Object f47339n;

    /* JADX INFO: renamed from: o */
    private Object f47340o;

    /* JADX INFO: renamed from: p */
    private Object f47341p;

    /* JADX INFO: renamed from: q */
    private Object f47342q;

    /* JADX INFO: renamed from: r */
    private Object f47343r;

    /* JADX INFO: renamed from: s */
    private C6822b f47344s;

    /* JADX INFO: renamed from: t */
    public VerifyError f47345t;

    /* JADX INFO: renamed from: b */
    private NoSuchMethodError m40521b() {
        return null;
    }

    /* JADX INFO: renamed from: c */
    private VerifyError m40522c() {
        return null;
    }

    /* JADX INFO: renamed from: a */
    protected NegativeArraySizeException m40523a() {
        return null;
    }

    /* JADX INFO: renamed from: d */
    public LineNumberReader m40524d() {
        return null;
    }

    /* JADX INFO: renamed from: e */
    public C7281a m40525e() {
        C7281a c7281a = new C7281a(this.f47326a, this.f47327b, this.f47328c, this.f47329d, this.f47330e, this.f47331f, this.f47332g, this.f47333h, this.f47334i, this.f47335j, this.f47336k, this.f47337l, this.f47338m, this.f47339n, this.f47340o, this.f47341p, this.f47342q, this.f47343r);
        c7281a.m40488H(this.f47344s);
        return c7281a;
    }

    /* JADX INFO: renamed from: f */
    public C7282b m40526f(String str) {
        this.f47333h = str;
        return this;
    }

    /* JADX INFO: renamed from: g */
    public C7282b m40527g(String str) {
        this.f47329d = str;
        return this;
    }

    /* JADX INFO: renamed from: h */
    public C7282b m40528h(Object obj) {
        this.f47334i = obj;
        return this;
    }

    /* JADX INFO: renamed from: i */
    public C7282b m40529i(Object obj) {
        this.f47335j = obj;
        return this;
    }

    /* JADX INFO: renamed from: j */
    public C7282b m40530j(Object obj) {
        this.f47336k = obj;
        return this;
    }

    /* JADX INFO: renamed from: k */
    public C7282b m40531k(Object obj) {
        this.f47337l = obj;
        return this;
    }

    /* JADX INFO: renamed from: l */
    public C7282b m40532l(Object obj) {
        this.f47338m = obj;
        return this;
    }

    /* JADX INFO: renamed from: m */
    public C7282b m40533m(Object obj) {
        this.f47339n = obj;
        return this;
    }

    /* JADX INFO: renamed from: n */
    public C7282b m40534n(Object obj) {
        this.f47340o = obj;
        return this;
    }

    /* JADX INFO: renamed from: o */
    public C7282b m40535o(Object obj) {
        this.f47341p = obj;
        return this;
    }

    /* JADX INFO: renamed from: p */
    public C7282b m40536p(Object obj) {
        this.f47342q = obj;
        return this;
    }

    /* JADX INFO: renamed from: q */
    public C7282b m40537q(Object obj) {
        this.f47343r = obj;
        return this;
    }

    /* JADX INFO: renamed from: r */
    public C7282b m40538r(C6822b c6822b) {
        this.f47344s = c6822b;
        return this;
    }

    /* JADX INFO: renamed from: s */
    public C7282b m40539s(String str) {
        this.f47331f = str;
        return this;
    }

    /* JADX INFO: renamed from: t */
    public C7282b m40540t(String str) {
        this.f47327b = str;
        return this;
    }

    /* JADX INFO: renamed from: u */
    public C7282b m40541u(String str) {
        this.f47332g = str;
        return this;
    }

    /* JADX INFO: renamed from: v */
    public C7282b m40542v(String str) {
        this.f47328c = str;
        return this;
    }

    /* JADX INFO: renamed from: w */
    public C7282b m40543w(String str) {
        this.f47330e = str;
        return this;
    }

    /* JADX INFO: renamed from: x */
    public C7282b m40544x(String str) {
        this.f47326a = str;
        return this;
    }
}
