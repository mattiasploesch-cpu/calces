package p356f.p372c.p467s.p468a;

import android.annotation.SuppressLint;
import java.nio.DoubleBuffer;
import org.json.JSONObject;
import p148e.p150d.C5035a;
import p356f.p372c.p375g.p376d.p377a.C6822b;
import p356f.p372c.p375g.p381e.p400d.C6944c;

/* JADX INFO: renamed from: f.c.s.a.a */
/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"UnknownNullness"})
public class C7281a {

    /* JADX INFO: renamed from: a */
    private String f47303a;

    /* JADX INFO: renamed from: b */
    private String f47304b;

    /* JADX INFO: renamed from: c */
    private String f47305c;

    /* JADX INFO: renamed from: d */
    private String f47306d;

    /* JADX INFO: renamed from: e */
    private String f47307e;

    /* JADX INFO: renamed from: f */
    private String f47308f;

    /* JADX INFO: renamed from: g */
    private String f47309g;

    /* JADX INFO: renamed from: h */
    private String f47310h;

    /* JADX INFO: renamed from: i */
    private Object f47311i;

    /* JADX INFO: renamed from: j */
    private Object f47312j;

    /* JADX INFO: renamed from: k */
    private Object f47313k;

    /* JADX INFO: renamed from: l */
    private Object f47314l;

    /* JADX INFO: renamed from: m */
    private Object f47315m;

    /* JADX INFO: renamed from: n */
    private Object f47316n;

    /* JADX INFO: renamed from: o */
    private Object f47317o;

    /* JADX INFO: renamed from: p */
    private Object f47318p;

    /* JADX INFO: renamed from: q */
    private Object f47319q;

    /* JADX INFO: renamed from: r */
    private Object f47320r;

    /* JADX INFO: renamed from: s */
    private C6822b f47321s;

    /* JADX INFO: renamed from: t */
    public Comparable f47322t;

    /* JADX INFO: renamed from: u */
    protected Short f47323u;

    /* JADX INFO: renamed from: v */
    private String f47324v = "X19fZndEdGRHWU0=";

    /* JADX INFO: renamed from: w */
    private String f47325w = "X19fcGJkTWdUTw==";

    public C7281a(String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, Object obj, Object obj2, Object obj3, Object obj4, Object obj5, Object obj6, Object obj7, Object obj8, Object obj9, Object obj10) {
        this.f47303a = str;
        this.f47304b = str2;
        this.f47305c = str3;
        this.f47306d = str4;
        this.f47307e = str5;
        this.f47308f = str6;
        this.f47309g = str7;
        this.f47310h = str8;
        this.f47311i = obj;
        this.f47312j = obj2;
        this.f47313k = obj3;
        this.f47314l = obj4;
        this.f47315m = obj5;
        this.f47316n = obj6;
        this.f47317o = obj7;
        this.f47318p = obj8;
        this.f47319q = obj9;
        this.f47320r = obj10;
    }

    /* JADX INFO: renamed from: c */
    private Appendable m40480c() {
        return null;
    }

    /* JADX INFO: renamed from: A */
    public void m40481A(Object obj) {
        this.f47314l = obj;
    }

    /* JADX INFO: renamed from: B */
    public void m40482B(Object obj) {
        this.f47315m = obj;
    }

    /* JADX INFO: renamed from: C */
    public void m40483C(Object obj) {
        this.f47316n = obj;
    }

    /* JADX INFO: renamed from: D */
    public void m40484D(Object obj) {
        this.f47317o = obj;
    }

    /* JADX INFO: renamed from: E */
    public void m40485E(Object obj) {
        this.f47318p = obj;
    }

    /* JADX INFO: renamed from: F */
    public void m40486F(Object obj) {
        this.f47319q = obj;
    }

    /* JADX INFO: renamed from: G */
    public void m40487G(Object obj) {
        this.f47320r = obj;
    }

    /* JADX INFO: renamed from: H */
    public void m40488H(C6822b c6822b) {
        this.f47321s = c6822b;
    }

    /* JADX INFO: renamed from: I */
    public void m40489I(String str) {
        this.f47308f = str;
    }

    /* JADX INFO: renamed from: J */
    public void m40490J(String str) {
        this.f47304b = str;
    }

    /* JADX INFO: renamed from: K */
    public void m40491K(String str) {
        this.f47309g = str;
    }

    /* JADX INFO: renamed from: L */
    public void m40492L(String str) {
        this.f47305c = str;
    }

    /* JADX INFO: renamed from: M */
    public void m40493M(String str) {
        this.f47307e = str;
    }

    /* JADX INFO: renamed from: N */
    public void m40494N(String str) {
        this.f47303a = str;
    }

    /* JADX INFO: renamed from: O */
    public JSONObject m40495O() {
        JSONObject jSONObject = new JSONObject();
        C6822b c6822b = this.f47321s;
        if (c6822b != null) {
            String strM38017v = C6944c.m38017v(c6822b);
            String str = this.f47308f;
            if (str == null || str.isEmpty()) {
                jSONObject.put("infix", strM38017v);
            } else {
                jSONObject.put("column2", strM38017v);
            }
        }
        String str2 = this.f47303a;
        if (str2 != null) {
            jSONObject.put("source", str2);
        }
        String str3 = this.f47307e;
        if (str3 != null) {
            jSONObject.put("originalInput", str3);
        }
        String str4 = this.f47308f;
        if (str4 != null) {
            jSONObject.put("infix", str4);
        }
        String str5 = this.f47304b;
        if (str5 != null) {
            jSONObject.put("infixVariant", str5);
        }
        String str6 = this.f47309g;
        if (str6 != null) {
            jSONObject.put(C5035a.a.f29390g, str6);
        }
        String str7 = this.f47305c;
        if (str7 != null) {
            jSONObject.put("latexVariant", str7);
        }
        String str8 = this.f47310h;
        if (str8 != null) {
            jSONObject.put("asciiMath", str8);
        }
        String str9 = this.f47306d;
        if (str9 != null) {
            jSONObject.put("asciiMathVariant", str9);
        }
        Object obj = this.f47311i;
        if (obj != null) {
            jSONObject.put("column0", obj.toString());
        }
        Object obj2 = this.f47312j;
        if (obj2 != null) {
            jSONObject.put("column1", obj2.toString());
        }
        Object obj3 = this.f47313k;
        if (obj3 != null) {
            jSONObject.put("column2", obj3.toString());
        }
        Object obj4 = this.f47314l;
        if (obj4 != null) {
            jSONObject.put("column3", obj4.toString());
        }
        return jSONObject;
    }

    /* JADX INFO: renamed from: a */
    protected DoubleBuffer m40496a() {
        return null;
    }

    /* JADX INFO: renamed from: b */
    protected TypeNotPresentException m40497b() {
        return null;
    }

    /* JADX INFO: renamed from: d */
    public String m40498d() {
        return this.f47310h;
    }

    /* JADX INFO: renamed from: e */
    public String m40499e() {
        return this.f47306d;
    }

    /* JADX INFO: renamed from: f */
    public Object m40500f() {
        return this.f47311i;
    }

    /* JADX INFO: renamed from: g */
    public Object m40501g() {
        return this.f47312j;
    }

    /* JADX INFO: renamed from: h */
    public Object m40502h() {
        return this.f47313k;
    }

    /* JADX INFO: renamed from: i */
    public Object m40503i() {
        return this.f47314l;
    }

    /* JADX INFO: renamed from: j */
    public Object m40504j() {
        return this.f47315m;
    }

    /* JADX INFO: renamed from: k */
    public Object m40505k() {
        return this.f47316n;
    }

    /* JADX INFO: renamed from: l */
    public Object m40506l() {
        return this.f47317o;
    }

    /* JADX INFO: renamed from: m */
    public Object m40507m() {
        return this.f47318p;
    }

    /* JADX INFO: renamed from: n */
    public Object m40508n() {
        return this.f47319q;
    }

    /* JADX INFO: renamed from: o */
    public Object m40509o() {
        return this.f47320r;
    }

    /* JADX INFO: renamed from: p */
    public String m40510p() {
        return this.f47308f;
    }

    /* JADX INFO: renamed from: q */
    public String m40511q() {
        return this.f47304b;
    }

    /* JADX INFO: renamed from: r */
    public String m40512r() {
        return this.f47309g;
    }

    /* JADX INFO: renamed from: s */
    public String m40513s() {
        return this.f47305c;
    }

    /* JADX INFO: renamed from: t */
    public String m40514t() {
        return this.f47307e;
    }

    /* JADX INFO: renamed from: u */
    public String m40515u() {
        return this.f47303a;
    }

    /* JADX INFO: renamed from: v */
    public void m40516v(String str) {
        this.f47310h = str;
    }

    /* JADX INFO: renamed from: w */
    public void m40517w(String str) {
        this.f47306d = str;
    }

    /* JADX INFO: renamed from: x */
    public void m40518x(Object obj) {
        this.f47311i = obj;
    }

    /* JADX INFO: renamed from: y */
    public void m40519y(Object obj) {
        this.f47312j = obj;
    }

    /* JADX INFO: renamed from: z */
    public void m40520z(Object obj) {
        this.f47313k = obj;
    }
}
