package p356f.p372c.p467s.p468a;

import android.graphics.Bitmap;
import java.io.File;
import java.net.URL;
import java.util.TreeSet;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import org.json.JSONArray;
import org.json.JSONObject;
import p148e.p150d.C5035a;
import p148e.p309m.p311e.C6344m;
import p148e.p309m.p311e.C6345n;
import p148e.p309m.p311e.InterfaceC6341j;
import p356f.p372c.p375g.p376d.p377a.C6822b;
import p356f.p372c.p375g.p381e.p400d.C6944c;
import p356f.p372c.p441h.p443b.C7104a;
import p356f.p372c.p444i.p449j.C7139b;
import p580l.AbstractC7950a0;
import p580l.C7952b0;
import p580l.C8029u;
import p580l.C8030v;
import p580l.C8031w;
import p580l.C8034z;

/* JADX INFO: renamed from: f.c.s.a.d */
/* JADX INFO: loaded from: classes.dex */
public class C7284d {

    /* JADX INFO: renamed from: a */
    public static boolean f47350a = false;

    /* JADX INFO: renamed from: b */
    public static String f47351b = "null";

    /* JADX INFO: renamed from: c */
    private static final C7104a f47352c = new C7104a(new byte[]{80, 65, 89, 77, 65, 120, 99, 76, 74, 104, 107, 99, 69, 81, 115, 81, 69, 103, 85, 77, 65, 67, 56, 79, 67, 119, 81, 76, 69, 81, 61, 61, 10});

    /* JADX INFO: renamed from: d */
    private static final C8029u f47353d = C8029u.m44128c("application/json; charset=utf-8");

    /* JADX INFO: renamed from: e */
    private static C7284d f47354e;

    /* JADX INFO: renamed from: f */
    private final ExecutorService f47355f = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

    /* JADX INFO: renamed from: g */
    private final CopyOnWriteArrayList<C6822b> f47356g = new CopyOnWriteArrayList<>();

    /* JADX INFO: renamed from: h */
    private AtomicInteger f47357h = new AtomicInteger(0);

    /* JADX INFO: renamed from: i */
    private File f47358i = null;

    /* JADX INFO: renamed from: f.c.s.a.d$a */
    class a implements Runnable {

        /* JADX INFO: renamed from: u2 */
        final /* synthetic */ Bitmap f47359u2;

        /* JADX INFO: renamed from: v2 */
        final /* synthetic */ C7281a f47360v2;

        /* JADX INFO: renamed from: w2 */
        final /* synthetic */ String f47361w2;

        a(Bitmap bitmap, C7281a c7281a, String str) {
            this.f47359u2 = bitmap;
            this.f47360v2 = c7281a;
            this.f47361w2 = str;
        }

        @Override // java.lang.Runnable
        public void run() {
            File fileM40546e = null;
            try {
                fileM40546e = C7284d.this.f47358i != null ? C7283c.m40546e(this.f47359u2, C7284d.this.f47358i) : null;
                JSONObject jSONObjectM40495O = this.f47360v2.m40495O();
                if (fileM40546e == null) {
                    C7284d.this.m40558s(this.f47361w2, "/api/expression", jSONObjectM40495O);
                } else {
                    C7284d.this.m40559t(this.f47361w2, "/api/expression/attachment", jSONObjectM40495O, fileM40546e);
                }
                C7284d.this.m40560u(this.f47361w2, "/api/expression/multiples");
            } catch (Exception e2) {
                C7139b.m39729l(e2);
            }
            if (fileM40546e != null) {
                try {
                    fileM40546e.delete();
                } catch (Exception unused) {
                }
            }
        }
    }

    private C7284d() {
    }

    /* JADX INFO: renamed from: f */
    public static C7284d m40555f() {
        if (f47354e == null) {
            f47354e = new C7284d();
        }
        return f47354e;
    }

    /* JADX INFO: renamed from: h */
    public static void m40556h(File file) {
        m40555f().f47358i = file;
    }

    /* JADX INFO: renamed from: r */
    private C7952b0 m40557r(String str, String str2, String str3) {
        C8031w c8031w = new C8031w();
        C8034z.a aVar = new C8034z.a();
        aVar.m44200i(new URL(str + str2));
        aVar.m44194c("Content-Type", "application/json");
        aVar.m44194c("Accept-Encoding", "gzip, deflate, br");
        aVar.m44194c("Accept", "*/*");
        aVar.m44194c("AppId", "advanced.scientific.calculator.calc991.plus");
        aVar.m44194c("VersionCode", String.valueOf(20210902));
        aVar.m44194c("VersionName", "5.4.4.229");
        aVar.m44197f(AbstractC7950a0.m43469d(f47353d, str3));
        C7952b0 c7952b0Mo43557A0 = c8031w.mo43558a(aVar.m44192a()).mo43557A0();
        if (c7952b0Mo43557A0.m43479f() == 200) {
            this.f47357h.incrementAndGet();
        }
        return c7952b0Mo43557A0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: s */
    public C7952b0 m40558s(String str, String str2, JSONObject jSONObject) {
        return m40557r(str, str2, jSONObject.toString(0));
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: t */
    public C7952b0 m40559t(String str, String str2, JSONObject jSONObject, File file) {
        C8031w c8031w = new C8031w();
        C8034z.a aVar = new C8034z.a();
        aVar.m44200i(new URL(str + str2));
        aVar.m44194c("Accept-Encoding", "gzip, deflate, br");
        aVar.m44194c("Accept", "*/*");
        aVar.m44194c("AppId", "advanced.scientific.calculator.calc991.plus");
        aVar.m44194c("VersionCode", String.valueOf(20210902));
        aVar.m44194c("VersionName", "5.4.4.229");
        aVar.m44197f(new C8030v.a().m44138e(C8030v.f51222e).m44135b("file", file.getName(), AbstractC7950a0.m43468c(C8029u.m44128c(C7283c.m40547f(file.getPath())), file)).m44134a(C5035a.a.f29389f, jSONObject.toString(0)).m44137d());
        C7952b0 c7952b0Mo43557A0 = c8031w.mo43558a(aVar.m44192a()).mo43557A0();
        if (c7952b0Mo43557A0.m43479f() == 200) {
            this.f47357h.incrementAndGet();
        }
        return c7952b0Mo43557A0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: u */
    public synchronized void m40560u(String str, String str2) {
        TreeSet<C6822b> treeSet = new TreeSet(this.f47356g);
        if (treeSet.isEmpty()) {
            return;
        }
        try {
            JSONArray jSONArray = new JSONArray();
            for (C6822b c6822b : treeSet) {
                String strM38017v = C6944c.m38017v(c6822b);
                jSONArray.put(new C7282b().m40544x("keyboard").m40539s(strM38017v).m40541u(C6944c.m38011p(c6822b)).m40525e().m40495O());
            }
            m40557r(str, str2, jSONArray.toString(0));
        } catch (Exception e2) {
            C7139b.m39729l(e2);
        }
        this.f47356g.clear();
    }

    /* JADX INFO: renamed from: e */
    public synchronized void m40561e(C6822b c6822b) {
        try {
            this.f47356g.add(c6822b.m37158G3());
        } catch (Exception e2) {
            C7139b.m39729l(e2);
        }
    }

    /* JADX INFO: renamed from: g */
    public int m40562g() {
        return this.f47357h.get();
    }

    /* JADX INFO: renamed from: i */
    public void m40563i(Bitmap bitmap, C6822b c6822b) {
        m40568n(null, null, null, bitmap, c6822b, null, null);
    }

    /* JADX INFO: renamed from: j */
    public void m40564j(Bitmap bitmap, C6822b c6822b, String str, String str2) {
        m40568n(null, str2, str, bitmap, c6822b, null, null);
    }

    /* JADX INFO: renamed from: k */
    public void m40565k(C6822b c6822b) {
        m40568n(null, null, null, null, c6822b, null, null);
    }

    /* JADX INFO: renamed from: l */
    public void m40566l(C7281a c7281a) {
        m40567m(c7281a, null);
    }

    /* JADX INFO: renamed from: m */
    public void m40567m(C7281a c7281a, Bitmap bitmap) {
        String strMo34499c;
        InterfaceC6341j interfaceC6341jM34523e = C6345n.m34523e();
        String str = f47351b;
        if (!f47350a && interfaceC6341jM34523e != null && (strMo34499c = interfaceC6341jM34523e.mo34499c(C6344m.f40742K.get())) != null && !strMo34499c.isEmpty()) {
            str = strMo34499c;
        }
        this.f47355f.submit(new a(bitmap, c7281a, str));
    }

    /* JADX INFO: renamed from: n */
    public void m40568n(String str, String str2, String str3, Bitmap bitmap, C6822b c6822b, Object obj, Object obj2) {
        m40569o(str, str2, str3, bitmap, c6822b, obj, obj2, null, null, null);
    }

    /* JADX INFO: renamed from: o */
    public void m40569o(String str, String str2, String str3, Bitmap bitmap, C6822b c6822b, Object obj, Object obj2, Object obj3, Object obj4, String str4) {
        try {
            m40567m(new C7282b().m40539s(str).m40541u(str2).m40526f(str3).m40538r(c6822b != null ? c6822b.m37158G3() : null).m40528h(obj).m40529i(obj2).m40530j(obj3).m40531k(obj4).m40544x(str4).m40525e(), bitmap);
        } catch (Exception e2) {
            C7139b.m39729l(e2);
        }
    }

    /* JADX INFO: renamed from: p */
    public void m40570p(Bitmap bitmap) {
        m40568n(null, null, null, bitmap, null, null, null);
    }

    /* JADX INFO: renamed from: q */
    public void m40571q(String str, JSONObject jSONObject) {
        m40568n(null, str, null, null, null, null, jSONObject);
    }

    /* JADX INFO: renamed from: v */
    public void m40572v() {
        this.f47357h.set(0);
    }

    /* JADX INFO: renamed from: w */
    public void m40573w() throws InterruptedException {
        this.f47355f.shutdown();
        this.f47355f.awaitTermination(10L, TimeUnit.MINUTES);
    }
}
