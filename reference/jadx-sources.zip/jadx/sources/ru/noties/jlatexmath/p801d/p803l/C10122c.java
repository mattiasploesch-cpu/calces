package ru.noties.jlatexmath.p801d.p803l;

/* JADX INFO: renamed from: ru.noties.jlatexmath.d.l.c */
/* JADX INFO: loaded from: classes2.dex */
public class C10122c {

    /* JADX INFO: renamed from: a */
    public float f59970a;

    /* JADX INFO: renamed from: b */
    public float f59971b;

    public C10122c(float f2, float f3) {
    }
}
