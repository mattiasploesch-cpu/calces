package ru.noties.jlatexmath.p801d;

/* JADX INFO: renamed from: ru.noties.jlatexmath.d.g */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC10114g {
}
