package ru.noties.jlatexmath.p801d;

/* JADX INFO: renamed from: ru.noties.jlatexmath.d.h */
/* JADX INFO: loaded from: classes2.dex */
public class C10115h {

    /* JADX INFO: renamed from: a */
    public int f59946a;

    /* JADX INFO: renamed from: b */
    public int f59947b;

    /* JADX INFO: renamed from: c */
    public int f59948c;

    /* JADX INFO: renamed from: d */
    public int f59949d;

    public C10115h(int i2, int i3, int i4, int i5) {
        this.f59946a = i2;
        this.f59947b = i3;
        this.f59948c = i4;
        this.f59949d = i5;
    }
}
