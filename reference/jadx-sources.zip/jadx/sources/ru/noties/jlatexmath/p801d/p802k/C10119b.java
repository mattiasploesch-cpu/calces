package ru.noties.jlatexmath.p801d.p802k;

import android.graphics.Paint;
import android.graphics.Rect;
import ru.noties.jlatexmath.p801d.C10112e;
import ru.noties.jlatexmath.p801d.InterfaceC10113f;
import ru.noties.jlatexmath.p801d.p803l.AbstractC10123d;

/* JADX INFO: renamed from: ru.noties.jlatexmath.d.k.b */
/* JADX INFO: loaded from: classes2.dex */
public class C10119b {

    /* JADX INFO: renamed from: a */
    private final char[] f59956a;

    /* JADX INFO: renamed from: b */
    private final C10112e f59957b;

    /* JADX INFO: renamed from: c */
    private final AbstractC10123d f59958c;

    public C10119b(String str, C10112e c10112e, C10118a c10118a) {
        this.f59956a = str.toCharArray();
        this.f59957b = c10112e;
        Paint paint = new Paint(1);
        paint.setTypeface(c10112e.m56445g());
        paint.setTextSize(c10112e.m56444e());
        Rect rect = new Rect();
        paint.getTextBounds(str, 0, str.length(), rect);
        this.f59958c = new AbstractC10123d.a(rect.left, rect.top, rect.width(), rect.height());
    }

    /* JADX INFO: renamed from: a */
    public void m56446a(InterfaceC10113f interfaceC10113f, int i2, int i3) {
        C10112e c10112eMo56416e = interfaceC10113f.mo56416e();
        C10112e c10112e = this.f59957b;
        boolean z = c10112e != c10112eMo56416e;
        if (z) {
            interfaceC10113f.mo56432u(c10112e);
        }
        char[] cArr = this.f59956a;
        interfaceC10113f.mo56419h(cArr, 0, cArr.length, i2, i3);
        if (z) {
            interfaceC10113f.mo56432u(c10112eMo56416e);
        }
    }

    /* JADX INFO: renamed from: b */
    public AbstractC10123d m56447b() {
        return this.f59958c;
    }
}
