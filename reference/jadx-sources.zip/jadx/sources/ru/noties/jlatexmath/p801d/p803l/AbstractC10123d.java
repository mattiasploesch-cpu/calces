package ru.noties.jlatexmath.p801d.p803l;

/* JADX INFO: renamed from: ru.noties.jlatexmath.d.l.d */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC10123d {

    /* JADX INFO: renamed from: ru.noties.jlatexmath.d.l.d$a */
    public static class a extends AbstractC10123d {

        /* JADX INFO: renamed from: a */
        public float f59972a;

        /* JADX INFO: renamed from: b */
        public float f59973b;

        /* JADX INFO: renamed from: c */
        public float f59974c;

        /* JADX INFO: renamed from: d */
        public float f59975d;

        public a(float f2, float f3, float f4, float f5) {
            this.f59972a = f2;
            this.f59973b = f3;
            this.f59974c = f4;
            this.f59975d = f5;
        }

        @Override // ru.noties.jlatexmath.p801d.p803l.AbstractC10123d
        /* JADX INFO: renamed from: a */
        public float mo56460a() {
            return this.f59975d;
        }

        @Override // ru.noties.jlatexmath.p801d.p803l.AbstractC10123d
        /* JADX INFO: renamed from: b */
        public float mo56461b() {
            return this.f59974c;
        }

        @Override // ru.noties.jlatexmath.p801d.p803l.AbstractC10123d
        /* JADX INFO: renamed from: c */
        public float mo56462c() {
            return this.f59972a;
        }

        @Override // ru.noties.jlatexmath.p801d.p803l.AbstractC10123d
        /* JADX INFO: renamed from: d */
        public float mo56463d() {
            return this.f59973b;
        }

        public String toString() {
            return "Float{x=" + this.f59972a + ", y=" + this.f59973b + ", w=" + this.f59974c + ", h=" + this.f59975d + '}';
        }
    }

    /* JADX INFO: renamed from: a */
    public abstract float mo56460a();

    /* JADX INFO: renamed from: b */
    public abstract float mo56461b();

    /* JADX INFO: renamed from: c */
    public abstract float mo56462c();

    /* JADX INFO: renamed from: d */
    public abstract float mo56463d();
}
