package ru.noties.jlatexmath.p801d;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import ru.noties.jlatexmath.p801d.p803l.AbstractC10123d;
import ru.noties.jlatexmath.p801d.p803l.C10120a;
import ru.noties.jlatexmath.p801d.p803l.C10121b;
import ru.noties.jlatexmath.p801d.p803l.C10124e;

/* JADX INFO: renamed from: ru.noties.jlatexmath.d.a */
/* JADX INFO: loaded from: classes2.dex */
public class C10108a implements InterfaceC10113f {

    /* JADX INFO: renamed from: a */
    private final RectF f59923a = new RectF();

    /* JADX INFO: renamed from: b */
    private final Paint f59924b;

    /* JADX INFO: renamed from: c */
    private Canvas f59925c;

    /* JADX INFO: renamed from: d */
    private C10110c f59926d;

    /* JADX INFO: renamed from: e */
    private InterfaceC10117j f59927e;

    /* JADX INFO: renamed from: f */
    private C10112e f59928f;

    /* JADX INFO: renamed from: g */
    private C10120a f59929g;

    public C10108a() {
        Paint paint = new Paint(1);
        this.f59924b = paint;
        paint.setStrokeCap(Paint.Cap.BUTT);
        paint.setStrokeJoin(Paint.Join.MITER);
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10113f
    /* JADX INFO: renamed from: a */
    public void mo56412a(int i2, int i3, int i4, int i5, int i6, int i7) {
        this.f59924b.setStyle(Paint.Style.FILL);
        this.f59923a.set(i2, i3, i2 + i4, i3 + i5);
        this.f59925c.drawArc(this.f59923a, i6, i7, false, this.f59924b);
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10113f
    /* JADX INFO: renamed from: b */
    public void mo56413b(C10116i.a aVar, Object obj) {
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10113f
    /* JADX INFO: renamed from: c */
    public C10110c mo56414c() {
        if (this.f59926d == null) {
            this.f59926d = new C10110c(this.f59924b.getColor());
        }
        return this.f59926d;
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10113f
    /* JADX INFO: renamed from: d */
    public void mo56415d(double d2) {
        this.f59925c.rotate((float) Math.toDegrees(d2));
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10113f
    /* JADX INFO: renamed from: e */
    public C10112e mo56416e() {
        return this.f59928f;
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10113f
    /* JADX INFO: renamed from: f */
    public void mo56417f(double d2, double d3, double d4) {
        this.f59925c.rotate((float) Math.toDegrees(d2), (float) d3, (float) d4);
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10113f
    /* JADX INFO: renamed from: g */
    public C10116i mo56418g() {
        return null;
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10113f
    /* JADX INFO: renamed from: h */
    public void mo56419h(char[] cArr, int i2, int i3, int i4, int i5) {
        C10112e c10112e = this.f59928f;
        if (c10112e != null) {
            this.f59924b.setTypeface(c10112e.m56445g());
            this.f59924b.setTextSize(this.f59928f.m56444e());
        }
        this.f59925c.drawText(cArr, i2, i3, i4, i5, this.f59924b);
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10113f
    /* JADX INFO: renamed from: i */
    public C10120a mo56420i() {
        C10120a c10120aM56454g = this.f59929g.m56454g();
        this.f59929g = c10120aM56454g;
        return c10120aM56454g;
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10113f
    /* JADX INFO: renamed from: j */
    public void mo56421j(InterfaceC10117j interfaceC10117j) {
        this.f59927e = interfaceC10117j;
        this.f59924b.setStrokeWidth(interfaceC10117j.mo56435a());
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10113f
    /* JADX INFO: renamed from: k */
    public void mo56422k(double d2, double d3) {
        this.f59929g.m56455h(d2, d3);
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10113f
    /* JADX INFO: renamed from: l */
    public void mo56423l(AbstractC10123d.a aVar) {
        this.f59924b.setStyle(Paint.Style.FILL);
        Canvas canvas = this.f59925c;
        float f2 = aVar.f59972a;
        float f3 = aVar.f59973b;
        canvas.drawRect(f2, f3, f2 + aVar.f59974c, f3 + aVar.f59975d, this.f59924b);
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10113f
    /* JADX INFO: renamed from: m */
    public void mo56424m(int i2, int i3, int i4, int i5, int i6, int i7) {
        this.f59924b.setStyle(Paint.Style.STROKE);
        this.f59923a.set(i2, i3, i2 + i4, i3 + i5);
        this.f59925c.drawArc(this.f59923a, i6, i7, false, this.f59924b);
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10113f
    /* JADX INFO: renamed from: n */
    public void mo56425n(C10120a c10120a) {
        if (this.f59925c != c10120a.m56450c()) {
            throw new IllegalStateException("Supplied transform has different Canvas attached");
        }
        this.f59929g = c10120a.m56453f();
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10113f
    /* JADX INFO: renamed from: o */
    public void mo56426o(C10116i c10116i) {
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10113f
    /* JADX INFO: renamed from: p */
    public void mo56427p(C10121b c10121b) {
        this.f59924b.setStyle(Paint.Style.STROKE);
        this.f59925c.drawLine((float) c10121b.f59966a, (float) c10121b.f59967b, (float) c10121b.f59968c, (float) c10121b.f59969d, this.f59924b);
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10113f
    /* JADX INFO: renamed from: q */
    public void mo56428q(C10124e c10124e) {
        this.f59924b.setStyle(Paint.Style.STROKE);
        RectF rectF = this.f59923a;
        float f2 = c10124e.f59976a;
        float f3 = c10124e.f59977b;
        rectF.set(f2, f3, c10124e.f59978c + f2, c10124e.f59979d + f3);
        this.f59925c.drawRoundRect(this.f59923a, c10124e.f59980e, c10124e.f59981f, this.f59924b);
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10113f
    /* JADX INFO: renamed from: r */
    public void mo56429r(AbstractC10123d.a aVar) {
        this.f59924b.setStyle(Paint.Style.STROKE);
        Canvas canvas = this.f59925c;
        float f2 = aVar.f59972a;
        float f3 = aVar.f59973b;
        canvas.drawRect(f2, f3, f2 + aVar.f59974c, f3 + aVar.f59975d, this.f59924b);
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10113f
    /* JADX INFO: renamed from: s */
    public void mo56430s(C10110c c10110c) {
        this.f59926d = c10110c;
        this.f59924b.setColor(c10110c.m56437b());
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10113f
    /* JADX INFO: renamed from: t */
    public InterfaceC10117j mo56431t() {
        if (this.f59927e == null) {
            this.f59927e = new C10109b(this.f59924b.getStrokeWidth(), 0, 0, this.f59924b.getStrokeMiter());
        }
        return this.f59927e;
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10113f
    /* JADX INFO: renamed from: u */
    public void mo56432u(C10112e c10112e) {
        this.f59928f = c10112e;
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10113f
    /* JADX INFO: renamed from: v */
    public void mo56433v(double d2, double d3) {
        this.f59929g.m56458k((float) d2, (float) d3);
    }

    /* JADX INFO: renamed from: w */
    public void m56434w(Canvas canvas) {
        this.f59925c = canvas;
        this.f59929g = C10120a.m56448b(canvas);
    }
}
