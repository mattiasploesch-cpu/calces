package ru.noties.jlatexmath.p801d;

import android.graphics.Typeface;
import java.util.Locale;

/* JADX INFO: renamed from: ru.noties.jlatexmath.d.e */
/* JADX INFO: loaded from: classes2.dex */
public class C10112e {

    /* JADX INFO: renamed from: a */
    private final Typeface f59943a;

    /* JADX INFO: renamed from: b */
    private int f59944b;

    /* JADX INFO: renamed from: c */
    private float f59945c;

    private C10112e(Typeface typeface, int i2, float f2) {
        this.f59943a = m56439a(typeface, i2);
        this.f59944b = i2;
        this.f59945c = f2;
    }

    public C10112e(String str, int i2, int i3) {
        this(m56441c(str, i2), i2, i3);
    }

    /* JADX INFO: renamed from: a */
    private static Typeface m56439a(Typeface typeface, int i2) {
        if (((typeface.isBold() ? 1 : 0) | (typeface.isItalic() ? 2 : 0)) != i2) {
            return Typeface.create(typeface, ((i2 & 1) != 0 ? 1 : 0) | ((i2 & 2) == 0 ? 0 : 2));
        }
        return typeface;
    }

    /* JADX INFO: renamed from: b */
    public static C10112e m56440b(Typeface typeface, float f2) {
        return new C10112e(typeface, 0, f2);
    }

    /* JADX INFO: renamed from: c */
    private static Typeface m56441c(String str, int i2) {
        Typeface typefaceCreate = Typeface.create(str.toLowerCase(Locale.US), m56442f(i2));
        return typefaceCreate == null ? Typeface.DEFAULT : typefaceCreate;
    }

    /* JADX INFO: renamed from: f */
    private static int m56442f(int i2) {
        if (i2 == 0) {
            return 0;
        }
        return ((i2 & 1) != 0 ? 1 : 0) | ((i2 & 2) != 0 ? 2 : 0);
    }

    /* JADX INFO: renamed from: d */
    public C10112e m56443d(int i2) {
        return new C10112e(this.f59943a, i2, this.f59945c);
    }

    /* JADX INFO: renamed from: e */
    public float m56444e() {
        return this.f59945c;
    }

    /* JADX INFO: renamed from: g */
    public Typeface m56445g() {
        return this.f59943a;
    }
}
