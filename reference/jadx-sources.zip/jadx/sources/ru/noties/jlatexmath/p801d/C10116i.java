package ru.noties.jlatexmath.p801d;

/* JADX INFO: renamed from: ru.noties.jlatexmath.d.i */
/* JADX INFO: loaded from: classes2.dex */
public class C10116i {

    /* JADX INFO: renamed from: a */
    public static final Object f59950a = null;

    /* JADX INFO: renamed from: b */
    public static final Object f59951b = null;

    /* JADX INFO: renamed from: c */
    public static final a f59952c = null;

    /* JADX INFO: renamed from: d */
    public static final a f59953d = null;

    /* JADX INFO: renamed from: e */
    public static final a f59954e = null;

    /* JADX INFO: renamed from: f */
    public static final Object f59955f = null;

    /* JADX INFO: renamed from: ru.noties.jlatexmath.d.i$a */
    public static abstract class a {
    }
}
