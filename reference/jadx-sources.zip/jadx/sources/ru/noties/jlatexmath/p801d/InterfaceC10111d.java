package ru.noties.jlatexmath.p801d;

/* JADX INFO: renamed from: ru.noties.jlatexmath.d.d */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC10111d {
    /* JADX INFO: renamed from: a */
    C10110c m56438a();
}
