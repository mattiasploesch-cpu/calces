package ru.noties.jlatexmath.p801d.p803l;

/* JADX INFO: renamed from: ru.noties.jlatexmath.d.l.b */
/* JADX INFO: loaded from: classes2.dex */
public class C10121b {

    /* JADX INFO: renamed from: a */
    public double f59966a;

    /* JADX INFO: renamed from: b */
    public double f59967b;

    /* JADX INFO: renamed from: c */
    public double f59968c;

    /* JADX INFO: renamed from: d */
    public double f59969d;

    /* JADX INFO: renamed from: a */
    public void m56459a(double d2, double d3, double d4, double d5) {
        this.f59966a = d2;
        this.f59967b = d3;
        this.f59968c = d4;
        this.f59969d = d5;
    }

    public String toString() {
        return "Float{x1=" + this.f59966a + ", y1=" + this.f59967b + ", x2=" + this.f59968c + ", y2=" + this.f59969d + '}';
    }
}
