package ru.noties.jlatexmath.p801d;

/* JADX INFO: renamed from: ru.noties.jlatexmath.d.j */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC10117j {
    /* JADX INFO: renamed from: a */
    float mo56435a();
}
