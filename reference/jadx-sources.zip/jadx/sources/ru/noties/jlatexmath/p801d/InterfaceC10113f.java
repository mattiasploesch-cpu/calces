package ru.noties.jlatexmath.p801d;

import ru.noties.jlatexmath.p801d.p803l.AbstractC10123d;
import ru.noties.jlatexmath.p801d.p803l.C10120a;
import ru.noties.jlatexmath.p801d.p803l.C10121b;
import ru.noties.jlatexmath.p801d.p803l.C10124e;

/* JADX INFO: renamed from: ru.noties.jlatexmath.d.f */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC10113f extends InterfaceC10114g {
    /* JADX INFO: renamed from: a */
    void mo56412a(int i2, int i3, int i4, int i5, int i6, int i7);

    /* JADX INFO: renamed from: b */
    void mo56413b(C10116i.a aVar, Object obj);

    /* JADX INFO: renamed from: c */
    C10110c mo56414c();

    /* JADX INFO: renamed from: d */
    void mo56415d(double d2);

    /* JADX INFO: renamed from: e */
    C10112e mo56416e();

    /* JADX INFO: renamed from: f */
    void mo56417f(double d2, double d3, double d4);

    /* JADX INFO: renamed from: g */
    C10116i mo56418g();

    /* JADX INFO: renamed from: h */
    void mo56419h(char[] cArr, int i2, int i3, int i4, int i5);

    /* JADX INFO: renamed from: i */
    C10120a mo56420i();

    /* JADX INFO: renamed from: j */
    void mo56421j(InterfaceC10117j interfaceC10117j);

    /* JADX INFO: renamed from: k */
    void mo56422k(double d2, double d3);

    /* JADX INFO: renamed from: l */
    void mo56423l(AbstractC10123d.a aVar);

    /* JADX INFO: renamed from: m */
    void mo56424m(int i2, int i3, int i4, int i5, int i6, int i7);

    /* JADX INFO: renamed from: n */
    void mo56425n(C10120a c10120a);

    /* JADX INFO: renamed from: o */
    void mo56426o(C10116i c10116i);

    /* JADX INFO: renamed from: p */
    void mo56427p(C10121b c10121b);

    /* JADX INFO: renamed from: q */
    void mo56428q(C10124e c10124e);

    /* JADX INFO: renamed from: r */
    void mo56429r(AbstractC10123d.a aVar);

    /* JADX INFO: renamed from: s */
    void mo56430s(C10110c c10110c);

    /* JADX INFO: renamed from: t */
    InterfaceC10117j mo56431t();

    /* JADX INFO: renamed from: u */
    void mo56432u(C10112e c10112e);

    /* JADX INFO: renamed from: v */
    void mo56433v(double d2, double d3);
}
