package ru.noties.jlatexmath.p801d;

import android.graphics.Color;
import p148e.p257h.p274c.p275d.p276g.C6063a;

/* JADX INFO: renamed from: ru.noties.jlatexmath.d.c */
/* JADX INFO: loaded from: classes2.dex */
public class C10110c {

    /* JADX INFO: renamed from: a */
    public static final C10110c f59932a;

    /* JADX INFO: renamed from: b */
    public static final C10110c f59933b;

    /* JADX INFO: renamed from: c */
    public static final C10110c f59934c;

    /* JADX INFO: renamed from: d */
    public static final C10110c f59935d;

    /* JADX INFO: renamed from: e */
    public static final C10110c f59936e;

    /* JADX INFO: renamed from: f */
    public static final C10110c f59937f;

    /* JADX INFO: renamed from: g */
    public static final C10110c f59938g;

    /* JADX INFO: renamed from: h */
    public static final C10110c f59939h;

    /* JADX INFO: renamed from: i */
    public static final C10110c f59940i;

    /* JADX INFO: renamed from: j */
    public static final C10110c f59941j;

    /* JADX INFO: renamed from: k */
    private final int f59942k;

    static {
        C10110c c10110c = new C10110c(-16777216);
        f59932a = c10110c;
        f59933b = new C10110c(-1);
        C10110c c10110c2 = new C10110c(C6063a.f38733f);
        f59934c = c10110c2;
        f59935d = new C10110c(C6063a.f38734g);
        f59936e = new C10110c(C6063a.f38735h);
        f59937f = new C10110c(Color.parseColor("cyan"));
        f59938g = new C10110c(Color.parseColor("magenta"));
        f59939h = new C10110c(Color.parseColor("yellow"));
        f59940i = c10110c;
        f59941j = c10110c2;
    }

    public C10110c(float f2, float f3, float f4) {
        this((int) ((f2 * 255.0f) + 0.5f), (int) ((f3 * 255.0f) + 0.5f), (int) ((f4 * 255.0f) + 0.5f));
    }

    public C10110c(int i2) {
        this.f59942k = i2;
    }

    public C10110c(int i2, int i3, int i4) {
        this(Color.rgb(i2, i3, i4));
    }

    /* JADX INFO: renamed from: a */
    public static C10110c m56436a(String str) {
        return new C10110c(Color.parseColor(str));
    }

    /* JADX INFO: renamed from: b */
    public int m56437b() {
        return this.f59942k;
    }
}
