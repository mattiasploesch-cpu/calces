package ru.noties.jlatexmath.p801d.p803l;

/* JADX INFO: renamed from: ru.noties.jlatexmath.d.l.e */
/* JADX INFO: loaded from: classes2.dex */
public class C10124e {

    /* JADX INFO: renamed from: a */
    public float f59976a;

    /* JADX INFO: renamed from: b */
    public float f59977b;

    /* JADX INFO: renamed from: c */
    public float f59978c;

    /* JADX INFO: renamed from: d */
    public float f59979d;

    /* JADX INFO: renamed from: e */
    public float f59980e;

    /* JADX INFO: renamed from: f */
    public float f59981f;

    public C10124e(float f2, float f3, float f4, float f5, float f6, float f7) {
        this.f59976a = f2;
        this.f59977b = f3;
        this.f59978c = f4;
        this.f59979d = f5;
        this.f59980e = f6;
        this.f59981f = f7;
    }

    public String toString() {
        return "Float{x=" + this.f59976a + ", y=" + this.f59977b + ", width=" + this.f59978c + ", height=" + this.f59979d + ", arcwidth=" + this.f59980e + ", archeight=" + this.f59981f + '}';
    }
}
