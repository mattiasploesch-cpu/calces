package ru.noties.jlatexmath.p801d;

/* JADX INFO: renamed from: ru.noties.jlatexmath.d.b */
/* JADX INFO: loaded from: classes2.dex */
public class C10109b implements InterfaceC10117j {

    /* JADX INFO: renamed from: a */
    private final float f59930a;

    /* JADX INFO: renamed from: b */
    private final float f59931b;

    public C10109b(float f2, int i2, int i3) {
        this(f2, i2, i3, 10.0f);
    }

    public C10109b(float f2, int i2, int i3, float f3) {
        this.f59930a = f2;
        this.f59931b = f3;
    }

    @Override // ru.noties.jlatexmath.p801d.InterfaceC10117j
    /* JADX INFO: renamed from: a */
    public float mo56435a() {
        return this.f59930a;
    }

    public String toString() {
        return "BasicStroke{width=" + this.f59930a + ", miterLimit=" + this.f59931b + '}';
    }
}
