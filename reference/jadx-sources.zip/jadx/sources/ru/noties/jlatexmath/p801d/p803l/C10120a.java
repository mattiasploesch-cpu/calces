package ru.noties.jlatexmath.p801d.p803l;

import android.graphics.Canvas;

/* JADX INFO: renamed from: ru.noties.jlatexmath.d.l.a */
/* JADX INFO: loaded from: classes2.dex */
public class C10120a implements Cloneable {

    /* JADX INFO: renamed from: A2 */
    private float f59959A2;

    /* JADX INFO: renamed from: u2 */
    private final C10120a f59960u2;

    /* JADX INFO: renamed from: v2 */
    private final Canvas f59961v2;

    /* JADX INFO: renamed from: w2 */
    private int f59962w2 = -1;

    /* JADX INFO: renamed from: x2 */
    private double f59963x2 = 1.0d;

    /* JADX INFO: renamed from: y2 */
    private double f59964y2 = 1.0d;

    /* JADX INFO: renamed from: z2 */
    private float f59965z2;

    private C10120a(C10120a c10120a, Canvas canvas) {
        this.f59960u2 = c10120a;
        this.f59961v2 = canvas;
    }

    /* JADX INFO: renamed from: b */
    public static C10120a m56448b(Canvas canvas) {
        return new C10120a(null, canvas);
    }

    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    public C10120a clone() {
        C10120a c10120a = new C10120a(this, this.f59961v2);
        c10120a.m56456i(this.f59963x2, this.f59964y2);
        c10120a.m56457j(this.f59965z2, this.f59959A2);
        c10120a.f59962w2 = this.f59961v2.save();
        return c10120a;
    }

    /* JADX INFO: renamed from: c */
    public Canvas m56450c() {
        return this.f59961v2;
    }

    /* JADX INFO: renamed from: d */
    public double m56451d() {
        return this.f59963x2;
    }

    /* JADX INFO: renamed from: e */
    public double m56452e() {
        return this.f59964y2;
    }

    /* JADX INFO: renamed from: f */
    public C10120a m56453f() {
        int i2 = this.f59962w2;
        if (i2 != -1) {
            this.f59961v2.restoreToCount(i2);
            this.f59962w2 = -1;
        }
        C10120a c10120a = this.f59960u2;
        if (c10120a != null) {
            return c10120a;
        }
        throw new IllegalStateException("Cannot restore root transform instance");
    }

    /* JADX INFO: renamed from: g */
    public C10120a m56454g() {
        C10120a c10120a = new C10120a(this, this.f59961v2);
        c10120a.m56456i(this.f59963x2, this.f59964y2);
        c10120a.m56457j(this.f59965z2, this.f59959A2);
        c10120a.f59962w2 = this.f59961v2.save();
        return c10120a;
    }

    /* JADX INFO: renamed from: h */
    public void m56455h(double d2, double d3) {
        m56456i(d2, d3);
        this.f59961v2.scale((float) d2, (float) d3);
    }

    /* JADX INFO: renamed from: i */
    public void m56456i(double d2, double d3) {
        this.f59963x2 = d2;
        this.f59964y2 = d3;
    }

    /* JADX INFO: renamed from: j */
    public void m56457j(float f2, float f3) {
        this.f59965z2 = f2;
        this.f59959A2 = f3;
    }

    /* JADX INFO: renamed from: k */
    public void m56458k(float f2, float f3) {
        this.f59961v2.translate(f2, f3);
        m56457j(f2, f3);
    }
}
