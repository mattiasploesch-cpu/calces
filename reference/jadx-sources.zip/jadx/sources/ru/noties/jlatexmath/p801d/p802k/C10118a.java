package ru.noties.jlatexmath.p801d.p802k;

/* JADX INFO: renamed from: ru.noties.jlatexmath.d.k.a */
/* JADX INFO: loaded from: classes2.dex */
public class C10118a {
}
