package ru.noties.jlatexmath;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import ru.noties.jlatexmath.p800c.C10107a;
import ru.noties.jlatexmath.p801d.C10110c;

/* JADX INFO: loaded from: classes2.dex */
public class JLatexMathView extends View {

    /* JADX INFO: renamed from: A2 */
    private float f59895A2;

    /* JADX INFO: renamed from: B2 */
    private float f59896B2;

    /* JADX INFO: renamed from: C2 */
    private float f59897C2;

    /* JADX INFO: renamed from: u2 */
    private int f59898u2;

    /* JADX INFO: renamed from: v2 */
    private int f59899v2;

    /* JADX INFO: renamed from: w2 */
    private Drawable f59900w2;

    /* JADX INFO: renamed from: x2 */
    private int f59901x2;

    /* JADX INFO: renamed from: y2 */
    private int f59902y2;

    /* JADX INFO: renamed from: z2 */
    private C10106b f59903z2;

    public JLatexMathView(Context context) {
        super(context);
        m56391d(context, null);
    }

    public JLatexMathView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        m56391d(context, attributeSet);
    }

    /* JADX INFO: renamed from: b */
    private static float m56390b(int i2, float f2) {
        if (i2 == 0) {
            return 0.0f;
        }
        return 1 == i2 ? f2 / 2.0f : f2;
    }

    /* JADX INFO: renamed from: d */
    private void m56391d(Context context, AttributeSet attributeSet) {
        Drawable colorDrawable;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C10107a.f59917a);
        try {
            int i2 = C10107a.f59920d;
            int resourceId = typedArrayObtainStyledAttributes.getResourceId(i2, 0);
            if (resourceId != 0) {
                String resourceTypeName = context.getResources().getResourceTypeName(resourceId);
                if ("drawable".equals(resourceTypeName)) {
                    colorDrawable = typedArrayObtainStyledAttributes.getDrawable(i2);
                } else {
                    if (!"color".equals(resourceTypeName)) {
                        throw new IllegalStateException(String.format("Unexpected background reference: %s is of type: %s. Supported: drawable, color", context.getResources().getResourceName(resourceId), resourceTypeName));
                    }
                    colorDrawable = new ColorDrawable(typedArrayObtainStyledAttributes.getColor(i2, 0));
                }
            } else {
                colorDrawable = null;
            }
            m56395f(typedArrayObtainStyledAttributes.getDimensionPixelSize(C10107a.f59922f, 0)).m56394e(typedArrayObtainStyledAttributes.getColor(C10107a.f59921e, C10110c.f59932a.m56437b())).m56393c(colorDrawable).m56392a(typedArrayObtainStyledAttributes.getInteger(C10107a.f59919c, 0), typedArrayObtainStyledAttributes.getInteger(C10107a.f59918b, 0));
            typedArrayObtainStyledAttributes.recycle();
            if (isInEditMode()) {
                AbstractC10105a.m56398c(context);
                setLatex((((((((("\\begin{array}{l}\\forall\\varepsilon\\in\\mathbb{R}_+^*\\ \\exists\\eta>0\\ |x-x_0|\\leq\\eta\\Longrightarrow|f(x)-f(x_0)|\\leq\\varepsilon\\\\") + "\\det\\begin{bmatrix}a_{11}&a_{12}&\\cdots&a_{1n}\\\\a_{21}&\\ddots&&\\vdots\\\\\\vdots&&\\ddots&\\vdots\\\\a_{n1}&\\cdots&\\cdots&a_{nn}\\end{bmatrix}\\overset{\\mathrm{def}}{=}\\sum_{\\sigma\\in\\mathfrak{S}_n}\\varepsilon(\\sigma)\\prod_{k=1}^n a_{k\\sigma(k)}\\\\") + "\\sideset{_\\alpha^\\beta}{_\\gamma^\\delta}{\\begin{pmatrix}a&b\\\\c&d\\end{pmatrix}}\\\\") + "\\int_0^\\infty{x^{2n} e^{-a x^2}\\,dx} = \\frac{2n-1}{2a} \\int_0^\\infty{x^{2(n-1)} e^{-a x^2}\\,dx} = \\frac{(2n-1)!!}{2^{n+1}} \\sqrt{\\frac{\\pi}{a^{2n+1}}}\\\\") + "\\int_a^b{f(x)\\,dx} = (b - a) \\sum\\limits_{n = 1}^\\infty  {\\sum\\limits_{m = 1}^{2^n  - 1} {\\left( { - 1} \\right)^{m + 1} } } 2^{ - n} f(a + m\\left( {b - a} \\right)2^{-n} )\\\\") + "\\int_{-\\pi}^{\\pi} \\sin(\\alpha x) \\sin^n(\\beta x) dx = \\textstyle{\\left \\{ \\begin{array}{cc} (-1)^{(n+1)/2} (-1)^m \\frac{2 \\pi}{2^n} \\binom{n}{m} & n \\mbox{ odd},\\ \\alpha = \\beta (2m-n) \\\\ 0 & \\mbox{otherwise} \\\\ \\end{array} \\right .}\\\\") + "L = \\int_a^b \\sqrt{ \\left|\\sum_{i,j=1}^ng_{ij}(\\gamma(t))\\left(\\frac{d}{dt}x^i\\circ\\gamma(t)\\right)\\left(\\frac{d}{dt}x^j\\circ\\gamma(t)\\right)\\right|}\\,dt\\\\") + "\\begin{array}{rl} s &= \\int_a^b\\left\\|\\frac{d}{dt}\\vec{r}\\,(u(t),v(t))\\right\\|\\,dt \\\\ &= \\int_a^b \\sqrt{u'(t)^2\\,\\vec{r}_u\\cdot\\vec{r}_u + 2u'(t)v'(t)\\, \\vec{r}_u\\cdot\\vec{r}_v+ v'(t)^2\\,\\vec{r}_v\\cdot\\vec{r}_v}\\,\\,\\, dt. \\end{array}\\\\") + "\\end{array}");
            }
        } catch (Throwable th) {
            typedArrayObtainStyledAttributes.recycle();
            throw th;
        }
    }

    /* JADX INFO: renamed from: a */
    public JLatexMathView m56392a(int i2, int i3) {
        this.f59901x2 = i2;
        this.f59902y2 = i3;
        return this;
    }

    /* JADX INFO: renamed from: c */
    public JLatexMathView m56393c(Drawable drawable) {
        this.f59900w2 = drawable;
        return this;
    }

    /* JADX INFO: renamed from: e */
    public JLatexMathView m56394e(int i2) {
        this.f59899v2 = i2;
        return this;
    }

    /* JADX INFO: renamed from: f */
    public JLatexMathView m56395f(int i2) {
        this.f59898u2 = i2;
        return this;
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f59903z2 == null) {
            return;
        }
        int iSave = canvas.save();
        try {
            float f2 = this.f59896B2;
            if (f2 > 0.0f) {
                canvas.translate(f2, 0.0f);
            }
            float f3 = this.f59897C2;
            if (f3 > 0.0f) {
                canvas.translate(0.0f, f3);
            }
            float f4 = this.f59895A2;
            if (f4 > 0.0f && Float.compare(f4, 1.0f) != 0) {
                float f5 = this.f59895A2;
                canvas.scale(f5, f5);
            }
            this.f59903z2.draw(canvas);
        } finally {
            canvas.restoreToCount(iSave);
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i2, int i3) {
        if (this.f59903z2 == null) {
            super.onMeasure(i2, i3);
            return;
        }
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        int mode2 = View.MeasureSpec.getMode(i3);
        int size2 = View.MeasureSpec.getSize(i3);
        int intrinsicWidth = this.f59903z2.getIntrinsicWidth();
        int intrinsicHeight = this.f59903z2.getIntrinsicHeight();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        if (1073741824 != mode) {
            int paddingRight = intrinsicWidth + paddingLeft + getPaddingRight();
            size = size > 0 ? Math.min(size, paddingRight) : paddingRight;
        }
        if (1073741824 != mode2) {
            int paddingBottom = intrinsicHeight + paddingTop + getPaddingBottom();
            size2 = size2 > 0 ? Math.min(size2, paddingBottom) : paddingBottom;
        }
        int paddingRight2 = (size - paddingLeft) - getPaddingRight();
        int paddingBottom2 = (size2 - paddingTop) - getPaddingBottom();
        float fMin = (intrinsicWidth >= paddingRight2 || intrinsicHeight >= paddingBottom2) ? Math.min(paddingRight2 / intrinsicWidth, paddingBottom2 / intrinsicHeight) : 1.0f;
        int i4 = (int) ((intrinsicWidth * fMin) + 0.5f);
        int i5 = (int) ((intrinsicHeight * fMin) + 0.5f);
        if (1073741824 != mode) {
            size = i4 + paddingLeft + getPaddingRight();
        }
        if (1073741824 != mode2) {
            size2 = i5 + paddingTop + getPaddingBottom();
        }
        float fM56390b = m56390b(this.f59902y2, ((size - paddingLeft) - getPaddingRight()) - i4);
        float fM56390b2 = m56390b(this.f59901x2, ((size2 - paddingTop) - getPaddingBottom()) - i5);
        this.f59895A2 = fMin;
        this.f59896B2 = paddingLeft + fM56390b;
        this.f59897C2 = paddingTop + fM56390b2;
        setMeasuredDimension(size, size2);
    }

    public void setLatex(String str) {
        setLatexDrawable(C10106b.m56400a(str).m56411k(this.f59898u2).m56409i(this.f59899v2).m56407g(this.f59900w2).m56410j(false).m56408h());
    }

    public void setLatexDrawable(C10106b c10106b) {
        this.f59903z2 = c10106b;
        requestLayout();
    }
}
