package ru.noties.jlatexmath;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import p591n.p760j.p761a.p762a.C9743j3;
import p591n.p760j.p761a.p762a.C9743j3.b;
import p591n.p760j.p761a.p762a.C9753l3;
import ru.noties.jlatexmath.p801d.C10108a;
import ru.noties.jlatexmath.p801d.C10110c;
import ru.noties.jlatexmath.p801d.C10115h;

/* JADX INFO: renamed from: ru.noties.jlatexmath.b */
/* JADX INFO: loaded from: classes2.dex */
public class C10106b extends Drawable {

    /* JADX INFO: renamed from: a */
    private final C9753l3 f59905a;

    /* JADX INFO: renamed from: b */
    private final int f59906b;

    /* JADX INFO: renamed from: c */
    private final Drawable f59907c;

    /* JADX INFO: renamed from: d */
    private final C10108a f59908d;

    /* JADX INFO: renamed from: e */
    private final int f59909e;

    /* JADX INFO: renamed from: f */
    private final int f59910f;

    /* JADX INFO: renamed from: ru.noties.jlatexmath.b$a */
    public static class a {

        /* JADX INFO: renamed from: a */
        private final String f59911a;

        /* JADX INFO: renamed from: b */
        private float f59912b;

        /* JADX INFO: renamed from: c */
        private int f59913c = -16777216;

        /* JADX INFO: renamed from: d */
        private int f59914d;

        /* JADX INFO: renamed from: e */
        private Drawable f59915e;

        /* JADX INFO: renamed from: f */
        private C10115h f59916f;

        public a(String str) {
            this.f59911a = str;
        }

        /* JADX INFO: renamed from: g */
        public a m56407g(Drawable drawable) {
            this.f59915e = drawable;
            return this;
        }

        /* JADX INFO: renamed from: h */
        public C10106b m56408h() {
            return new C10106b(this);
        }

        /* JADX INFO: renamed from: i */
        public a m56409i(int i2) {
            this.f59913c = i2;
            return this;
        }

        @Deprecated
        /* JADX INFO: renamed from: j */
        public a m56410j(boolean z) {
            return this;
        }

        /* JADX INFO: renamed from: k */
        public a m56411k(float f2) {
            this.f59912b = f2;
            return this;
        }
    }

    C10106b(a aVar) {
        C9753l3 c9753l3M53572a = new C9743j3(aVar.f59911a).new b().m53573b(new C10110c(aVar.f59913c)).m53574c(aVar.f59912b).m53575d(0).m53572a();
        this.f59905a = c9753l3M53572a;
        if (aVar.f59916f != null) {
            c9753l3M53572a.m53589e(aVar.f59916f);
        }
        this.f59906b = aVar.f59914d;
        this.f59907c = aVar.f59915e;
        this.f59908d = new C10108a();
        int iM53586b = c9753l3M53572a.m53586b();
        this.f59909e = iM53586b;
        int iM53585a = c9753l3M53572a.m53585a();
        this.f59910f = iM53585a;
        setBounds(0, 0, iM53586b, iM53585a);
    }

    /* JADX INFO: renamed from: a */
    public static a m56400a(String str) {
        return new a(str);
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        int i2;
        Rect bounds = getBounds();
        int iSave = canvas.save();
        try {
            Drawable drawable = this.f59907c;
            if (drawable != null) {
                drawable.draw(canvas);
            }
            int iWidth = bounds.width();
            int iHeight = bounds.height();
            int i3 = this.f59909e;
            float fMin = (i3 > iWidth || this.f59910f > iHeight) ? Math.min(iWidth / i3, iHeight / this.f59910f) : 1.0f;
            int i4 = (int) ((this.f59909e * fMin) + 0.5f);
            int i5 = (iHeight - ((int) ((this.f59910f * fMin) + 0.5f))) / 2;
            int i6 = this.f59906b;
            if (i6 == 1) {
                i2 = (iWidth - i4) / 2;
            } else {
                i2 = i6 == 2 ? iWidth - i4 : 0;
            }
            if (i5 != 0 || i2 != 0) {
                canvas.translate(i2, i5);
            }
            if (Float.compare(fMin, 1.0f) != 0) {
                canvas.scale(fMin, fMin);
            }
            this.f59908d.m56434w(canvas);
            this.f59905a.m53587c(null, this.f59908d, 0, 0);
        } finally {
            canvas.restoreToCount(iSave);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicHeight() {
        return this.f59910f;
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicWidth() {
        return this.f59909e;
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        return -1;
    }

    @Override // android.graphics.drawable.Drawable
    protected void onBoundsChange(Rect rect) {
        super.onBoundsChange(rect);
        Drawable drawable = this.f59907c;
        if (drawable != null) {
            drawable.setBounds(rect);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i2) {
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
    }
}
