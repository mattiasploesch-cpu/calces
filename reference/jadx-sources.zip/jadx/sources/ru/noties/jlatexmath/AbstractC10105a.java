package ru.noties.jlatexmath;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Typeface;
import java.io.IOException;
import java.io.InputStream;

/* JADX INFO: renamed from: ru.noties.jlatexmath.a */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC10105a {

    /* JADX INFO: renamed from: a */
    @SuppressLint({"StaticFieldLeak"})
    private static Context f59904a;

    /* JADX INFO: renamed from: a */
    private static Context m56396a() {
        Context context = f59904a;
        if (context != null) {
            return context;
        }
        throw new NullPointerException("Please call `#init(Context)` method to initialize jLatexMath");
    }

    /* JADX INFO: renamed from: b */
    public static InputStream m56397b(String str) {
        try {
            return m56396a().getAssets().open("org/scilab/forge/jlatexmath/" + str);
        } catch (IOException e2) {
            throw new RuntimeException(e2);
        }
    }

    /* JADX INFO: renamed from: c */
    public static void m56398c(Context context) {
        f59904a = context.getApplicationContext();
    }

    /* JADX INFO: renamed from: d */
    public static Typeface m56399d(String str) {
        return Typeface.createFromAsset(m56396a().getAssets(), "org/scilab/forge/jlatexmath/" + str);
    }
}
