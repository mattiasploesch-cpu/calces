package ru.noties.jlatexmath.p800c;

import advanced.scientific.calculator.calc991.plus.C0001R;

/* JADX INFO: renamed from: ru.noties.jlatexmath.c.a */
/* JADX INFO: loaded from: classes2.dex */
public final class C10107a {

    /* JADX INFO: renamed from: a */
    public static final int[] f59917a = {C0001R.attr.jlmv_alignHorizontal, C0001R.attr.jlmv_alignVertical, C0001R.attr.jlmv_background, C0001R.attr.jlmv_latex, C0001R.attr.jlmv_textColor, C0001R.attr.jlmv_textSize};

    /* JADX INFO: renamed from: b */
    public static final int f59918b = 0;

    /* JADX INFO: renamed from: c */
    public static final int f59919c = 1;

    /* JADX INFO: renamed from: d */
    public static final int f59920d = 2;

    /* JADX INFO: renamed from: e */
    public static final int f59921e = 4;

    /* JADX INFO: renamed from: f */
    public static final int f59922f = 5;
}
